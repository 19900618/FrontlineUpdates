import type { NextRequest } from "next/server";
import { getTerritoryClients, getTerritoryMonths, type LocDim } from "@/lib/data";
import { auth, authConfigured } from "@/auth";

/**
 * GET /api/territory?country=Rwanda&dim=territory&name=Bugesera%20A
 * dim = 'territory' (Rwanda) or 'branch' (Uganda/Kenya).
 * Non-terminal clients for one country+location + this/last-month completions.
 * Auth-gated (returns PII).
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const country = req.nextUrl.searchParams.get("country") ?? "Rwanda";
  const dim: LocDim = req.nextUrl.searchParams.get("dim") === "branch" ? "branch" : "territory";
  const name = req.nextUrl.searchParams.get("name");
  if (!name) return Response.json({ clients: [], completedThisMonth: 0, completedLastMonth: 0 });

  try {
    const [clients, months] = await Promise.all([
      getTerritoryClients(country, dim, name),
      getTerritoryMonths(country, dim, name),
    ]);
    return Response.json({
      clients,
      completedThisMonth: months.this_month,
      completedLastMonth: months.last_month,
    });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
