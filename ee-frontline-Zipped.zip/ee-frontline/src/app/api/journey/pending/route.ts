import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getPendingTasks } from "@/lib/journey-pending";
import { getTerritoryBuilds } from "@/lib/territory";
import { PENDING_CARDS } from "@/lib/format";
import { COUNTRIES, type CountryName } from "@/lib/workspaces";

export const dynamic = "force-dynamic";

/**
 * GET /api/journey/pending?country=Rwanda&card=P5&role=tl
 * The records behind one pending card on the journey board, for one role:
 * `tl` is the houses waiting for the step (the Territory Leads rule), `qa` is
 * the QA tasks still open for it (the Individual QA rule). Auth-gated: these
 * carry customer and staff names. The country, the card and the role come
 * from fixed lists, so none can reach a query as free text.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const p = req.nextUrl.searchParams;
  const names = COUNTRIES.map((c) => c.name);
  const country = p.get("country") as CountryName | null;
  if (!country || !names.includes(country)) {
    return Response.json({ error: "country must be one of " + names.join(", ") }, { status: 400 });
  }
  const card = PENDING_CARDS.find((c) => c.key === p.get("card"));
  if (!card) {
    return Response.json({ error: "card must be one of " + PENDING_CARDS.map((c) => c.key).join(", ") }, { status: 400 });
  }
  const role = p.get("role");
  if (role !== "tl" && role !== "qa") {
    return Response.json({ error: "role must be tl or qa" }, { status: 400 });
  }
  try {
    if (role === "tl") {
      const lists = await Promise.all(card.reasons.map((reason) => getTerritoryBuilds(country, "", "pending", 3000, reason)));
      // The card counts only houses with a territory (Rwanda) or branch, so the list does too.
      return Response.json({ rows: lists.flat().filter((r) => r.territory !== "") });
    }
    if (!card.qaSubject) return Response.json({ rows: [] });
    // All three task types at once: the drawer filters by type, starting on this card's.
    return Response.json({ rows: await getPendingTasks(country) });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
