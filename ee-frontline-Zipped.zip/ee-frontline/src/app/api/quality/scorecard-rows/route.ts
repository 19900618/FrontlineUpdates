import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getScorecardRows, type ScorecardDim, type Unit } from "@/lib/quality-scorecards";
import { COUNTRIES, type CountryName } from "@/lib/workspaces";

export const dynamic = "force-dynamic";

const DIMS: ScorecardDim[] = ["final-eval", "matching", "cases"];
const isDay = (v: string | null): v is string => !!v && /^\d{4}-\d{2}-\d{2}$/.test(v);

/**
 * GET /api/quality/scorecard-rows?country=Rwanda&from=2026-09-01&to=2026-09-30&dim=final-eval
 * The records behind one scorecard, which are exactly what that card counts and
 * nothing wider. Auth-gated: these carry customer names. The country and the cut
 * come from fixed lists and the dates must be dates, so neither can reach the
 * query as free text.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const p = req.nextUrl.searchParams;
  const names = COUNTRIES.map((c) => c.name);
  const country = p.get("country") as CountryName | null;
  if (!country || !names.includes(country)) {
    return Response.json({ error: "country must be one of " + names.join(", ") }, { status: 400 });
  }
  const dim = String(p.get("dim") ?? "") as ScorecardDim;
  if (!DIMS.includes(dim)) {
    return Response.json({ error: "dim must be one of " + DIMS.join(", ") }, { status: 400 });
  }
  const from = p.get("from"), to = p.get("to");
  if (!isDay(from) || !isDay(to) || from > to) {
    return Response.json({ error: "from and to must be dates, from on or before to" }, { status: 400 });
  }
  try {
    const branch = p.get("branch"), territory = p.get("territory");
    const unit: Unit = territory ? { level: "territory", name: territory }
      : branch ? { level: "branch", name: branch } : null;
    const rows = await getScorecardRows(country, from, to, dim, 300, unit);
    return Response.json({ rows });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
