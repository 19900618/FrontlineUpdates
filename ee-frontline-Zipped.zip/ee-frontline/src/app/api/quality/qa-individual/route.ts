import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getQaTasks, getQaOfficerEvals } from "@/lib/quality-individual";
import { QA_STAGES } from "@/lib/quality-stages";
import { COUNTRIES, type CountryName } from "@/lib/workspaces";

export const dynamic = "force-dynamic";

const isDay = (v: string | null): v is string => !!v && /^\d{4}-\d{2}-\d{2}$/.test(v);
/** Salesforce ids are alphanumeric; an empty one means the unassigned pile. */
const isId = (v: string): boolean => v === "" || /^[A-Za-z0-9]{15,20}$/.test(v);

/**
 * GET /api/quality/qa-individual?country=Rwanda&what=evals&officerId=…&from=…&to=…&stage=Screed
 * The records behind one QA officer's figures: what they evaluated, or what is
 * still waiting on them. Auth-gated: these carry customer and staff names.
 * Country and stage come from fixed lists and the officer id must look like an
 * id, so none of them can reach the query as free text.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const p = req.nextUrl.searchParams;
  const names = COUNTRIES.map((c) => c.name);
  const country = p.get("country") as CountryName | null;
  if (!country || !names.includes(country)) {
    return Response.json({ error: "country must be one of " + names.join(", ") }, { status: 400 });
  }
  const what = p.get("what");
  if (what !== "evals" && what !== "tasks") {
    return Response.json({ error: "what must be evals or tasks" }, { status: 400 });
  }
  const officerId = String(p.get("officerId") ?? "");
  if (!isId(officerId)) {
    return Response.json({ error: "officerId is not an id" }, { status: 400 });
  }
  const from = p.get("from"), to = p.get("to");
  if (!isDay(to) || (what === "evals" && (!isDay(from) || from > to))) {
    return Response.json({ error: "from and to must be dates, from on or before to" }, { status: 400 });
  }
  const stage = String(p.get("stage") ?? "");
  if (stage !== "" && !(QA_STAGES as readonly string[]).includes(stage)) {
    return Response.json({ error: "stage must be one of " + QA_STAGES.join(", ") }, { status: 400 });
  }

  try {
    const rows = what === "tasks"
      ? await getQaTasks(country, to, officerId, 300)
      : await getQaOfficerEvals(country, from as string, to, officerId, stage, 300);
    return Response.json({ rows });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
