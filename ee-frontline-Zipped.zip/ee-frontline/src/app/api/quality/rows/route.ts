import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getSentBack } from "@/lib/quality";
import { COUNTRIES, type CountryName } from "@/lib/workspaces";

export const dynamic = "force-dynamic";

const DIMS = ["unit", "branch"] as const;
const isDay = (v: string | null): v is string => !!v && /^\d{4}-\d{2}-\d{2}$/.test(v);

/**
 * GET /api/quality/rows?country=Rwanda&from=2026-09-01&to=2026-09-30&dim=unit&name=Kamonyi%20A
 * The houses one territory or branch still owes rework on: QA sent them back and
 * nothing has cleared them since. Auth-gated: these carry customer, CSO and mason
 * names. The country and the level come from fixed lists and the dates must be
 * dates, so neither can reach the query as free text.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const p = req.nextUrl.searchParams;
  const names = COUNTRIES.map((c) => c.name);
  const country = p.get("country") as CountryName | null;
  if (!country || !names.includes(country)) {
    return Response.json({ error: "country must be one of " + names.join(", ") }, { status: 400 });
  }
  const dim = String(p.get("dim") ?? "") as (typeof DIMS)[number];
  if (!DIMS.includes(dim)) {
    return Response.json({ error: "dim must be one of " + DIMS.join(", ") }, { status: 400 });
  }
  const from = p.get("from"), to = p.get("to");
  if (!isDay(from) || !isDay(to) || from > to) {
    return Response.json({ error: "from and to must be dates, from on or before to" }, { status: 400 });
  }
  const name = String(p.get("name") ?? "");
  if (!name) {
    return Response.json({ error: "name is required" }, { status: 400 });
  }
  try {
    const rows = await getSentBack(country, from, to, dim, name, 300);
    return Response.json({ rows });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
