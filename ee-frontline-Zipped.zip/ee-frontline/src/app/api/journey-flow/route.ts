import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getFlowSummary } from "@/lib/journey-flow";
import { parseFlowQuery, todayIn } from "@/lib/journey-flow-shared";

/**
 * GET /api/journey-flow?country=Rwanda&loc=&product=all&cohort=2026&gran=week&start=2026-09-07&end=2026-09-13
 * Moves per step and route, customers waiting at each step, and the trend. Auth-gated.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const q = parseFlowQuery(req.nextUrl.searchParams);
  if (!q) return Response.json({ error: "bad query" }, { status: 400 });
  try {
    return Response.json(await getFlowSummary(q, todayIn("Africa/Kigali")));
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
