import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getFlowRows } from "@/lib/journey-flow";
import { parseFlowQuery } from "@/lib/journey-flow-shared";

const TO_KEYS = [0, 1, 2, 3, 4, 5, 6, 9]; // 0 = every step
const FROM_KEYS = [-1, 0, 1, 2, 3, 4, 5, 6]; // -1 = every route

/**
 * GET /api/journey-flow/rows?<same filters>&to=2&from=-1
 * The customers who moved in the window. Auth-gated (returns names and phone numbers).
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const sp = req.nextUrl.searchParams;
  const q = parseFlowQuery(sp);
  const to = Number(sp.get("to") ?? 0);
  const from = Number(sp.get("from") ?? -1);
  if (!q || !TO_KEYS.includes(to) || !FROM_KEYS.includes(from)) {
    return Response.json({ error: "bad query" }, { status: 400 });
  }
  try {
    return Response.json(await getFlowRows(q, to, from));
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
