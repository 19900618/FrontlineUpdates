import type { NextRequest } from "next/server";
import { getMasonRoster } from "@/lib/capacity";
import { auth, authConfigured } from "@/auth";

/**
 * GET /api/capacity/roster?level=territory&name=Nyamasheke%20A&weekEnd=2026-09-07
 * Mason x week rows for one territory, district or branch, for the weeks up to
 * weekEnd. Fetched on demand when a deep dive opens, so the page never ships
 * every mason in the country. Auth-gated: mason names are staff data.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const level = req.nextUrl.searchParams.get("level");
  const name = req.nextUrl.searchParams.get("name");
  const weekEnd = req.nextUrl.searchParams.get("weekEnd");
  if ((level !== "territory" && level !== "district" && level !== "branch") || !name || !weekEnd || !/^\d{4}-\d{2}-\d{2}$/.test(weekEnd)) {
    return Response.json({ error: "level (territory, district or branch), name and weekEnd (YYYY-MM-DD) are required" }, { status: 400 });
  }
  try {
    const rows = await getMasonRoster(level, name, weekEnd);
    return Response.json({ rows });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
