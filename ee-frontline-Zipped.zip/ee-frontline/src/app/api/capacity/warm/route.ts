import type { NextRequest } from "next/server";
import {
  capacityComputesInFlight, capacityMonths, capacityTier, getCapacityData, watchCapacityComputes,
  type CapacityCompute, type CapacityTier,
} from "@/lib/capacity";
import { CAPACITY_COUNTRIES, type CapacityCountry } from "@/lib/capacity-ui";
import { getWorkspaceData } from "@/lib/workspace";
import { getCeoData } from "@/lib/ceo";
import { ctsYear, getCtsData } from "@/lib/cts";
import { defaultPeriod, periodInfo } from "@/lib/period";

export const dynamic = "force-dynamic";
// An empty cache is every country and month, about 12 s each, four at a time.
export const maxDuration = 300;
const CONCURRENCY = 4;
const RECENT_WS_MONTHS = 3;

type Outcome = "skipped" | "refreshed" | "failed";
type Report = {
  country: CapacityCountry; month: string; tier: CapacityTier; outcome: Outcome; ms: number;
  rows?: number; dataAsAt?: string; error?: string;
};

/**
 * GET /api/capacity/warm, called by the Vercel cron in vercel.json every 25
 * minutes with `Authorization: Bearer $CRON_SECRET`. It asks for the same
 * cached data the page reads, for every country and every month the page
 * offers, so no visitor is the first to load a month and wait ten seconds
 * for the capacity function.
 *
 * It never runs a query of its own. `getCapacityData` is the page's cache
 * entry: a fresh entry returns at once with no query ("skipped"), a stale or
 * missing one computes ("refreshed"), and the two tiers decide what fresh
 * means: 15 minutes for the last three months, a day for the rest. Four
 * months compute at a time. A stale entry returns before its refresh has
 * finished, so the worker waits for that refresh before taking the next
 * month; that is what keeps the count at four and the report honest. One
 * month failing does not stop the others.
 */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return Response.json({ error: "CRON_SECRET is not set" }, { status: 503 });
  if (req.headers.get("authorization") !== `Bearer ${secret}`) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }

  // Newest first, so the months people open most are warm soonest.
  const months = capacityMonths().reverse();
  const queue = CAPACITY_COUNTRIES.flatMap((country) => months.map((month) => ({ country, month })));
  const total = queue.length;

  const computes = new Map<string, CapacityCompute>();
  let maxConcurrency = 0;
  const unwatch = watchCapacityComputes((c) => {
    computes.set(`${c.country}|${c.month}`, c);
    maxConcurrency = Math.max(maxConcurrency, capacityComputesInFlight());
  });

  const started = Date.now();
  const reports: Report[] = [];
  async function worker() {
    for (let next = queue.shift(); next; next = queue.shift()) {
      const { country, month } = next;
      const key = `${country}|${month}`;
      const tier = capacityTier(month);
      const t0 = Date.now();
      try {
        const { rows, builtAt } = await getCapacityData(country, month);
        const compute = computes.get(key);
        if (compute) await compute.done;
        reports.push({
          country, month, tier, ms: Date.now() - t0, rows: rows.length, dataAsAt: builtAt,
          outcome: compute ? (compute.error ? "failed" : "refreshed") : "skipped",
          ...(compute?.error ? { error: compute.error } : {}),
        });
      } catch (err) {
        reports.push({ country, month, tier, outcome: "failed", ms: Date.now() - t0, error: err instanceof Error ? err.message : String(err) });
      }
    }
  }
  try {
    await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  } finally {
    unwatch();
  }

  // The country workspaces read the period function for the current month
  // (January to date) and the two months before it. Same cache entries the
  // pages read; a fresh one costs nothing.
  const wsMonths = capacityMonths().slice(-RECENT_WS_MONTHS).reverse();
  const workspace: { country: CapacityCountry; month: string; ms: number; outcome: "ok" | "failed"; error?: string }[] = [];
  await Promise.all(CAPACITY_COUNTRIES.map(async (country) => {
    for (const month of wsMonths) {
      const t0 = Date.now();
      const info = periodInfo({ ...defaultPeriod(), month, weeks: [1] });
      try {
        await getWorkspaceData(country, info.fetchMonth, info.fetchFrom);
        workspace.push({ country, month, ms: Date.now() - t0, outcome: "ok" });
      } catch (err) {
        workspace.push({ country, month, ms: Date.now() - t0, outcome: "failed", error: err instanceof Error ? err.message : String(err) });
      }
    }
  }));

  // The CEO dashboard reads the QuickBooks view, 20 to 30 seconds cold, so
  // the current year is kept warm too. Same cache entry the page reads.
  const ceoYear = new Date().getUTCFullYear();
  const ceoT0 = Date.now();
  const ceo: { year: number; ms: number; outcome: "ok" | "failed"; error?: string } = await getCeoData(ceoYear)
    .then(() => ({ year: ceoYear, ms: Date.now() - ceoT0, outcome: "ok" as const }))
    .catch((err: unknown) => ({ year: ceoYear, ms: Date.now() - ceoT0, outcome: "failed" as const, error: err instanceof Error ? err.message : String(err) }));

  // The Cost to serve page reads both QuickBooks views, about 30 seconds each,
  // for all three countries in one entry; kept warm the same way.
  const ctsT0 = Date.now();
  const cts: { year: number; ms: number; outcome: "ok" | "failed"; error?: string } = await getCtsData(ctsYear())
    .then((d) => ({ year: d.year, ms: Date.now() - ctsT0, outcome: "ok" as const }))
    .catch((err: unknown) => ({ year: ctsYear(), ms: Date.now() - ctsT0, outcome: "failed" as const, error: err instanceof Error ? err.message : String(err) }));

  const summary = { total, skipped: 0, refreshed: 0, failed: 0 };
  for (const r of reports) summary[r.outcome] += 1;
  const order = (r: Report) => `${CAPACITY_COUNTRIES.indexOf(r.country)}|${r.month}`;
  reports.sort((a, b) => order(a).localeCompare(order(b)));
  return Response.json(
    { months, summary, maxConcurrency, concurrencyLimit: CONCURRENCY, totalMs: Date.now() - started, combos: reports, workspace, ceo, cts },
    { status: summary.failed || workspace.some((w) => w.outcome === "failed") || ceo.outcome === "failed" || cts.outcome === "failed" ? 500 : 200 },
  );
}
