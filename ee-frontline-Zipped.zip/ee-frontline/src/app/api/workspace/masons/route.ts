import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getMasons } from "@/lib/workspace";
import { CAPACITY_COUNTRIES, type CapacityCountry } from "@/lib/capacity-ui";

const LEVELS = ["territory", "district", "branch", "country"] as const;
const DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * GET /api/workspace/masons?country=Rwanda&level=territory&name=Bugesera%20A&start=2026-09-01&end=2026-09-30&weeks=1234
 * One row per mason for a place and period. Auth-gated: mason names are staff data.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) return Response.json({ error: "unauthorized" }, { status: 401 });
  const p = req.nextUrl.searchParams;
  const country = p.get("country") as CapacityCountry;
  const level = p.get("level") as (typeof LEVELS)[number];
  const name = p.get("name") ?? "";
  const start = p.get("start") ?? "";
  const end = p.get("end") ?? "";
  const weeks = p.get("weeks") ?? "";
  if (!CAPACITY_COUNTRIES.includes(country) || !LEVELS.includes(level) || !name || !DATE.test(start) || !DATE.test(end) || !/^(Q|[1-4]{1,4})$/.test(weeks)) {
    return Response.json({ error: "bad query" }, { status: 400 });
  }
  try {
    return Response.json({ rows: await getMasons(country, level, name, start, end, weeks) });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
