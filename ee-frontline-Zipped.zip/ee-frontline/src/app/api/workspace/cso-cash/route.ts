import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getCsoCash } from "@/lib/workspace";
import { CAPACITY_COUNTRIES, type CapacityCountry } from "@/lib/capacity-ui";

const DATE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * GET /api/workspace/cso-cash?country=Rwanda&day=2026-09-22&weekStart=2026-09-22&weekEnd=2026-09-30&start=2026-09-01&end=2026-09-30
 * Money per CSO for the chosen day, its calendar week and the period. Auth-gated.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) return Response.json({ error: "unauthorized" }, { status: 401 });
  const p = req.nextUrl.searchParams;
  const country = p.get("country") as CapacityCountry;
  const dates = ["day", "weekStart", "weekEnd", "start", "end"].map((k) => p.get(k) ?? "");
  if (!CAPACITY_COUNTRIES.includes(country) || dates.some((d) => !DATE.test(d))) {
    return Response.json({ error: "bad query" }, { status: 400 });
  }
  const [day, weekStart, weekEnd, start, end] = dates;
  try {
    return Response.json({ rows: await getCsoCash(country, day, weekStart, weekEnd, start, end) });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
