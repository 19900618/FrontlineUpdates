import type { NextRequest } from "next/server";
import { auth, authConfigured } from "@/auth";
import { getTerritoryBuilds, type BuildFilter } from "@/lib/territory";
import { COUNTRIES, type CountryName } from "@/lib/workspaces";

export const dynamic = "force-dynamic";

const FILTERS: BuildFilter[] = ["all", "not-started", "in-progress", "pending", "late", "pending-tl", "pending-stock"];

/**
 * GET /api/territory-builds?country=Rwanda&territory=Ngoma%20A&filter=late
 * &reason=Waiting%20for%20screed%20evaluation narrows the pending slice to one
 * waiting state.
 * The builds behind one territory's figures. Auth-gated: these carry customer,
 * CSO and mason names. The country and the slice come from fixed lists, and the
 * territory is matched against a column rather than interpolated, so neither can
 * reach the query as free text.
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const p = req.nextUrl.searchParams;
  const names = COUNTRIES.map((c) => c.name);
  const country = p.get("country") as CountryName | null;
  if (!country || !names.includes(country)) {
    return Response.json({ error: "country must be one of " + names.join(", ") }, { status: 400 });
  }
  const filter = String(p.get("filter") ?? "all") as BuildFilter;
  if (!FILTERS.includes(filter)) {
    return Response.json({ error: "filter must be one of " + FILTERS.join(", ") }, { status: 400 });
  }
  const territory = String(p.get("territory") ?? "");
  if (!territory) {
    return Response.json({ error: "territory is required" }, { status: 400 });
  }
  try {
    const rows = await getTerritoryBuilds(country, territory, filter, 300, p.get("reason") ?? "");
    return Response.json({ rows });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
