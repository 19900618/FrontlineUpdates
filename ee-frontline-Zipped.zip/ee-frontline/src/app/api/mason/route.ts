import type { NextRequest } from "next/server";
import { getMasonDataset } from "@/lib/mason/data";
import { auth, authConfigured } from "@/auth";

/** GET /api/mason?district=Kamonyi — the mason dataset for a district. Auth-gated (PII). */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const country = req.nextUrl.searchParams.get("country") ?? "Rwanda";
  const unit = req.nextUrl.searchParams.get("unit") ?? "";
  const sub = req.nextUrl.searchParams.get("sub") ?? "";
  try {
    const dataset = await getMasonDataset(country, unit, sub);
    return Response.json({ dataset });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
