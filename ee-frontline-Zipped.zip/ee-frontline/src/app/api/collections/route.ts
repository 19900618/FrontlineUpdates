import type { NextRequest } from "next/server";
import { getCollectionsBacklog } from "@/lib/collections";
import { auth, authConfigured } from "@/auth";

/**
 * GET /api/collections?country=Rwanda
 * Backlog rows (signed, not yet collected) for one country, closest-to-milestone
 * first. Auth-gated (returns customer PII + phone numbers).
 */
export async function GET(req: NextRequest) {
  if (authConfigured && !(await auth())) {
    return Response.json({ error: "unauthorized" }, { status: 401 });
  }
  const country = req.nextUrl.searchParams.get("country") ?? "Rwanda";
  try {
    const rows = await getCollectionsBacklog(country);
    return Response.json({ rows });
  } catch (err) {
    return Response.json({ error: err instanceof Error ? err.message : String(err) }, { status: 500 });
  }
}
