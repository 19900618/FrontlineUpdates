import { signIn } from "@/auth";
import Logo from "@/components/Logo";

export default function SignIn() {
  return (
    <main className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center p-8">
      <div
        className="w-full rounded-lg border p-8 text-center"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        <div className="mb-4 flex justify-center">
          <Logo height={40} />
        </div>
        <h1 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>
          Frontline Toolkit
        </h1>
        <p className="mt-2 text-sm" style={{ color: "var(--text-secondary)" }}>
          Sign in with your <b>@earthenable.org</b> Google account to continue.
        </p>
        <form
          action={async () => {
            "use server";
            await signIn("google", { redirectTo: "/" });
          }}
          className="mt-6"
        >
          <button
            type="submit"
            className="w-full rounded-md border px-4 py-2 text-sm font-medium"
            style={{ background: "var(--accent-strong)", color: "#ffffff", borderColor: "var(--accent-strong)" }}
          >
            Sign in with Google
          </button>
        </form>
      </div>
    </main>
  );
}
