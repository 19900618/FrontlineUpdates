import { auth, authConfigured } from "@/auth";
import Logo from "@/components/Logo";
import WorkspaceCard from "@/components/WorkspaceCard";
import { CEO, COUNTRIES, TOOLKIT } from "@/lib/workspaces";

/**
 * Home page after sign-in: pick a workspace. Three country workspaces for the new
 * dashboards, and the frontline toolkit, which keeps every page the app had before.
 */
export default async function Home() {
  const userEmail = authConfigured ? ((await auth())?.user?.email ?? null) : null;

  return (
    <div className="flex min-h-[100dvh] flex-col">
      <header className="flex items-center justify-between gap-4 border-b px-4 py-3 sm:px-8"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <Logo height={30} />
        {userEmail && (
          <div className="flex min-w-0 items-center gap-3 text-xs">
            <span className="hidden truncate sm:inline" style={{ color: "var(--text-secondary)" }}>{userEmail}</span>
            {/* Auth.js route, not a page: a plain link is right, so the page-link rule is off here. */}
            {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
            <a href="/api/auth/signout" style={{ color: "var(--text-muted)" }}>Sign out</a>
          </div>
        )}
      </header>

      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-10 sm:px-8 sm:py-14">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl" style={{ color: "var(--text-primary)" }}>
          Where are you working today?
        </h1>
        <p className="mt-2 text-sm" style={{ color: "var(--text-secondary)" }}>
          Pick a country, open the Classic Frontline Toolkit for the dashboards you already use, or the CEO dashboard for all three countries at once.
        </p>

        <div className="mt-8 grid gap-5 sm:grid-cols-2">
          {COUNTRIES.map((c) => (
            <WorkspaceCard key={c.slug} href={`/${c.slug}`} title={c.name} code={c.code}
              kicker="Country workspace" blurb={`Capacity planning and operations for ${c.name}.`}
              from={c.from} to={c.to} glow={c.glow} flag={c.code} />
          ))}
          <WorkspaceCard href={TOOLKIT.href} title={TOOLKIT.name} code={TOOLKIT.code}
            kicker="All countries"
            blurb="Journey board, CSO performance, collections and capacity planning, as they are today."
            from={TOOLKIT.from} to={TOOLKIT.to} glow={TOOLKIT.glow} />
          {/* Cross-country, so it takes the full row rather than sitting under one country. */}
          <div className="grid sm:col-span-2">
            <WorkspaceCard href={CEO.href} title={CEO.name} code={CEO.code}
              kicker="All countries"
              blurb="SQM-E built, mason earnings and cost to serve, actual against budget, for Rwanda, Uganda and Kenya."
              from={CEO.from} to={CEO.to} glow={CEO.glow} />
          </div>
        </div>
      </main>
    </div>
  );
}
