import { redirect } from "next/navigation";
import { auth, authConfigured } from "@/auth";

/**
 * The login gate for everything past the sign-in page: the home page, the country
 * workspaces and the toolkit. Protecting here means every current and future page
 * under (app) is gated at once. The gate is opt-in, off locally until Google OAuth
 * env vars are set.
 */
// Always render per request so the session check runs; never prerender a gated page.
export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  if (authConfigured) {
    const session = await auth();
    if (!session) redirect("/signin");
  }
  return <>{children}</>;
}
