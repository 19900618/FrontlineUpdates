import { auth, authConfigured } from "@/auth";
import Sidebar from "@/components/Sidebar";

/**
 * Shell for the toolkit pages (everything the app had before the country workspaces):
 * persistent sidebar nav. The login gate sits one level up, in (app)/layout.tsx.
 */
export default async function ToolkitLayout({ children }: { children: React.ReactNode }) {
  const userEmail = authConfigured ? ((await auth())?.user?.email ?? null) : null;

  return (
    <div className="flex min-h-[100dvh] flex-col md:flex-row">
      <Sidebar userEmail={userEmail} />
      <main className="min-w-0 flex-1">{children}</main>
    </div>
  );
}
