import { getCollectionsSummary } from "@/lib/collections";
import CollectionsBoard from "@/components/CollectionsBoard";

export const dynamic = "force-dynamic";

export default async function CollectionsPage() {
  const summary = await getCollectionsSummary();
  return <CollectionsBoard summary={summary} />;
}
