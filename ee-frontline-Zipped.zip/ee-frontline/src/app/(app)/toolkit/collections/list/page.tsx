import CollectionsList, { type ListInitial } from "@/components/CollectionsList";

export const dynamic = "force-dynamic";

export default async function CollectionsListPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;
  const product = sp.product === "Floor" || sp.product === "Plaster" ? sp.product : "All";
  const seg = sp.seg === "active" || sp.seg === "stalled" || sp.seg === "never" ? sp.seg : "All";
  const initial: ListInitial = {
    country: sp.country ?? "Rwanda",
    product,
    seg,
    from: sp.from ?? "2026-01-01",
    to: sp.to ?? "",
    within: Number(sp.within) > 0 ? Number(sp.within) : 0, // 0 = no distance cap
    loc: sp.loc ?? "All",
  };
  return <CollectionsList initial={initial} />;
}
