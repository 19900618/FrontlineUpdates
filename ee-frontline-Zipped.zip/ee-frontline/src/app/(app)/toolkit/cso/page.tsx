import { getCsoTerritoryMonths, getTerritoryCapacity, getCsoHeadcount } from "@/lib/cso";
import CsoOverview from "@/components/CsoOverview";

export const dynamic = "force-dynamic";

export default async function CsoPage() {
  const [rows, capacity, headcount] = await Promise.all([
    getCsoTerritoryMonths(),
    getTerritoryCapacity(),
    getCsoHeadcount(),
  ]);
  return <CsoOverview rows={rows} capacity={capacity} headcount={headcount} />;
}
