import { getCsoMonths, getCsoPending } from "@/lib/cso";
import CsoIndividual from "@/components/CsoIndividual";

export const dynamic = "force-dynamic";

export default async function CsoIndividualPage() {
  const [rows, pending] = await Promise.all([getCsoMonths(), getCsoPending()]);
  return <CsoIndividual rows={rows} pending={pending} />;
}
