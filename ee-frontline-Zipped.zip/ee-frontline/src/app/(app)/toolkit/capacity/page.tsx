import { getCapacityCalendar, getCapacityData, defaultCapacityMonth } from "@/lib/capacity";
import { CAPACITY_COUNTRIES, type CapacityCountry } from "@/lib/capacity-ui";
import CapacityBoard, { type OpenKey } from "@/components/CapacityBoard";

export const dynamic = "force-dynamic";

const first = (v: string | string[] | undefined): string | undefined => (Array.isArray(v) ? v[0] : v);

/**
 * Country and month live in the URL, not in board state, because one month of
 * the weekly view is about a thousand rows for Rwanda (66 names x 15 week
 * sets) and a year of it, or every country at once, is too heavy for a
 * phone. The board owns every other filter. The key resets the week
 * selection when either changes. `territory`, `district` or `branch` opens a
 * deep dive straight away, so a link can point at one place.
 */
export default async function CapacityPage({
  searchParams,
}: {
  searchParams: Promise<{
    country?: string | string[];
    month?: string | string[];
    territory?: string | string[];
    district?: string | string[];
    branch?: string | string[];
  }>;
}) {
  const params = await searchParams;
  const wantedCountry = first(params.country);
  const country: CapacityCountry = CAPACITY_COUNTRIES.includes(wantedCountry as CapacityCountry)
    ? (wantedCountry as CapacityCountry)
    : CAPACITY_COUNTRIES[0];
  const calendar = getCapacityCalendar();
  const wanted = first(params.month);
  const month = wanted && calendar.some((w) => w.month === wanted) ? wanted : defaultCapacityMonth(calendar);
  const { rows, trend, builtAt } = await getCapacityData(country, month);

  const territory = first(params.territory);
  const district = first(params.district);
  const branch = first(params.branch);
  let initialOpen: OpenKey | null = null;
  if (territory && rows.some((r) => r.level === "territory" && r.name === territory)) {
    initialOpen = { level: "territory", name: territory, from: "table" };
  } else if (district && rows.some((r) => r.level === "district" && r.name === district)) {
    initialOpen = { level: "district", name: district, from: "table" };
  } else if (branch && rows.some((r) => r.level === "branch" && r.name === branch)) {
    initialOpen = { level: "branch", name: branch, from: "table" };
  }

  return (
    <CapacityBoard key={`${country}|${month}`} country={country} calendar={calendar} month={month} rows={rows} trend={trend} builtAt={builtAt} initialOpen={initialOpen} />
  );
}
