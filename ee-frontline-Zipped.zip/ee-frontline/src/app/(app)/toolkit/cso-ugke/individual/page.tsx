import { getUgkeCsoMonths, getUgkePending } from "@/lib/cso-ugke";
import UgkeIndividual from "@/components/UgkeIndividual";

export const dynamic = "force-dynamic";

export default async function UgkeCsoIndividualPage() {
  const [rows, pending] = await Promise.all([getUgkeCsoMonths(), getUgkePending()]);
  return <UgkeIndividual rows={rows} pending={pending} />;
}
