import { getUgkeBranchMonths, getUgkeCsoMonths, getUgkePending } from "@/lib/cso-ugke";
import UgkeOverview from "@/components/UgkeOverview";

export const dynamic = "force-dynamic";

export default async function UgkeCsoPage() {
  const [rows, branches, pending] = await Promise.all([getUgkeCsoMonths(), getUgkeBranchMonths(), getUgkePending()]);
  return <UgkeOverview rows={rows} branches={branches} pending={pending} />;
}
