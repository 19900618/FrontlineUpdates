import { getMatrix, getSummary, getLastSync } from "@/lib/data";
import { hasCredentials } from "@/lib/bigquery";
import Dashboard from "@/components/Dashboard";
import { getWaitingByUnit } from "@/lib/territory";
import { COUNTRIES } from "@/lib/workspaces";

// Render on-demand (not at build) — data comes from BigQuery via cached queries.
export const dynamic = "force-dynamic";

// The login gate lives in (app)/layout.tsx, so this page just fetches + renders.
// Matrix (heatmap) + country summary (scorecards) load here; per-territory client
// detail is fetched on demand from /api/territory (cached per territory).
export default async function Page() {
  if (!hasCredentials()) return <SetupNeeded />;

  try {
    // The pending cards read each country's waiting-for rows; the board picks the country on screen.
    const [matrix, summary, syncedMs, ...waitingByCountry] = await Promise.all([
      getMatrix(), getSummary(), getLastSync(), ...COUNTRIES.map((c) => getWaitingByUnit(c.name)),
    ]);
    const waiting = waitingByCountry.flat();
    // Honest freshness = when Salesforce last synced into BigQuery (Fivetran),
    // NOT the render time. This is the true data-as-of.
    let dataAsOf = "sync time unknown";
    if (syncedMs) {
      const asOf = new Date(syncedMs).toLocaleString("en-GB", {
        day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC",
      });
      const lagMin = Math.max(0, Math.round((Date.now() - syncedMs) / 60000));
      const lag = lagMin < 90 ? `${lagMin} min` : `~${Math.round(lagMin / 60)}h`;
      dataAsOf = `Salesforce data synced ${lag} ago (${asOf} UTC) · dashboard cache refreshes every 15 min`;
    }
    return <Dashboard matrix={matrix} summary={summary} waiting={waiting} generatedAt={dataAsOf} />;
  } catch (err) {
    return <QueryError message={err instanceof Error ? err.message : String(err)} />;
  }
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <main className="mx-auto max-w-2xl p-8">
      <div
        className="rounded-lg border p-6"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        {children}
      </div>
    </main>
  );
}

function SetupNeeded() {
  return (
    <Shell>
      <h1 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>
        Add your BigQuery key
      </h1>
      <p className="mt-2 text-sm" style={{ color: "var(--text-secondary)" }}>
        The app is running, but it has no service-account credentials yet, so it
        can&apos;t read BigQuery. To see live data:
      </p>
      <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm" style={{ color: "var(--text-secondary)" }}>
        <li>Follow <code>SETUP.md</code> → &quot;1. BigQuery service account&quot;.</li>
        <li>Save the downloaded JSON as <code>gcp-key.json</code> in the project root.</li>
        <li>Restart <code>npm run dev</code>.</li>
      </ol>
      <p className="mt-3 text-xs" style={{ color: "var(--text-muted)" }}>
        The key file is git-ignored and never leaves your machine.
      </p>
    </Shell>
  );
}

function QueryError({ message }: { message: string }) {
  return (
    <Shell>
      <h1 className="text-lg font-semibold" style={{ color: "var(--critical)" }}>
        Couldn&apos;t query BigQuery
      </h1>
      <p className="mt-2 text-sm" style={{ color: "var(--text-secondary)" }}>
        Credentials were found, but the query failed. Most often this is a missing
        role. The service account needs <b>BigQuery Data Viewer</b> and{" "}
        <b>BigQuery Job User</b> on <code>earth-enable-main</code>.
      </p>
      <pre
        className="mt-3 overflow-x-auto rounded border p-3 text-xs"
        style={{ color: "var(--text-muted)", borderColor: "var(--border)" }}
      >
        {message}
      </pre>
    </Shell>
  );
}
