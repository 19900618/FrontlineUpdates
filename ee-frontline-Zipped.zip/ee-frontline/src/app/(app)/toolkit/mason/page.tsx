import { getMasonDataset } from "@/lib/mason/data";
import MasonBoard from "@/components/MasonBoard";

export const dynamic = "force-dynamic";

export default async function MasonPage() {
  const dataset = await getMasonDataset("Rwanda", "Bugesera", "Bugesera A");
  return <MasonBoard dataset={dataset} />;
}
