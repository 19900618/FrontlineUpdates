import { getLastSync, getMatrix } from "@/lib/data";
import { hasCredentials } from "@/lib/bigquery";
import { getFlowSummary } from "@/lib/journey-flow";
import { defaultWindow, todayIn, type FlowQuery, type FlowSummary } from "@/lib/journey-flow-shared";
import JourneyFlow from "@/components/JourneyFlow";

// Render on demand (not at build): data comes from BigQuery via cached queries.
export const dynamic = "force-dynamic";

const COUNTRIES = ["Rwanda", "Uganda", "Kenya"];

/**
 * Customer journey flow: how many customers moved between journey steps in a chosen
 * day, week, month or date range, and who they were. The first view (Rwanda, last
 * week) is fetched here; every change after that goes through /api/journey-flow.
 */
export default async function Page() {
  if (!hasCredentials()) {
    return <Notice title="Add your BigQuery key" text="The app has no service-account credentials yet, so it can't read BigQuery. See SETUP.md." />;
  }
  const today = todayIn("Africa/Kigali");
  const initialQuery: FlowQuery = {
    country: "Rwanda", dim: "territory", loc: "", product: "all", cohort: "2026", gran: "week",
    ...defaultWindow("week", today),
  };
  const data = await load(initialQuery, today);
  if ("error" in data) return <Notice title="Couldn't query BigQuery" text={data.error} />;
  return (
    <JourneyFlow locations={data.locations} initialQuery={initialQuery} initialSummary={data.summary} today={today} syncNote={data.syncNote} />
  );
}

async function load(q: FlowQuery, today: string): Promise<
  { locations: Record<string, string[]>; summary: FlowSummary; syncNote: string } | { error: string }
> {
  try {
    const [matrix, syncedMs, summary] = await Promise.all([getMatrix(), getLastSync(), getFlowSummary(q, today)]);
    // Territory (Rwanda) or branch (Uganda, Kenya) pickers, from the board's own location list.
    const sets: Record<string, Set<string>> = {};
    for (const r of matrix) {
      if (!COUNTRIES.includes(r.country)) continue;
      const loc = r.country === "Rwanda" ? r.territory : r.branch;
      if (loc !== "Unassigned") (sets[r.country] ??= new Set()).add(loc);
    }
    const locations = Object.fromEntries(Object.entries(sets).map(([c, s]) => [c, [...s].sort()]));
    return { locations, summary, syncNote: syncNoteFor(syncedMs) };
  } catch (err) {
    return { error: err instanceof Error ? err.message : String(err) };
  }
}

/** Honest freshness: when Salesforce last synced into BigQuery, not when the page rendered. */
function syncNoteFor(syncedMs: number | null): string {
  if (!syncedMs) return "Salesforce sync time unknown";
  const asOf = new Date(syncedMs).toLocaleString("en-GB", {
    day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC",
  });
  const lagMin = Math.max(0, Math.round((Date.now() - syncedMs) / 60000));
  const lag = lagMin < 90 ? `${lagMin} min` : `~${Math.round(lagMin / 60)}h`;
  return `Salesforce data synced ${lag} ago (${asOf} UTC) · refreshes every 15 min`;
}

function Notice({ title, text }: { title: string; text: string }) {
  return (
    <main className="mx-auto max-w-2xl p-8">
      <div className="rounded-lg border p-6" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <h1 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>{title}</h1>
        <p className="mt-2 wrap-break-word text-sm" style={{ color: "var(--text-secondary)" }}>{text}</p>
      </div>
    </main>
  );
}
