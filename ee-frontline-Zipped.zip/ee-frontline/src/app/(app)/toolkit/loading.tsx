import Spinner from "@/components/Spinner";

/**
 * Shown while a page fetches its data on the server. Every toolkit page reads
 * BigQuery on demand, which takes a few seconds, so without this the app looks
 * frozen after a click.
 */
export default function Loading() {
  return (
    <div className="flex min-h-[70dvh] flex-col items-center justify-center gap-3 p-8">
      <span style={{ color: "var(--accent-strong)" }}>
        <Spinner size={30} />
      </span>
      <p className="text-center text-sm" style={{ color: "var(--text-muted)" }}>
        Loading the latest data. This takes a few seconds the first time.
      </p>
    </div>
  );
}
