import Spinner from "@/components/Spinner";

/** Shown while the CEO dashboard reads its year on the server. */
export default function Loading() {
  return (
    <div className="flex min-h-[70dvh] flex-col items-center justify-center gap-3 p-8">
      <span style={{ color: "var(--accent-strong)" }}><Spinner size={30} /></span>
      <p className="text-center text-sm font-medium" style={{ color: "var(--text-primary)" }}>Loading the CEO dashboard</p>
      <p className="-mt-2 text-center text-xs" style={{ color: "var(--text-muted)" }}>Bringing together the latest figures for the year.</p>
    </div>
  );
}
