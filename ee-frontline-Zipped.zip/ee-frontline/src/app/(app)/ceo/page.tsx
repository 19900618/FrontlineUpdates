import { auth, authConfigured } from "@/auth";
import CeoDashboard from "@/components/CeoDashboard";
import { ceoYears, getCeoData } from "@/lib/ceo";

/**
 * The CEO dashboard: cross-country, so it sits beside the country workspaces
 * rather than inside one. The year is URL state (`?y=2025`), 2026 by default.
 */
export const dynamic = "force-dynamic";
// A cold year reads the QuickBooks view, which takes 20 to 30 seconds.
export const maxDuration = 120;

export default async function CeoPage(props: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await props.searchParams;
  const years = ceoYears();
  const raw = Array.isArray(sp.y) ? sp.y[0] : sp.y;
  const year = years.includes(Number(raw)) ? Number(raw) : 2026;
  const [data, userEmail] = await Promise.all([
    getCeoData(year),
    authConfigured ? auth().then((s) => s?.user?.email ?? null) : Promise.resolve(null),
  ]);
  return <CeoDashboard data={data} years={years} userEmail={userEmail} />;
}
