import SalesPage from "@/components/ws/SalesPage";
import { getWorkspaceCsos } from "@/lib/workspace";
import { getMatrix, getSummary } from "@/lib/data";
import { getWaitingByUnit } from "@/lib/territory";
import { loadWorkspace, type WsPageProps } from "../workspace-page";

export const dynamic = "force-dynamic";

/**
 * The Customer journey tab is the Classic Journey board, so it reads the
 * board's own cached queries (the matrix and the country summary, every
 * country at once, as /toolkit does) when that tab is open.
 */
export default async function CountrySales(props: WsPageProps) {
  const { country: slug } = await props.params;
  const sp = await props.searchParams;
  const tab = Array.isArray(sp.tab) ? sp.tab[0] : sp.tab;
  const w = await loadWorkspace(slug, sp);
  // The pending cards read the Territory Leads waiting-for rule for this country only.
  const board = tab === "journey"
    ? await Promise.all([getMatrix(), getSummary(), getWaitingByUnit(w.country)]).then(([matrix, summary, waiting]) => ({ matrix, summary, waiting }))
    : null;
  const csos = await getWorkspaceCsos(w.country);
  return <SalesPage country={w.country} slug={w.slug} calendar={w.calendar} data={w.data} journey={w.journey} csos={csos} userEmail={w.userEmail} board={board} />;
}
