import MasonsPage from "@/components/ws/MasonsPage";
import { loadWorkspace, type WsPageProps } from "../workspace-page";

export const dynamic = "force-dynamic";

export default async function CountryMasons(props: WsPageProps) {
  const { country: slug } = await props.params;
  const sp = await props.searchParams;
  const w = await loadWorkspace(slug, sp);
  return <MasonsPage country={w.country} slug={w.slug} calendar={w.calendar} data={w.data} journey={w.journey} userEmail={w.userEmail} />;
}
