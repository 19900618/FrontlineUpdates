import Spinner from "@/components/Spinner";

/** Shown while a workspace page computes its period on the server. */
export default function Loading() {
  return (
    <div className="flex min-h-[70dvh] flex-col items-center justify-center gap-3 p-8">
      <span style={{ color: "var(--accent-strong)" }}><Spinner size={30} /></span>
      <p className="text-center text-sm font-medium" style={{ color: "var(--text-primary)" }}>Loading the workspace</p>
      <p className="-mt-2 text-center text-xs" style={{ color: "var(--text-muted)" }}>Bringing together the latest figures for this period.</p>
    </div>
  );
}
