import { notFound } from "next/navigation";
import { auth, authConfigured } from "@/auth";
import { capacityCalendar } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import { ctsYear, getCtsData } from "@/lib/cts";
import { periodYears } from "@/lib/period";
import { findCountry } from "@/lib/workspaces";
import CtsPage from "@/components/ws/CtsPage";

export const dynamic = "force-dynamic";
// A cold year reads the two QuickBooks views, about 30 seconds each, in parallel.
export const maxDuration = 120;

/**
 * Cost to serve for one country workspace: the closed months of the current
 * year, country and branch layers, USD or local currency. The year is one
 * cache entry for all three countries, kept warm by the cron, so the page
 * only picks its country out of it.
 */
export default async function CountryCtsPage(props: { params: Promise<{ country: string }> }) {
  const { country: slug } = await props.params;
  const country = findCountry(slug);
  if (!country) notFound();
  const calendar = capacityCalendar();
  const [data, userEmail] = await Promise.all([
    getCtsData(ctsYear()),
    authConfigured ? auth().then((s) => s?.user?.email ?? null) : Promise.resolve(null),
  ]);
  const name = country.name as CapacityCountry;
  const computed = new Date(data.builtAt).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC" });
  return (
    <CtsPage key={`${slug}|${data.builtAt}`} country={name} slug={country.slug} calendar={calendar} years={periodYears(calendar)} userEmail={userEmail}
      freshness={`QuickBooks figures move only when a month's books are closed · figures computed ${computed} UTC · refresh every 15 minutes`}
      data={data.countries[name]} months={data.months} year={data.year} />
  );
}
