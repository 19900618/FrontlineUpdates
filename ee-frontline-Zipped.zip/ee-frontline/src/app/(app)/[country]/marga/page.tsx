import { notFound } from "next/navigation";
import MargaPage from "@/components/ws/MargaPage";
import { getQuality } from "@/lib/quality";
import { leadsPeriodOf } from "@/lib/leads-period";
import { loadCapacity, type WsPageProps } from "../workspace-page";

/**
 * The MARGA meeting, Rwanda only: the four blocks of the Monday workbook,
 * columns in the workbook's order, with a Copy table on each so a paste
 * lands in the shape the team already reads.
 */
export const dynamic = "force-dynamic";

export default async function MargaMeetingPage(props: WsPageProps) {
  const { country: slug } = await props.params;
  if (slug !== "rwanda") notFound();
  const sp = await props.searchParams;
  const w = await loadCapacity(slug, sp);
  const leads = leadsPeriodOf(w.period);
  const quality = await getQuality(w.country, leads.from, leads.to, null);
  return (
    <MargaPage country={w.country} slug={w.slug} calendar={w.calendar} years={w.years} data={w.data} nowData={w.nowData} nowMonth={w.nowMonth}
      quality={quality} userEmail={w.userEmail} />
  );
}
