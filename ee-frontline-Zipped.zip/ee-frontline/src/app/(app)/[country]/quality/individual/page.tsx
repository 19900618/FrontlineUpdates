import { getQaIndividual } from "@/lib/quality-individual";
import QaIndividual from "@/components/QaIndividual";
import { loadLeads } from "../../leads-page";
import type { WsPageProps } from "../../workspace-page";

export const dynamic = "force-dynamic";

/**
 * Individual QA for one country workspace: each QA officer's own record, over
 * the window in the shared filter bar.
 */
export default async function CountryQaIndividualPage(props: WsPageProps) {
  const { country: slug } = await props.params;
  const sp = await props.searchParams;
  const w = await loadLeads(slug, sp);
  const data = await getQaIndividual(w.country, w.leads.from, w.leads.to);
  return (
    <QaIndividual key={`${w.slug}|${w.leads.from}|${w.leads.to}`}
      country={w.country} slug={w.slug} calendar={w.calendar} years={w.years} userEmail={w.userEmail} freshness={w.freshness} units={w.units}
      leads={w.leads} data={data} />
  );
}
