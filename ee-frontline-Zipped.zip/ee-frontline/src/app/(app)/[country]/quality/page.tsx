import { getQuality } from "@/lib/quality";
import { getScorecards, getScoreTrend } from "@/lib/quality-scorecards";
import { trendWindow } from "@/lib/leads-period";
import QualityBoard from "@/components/QualityBoard";
import { loadLeads } from "../leads-page";
import type { WsPageProps } from "../workspace-page";

export const dynamic = "force-dynamic";

/**
 * Quality for one country workspace. The country comes from the route, the
 * window and the scope from the shared filter bar's URL state, and every
 * query is scoped to them before it runs.
 */
export default async function CountryQualityPage(props: WsPageProps) {
  const { country: slug } = await props.params;
  const sp = await props.searchParams;
  const w = await loadLeads(slug, sp);
  // The trend under the scorecards runs over the six periods ending with this one, at the picker's grain.
  const trend = trendWindow(w.leads);
  const [data, scorecards, scoreTrend] = await Promise.all([
    getQuality(w.country, w.leads.from, w.leads.to, w.unit),
    getScorecards(w.country, w.leads.from, w.leads.to, w.unit),
    getScoreTrend(w.country, trend.grain, trend.from, trend.to, w.unit),
  ]);
  return (
    <QualityBoard key={`${w.slug}|${w.leads.from}|${w.leads.to}|${w.unit?.name ?? ""}`}
      country={w.country} slug={w.slug} calendar={w.calendar} years={w.years} userEmail={w.userEmail} freshness={w.freshness} units={w.units}
      leads={w.leads} data={data} scorecards={scorecards} scoreTrend={scoreTrend} buckets={trend.buckets} />
  );
}
