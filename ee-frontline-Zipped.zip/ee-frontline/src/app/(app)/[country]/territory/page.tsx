import { getTerritories } from "@/lib/territory";
import TerritoryBoard from "@/components/TerritoryBoard";
import { loadLeads } from "../leads-page";
import type { WsPageProps } from "../workspace-page";

export const dynamic = "force-dynamic";

/**
 * Territory leads for one country workspace: what each territory is carrying,
 * and what is stuck, over the window in the shared filter bar.
 */
export default async function CountryTerritoryPage(props: WsPageProps) {
  const { country: slug } = await props.params;
  const sp = await props.searchParams;
  const w = await loadLeads(slug, sp);
  const data = await getTerritories(w.country, w.leads.from, w.leads.to);
  return (
    <TerritoryBoard key={`${w.slug}|${w.leads.from}|${w.leads.to}`}
      country={w.country} slug={w.slug} calendar={w.calendar} years={w.years} userEmail={w.userEmail} freshness={w.freshness} units={w.units}
      leads={w.leads} data={data} />
  );
}
