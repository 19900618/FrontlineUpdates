import OverviewPage from "@/components/ws/OverviewPage";
import { loadWorkspace, type WsPageProps } from "./workspace-page";

/**
 * A country workspace's Overview. The period, scope and toggle are URL
 * state; the data is the view's rows for the country and period.
 */
export const dynamic = "force-dynamic";

export default async function CountryOverview(props: WsPageProps) {
  const { country: slug } = await props.params;
  const sp = await props.searchParams;
  const w = await loadWorkspace(slug, sp);
  return <OverviewPage country={w.country} slug={w.slug} calendar={w.calendar} data={w.data} journey={w.journey} userEmail={w.userEmail} />;
}
