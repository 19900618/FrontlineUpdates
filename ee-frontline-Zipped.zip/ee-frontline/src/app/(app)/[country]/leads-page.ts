import { notFound } from "next/navigation";
import { auth, authConfigured } from "@/auth";
import { capacityCalendar, todayUtc } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import { leadsPeriodOf, type Period as LeadsPeriod } from "@/lib/leads-period";
import { parsePeriod, parseScope, periodInfo, periodYears, type PeriodInfo, type Scope } from "@/lib/period";
import { getCalendar, type Unit } from "@/lib/quality-scorecards";
import { findCountry } from "@/lib/workspaces";
import { getSyncedMs, getUnitNames } from "@/lib/workspace";
import { freshnessLine } from "@/lib/workspace-ui";

type Params = Record<string, string | string[] | undefined>;
const first = (v: string | string[] | undefined): string | null => (Array.isArray(v) ? v[0] ?? null : v ?? null);

/**
 * What the Quality and Territory leads pages need before they render: the
 * country from the slug, the shared period from the URL (`p`, `w`) turned
 * into the date window their queries take, the scope (`s`) as the unit that
 * narrows them, and the years the evaluations cover for the year filter. The
 * calendar starts at the first of those years so the period control can
 * reach every month with data.
 */
export async function loadLeads(slug: string, searchParams: Params) {
  const country = findCountry(slug);
  if (!country) notFound();
  const cal = await getCalendar();
  const minYear = Math.min(2026, ...cal.years);
  const calendar = capacityCalendar(todayUtc(), `${minYear}-01-01`);
  const sp = { get: (k: string) => first(searchParams[k]) };
  const period: PeriodInfo = periodInfo(parsePeriod(sp, calendar), calendar);
  const leads: LeadsPeriod = leadsPeriodOf(period);
  const scope: Scope = parseScope(sp);
  const unit: Unit = scope ? { level: scope.level === "territory" ? "territory" : "branch", name: scope.name } : null;
  const [userEmail, syncedMs, units] = await Promise.all([
    authConfigured ? auth().then((s) => s?.user?.email ?? null) : Promise.resolve(null),
    getSyncedMs().catch(() => null),
    getUnitNames(country.name as CapacityCountry).catch(() => [] as string[]),
  ]);
  const years = [...new Set([...periodYears(calendar), ...cal.years])].sort((a, b) => b - a);
  return {
    country: country.name as CapacityCountry, slug: country.slug, calendar, years, period, leads, scope, unit, userEmail, units,
    freshness: freshnessLine(syncedMs, ""),
  };
}
