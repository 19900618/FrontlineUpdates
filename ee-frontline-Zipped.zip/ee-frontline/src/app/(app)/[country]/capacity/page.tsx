import CapacityPage from "@/components/ws/CapacityPage";
import { loadCapacity, type WsPageProps } from "../workspace-page";

/**
 * Capacity planning, page 1: people, not volume. Masons and CSOs against
 * requirement, the People table, the last five weeks, and the backlog.
 */
export const dynamic = "force-dynamic";

export default async function CountryCapacityPage(props: WsPageProps) {
  const { country: slug } = await props.params;
  const sp = await props.searchParams;
  const w = await loadCapacity(slug, sp);
  return (
    <CapacityPage country={w.country} slug={w.slug} calendar={w.calendar} years={w.years} data={w.data} nowData={w.nowData} nowMonth={w.nowMonth}
      journey={w.journey} userEmail={w.userEmail} />
  );
}
