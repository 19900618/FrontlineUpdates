import { notFound } from "next/navigation";
import { auth, authConfigured } from "@/auth";
import { capacityCalendar } from "@/lib/capacity-calendar";
import { periodYears } from "@/lib/period";
import type { CapacityCountry } from "@/lib/capacity-ui";
import { parsePeriod, periodInfo, type PeriodInfo } from "@/lib/period";
import { findCountry } from "@/lib/workspaces";
import { getJourneyStock, getWorkspaceData } from "@/lib/workspace";

type Params = Record<string, string | string[] | undefined>;
export type WsPageProps = { params: Promise<{ country: string }>; searchParams: Promise<Params> };
const first = (v: string | string[] | undefined): string | null => (Array.isArray(v) ? v[0] ?? null : v ?? null);

/**
 * What every workspace page needs before it renders: the country from the
 * slug, the period from the URL, the period rows and the journey stock,
 * both cached 15 minutes. Only the selected country is ever queried.
 */
export async function loadWorkspace(slug: string, searchParams: Params) {
  const country = findCountry(slug);
  if (!country) notFound();
  const calendar = capacityCalendar();
  const sp = { get: (k: string) => first(searchParams[k]) };
  const period: PeriodInfo = periodInfo(parsePeriod(sp, calendar), calendar);
  const name = country.name as CapacityCountry;
  const [data, journey, userEmail] = await Promise.all([
    getWorkspaceData(name, period.fetchMonth, period.fetchFrom),
    getJourneyStock(name),
    authConfigured ? auth().then((s) => s?.user?.email ?? null) : Promise.resolve(null),
  ]);
  return { country: name, slug: country.slug, calendar, period, data, journey, userEmail };
}

/**
 * The capacity pages also draw the last five complete weeks whatever the
 * period says, so they need the current month's rows (which carry the single
 * weeks of the two months before it) as well as the selected period's. The
 * current month is always warm, so this costs nothing when the period is
 * elsewhere and nothing at all when it is the current month.
 */
export async function loadCapacity(slug: string, searchParams: Params) {
  const w = await loadWorkspace(slug, searchParams);
  const months = [...new Set(w.calendar.map((c) => c.month))];
  const now = months[months.length - 1];
  const jan = `${now.slice(0, 4)}-01-01`;
  const nowData = w.period.fetchMonth === now && w.period.fetchFrom <= jan ? w.data : await getWorkspaceData(w.country, now, jan);
  return { ...w, nowData, nowMonth: now, years: periodYears(w.calendar) };
}
