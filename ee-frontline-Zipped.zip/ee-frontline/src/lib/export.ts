"use client";

/**
 * Table export helpers shared by every module.
 *
 * Two routes on purpose:
 *  - CSV download, for filing and for Excel.
 *  - Copy for Google Sheets, which puts TAB-separated text on the clipboard so
 *    it pastes straight into a sheet. This exists because downloading a CSV and
 *    importing it into Sheets loses people: the import dialog guesses delimiters,
 *    mangles leading zeros in phone numbers, and reformats dates. A paste keeps
 *    the columns and needs no import step at all.
 */

export type Cell = string | number | null | undefined;

const csvCell = (v: Cell): string => {
  const s = v == null ? "" : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/** Tabs and newlines would break the paste, so they are flattened to spaces. */
const tsvCell = (v: Cell): string => (v == null ? "" : String(v).replace(/[\t\r\n]+/g, " "));

export function toCsv(headers: string[], rows: Cell[][]): string {
  return [headers.map(csvCell).join(","), ...rows.map((r) => r.map(csvCell).join(","))].join("\r\n");
}

export function toTsv(headers: string[], rows: Cell[][]): string {
  return [headers.map(tsvCell).join("\t"), ...rows.map((r) => r.map(tsvCell).join("\t"))].join("\n");
}

/** Download as CSV. The BOM keeps accented names readable when opened in Excel. */
export function downloadCsv(filename: string, headers: string[], rows: Cell[][]): void {
  const blob = new Blob(["\ufeff" + toCsv(headers, rows)], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/**
 * Put the table on the clipboard as TSV. Returns false if the browser refused,
 * so the caller can tell the user rather than silently doing nothing.
 */
export async function copyForSheets(headers: string[], rows: Cell[][]): Promise<boolean> {
  const text = toTsv(headers, rows);
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // fall through to the legacy path (older Android browsers, denied permission)
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

/** Today as YYYY-MM-DD, for filenames. */
export const stamp = (): string => new Date().toISOString().slice(0, 10);
