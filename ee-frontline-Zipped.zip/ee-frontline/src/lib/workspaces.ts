/**
 * The four boxes on the home page. Each country gets its own workspace for the new
 * dashboards; the toolkit box holds every page the app had before the split, unchanged,
 * under /toolkit.
 *
 * Country pages live at /<slug> (src/app/(app)/[country]). Adding a country is a line
 * here; the route picks it up.
 */
/** The country as Salesforce and BigQuery spell it. Queries take this, never a bare string. */
export type CountryName = "Rwanda" | "Uganda" | "Kenya";

export type Country = {
  slug: "rwanda" | "uganda" | "kenya";
  name: CountryName;
  code: "RW" | "UG" | "KE";
  /** Card gradient, dark enough for white text, in the flag's own hues. */
  from: string;
  to: string;
  glow: string;
};

export const COUNTRIES: Country[] = [
  { slug: "rwanda", name: "Rwanda", code: "RW", from: "#075985", to: "#1e3a8a", glow: "#fde047" },
  { slug: "uganda", name: "Uganda", code: "UG", from: "#7f1d1d", to: "#1c1917", glow: "#fbbf24" },
  { slug: "kenya", name: "Kenya", code: "KE", from: "#14532d", to: "#1c1917", glow: "#34d399" },
];

export const TOOLKIT = {
  href: "/toolkit",
  name: "Classic Frontline Toolkit",
  code: "EE",
  from: "#2b2520",
  to: "#7c3a0e",
  glow: "#ee7203",
};

/** The fifth box: cross-country, so it lives beside the workspaces, not inside one. */
export const CEO = {
  href: "/ceo",
  name: "CEO dashboard",
  code: "CEO",
  from: "#1f2937",
  to: "#0f172a",
  glow: "#fbbf24",
};

/**
 * The areas inside a country workspace, in the order they appear in the menu.
 * An area with children is a group: its link opens the first child and the
 * group expands in the menu while any child is on screen. A child with a
 * `tab` is the same route with `?tab=`: the sub-pages of Sales and
 * collections and Masons live in the menu, not as tabs on the page, and their
 * routes did not change. `rwandaOnly` hides an area from the other countries.
 * An area with no path has no page yet; it is listed, but never a link.
 *
 * This lives here, not in the menu component, because the menu is a client
 * component: a value exported from one reaches a server page as a stub.
 */
export type Area = { label: string; path?: string; tab?: string; children?: Area[]; rwandaOnly?: boolean };

export const AREAS: Area[] = [
  { label: "Overview", path: "" },
  {
    label: "Sales and collections", path: "/sales",
    children: [
      { label: "Overview", path: "/sales" },
      { label: "Individual CSOs", path: "/sales", tab: "csos" },
      { label: "Customer journey", path: "/sales", tab: "journey" },
    ],
  },
  {
    label: "Masons", path: "/masons",
    children: [
      { label: "Overview", path: "/masons" },
      { label: "Individual masons", path: "/masons", tab: "masons" },
    ],
  },
  {
    label: "Quality", path: "/quality",
    children: [
      { label: "Overview", path: "/quality" },
      { label: "Individual QA", path: "/quality/individual" },
    ],
  },
  { label: "Territory leads", path: "/territory" },
  {
    label: "Capacity planning", path: "/capacity",
    children: [
      { label: "People and backlog", path: "/capacity" },
      { label: "MARGA meeting", path: "/marga", rwandaOnly: true },
    ],
  },
  { label: "Cost to serve", path: "/cts" },
];

export const findCountry = (slug: string) => COUNTRIES.find((c) => c.slug === slug);
