/**
 * The period control of the country workspaces, as URL state. Client-safe.
 *
 * Two modes. A MONTH with any combination of its four calendar weeks (days
 * 1-7, 8-14, 15-21, 22 to month end), all four by default; or a QUARTER. The
 * choice lives in the URL (`p=2026-09&w=1234`, `p=2026-Q3`) so it persists
 * across the three pages and every drill-down, and the scope (`s=level:name`)
 * and Rwanda's territory or branch toggle (`d=district`) travel with it.
 *
 * Which weeks exist, and whether they are complete, comes from the capacity
 * calendar (src/lib/capacity-calendar.ts), the same arithmetic the SQL uses.
 * Every number for a period is read from the view's row for that period
 * (week set within a month, or the quarter); nothing here adds months up.
 */
import { capacityCalendar, todayUtc, type CapacityWeek } from "./capacity-calendar";

export type PeriodMode = "month" | "quarter";

export type Period = {
  mode: PeriodMode;
  /** 'YYYY-MM-01': the month, or the quarter's first month. */
  month: string;
  /** Month mode: the selected week numbers, ascending, 1 to 4. Empty in quarter mode. */
  weeks: number[];
};

export type PeriodInfo = Period & {
  /** The view's week_key for this period: '1234', '13' ... or 'Q'. */
  weekKey: string;
  /** 'September 2026', 'W1+W3 of September 2026', 'Q3 2026'. */
  label: string;
  /** Short form for headings: 'September', 'W1+W3 of September', 'Q3'. */
  short: string;
  /** The calendar weeks the period holds (started weeks only). */
  calendarWeeks: CapacityWeek[];
  start: string;
  end: string;
  /** True when every started week of the month (or quarter) is selected. */
  isWhole: boolean;
  /** The month to ask the view for: the month itself, or the quarter's latest started month. */
  fetchMonth: string;
  /** The first month the view should compute, so the trend runs from January and movement has a previous period. */
  fetchFrom: string;
  /** Any week in progress. */
  inProgress: boolean;
};

const MONTHS_LONG = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

const ym = (month: string) => month.slice(0, 7);
const monthOf = (y: number, m0: number) => `${y}-${String(m0 + 1).padStart(2, "0")}-01`;
const addMonths = (month: string, n: number) => {
  const [y, m] = month.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1 + n, 1));
  return monthOf(d.getUTCFullYear(), d.getUTCMonth());
};
export const addMonthsIso = addMonths;

/** The capacity calendar week holding a day: days 1-7, 8-14, 15-21, 22 to month end. */
export function weekOfDay(day: string): { start: string; end: string; weekNo: number } {
  const [y, m, d] = day.split("-").map(Number);
  const weekNo = Math.min(Math.ceil(d / 7), 4);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const startD = (weekNo - 1) * 7 + 1;
  const endD = weekNo === 4 ? last : weekNo * 7;
  const pad = (n: number) => String(n).padStart(2, "0");
  return { start: `${y}-${pad(m)}-${pad(startD)}`, end: `${y}-${pad(m)}-${pad(endD)}`, weekNo };
}

export const quarterOf = (month: string) => Math.floor((Number(month.slice(5, 7)) - 1) / 3) + 1;
export const quarterStart = (month: string) => monthOf(Number(month.slice(0, 4)), (quarterOf(month) - 1) * 3);
export const monthLabel = (month: string) => `${MONTHS_LONG[Number(month.slice(5, 7)) - 1]} ${month.slice(0, 4)}`;
export const monthName = (month: string) => MONTHS_LONG[Number(month.slice(5, 7)) - 1];

/** Every month the calendar offers, oldest first. */
export function periodMonths(calendar: CapacityWeek[] = capacityCalendar()): string[] {
  return [...new Set(calendar.map((w) => w.month))];
}

/** Every year the calendar offers, newest first. */
export function periodYears(calendar: CapacityWeek[] = capacityCalendar()): number[] {
  return [...new Set(calendar.map((w) => Number(w.month.slice(0, 4))))].sort((a, b) => b - a);
}

/** The whole of a month as a period: every started week of it. */
export function wholeMonthPeriod(month: string, calendar: CapacityWeek[] = capacityCalendar()): Period {
  return { mode: "month", month, weeks: calendar.filter((w) => w.month === month).map((w) => w.weekNo) };
}

/**
 * The same period moved to another year: the same month or quarter when the
 * calendar has it, else the latest one that year offers.
 */
export function periodInYear(period: Period, year: number, calendar: CapacityWeek[] = capacityCalendar()): Period {
  const y = String(year);
  if (period.mode === "quarter") {
    const qs = periodQuarters(calendar).filter((q) => q.startsWith(y));
    const same = `${y}${period.month.slice(4)}`;
    const q = qs.includes(same) ? same : qs[qs.length - 1];
    return q ? { mode: "quarter", month: q, weeks: [] } : period;
  }
  const ms = periodMonths(calendar).filter((m) => m.startsWith(y));
  const same = `${y}${period.month.slice(4)}`;
  const m = ms.includes(same) ? same : ms[ms.length - 1];
  return m ? wholeMonthPeriod(m, calendar) : period;
}

/** Every quarter with at least one started week, oldest first, as their first month. */
export function periodQuarters(calendar: CapacityWeek[] = capacityCalendar()): string[] {
  return [...new Set(calendar.map((w) => quarterStart(w.month)))];
}

/** The month a manager should land on: the current month. The week in progress is labelled. */
export function defaultPeriod(calendar: CapacityWeek[] = capacityCalendar()): Period {
  const months = periodMonths(calendar);
  const month = months[months.length - 1];
  return { mode: "month", month, weeks: calendar.filter((w) => w.month === month).map((w) => w.weekNo) };
}

/** Read the period from search params; anything malformed falls back to the default. */
export function parsePeriod(params: { get(name: string): string | null }, calendar: CapacityWeek[] = capacityCalendar()): Period {
  const p = params.get("p") ?? "";
  const fallback = defaultPeriod(calendar);
  const q = /^(\d{4})-Q([1-4])$/.exec(p);
  if (q) {
    const month = monthOf(Number(q[1]), (Number(q[2]) - 1) * 3);
    if (periodQuarters(calendar).includes(month)) return { mode: "quarter", month, weeks: [] };
    return fallback;
  }
  const m = /^(\d{4})-(\d{2})$/.exec(p);
  if (!m) return fallback;
  const month = `${m[1]}-${m[2]}-01`;
  const started = calendar.filter((w) => w.month === month).map((w) => w.weekNo);
  if (started.length === 0) return fallback;
  const w = params.get("w") ?? "";
  const weeks = [...new Set(w.split("").map(Number).filter((n) => started.includes(n)))].sort();
  return { mode: "month", month, weeks: weeks.length ? weeks : started };
}

/** The URL form of a period. */
export function periodParams(period: Period, calendar: CapacityWeek[] = capacityCalendar()): Record<string, string> {
  if (period.mode === "quarter") return { p: `${period.month.slice(0, 4)}-Q${quarterOf(period.month)}` };
  const started = calendar.filter((w) => w.month === period.month).map((w) => w.weekNo);
  const all = started.every((n) => period.weeks.includes(n));
  return all ? { p: ym(period.month) } : { p: ym(period.month), w: period.weeks.join("") };
}

export function periodInfo(period: Period, calendar: CapacityWeek[] = capacityCalendar()): PeriodInfo {
  const today = todayUtc();
  if (period.mode === "quarter") {
    const months = [0, 1, 2].map((i) => addMonths(period.month, i));
    const weeks = calendar.filter((w) => months.includes(w.month));
    const last = weeks[weeks.length - 1];
    const label = `Q${quarterOf(period.month)} ${period.month.slice(0, 4)}`;
    return {
      ...period, weekKey: "Q", label, short: `Q${quarterOf(period.month)}`,
      calendarWeeks: weeks, start: period.month, end: last?.weekEnd ?? period.month,
      isWhole: true, fetchMonth: last?.month ?? period.month,
      // January of the year, and three months before the quarter so the previous quarter is in the window.
      fetchFrom: [monthOf(Number(period.month.slice(0, 4)), 0), addMonths(period.month, -3)].sort()[0],
      inProgress: weeks.some((w) => w.isCurrent),
    };
  }
  const inMonth = calendar.filter((w) => w.month === period.month);
  const chosen = inMonth.filter((w) => period.weeks.includes(w.weekNo));
  const isWhole = inMonth.length > 0 && inMonth.every((w) => period.weeks.includes(w.weekNo));
  const wk = `W${period.weeks.join("+W")}`;
  const name = monthName(period.month);
  return {
    ...period, weekKey: period.weeks.join(""),
    label: isWhole ? monthLabel(period.month) : `${wk} of ${monthLabel(period.month)}`,
    short: isWhole ? name : `${wk} of ${name}`,
    calendarWeeks: chosen,
    start: chosen[0]?.weekStart ?? period.month,
    end: chosen[chosen.length - 1]?.weekEnd ?? period.month,
    isWhole, fetchMonth: period.month,
    fetchFrom: [monthOf(Number(period.month.slice(0, 4)), 0), addMonths(period.month, -1)].sort()[0],
    inProgress: chosen.some((w) => w.isCurrent) || period.month > today.slice(0, 7) + "-01",
  };
}

/** The week set the view's whole-month row uses for a month: every started week. */
export function wholeMonthKey(month: string, calendar: CapacityWeek[] = capacityCalendar()): string {
  return calendar.filter((w) => w.month === month).map((w) => w.weekNo).join("");
}

/** 'W1 (01-07 Sep)' style label for a week chip. */
export function weekChipLabel(w: CapacityWeek): string {
  return `${Number(w.weekStart.slice(8, 10))}-${Number(w.weekEnd.slice(8, 10))}`;
}

/** The workspace scope: one unit, or the whole country. */
export type Scope = { level: "territory" | "district" | "branch"; name: string } | null;

export function parseScope(params: { get(name: string): string | null }): Scope {
  const s = params.get("s");
  if (!s) return null;
  const i = s.indexOf(":");
  if (i < 0) return null;
  const level = s.slice(0, i);
  const name = s.slice(i + 1);
  if ((level !== "territory" && level !== "district" && level !== "branch") || !name) return null;
  return { level, name };
}

export const scopeParam = (scope: Scope): Record<string, string> => (scope ? { s: `${scope.level}:${scope.name}` } : {});
