/**
 * Client-safe constants, types and date helpers for the Customer journey flow page.
 *
 * Every step and every date rule lives in BigQuery (salesforce.customer_journey_events_v1).
 * This file only names and colours the steps for display, and does calendar arithmetic
 * to turn "last week" into a start and an end date. Dates are handled as YYYY-MM-DD
 * strings in UTC so the server and the browser always agree.
 */
import { bucketColor } from "./format";

export type Gran = "day" | "week" | "month";
/** Product families as the business sells them. Plaster, paint and ceiling plaster are separate. */
export type Product = "all" | "floor" | "plaster" | "paint" | "ceiling plaster";
export type Cohort = "2026" | "all";
export type LocDim = "territory" | "branch";

/** Display names for the view's product_family values. */
export const PRODUCT_LABEL: Record<string, string> = {
  floor: "Floor",
  plaster: "Plaster",
  paint: "Paint",
  "ceiling plaster": "Ceiling plaster",
  repair: "Repair",
  house: "House",
  other: "Not recorded",
};

/** Filter choices. Ceiling plaster is Uganda only, so it is offered there alone. */
export const PRODUCT_OPTIONS: [Product, string][] = [
  ["all", "All"],
  ["floor", "Floor"],
  ["plaster", "Plaster"],
  ["paint", "Paint"],
];
export const CEILING_OPTION: [Product, string] = ["ceiling plaster", "Ceiling plaster"];

export type FlowQuery = {
  country: string;
  dim: LocDim;
  loc: string; // "" = the whole country
  product: Product;
  cohort: Cohort;
  gran: Gran;
  start: string;
  end: string;
};

export type Step = {
  key: number; // the view's to_key
  name: string;
  short: string;
  lines: string[]; // label split for the chart boxes
  hint: string;
  color: string;
};

/** The view's steps in journey order. Colours match the customer journey board columns. */
export const STEPS: Step[] = [
  { key: 1, name: "Signed", short: "Signed", lines: ["Signed"], color: bucketColor("3"),
    hint: "The customer signed the contract." },
  { key: 2, name: "Paid enough to build", short: "Paid", lines: ["Paid enough", "to build"], color: bucketColor("4"),
    hint: "Paid up to the gate to start: floor 50%, plaster and paint 100% in Rwanda and 75% in Uganda and Kenya." },
  { key: 3, name: "Materials ready", short: "Materials ready", lines: ["Materials ready"], color: bucketColor("5"),
    hint: "The branch ticked Materials available in Salesforce (after the customer paid enough)." },
  { key: 4, name: "Build started", short: "Started", lines: ["Build started"], color: bucketColor("6"),
    hint: "The first of: masons' first timesheet, first plaster evaluation, construction start or anti-termite delivery." },
  { key: 5, name: "Varnish or paint delivered", short: "Delivered", lines: ["Varnish or paint", "delivered"], color: bucketColor("7"),
    hint: "Varnish (floors) or paint (walls) delivered to the house." },
  { key: 6, name: "Completed", short: "Completed", lines: ["Completed"], color: bucketColor("8"),
    hint: "A completion date is recorded in Salesforce." },
  { key: 9, name: "Lost", short: "Lost", lines: ["Lost"], color: "var(--critical)",
    hint: "The contract was marked Closed Lost." },
];

export const stepOf = (key: number | null | undefined): Step | undefined => STEPS.find((s) => s.key === key);

/** Position of each step on the main line. Materials ready sits beside Paid, never on the line. */
export const MAIN_IDX: Record<number, number> = { 1: 0, 2: 1, 3: 1, 4: 2, 5: 3, 6: 4 };

export type MovePair = { to: number; from: number | null; n: number; prev: number; skipped: number; medianDays: number | null };
export type MoveTotal = { to: number; n: number; prev: number; skipped: number; medianDays: number | null };
export type Stock = { pos: number; atStart: number; atEnd: number };
export type TrendRow = { period: string; to: number; n: number };
export type FlowSummary = {
  pairs: MovePair[]; // moves per route (from -> to) in the window
  totals: MoveTotal[]; // moves per step, every route combined
  stock: Stock[]; // customers at each step when the window opened and closed
  trend: TrendRow[]; // moves per step per day, week or month
  latest: string | null; // most recent movement recorded for the country
};

export type FlowRow = {
  opportunity_id: string;
  opportunity_label: string | null;
  customer_name: string | null;
  phone: string | null;
  cso_name: string | null;
  country: string;
  branch: string;
  district: string | null;
  territory: string;
  track: string;
  product_family: string;
  signed_date: string | null;
  to_key: number;
  event_date: string;
  from_key: number | null;
  from_date: string | null;
  days_from_prev: number | null;
  skipped_steps: number;
  now_bucket: string | null;
  now_stage: string | null;
};

/** A picked movement: every route into `to`, or one route when `from` is set. */
export type FlowPick = { to: number; from: number | null } | null;

// ---------- dates ----------

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const MONTHS_LONG = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const D = (iso: string) => new Date(`${iso}T00:00:00Z`);
const iso = (d: Date) => d.toISOString().slice(0, 10);

/** Today's date in a timezone, as YYYY-MM-DD. */
export function todayIn(timeZone: string): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

export function addDays(day: string, n: number): string {
  const d = D(day);
  d.setUTCDate(d.getUTCDate() + n);
  return iso(d);
}

export function daysInclusive(start: string, end: string): number {
  return Math.round((D(end).getTime() - D(start).getTime()) / 86_400_000) + 1;
}

/** First day of the day, week (Monday) or month holding `day`. */
export function periodStart(g: Gran, day: string): string {
  if (g === "day") return day;
  if (g === "week") return addDays(day, -((D(day).getUTCDay() + 6) % 7));
  return `${day.slice(0, 8)}01`;
}

export function periodEnd(g: Gran, day: string): string {
  if (g === "day") return day;
  if (g === "week") return addDays(periodStart("week", day), 6);
  const d = D(day);
  return iso(new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)));
}

/** Start of the period `n` periods away from the one holding `day`. */
export function shiftPeriod(g: Gran, day: string, n: number): string {
  if (g === "day") return addDays(day, n);
  if (g === "week") return addDays(periodStart("week", day), 7 * n);
  const d = D(day);
  return iso(new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, 1)));
}

export const windowFor = (g: Gran, day: string) => ({ start: periodStart(g, day), end: periodEnd(g, day) });

/** The last complete period: yesterday, last week or last month. */
export const defaultWindow = (g: Gran, today: string) => windowFor(g, shiftPeriod(g, today, -1));

export const isWholePeriod = (g: Gran, start: string, end: string) =>
  start === periodStart(g, start) && end === periodEnd(g, start);

/** The same number of days immediately before the window, for the comparison. */
export function previousWindow(start: string, end: string) {
  const pend = addDays(start, -1);
  return { start: addDays(pend, -(daysInclusive(start, end) - 1)), end: pend };
}

export const COHORT_START: Record<Cohort, string> = { "2026": "2026-01-01", all: "2024-01-01" };
const TREND_LEN: Record<Gran, number> = { day: 14, week: 12, month: 12 };

/** Period starts for the trend charts, oldest first, ending with the current (unfinished) period. */
export function trendPeriods(g: Gran, today: string, cohort: Cohort): string[] {
  const out: string[] = [];
  for (let i = TREND_LEN[g] - 1; i >= 0; i--) {
    const p = periodStart(g, shiftPeriod(g, today, -i));
    if (periodEnd(g, p) >= COHORT_START[cohort]) out.push(p);
  }
  return out;
}

export const fmtDay = (day: string) => `${Number(day.slice(8))} ${MONTHS[Number(day.slice(5, 7)) - 1]}`;
const fmtDayYear = (day: string) => `${fmtDay(day)} ${day.slice(0, 4)}`;

/** "Tue 15 Sep 2026", "8 to 14 Sep 2026", "August 2026", "28 Aug to 3 Sep 2026". */
export function fmtRange(start: string, end: string): string {
  if (start === end) return `${WEEKDAYS[D(start).getUTCDay()]} ${fmtDayYear(start)}`;
  if (isWholePeriod("month", start, end)) return `${MONTHS_LONG[Number(start.slice(5, 7)) - 1]} ${start.slice(0, 4)}`;
  if (start.slice(0, 7) === end.slice(0, 7)) return `${Number(start.slice(8))} to ${fmtDayYear(end)}`;
  return `${fmtDay(start)} to ${fmtDayYear(end)}`;
}

/** Short axis label for a trend period. */
export function fmtPeriod(g: Gran, p: string): string {
  if (g === "month") return MONTHS[Number(p.slice(5, 7)) - 1];
  return fmtDay(p);
}

/** Tooltip label for a trend period. */
export function fmtPeriodLong(g: Gran, p: string): string {
  if (g === "day") return `${WEEKDAYS[D(p).getUTCDay()]} ${fmtDayYear(p)}`;
  if (g === "week") return `Week of ${fmtDayYear(p)}`;
  return `${MONTHS_LONG[Number(p.slice(5, 7)) - 1]} ${p.slice(0, 4)}`;
}

/** "Yesterday", "Last week", "This month so far" when the window is one of those. */
export function relativeName(g: Gran, start: string, end: string, today: string): string | null {
  if (!isWholePeriod(g, start, end)) return null;
  const names: Record<Gran, [string, string]> = {
    day: ["Today so far", "Yesterday"],
    week: ["This week so far", "Last week"],
    month: ["This month so far", "Last month"],
  };
  if (start === periodStart(g, today)) return names[g][0];
  if (start === periodStart(g, shiftPeriod(g, today, -1))) return names[g][1];
  return null;
}

// ---------- query string (shared by the page and the API routes) ----------

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function flowQueryString(q: FlowQuery): string {
  return new URLSearchParams({
    country: q.country, loc: q.loc, product: q.product, cohort: q.cohort, gran: q.gran, start: q.start, end: q.end,
  }).toString();
}

export function parseFlowQuery(sp: URLSearchParams): FlowQuery | null {
  const country = sp.get("country") ?? "Rwanda";
  const gran = sp.get("gran") as Gran;
  const product = sp.get("product") as Product;
  const cohort = sp.get("cohort") as Cohort;
  const start = sp.get("start") ?? "";
  const end = sp.get("end") ?? "";
  const loc = sp.get("loc") ?? "";
  if (!["day", "week", "month"].includes(gran)) return null;
  if (!["all", "floor", "plaster", "paint", "ceiling plaster"].includes(product)) return null;
  if (!["2026", "all"].includes(cohort)) return null;
  if (!DATE_RE.test(start) || !DATE_RE.test(end) || start > end) return null;
  if (country.length > 40 || loc.length > 80) return null;
  // Rwanda is managed by territory, Uganda and Kenya by branch (same rule as the journey board).
  return { country, dim: country === "Rwanda" ? "territory" : "branch", loc, product, cohort, gran, start, end };
}
