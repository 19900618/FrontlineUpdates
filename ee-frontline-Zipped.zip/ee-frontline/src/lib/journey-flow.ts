import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import { locColumn } from "./data";
import {
  COHORT_START, previousWindow, trendPeriods,
  type FlowQuery, type FlowRow, type FlowSummary, type Gran,
} from "./journey-flow-shared";

/**
 * Customer journey flow. Reads earth-enable-main.salesforce.customer_journey_events_v1:
 * one row per job per step forward, dated. Which steps exist, how each is dated and the
 * data guards all live in that view; these queries only filter and count.
 *
 * A job's position on any date is the highest to_key it has reached by then. The view
 * orders to_key so that holds (1 Signed ... 6 Completed, 9 Lost on top).
 */
const VIEW = "`earth-enable-main.salesforce.customer_journey_events_v1`";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync
const ROW_LIMIT = 3000;
const TRUNC: Record<Gran, string> = { day: "DAY", week: "WEEK(MONDAY)", month: "MONTH" };

type Raw = Record<string, unknown>;
const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

/** Filters every query shares: country, one territory or branch, product and contract cohort. */
function scope(q: FlowQuery) {
  return {
    where: `country = @country AND (@loc = '' OR ${locColumn(q.dim)} = @loc)
      AND (@product = 'all' OR product_family = @product) AND signed_date >= DATE(@cohortStart)`,
    params: { country: q.country, loc: q.loc, product: q.product, cohortStart: COHORT_START[q.cohort] },
  };
}

async function fetchFlowSummary(q: FlowQuery, today: string): Promise<FlowSummary> {
  const { where, params } = scope(q);
  const prev = previousWindow(q.start, q.end);
  const periods = trendPeriods(q.gran, today, q.cohort);
  const inWindow = "event_date BETWEEN DATE(@start) AND DATE(@end)";

  const [moves, stock, trend, latest] = await Promise.all([
    // Moves in the window and in the window before it, per route and per step (ROLLUP).
    query<Raw>(
      `SELECT to_key, from_key, GROUPING(from_key) AS is_total,
        COUNTIF(${inWindow}) AS n,
        COUNTIF(event_date BETWEEN DATE(@pstart) AND DATE(@pend)) AS prev,
        COUNTIF(${inWindow} AND skipped_steps > 0) AS skipped,
        APPROX_QUANTILES(IF(${inWindow}, days_from_prev, NULL), 2)[SAFE_OFFSET(1)] AS median_days
      FROM ${VIEW}
      WHERE ${where} AND event_date BETWEEN DATE(@pstart) AND DATE(@end)
      GROUP BY ROLLUP(to_key, from_key)
      HAVING GROUPING(to_key) = 0`,
      { ...params, start: q.start, end: q.end, pstart: prev.start, pend: prev.end },
    ),
    // Where every job stood when the window opened and when it closed.
    query<Raw>(
      `WITH p AS (
        SELECT opportunity_id,
          MAX(IF(event_date < DATE(@start), to_key, NULL)) AS pos_start,
          MAX(to_key) AS pos_end
        FROM ${VIEW}
        WHERE ${where} AND event_date <= DATE(@end)
        GROUP BY opportunity_id
      )
      SELECT k AS pos, COUNTIF(pos_start = k) AS at_start, COUNTIF(pos_end = k) AS at_end
      FROM p CROSS JOIN UNNEST([1, 2, 3, 4, 5, 6, 9]) AS k
      GROUP BY k`,
      { ...params, start: q.start, end: q.end },
    ),
    query<Raw>(
      `SELECT CAST(DATE_TRUNC(event_date, ${TRUNC[q.gran]}) AS STRING) AS period, to_key, COUNT(*) AS n
      FROM ${VIEW}
      WHERE ${where} AND event_date >= DATE(@tstart)
      GROUP BY 1, 2`,
      { ...params, tstart: periods[0] ?? q.start },
    ),
    query<Raw>(`SELECT CAST(MAX(event_date) AS STRING) AS latest FROM ${VIEW} WHERE country = @country`, { country: q.country }),
  ]);

  const move = (r: Raw) => ({
    to: num(r.to_key), n: num(r.n), prev: num(r.prev), skipped: num(r.skipped), medianDays: numOrNull(r.median_days),
  });
  return {
    pairs: moves.filter((r) => num(r.is_total) === 0).map((r) => ({ ...move(r), from: numOrNull(r.from_key) })),
    totals: moves.filter((r) => num(r.is_total) === 1).map(move),
    stock: stock.map((r) => ({ pos: num(r.pos), atStart: num(r.at_start), atEnd: num(r.at_end) })),
    trend: trend.map((r) => ({ period: String(r.period), to: num(r.to_key), n: num(r.n) })),
    latest: strOrNull(latest[0]?.latest),
  };
}

/** The customers behind the numbers: moves in the window, optionally one step or one route. */
async function fetchFlowRows(q: FlowQuery, to: number, from: number): Promise<{ rows: FlowRow[]; truncated: boolean }> {
  const { where, params } = scope(q);
  const rows = await query<Raw>(
    `SELECT opportunity_id, opportunity_label, customer_name, customer_phone AS phone, cso_name, country,
      COALESCE(NULLIF(TRIM(branch),''),'Unassigned') AS branch, district,
      COALESCE(NULLIF(TRIM(territory),''),'Unassigned') AS territory, track, product_family,
      CAST(signed_date AS STRING) AS signed_date, to_key, CAST(event_date AS STRING) AS event_date,
      from_key, CAST(from_date AS STRING) AS from_date, days_from_prev, skipped_steps, now_bucket, now_stage
    FROM ${VIEW}
    WHERE ${where} AND event_date BETWEEN DATE(@start) AND DATE(@end)
      AND (@to = 0 OR to_key = @to) AND (@from = -1 OR IFNULL(from_key, 0) = @from)
    ORDER BY event_date DESC, to_key, customer_name
    LIMIT ${ROW_LIMIT + 1}`,
    { ...params, start: q.start, end: q.end, to, from },
  );
  return {
    truncated: rows.length > ROW_LIMIT,
    rows: rows.slice(0, ROW_LIMIT).map((r) => ({
      opportunity_id: String(r.opportunity_id),
      opportunity_label: strOrNull(r.opportunity_label),
      customer_name: strOrNull(r.customer_name),
      phone: strOrNull(r.phone),
      cso_name: strOrNull(r.cso_name),
      country: String(r.country),
      branch: String(r.branch),
      district: strOrNull(r.district),
      territory: String(r.territory),
      track: String(r.track),
      product_family: String(r.product_family),
      signed_date: strOrNull(r.signed_date),
      to_key: num(r.to_key),
      event_date: String(r.event_date),
      from_key: numOrNull(r.from_key),
      from_date: strOrNull(r.from_date),
      days_from_prev: numOrNull(r.days_from_prev),
      skipped_steps: num(r.skipped_steps),
      now_bucket: strOrNull(r.now_bucket),
      now_stage: strOrNull(r.now_stage),
    })),
  };
}

export const getFlowSummary = unstable_cache(fetchFlowSummary, ["flow-summary-v3"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
export const getFlowRows = unstable_cache(fetchFlowRows, ["flow-rows-v3"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
