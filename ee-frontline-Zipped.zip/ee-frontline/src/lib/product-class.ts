import { PRODUCT_CLASS_BODY, PRODUCT_CLASS_PARAM } from "@/generated/sql";

/**
 * The company's product classification for the queries written in
 * TypeScript. The rule lives in sql/product_class.sql and nowhere else; the
 * build script copies its CASE into src/generated/sql.ts, and this helper
 * writes it over an expression. Apply it to the raw product string, old
 * field first:
 *
 *   productClass("COALESCE(o.product_interest_c, o.new_product_interest_c)")   salesforce.opportunity
 *   productClass("COALESCE(o.product_interest, o.new_product_interest)")       all_opportunities_master
 *
 * It returns 'Floor', 'Plaster', 'Paint', 'Repair', 'House', 'Other' or
 * 'Unknown'. Scored SQM-E is Floor plus Plaster only (`SCORED_PRODUCTS`);
 * paint is shown beside it, never inside it.
 */
export function productClass(expr: string): string {
  return `(${PRODUCT_CLASS_BODY.replace(new RegExp(`\\b${PRODUCT_CLASS_PARAM}\\b`, "g"), `(${expr})`)})`;
}

/** The products whose SQM-E counts against a target, as a SQL list. */
export const SCORED_PRODUCTS = "('Floor', 'Plaster')";
