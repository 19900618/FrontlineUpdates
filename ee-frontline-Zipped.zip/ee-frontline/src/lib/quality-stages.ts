/**
 * The six stages the cleaned evaluation table normalises every QA evaluation to.
 *
 * Client-safe on purpose: the pages need the list and its order to lay out a stage
 * breakdown, and importing it from the data layer would drag BigQuery into the
 * browser bundle.
 */
export const QA_STAGES = ["Compaction", "Screed", "Prior Paint", "Final", "Pre-House", "Other"] as const;
export type QaStage = (typeof QA_STAGES)[number];
