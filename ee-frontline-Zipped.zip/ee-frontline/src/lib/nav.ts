/**
 * Navigation config. Adding a module is a one-liner here plus a matching route
 * folder under src/app/(app)/toolkit/<path>/page.tsx (hrefs start with /toolkit).
 *
 * Two levels on purpose. A section is a heading; under it sit plain items and,
 * where one module has several views, a group that expands. Groups keep the menu
 * short: the sales pages are four pages, but only the country you are looking at
 * is open, and the labels inside a group can be short ("Overview") because the
 * group already says which country it is.
 *
 * `enabled: false` renders a greyed "soon" item, a visible placeholder for work
 * not built yet. `hidden: true` keeps a finished page out of the menu without
 * deleting its route or this line: flip it back to show the page again.
 */
export type NavItem = {
  label: string;
  href: string;
  enabled: boolean;
  soon?: boolean;
  hidden?: boolean;
};

export type NavGroup = {
  label: string;
  items: NavItem[];
};

export type NavEntry = NavItem | NavGroup;

export type NavSection = {
  title: string;
  entries: NavEntry[];
};

export const isGroup = (entry: NavEntry): entry is NavGroup => "items" in entry;

export const NAV: NavSection[] = [
  {
    title: "Customers",
    entries: [
      { label: "Journey board", href: "/toolkit", enabled: true },
      { label: "Journey flow", href: "/toolkit/journey-flow", enabled: true },
    ],
  },
  {
    title: "Sales & collections",
    entries: [
      {
        label: "Rwanda CSOs",
        items: [
          { label: "Overview", href: "/toolkit/cso", enabled: true },
          { label: "Individual CSOs", href: "/toolkit/cso/individual", enabled: true },
        ],
      },
      {
        label: "Uganda & Kenya CSOs",
        items: [
          { label: "Overview", href: "/toolkit/cso-ugke", enabled: true },
          { label: "Individual CSOs", href: "/toolkit/cso-ugke/individual", enabled: true },
        ],
      },
      { label: "Collections backlog", href: "/toolkit/collections", enabled: true },
    ],
  },
  {
    title: "Planning",
    entries: [
      { label: "Capacity planning", href: "/toolkit/capacity", enabled: true },
      // Parked at Vinamra's request (2026-09-16). The page still works at /mason.
      { label: "Mason scheduler", href: "/toolkit/mason", enabled: true, hidden: true },
    ],
  },
];
