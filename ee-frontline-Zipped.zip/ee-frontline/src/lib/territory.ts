import { unstable_cache } from "next/cache";
import { productClass } from "./product-class";
import { query } from "./bigquery";
import type { CountryName } from "./workspaces";

/**
 * What a territory lead is responsible for, read from the views that already hold it:
 *
 *   salesforce.customer_journey_app_v2
 *     one row per job with where it has reached (stage_class), how long it has sat
 *     there (days_in_stage), when building started, whose queue it is in
 *     (queue_owner) and whether materials have moved.
 *
 *   raw_data_from_salesforce.all_opportunities_master
 *     the mason on the job, the payment milestones and the install date, which is
 *     what makes a build late or on time.
 *
 *   raw_data_from_salesforce.bonus_tl_payout_by_month_territory
 *     the territory's own bonus: what it built against target, its on-time rate and
 *     what that pays.
 *
 * QA comes from the same tables and the same rule as the Quality pages, so a pass
 * rate here and there cannot disagree.
 */
const JOURNEY = "`earth-enable-main.salesforce.customer_journey_app_v2`";
const OPPS = "`earth-enable-main.raw_data_from_salesforce.all_opportunities_master`";
/** The opportunity itself, for the day construction actually started. */
const OPPORTUNITY = "`earth-enable-main.salesforce.opportunity`";
/**
 * The project, which Salesforce calls a work order. It carries the masons on the
 * build and the square metres each was given: Rwanda puts one mason on a project,
 * Uganda often two or more, up to four.
 *
 * `masons_c` is the names already joined for display, separated by <br>, and
 * `first..fourth_mason_sqm_c` are their shares. The name list is split back apart
 * here rather than shown as markup.
 */
const WORK_ORDER = "`earth-enable-main.salesforce.work_order`";
const BONUS = "`earth-enable-main.raw_data_from_salesforce.bonus_tl_payout_by_month_territory`";
const QA = "`earth-enable-main.raw_data_from_salesforce.all_qa_evaluations_clean`";
const EVALS = "`earth-enable-main.salesforce.qa_evals_all`";
/**
 * The mason timesheet, placed in its unit the way the capacity page places it:
 * Rwanda by territory, Uganda and Kenya by the branch on the line's location and
 * failing that the line's district, which outside Rwanda is itself a branch.
 */
const TIMESHEET = "`earth-enable-main.raw_data_from_salesforce.mason_timesheet_readable`";
const LOCATION = "`earth-enable-main.salesforce.location_c`";

/**
 * The company's productive rule, copied from capacity_mason_week, which copied it
 * from productive_masons_monthly and the TL bonus. A mason is productive over a
 * window when their approved gross pay in it clears the country's weekly bar times
 * the number of Wednesdays the window holds. Change these in productive_masons_monthly
 * first. Weeks 1 to 3 hold one Wednesday; week 4 runs to month end and holds two in
 * some months, so its bar doubles then, which is what the bonus does too.
 */
const WEEKLY_THRESHOLD: Record<CountryName, number> = { Rwanda: 25000, Uganda: 62500, Kenya: 2500 };
/**
 * The capacity function Built and Sold are read from, so a territory shows the
 * same figures here as on the capacity page. One row per unit per week set; this
 * page reads the single weeks and adds the ones its window covers, which is right
 * for a month, one of its four weeks, or a quarter alike.
 */
const CAPACITY = "`earth-enable-main.raw_data_from_salesforce.capacity_week`";
/**
 * The target tables the capacity functions read: Rwanda by territory, Uganda and
 * Kenya by branch. Rwanda carries the Nyagatare rule, the same as the SQL in sql/:
 * from September 2026 the district target (A + B) is shared B one half, A one
 * quarter, C one quarter; before that C has no target.
 */
const TL = "`earth-enable-main.raw_data_from_salesforce.tl_bonus_targets`";
const TARGETS_RW = `(
  SELECT month, territory, district, n_territories, sqme_target, build_target, min_productive_masons, min_build_productivity, manager FROM ${TL}
  WHERE NOT (territory IN ('Nyagatare A', 'Nyagatare B', 'Nyagatare C') AND month >= DATE '2026-09-01')
  UNION ALL
  -- From September 2026 the Nyagatare district target (the official A + B) is
  -- shared B one half, A one quarter, C one quarter (regional manager,
  -- 2026-09-29). Nothing is added: district and country totals stay official.
  -- Before that, A and B keep their rows and C has no target.
  SELECT d.month, s.territory, d.district, 3 AS n_territories,
    d.sqme_target * s.share, d.build_target * s.share, d.min_productive_masons * s.share,
    d.min_build_productivity, d.manager
  FROM (
    SELECT month, ANY_VALUE(district) AS district, ANY_VALUE(manager) AS manager,
      SUM(sqme_target) AS sqme_target, SUM(build_target) AS build_target,
      SUM(min_productive_masons) AS min_productive_masons, ANY_VALUE(min_build_productivity) AS min_build_productivity
    FROM ${TL}
    WHERE territory IN ('Nyagatare A', 'Nyagatare B') AND month >= DATE '2026-09-01'
    GROUP BY month
  ) d
  CROSS JOIN UNNEST([STRUCT('Nyagatare A' AS territory, 0.25 AS share), ('Nyagatare B', 0.5), ('Nyagatare C', 0.25)]) s
)`;
const TARGETS_BRANCH = "`earth-enable-main.raw_data_from_salesforce.branch_capacity_targets`";

const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync


/**
 * How long a build may take before it is late.
 *
 * The clock starts the day building began. Where no start date exists at all it
 * starts instead at the payment milestone the country measures the product on.
 * Either way a floor has 30 days to run and plaster has 20.
 *
 * The milestone differs by country and product, and the column names do not follow
 * a pattern: Rwanda measures a floor from half the money and plaster from all of
 * it, Uganda and Kenya measure floor and plaster from three quarters, paint is
 * measured from all of it in every country, and anything else falls back to all of
 * it. The three-quarter date is `seventyfive_payment_made_c`, not one of the
 * `date_NN_of_total_payment_is_made_c` family it sits beside.
 *
 * 1970-01-01 is Salesforce's empty date here and is read as missing.
 */
const FLOOR_DAYS = 30;
const PLASTER_DAYS = 20;

/**
 * What the job actually is: the company's canonical classification
 * (sql/product_class.sql, through productClass) over the raw product string, old
 * field first. Repair is tested before paint and paint before plaster, so
 * "Plaster_Paint | DirectSale" is Paint and "Repair_Masking | DirectSale" is Repair.
 * The four named classes are the ones this page shows; House, Other and Unknown are
 * not named, and a House is not counted at all.
 */
const PC = productClass("COALESCE(o.product_interest, o.new_product_interest)");
const PRODUCT = `CASE WHEN ${PC} IN ('Floor', 'Plaster', 'Paint', 'Repair') THEN ${PC} END`;

const IS_FLOOR = `${PC} = 'Floor'`;
/**
 * The products judged on the plaster standard. Paint is a product of its own and is
 * named as one everywhere on the page, but it is built and paid for like plaster,
 * so it runs on the same 20-day clock and the same payment milestone.
 */
const ON_PLASTER_CLOCK = `${PC} IN ('Plaster', 'Paint')`;

const clean = (col: string) => `NULLIF(${col}, DATE '1970-01-01')`;
const MILESTONE = `CASE
  WHEN @country = 'Rwanda' AND ${IS_FLOOR}
    THEN ${clean("op.date_50_of_total_payment_is_made_c")}
  WHEN @country = 'Rwanda' AND ${ON_PLASTER_CLOCK}
    THEN ${clean("op.date_100_of_total_payment_is_made_c")}
  -- Paint needs the full payment in every country; only plaster opens at 75% in Uganda and Kenya.
  WHEN @country IN ('Uganda', 'Kenya') AND ${PC} = 'Paint'
    THEN ${clean("op.date_100_of_total_payment_is_made_c")}
  WHEN @country IN ('Uganda', 'Kenya')
    THEN ${clean("op.seventyfive_payment_made_c")}
  ELSE ${clean("op.date_100_of_total_payment_is_made_c")} END`;

/**
 * The day the clock starts on a build.
 *
 * The date construction actually started, where somebody filled it in. Where they
 * did not, a floor is counted from the day its insecticide or anti-termite moved,
 * because that is the material that has to be on site before work begins, and
 * plaster from the payment milestone its country measures it on.
 *
 * The journey view's own `started_date` is deliberately not used: it is the
 * earliest of five signals, including a materials delivery, so a delivery made
 * today puts "started" at today on a build nobody has touched.
 */
const START_ANCHOR = `COALESCE(
  op.actual_construction_start_date_c,
  IF(${IS_FLOOR},
     COALESCE(NULLIF(o.insecticide_movement_date, DATE '1970-01-01'),
              NULLIF(o.anti_termite_movement_date, DATE '1970-01-01')), NULL),
  IF(${ON_PLASTER_CLOCK}, ${MILESTONE}, NULL))`;

/** Which of the three the clock was started from, so a row can say so. */
const ANCHOR_KIND = `CASE
  WHEN op.actual_construction_start_date_c IS NOT NULL THEN 'start'
  WHEN ${IS_FLOOR}
   AND COALESCE(NULLIF(o.insecticide_movement_date, DATE '1970-01-01'),
                NULLIF(o.anti_termite_movement_date, DATE '1970-01-01')) IS NOT NULL THEN 'materials'
  WHEN ${ON_PLASTER_CLOCK} AND ${MILESTONE} IS NOT NULL THEN 'payment'
  END`;

/**
 * The day the clock starts, and what the product allows from there: a floor has 30
 * days, plaster 20. The allowance is the product's, not the anchor's, so a build
 * gets the same window whether it is counted from the day work began or, where that
 * was never recorded, from the payment milestone.
 */
const ALLOWED = `CASE
  WHEN ${IS_FLOOR} THEN ${FLOOR_DAYS}
  WHEN ${ON_PLASTER_CLOCK} THEN ${PLASTER_DAYS} END`;

/** Days past the allowance for a build with no completion date yet. */
const DAYS_LATE = `IF(o.completed_date IS NULL AND ${START_ANCHOR} IS NOT NULL,
  DATE_DIFF(CURRENT_DATE(), ${START_ANCHOR}, DAY) - ${ALLOWED}, NULL)`;


/**
 * What a build is waiting on, in the order the work actually happens. The first
 * rule that matches is the answer, so a build reports the earliest step it has not
 * cleared rather than every step still ahead of it.
 *
 * A floor: insecticide has to move, then compaction is evaluated, then screed once
 * compaction has passed, then varnish moves, then the final evaluation.
 * Plaster: prior paint is evaluated, then the paint or varnish moves depending on
 * whether the job is interior or exterior, then the final evaluation.
 *
 * "Paid" is the payment milestone its country measures the product on. A build that
 * has not reached it is waiting for payment, which is the first step of all.
 */
const WAITING_FOR = `CASE
  WHEN o.completed_date IS NOT NULL THEN NULL
  -- Nothing can start until the customer has paid the share their country and
  -- product is measured on, so that is the first thing a build waits for.
  WHEN ${MILESTONE} IS NULL THEN 'Waiting for payment'

  WHEN ${IS_FLOOR} AND NOT COALESCE(o.insecticide_moved, FALSE)
    THEN 'Waiting for insecticide movement'
  WHEN ${IS_FLOOR} AND COALESCE(ev.n_compaction, 0) = 0
    THEN 'Waiting for compaction'
  WHEN ${IS_FLOOR} AND COALESCE(ev.n_compaction_pass, 0) > 0
   AND COALESCE(ev.n_screed, 0) = 0
    THEN 'Waiting for screed evaluation'
  WHEN ${IS_FLOOR} AND COALESCE(ev.n_screed, 0) > 0
   AND ${clean("o.varnish_movement_date")} IS NULL
    THEN 'Waiting for varnish movement'
  WHEN ${IS_FLOOR} AND ${clean("o.varnish_movement_date")} IS NOT NULL
   AND COALESCE(ev.n_final, 0) = 0
    THEN 'Waiting for final evaluation'

  WHEN ${ON_PLASTER_CLOCK} AND COALESCE(ev.n_prior_paint, 0) = 0
    THEN 'Waiting for prior paint evaluation'
  WHEN ${ON_PLASTER_CLOCK} AND COALESCE(ev.n_prior_paint, 0) > 0
   AND ${clean("o.varnish_movement_date")} IS NULL
    THEN IF(CONTAINS_SUBSTR(o.product_interest, 'Interior'), 'Waiting for paint movement', 'Waiting for varnish movement')
  WHEN ${ON_PLASTER_CLOCK} AND ${clean("o.varnish_movement_date")} IS NOT NULL
   AND COALESCE(ev.n_final, 0) = 0
    THEN 'Waiting for final evaluation'
  END`;

/** The steps each build has cleared, for the rules above. */
const STEPS = `
  SELECT opportunity_id,
    COUNTIF(stage = 'Compaction') AS n_compaction,
    COUNTIF(stage = 'Compaction' AND primary_decision = 'Pass') AS n_compaction_pass,
    COUNTIF(stage = 'Screed') AS n_screed,
    COUNTIF(stage = 'Prior Paint') AS n_prior_paint,
    COUNTIF(stage = 'Final') AS n_final,
    -- When each step was last cleared, so a build can say how long it has waited
    -- for the step after it.
    MAX(IF(stage = 'Compaction' AND primary_decision = 'Pass', primary_eval_date, NULL)) AS compaction_pass_dt,
    MAX(IF(stage = 'Screed', primary_eval_date, NULL)) AS screed_dt,
    MAX(IF(stage = 'Prior Paint', primary_eval_date, NULL)) AS prior_paint_dt
  FROM ${QA} WHERE location_country = @country GROUP BY 1`;

/**
 * The day the wait began: the date of the step before the one the build is
 * waiting for. Read beside WAITING_FOR; each branch mirrors the branch there.
 * Waiting for compaction runs from the insecticide movement, screed from the
 * compaction pass, prior paint (and payment) from the payment milestone, the
 * varnish or paint movement from the evaluation that cleared the way for it,
 * and the final evaluation from the varnish movement.
 */
const WAITING_SINCE = `CASE
  WHEN o.completed_date IS NOT NULL THEN NULL
  WHEN ${MILESTONE} IS NULL THEN NULL
  WHEN ${IS_FLOOR} AND NOT COALESCE(o.insecticide_moved, FALSE) THEN ${MILESTONE}
  WHEN ${IS_FLOOR} AND COALESCE(ev.n_compaction, 0) = 0
    THEN COALESCE(${clean("o.insecticide_movement_date")}, ${clean("o.anti_termite_movement_date")}, ${MILESTONE})
  WHEN ${IS_FLOOR} AND COALESCE(ev.n_compaction_pass, 0) > 0 AND COALESCE(ev.n_screed, 0) = 0 THEN ev.compaction_pass_dt
  WHEN ${IS_FLOOR} AND COALESCE(ev.n_screed, 0) > 0 AND ${clean("o.varnish_movement_date")} IS NULL THEN ev.screed_dt
  WHEN ${IS_FLOOR} AND ${clean("o.varnish_movement_date")} IS NOT NULL AND COALESCE(ev.n_final, 0) = 0
    THEN ${clean("o.varnish_movement_date")}
  WHEN ${ON_PLASTER_CLOCK} AND COALESCE(ev.n_prior_paint, 0) = 0 THEN ${MILESTONE}
  WHEN ${ON_PLASTER_CLOCK} AND COALESCE(ev.n_prior_paint, 0) > 0 AND ${clean("o.varnish_movement_date")} IS NULL THEN ev.prior_paint_dt
  WHEN ${ON_PLASTER_CLOCK} AND ${clean("o.varnish_movement_date")} IS NOT NULL AND COALESCE(ev.n_final, 0) = 0
    THEN ${clean("o.varnish_movement_date")}
  END`;

/**
 * A deal that was lost is not a build. The journey view already leaves Closed Lost
 * out, and every query here joins through it, so none reach the page today. The
 * guard is written out anyway: relying on another view's filter is the kind of
 * thing that stops being true without anyone noticing.
 */
const IS_LIVE = `COALESCE(op.stage_name, '') != 'Closed Lost'`;

/**
 * The builds this page counts: the capacity planning page's own population, a
 * first-phase job that is not a full house. Capacity leaves later phases and full
 * houses out, and the build, SQM-E and mason targets are set for that population,
 * so counting anything else here would put every figure on the page against a
 * target that was never meant to cover it. Applying it to the whole page rather
 * than to Built and Sold alone is what keeps Completed and Built the same builds.
 */
const IN_SCOPE = `SAFE_CAST(o.opportunity_phase AS INT64) = 1
  AND ${PC} != 'House'`;

/**
 * Where a build has reached, on the business's own terms.
 *
 * Finished is the simple one: it has a completion date. Otherwise it is under way
 * if building began, or, where no start date exists at all, if the product's own
 * sign of having begun is there: insecticide moved for a floor, and a project
 * status of In Progress or On Hold for plaster. Anything else has not started.
 *
 * The order matters: a floor whose insecticide has moved but whose start date was
 * never recorded is under way, not waiting. Read the other way round every such
 * build would be counted as untouched.
 *
 * `associated_project_status` is the field carrying New, In Progress, On Hold and
 * Completed. `project_status` next to it is an evaluation decision despite the
 * name, and is not this.
 */
const BUILD_STATE = `CASE
  WHEN o.completed_date IS NOT NULL THEN 'finished'
  WHEN op.actual_construction_start_date_c IS NOT NULL THEN 'in_progress'
  WHEN ${IS_FLOOR} AND o.insecticide_moved THEN 'in_progress'
  -- Paint and repairs are read the same way plaster is: the project's own status.
  -- 'Other', which has no product at all, is left on the start date alone.
  WHEN ${PC} IN ('Plaster', 'Paint', 'Repair')
   AND o.associated_project_status IN ('In Progress', 'On Hold') THEN 'in_progress'
  ELSE 'not_started' END`;

/** The QA rule the Quality pages use: the QA Survey's own department, blank counting as QA. */
const IS_QA = `(e.department IS NULL
  OR (NOT CONTAINS_SUBSTR(e.department, 'District') AND NOT CONTAINS_SUBSTR(e.department, 'Construction')))`;
const QA_STAGES = ["Compaction", "Screed", "Prior Paint"];

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const str = (v: unknown): string => (v == null ? "" : String(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

export type TerritoryRow = {
  territory: string;
  branch: string;
  /** Signed and paying, but nobody has started building. */
  notStarted: number;
  /**
   * Building, finishing or in repairs right now, and what those builds are. The
   * four named classes come from the company's own product field; anything left
   * over is the 'Other' class, which genuinely has no product recorded.
   */
  inProgress: number;
  inProgressFloor: number;
  inProgressPlaster: number;
  inProgressPaint: number;
  inProgressRepair: number;
  /** Builds installed inside the window. */
  finished: number;
  /** Of those finished in the window, how many beat the allowance and how many did not. */
  finishedOnTime: number;
  finishedLate: number;
  /** Builds not finished whose clock has run out, and the worst of them. */
  runningLate: number;
  /** Of those, the ones nobody has started. */
  lateNotStarted: number;
  worstDaysLate: number | null;
  qaPassed: number;
  qaFailed: number;
  /** Jobs sitting in the territory lead's own queue, and ones waiting on materials. */
  pendingTl: number;
  pendingStock: number;
  /** Builds waiting on an evaluation or a stock movement. */
  pendingAction: number;
  masons: number;
  /**
   * Masons who worked here in the window, and how many of them were productive.
   * Both follow the capacity page: working is a timesheet line starting in the
   * window, productive is the company's pay threshold. See WEEKLY_THRESHOLD.
   */
  masonsWorking: number;
  productiveMasons: number;
  /**
   * Sold and built as the capacity page counts them, read from the same function
   * it reads, so a territory shows the same figures on both pages.
   */
  soldCount: number;
  soldSqme: number;
  builtCount: number;
  builtSqme: number;
  /**
   * False when the capacity planning page has no row for this unit at all, which
   * is how a territory with no published target reaches it. Built and Sold are then
   * unknown rather than zero, and the page says so instead of showing a 0 that
   * would read as "built nothing".
   */
  inCapacity: boolean;
  /** What the builds waiting on a step are waiting for, biggest reason first. */
  waitingBreakdown: { reason: string; count: number }[];
  /** The territory's bonus over the months the window covers. */
  sqmeBuilt: number;
  sqmeTarget: number;
  /**
   * What the window was asked for, from the capacity targets the rest of the app
   * already reads. null means no target is published for this unit and window, which
   * is not the same as a target of zero, so the card says so rather than showing 0.
   */
  builtSqmeTarget: number | null;
  soldCountTarget: number | null;
  productiveMasonsTarget: number | null;
  onTimeRate: number | null;
  bonusRwf: number;
};

export type TerritoryData = {
  rows: TerritoryRow[];
  /** Months of bonus the window covers, so the page can say what the money is for. */
  bonusMonths: number;
};

/** One build in a territory, for the panel under it. */
export type TerritoryBuild = {
  opportunityId: string;
  customer: string;
  job: string;
  product: string | null;
  /** "Not started" or "In progress". The list holds no other state. */
  stage: string;
  signedDate: string | null;
  startedDate: string | null;
  /**
   * Days the clock has been running: since building started, or since the payment
   * milestone where no start date was ever recorded.
   */
  daysSinceStart: number | null;
  /** Which date the count runs from: "start", "materials" or "payment". */
  anchorKind: string | null;
  /** Days past the allowance. Negative means still inside it. */
  daysLate: number | null;
  mason: string | null;
  cso: string | null;
  queue: string | null;
  materialsAvailable: boolean | null;
  /** The territory (Rwanda) or branch the build sits in. */
  territory: string;
  /** The next step this build is waiting on, or null when it is not waiting. */
  waitingFor: string | null;
  /** The day that wait began: the date of the step before, or the payment milestone. */
  waitingSince: string | null;
  daysWaiting: number | null;
  pctPaid: number | null;
  /** The contract's square metres, and the same in SQM-E. */
  rawSqm: number | null;
  sqme: number | null;
  /** Masons on the project, and the square metres each was given. */
  masonCount: number;
  masonNames: string[];
  masonSqm: number[];
  /** The build's own size, from the opportunity. */
  projectSqm: number | null;
};

/** Which slice of a territory's builds to list. */
export type BuildFilter =
  | "all" | "not-started" | "in-progress" | "pending" | "late" | "pending-tl" | "pending-stock";

/** Wednesdays in a window, the multiplier the productive bar scales by. */
function wednesdays(from: string, to: string): number {
  let n = 0;
  for (let d = new Date(`${from}T00:00:00Z`); d <= new Date(`${to}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + 1)) {
    if (d.getUTCDay() === 3) n += 1;
  }
  return n;
}

async function fetchTerritories(
  country: CountryName, from: string, to: string,
): Promise<TerritoryData> {
  const unitOf = country === "Rwanda" ? "j.territory" : "COALESCE(j.branch, 'Unassigned')";
  /** A job with no territory belongs to no lead, so it is left out of this page. */
  const hasUnit = country === "Rwanda" ? "AND j.territory IS NOT NULL" : "";
  const [rows, bonus, capacity, targets, masons, waiting, months] = await Promise.all([
    query<Record<string, unknown>>(
      `
      WITH j AS (
        SELECT j.*, ${unitOf} AS unit_name
        FROM ${JOURNEY} j
        WHERE j.country = @country ${hasUnit}
      ),
      ev AS (${STEPS}),
      o AS (
        SELECT o.opportunity_id, o.mason_id, o.mason_name, o.install_date, o.completed_date,
          ${PRODUCT} AS product, ${ALLOWED} AS allowed, ${DAYS_LATE} AS days_late,
          ${BUILD_STATE} AS build_state,
          ${START_ANCHOR} AS start_date, ${ANCHOR_KIND} AS anchor_kind,
          ${WAITING_FOR} AS waiting_for
        FROM ${OPPS} o
        LEFT JOIN ${OPPORTUNITY} op ON op.id = o.opportunity_id
        LEFT JOIN ev ON ev.opportunity_id = o.opportunity_id
        WHERE o.location_country = @country AND ${IS_LIVE} AND ${IN_SCOPE}
      ),
      qa AS (
        SELECT q.opportunity_id,
          COUNTIF(q.primary_decision = 'Pass') AS passed,
          COUNTIF(q.primary_decision IS NOT NULL AND q.primary_decision NOT IN ('Pass', 'Not Ready for Evaluation')) AS failed
        FROM ${QA} q
        LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
        WHERE q.location_country = @country
          AND q.primary_eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
          AND q.stage IN UNNEST(@stages)
          AND ${IS_QA}
        GROUP BY 1
      )
      SELECT j.unit_name AS territory,
        ANY_VALUE(j.branch) AS branch,
        COUNTIF(o.build_state = 'not_started') AS not_started,
        COUNTIF(o.build_state = 'in_progress') AS in_progress,
        COUNTIF(o.build_state = 'in_progress' AND o.product = 'Floor') AS in_progress_floor,
        COUNTIF(o.build_state = 'in_progress' AND o.product = 'Plaster') AS in_progress_plaster,
        COUNTIF(o.build_state = 'in_progress' AND o.product = 'Paint') AS in_progress_paint,
        COUNTIF(o.build_state = 'in_progress' AND o.product = 'Repair') AS in_progress_repair,
        COUNTIF(o.completed_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)) AS finished,
        COUNTIF(o.completed_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
                AND o.start_date IS NOT NULL AND DATE_DIFF(o.completed_date, o.start_date, DAY) <= o.allowed) AS finished_on_time,
        COUNTIF(o.completed_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
                AND o.start_date IS NOT NULL AND DATE_DIFF(o.completed_date, o.start_date, DAY) > o.allowed) AS finished_late,
        COUNTIF(o.build_state != 'finished' AND o.days_late > 0) AS running_late,
        COUNTIF(o.build_state = 'not_started' AND o.days_late > 0) AS late_not_started,
        MAX(IF(o.build_state != 'finished', o.days_late, NULL)) AS worst_days_late,
        SUM(COALESCE(qa.passed, 0)) AS qa_passed,
        SUM(COALESCE(qa.failed, 0)) AS qa_failed,
        COUNTIF(o.waiting_for IS NOT NULL) AS pending_action,
        COUNTIF(o.build_state != 'finished' AND j.queue_owner = 'TL') AS pending_tl,
        COUNTIF(o.build_state != 'finished' AND j.stage_class IN ('ready_to_build', 'building')
                AND j.materials_available IS NOT TRUE) AS pending_stock,
        COUNT(DISTINCT IF(o.build_state = 'in_progress', o.mason_name, NULL)) AS masons
      FROM j
      LEFT JOIN o ON o.opportunity_id = j.opportunity_id
      LEFT JOIN qa ON qa.opportunity_id = j.opportunity_id
      GROUP BY 1
    `,
      { country, from, to, stages: QA_STAGES },
    ),

    // The territory's bonus over the months the window touches.
    query<Record<string, unknown>>(
      `SELECT ${country === "Rwanda" ? "territory" : "branch"} AS territory,
         SUM(sqme_built) AS sqme_built, SUM(sqme_target) AS sqme_target,
         SAFE_DIVIDE(SUM(floors_ot_on_time), NULLIF(SUM(floors_ot_measured), 0)) AS ontime_rate,
         SUM(total_bonus_rwf) AS bonus_rwf
       FROM ${BONUS}
       WHERE country = @country
         AND month BETWEEN DATE_TRUNC(CAST(@from AS DATE), MONTH) AND CAST(@to AS DATE)
       GROUP BY 1`,
      { country, from, to },
    ),

    // Sold and built, read from the function the capacity page itself reads, so the
    // two pages cannot drift apart. Only the additive columns are summed across
    // weeks: the function's own distinct counts are taken per week set and must
    // never be added, so this does not touch them. The call is made with the
    // window's last month and returns the six before it, so a quarter is covered
    // by one call. Its targets are not used: this page computes the month's own
    // (below), so it is right whether or not the function in BigQuery has been
    // redeployed with the same rule.
    query<Record<string, unknown>>(
      `SELECT name AS territory,
         SUM(contracts_sold) AS contracts_sold,
         SUM(sqme_sold) AS sqme_sold,
         SUM(contracts_built) AS contracts_built,
         SUM(sqme_built) AS sqme_built
       FROM ${CAPACITY}(@country, DATE_TRUNC(CAST(@to AS DATE), MONTH))
       WHERE level = @level AND is_single_week
         AND week_start >= CAST(@from AS DATE) AND week_end <= CAST(@to AS DATE)
       GROUP BY 1`,
      { country, from, to, level: country === "Rwanda" ? "territory" : "branch" },
    ),

    // What the window was asked for, from the same target tables and the same
    // arithmetic as the capacity functions, but against each month's OWN target:
    // every single week in the window takes a quarter of its month's target, the
    // sales target is the build target times 1.3, and the mason requirement, a
    // staffing level rather than a total, is the window's last month's.
    query<Record<string, unknown>>(
      `WITH t AS (
         SELECT 'Rwanda' AS country, territory AS unit, month, sqme_target, build_target, min_productive_masons
         FROM ${TARGETS_RW} WHERE territory IS NOT NULL
         UNION ALL
         SELECT country, branch, month, sqme_target, build_target, min_productive_masons
         FROM ${TARGETS_BRANCH}
       ),
       wk AS (
         -- The four weeks of each month the window touches (1-7, 8-14, 15-21,
         -- 22 to month end), kept when the whole week lies inside the window.
         SELECT m AS month, COUNT(*) AS n_weeks
         FROM UNNEST(GENERATE_DATE_ARRAY(DATE_TRUNC(CAST(@from AS DATE), MONTH), DATE_TRUNC(CAST(@to AS DATE), MONTH), INTERVAL 1 MONTH)) m,
           UNNEST([1, 2, 3, 4]) w
         WHERE DATE_ADD(m, INTERVAL (w - 1) * 7 DAY) >= CAST(@from AS DATE)
           AND IF(w = 4, LAST_DAY(m), DATE_ADD(m, INTERVAL w * 7 - 1 DAY)) <= CAST(@to AS DATE)
         GROUP BY 1
       )
       SELECT t.unit AS territory,
         SUM(t.sqme_target * 0.25 * wk.n_weeks) AS sqme_target,
         SUM(t.build_target * 1.3 * 0.25 * wk.n_weeks) AS sales_target,
         ANY_VALUE(t.min_productive_masons HAVING MAX t.month) AS min_masons
       FROM t JOIN wk USING (month)
       WHERE t.country = @country
       GROUP BY 1`,
      { country, from, to },
    ),

    // Masons who worked here, and how many were productive, on the company's own
    // rule. Distinct counts are taken over the whole window at once rather than per
    // week, so a mason working three weeks is one mason.
    query<Record<string, unknown>>(
      `WITH ts AS (
         SELECT
           IF(t.country = 'Rwanda', t.territory, COALESCE(NULLIF(TRIM(l.branch_c), ''), t.district)) AS unit,
           t.mason_id,
           t.start_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE) AS worked,
           IF(NOT t.is_deleted AND t.status = 'Approved'
              AND t.end_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE),
              IFNULL(t.amount_of_payment, 0.0), 0.0) AS pay
         FROM ${TIMESHEET} t
         LEFT JOIN ${LOCATION} l ON l.id = t.location_id AND t.country != 'Rwanda'
         WHERE t.country = @country AND NOT t.fivetran_deleted AND t.mason_id IS NOT NULL
           AND (t.start_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
             OR t.end_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE))
       ),
       per_mason AS (
         SELECT unit, mason_id, LOGICAL_OR(worked) AS worked, SUM(pay) AS earnings
         FROM ts WHERE unit IS NOT NULL GROUP BY 1, 2
       )
       SELECT unit AS territory,
         COUNT(DISTINCT IF(worked, mason_id, NULL)) AS masons_working,
         COUNT(DISTINCT IF(earnings >= @bar, mason_id, NULL)) AS productive_masons
       FROM per_mason GROUP BY 1`,
      { country, from, to, bar: WEEKLY_THRESHOLD[country] * wednesdays(from, to) },
    ),

    // What each unit's waiting builds are waiting for, from the same rule the
    // counts above use, so the parts always add up to the whole.
    query<Record<string, unknown>>(
      `WITH ev AS (${STEPS}),
       o AS (
         SELECT o.opportunity_id, ${WAITING_FOR} AS waiting_for
         FROM ${OPPS} o
         LEFT JOIN ${OPPORTUNITY} op ON op.id = o.opportunity_id
         LEFT JOIN ev ON ev.opportunity_id = o.opportunity_id
         WHERE o.location_country = @country AND ${IS_LIVE} AND ${IN_SCOPE}
       )
       SELECT ${unitOf} AS territory, o.waiting_for AS reason, COUNT(*) AS n
       FROM ${JOURNEY} j
       JOIN o ON o.opportunity_id = j.opportunity_id
       WHERE j.country = @country ${hasUnit} AND o.waiting_for IS NOT NULL
       GROUP BY 1, 2`,
      { country },
    ),

    query<Record<string, unknown>>(
      `SELECT COUNT(DISTINCT month) AS n FROM ${BONUS}
       WHERE country = @country
         AND month BETWEEN DATE_TRUNC(CAST(@from AS DATE), MONTH) AND CAST(@to AS DATE)`,
      { country, from, to },
    ),
  ]);

  const byUnit = new Map(bonus.map((b) => [str(b.territory), b]));
  const capOf = new Map(capacity.map((c) => [str(c.territory), c]));
  const tgtOf = new Map(targets.map((t) => [str(t.territory), t]));
  const masonOf = new Map(masons.map((m) => [str(m.territory), m]));
  const waitOf = new Map<string, { reason: string; count: number }[]>();
  for (const w of waiting) {
    const list = waitOf.get(str(w.territory)) ?? [];
    list.push({ reason: str(w.reason), count: num(w.n) });
    waitOf.set(str(w.territory), list);
  }
  for (const list of waitOf.values()) list.sort((a, b) => b.count - a.count);
  return {
    bonusMonths: num(months[0]?.n),
    rows: rows.map((r) => {
      const b = byUnit.get(str(r.territory));
      const c = capOf.get(str(r.territory));
      const tg = tgtOf.get(str(r.territory));
      const m = masonOf.get(str(r.territory));
      return {
        territory: str(r.territory),
        branch: str(r.branch),
        notStarted: num(r.not_started),
        inProgress: num(r.in_progress),
        inProgressFloor: num(r.in_progress_floor),
        inProgressPlaster: num(r.in_progress_plaster),
        inProgressPaint: num(r.in_progress_paint),
        inProgressRepair: num(r.in_progress_repair),
        finished: num(r.finished),
        finishedOnTime: num(r.finished_on_time),
        finishedLate: num(r.finished_late),
        runningLate: num(r.running_late),
        lateNotStarted: num(r.late_not_started),
        worstDaysLate: numOrNull(r.worst_days_late),
        qaPassed: num(r.qa_passed),
        qaFailed: num(r.qa_failed),
        pendingAction: num(r.pending_action),
        pendingTl: num(r.pending_tl),
        pendingStock: num(r.pending_stock),
        masons: num(r.masons),
        masonsWorking: num(m?.masons_working),
        productiveMasons: num(m?.productive_masons),
        soldCount: num(c?.contracts_sold),
        soldSqme: num(c?.sqme_sold),
        builtCount: num(c?.contracts_built),
        builtSqme: num(c?.sqme_built),
        inCapacity: c != null,
        waitingBreakdown: waitOf.get(str(r.territory)) ?? [],
        sqmeBuilt: num(b?.sqme_built),
        sqmeTarget: num(b?.sqme_target),
        builtSqmeTarget: numOrNull(tg?.sqme_target),
        soldCountTarget: numOrNull(tg?.sales_target),
        productiveMasonsTarget: numOrNull(tg?.min_masons),
        onTimeRate: numOrNull(b?.ontime_rate),
        bonusRwf: num(b?.bonus_rwf),
      };
    }),
  };
}

export const getTerritories = unstable_cache(fetchTerritories, ["territory-v25"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/**
 * The builds behind one territory's figures, worst first, or a whole country's
 * when `territory` is "". `reason` narrows the
 * pending slice to one waiting state, empty meaning all of them. It is bound as a
 * parameter, never interpolated, so it cannot reach the query as free text. An
 * empty string rather than null keeps it typed: BigQuery cannot infer a null's type.
 */
async function fetchTerritoryBuilds(
  country: CountryName, territory: string, filter: BuildFilter, limit: number,
  reason = "",
): Promise<TerritoryBuild[]> {
  const unitOf = country === "Rwanda" ? "j.territory" : "COALESCE(j.branch, 'Unassigned')";
  const where: Record<BuildFilter, string> = {
    all: "",
    "not-started": "AND o.build_state = 'not_started'",
    "in-progress": "AND o.build_state = 'in_progress'",
    pending: "AND o.waiting_for IS NOT NULL AND (@reason = '' OR o.waiting_for = @reason)",
    late: "AND o.build_state != 'finished' AND o.days_late > 0",
    "pending-tl": "AND j.queue_owner = 'TL'",
    "pending-stock": "AND j.stage_class IN ('ready_to_build', 'building') AND j.materials_available IS NOT TRUE",
  };

  const rows = await query<Record<string, unknown>>(
    `
    WITH ev AS (${STEPS}),
    o AS (
      SELECT o.opportunity_id, o.mason_name, o.install_date, o.completed_date, ${PRODUCT} AS product,
        ${DAYS_LATE} AS days_late, ${BUILD_STATE} AS build_state,
        ${START_ANCHOR} AS start_date, ${ANCHOR_KIND} AS anchor_kind,
        ${WAITING_FOR} AS waiting_for, ${WAITING_SINCE} AS waiting_since
      FROM ${OPPS} o
      LEFT JOIN ${OPPORTUNITY} op ON op.id = o.opportunity_id
      LEFT JOIN ev ON ev.opportunity_id = o.opportunity_id
      WHERE o.location_country = @country AND ${IS_LIVE} AND ${IN_SCOPE}
    ),
    w AS (
      SELECT op.id AS opportunity_id,
        wo.number_of_masons_assigned_c AS mason_count,
        wo.masons_c AS mason_names,
        -- BigQuery arrays cannot hold a null, and the position has to keep matching
        -- the name at the same index, so an unset share becomes 0 rather than dropping out.
        [COALESCE(wo.first_mason_sqm_c, 0), COALESCE(wo.second_mason_sqm_c, 0),
         COALESCE(wo.third_mason_sqm_c, 0), COALESCE(wo.fourth_mason_sqm_c, 0)] AS mason_sqm,
        wo.square_meters_from_opportunity_c AS project_sqm
      FROM ${OPPORTUNITY} op
      JOIN ${WORK_ORDER} wo ON wo.id = op.associated_project_c
      WHERE op.country_c = @country
    )
    SELECT j.opportunity_id, j.customer_name, j.opportunity_label, o.product,
      IF(o.build_state = 'in_progress', 'In progress', 'Not started') AS stage,
      CAST(j.signed_date AS STRING) AS signed_date,
      CAST(o.start_date AS STRING) AS started_date,
      -- Today minus the day the clock started: the start date, or the payment
      -- milestone where there is none. Days late is this less the deadline, so the
      -- two columns are the same clock read twice.
      DATE_DIFF(CURRENT_DATE(), o.start_date, DAY) AS days_since_start,
      o.anchor_kind,
      o.days_late, o.waiting_for, CAST(o.waiting_since AS STRING) AS waiting_since,
      DATE_DIFF(CURRENT_DATE(), o.waiting_since, DAY) AS days_waiting,
      ${unitOf} AS unit_name,
      o.mason_name, j.cso_name, j.queue_owner, j.materials_available,
      j.pct_paid, j.raw_sqm, j.sqme,
      w.mason_count, w.mason_names, w.mason_sqm, w.project_sqm
    FROM ${JOURNEY} j
    LEFT JOIN o ON o.opportunity_id = j.opportunity_id
    LEFT JOIN w ON w.opportunity_id = j.opportunity_id
    WHERE j.country = @country
      -- An empty territory asks for the whole country: the journey board's drawer does.
      AND (@territory = '' OR ${unitOf} = @territory)
      AND o.build_state != 'finished'
      ${where[filter]}
    ORDER BY days_since_start ASC NULLS LAST, j.signed_date
    LIMIT @limit
  `,
    { country, territory, limit, reason },
  );

  return rows.map((r) => ({
    opportunityId: str(r.opportunity_id),
    customer: str(r.customer_name),
    job: str(r.opportunity_label),
    product: strOrNull(r.product),
    stage: str(r.stage),
    signedDate: strOrNull(r.signed_date),
    startedDate: strOrNull(r.started_date),
    daysSinceStart: numOrNull(r.days_since_start),
    anchorKind: strOrNull(r.anchor_kind),
    daysLate: numOrNull(r.days_late),
    mason: strOrNull(r.mason_name),
    cso: strOrNull(r.cso_name),
    queue: strOrNull(r.queue_owner),
    materialsAvailable: r.materials_available == null ? null : Boolean(r.materials_available),
    territory: str(r.unit_name),
    waitingFor: strOrNull(r.waiting_for),
    waitingSince: strOrNull(r.waiting_since),
    daysWaiting: numOrNull(r.days_waiting),
    pctPaid: numOrNull(r.pct_paid),
    rawSqm: numOrNull(r.raw_sqm),
    sqme: numOrNull(r.sqme),
    masonCount: num(r.mason_count),
    // The names arrive as one display string; split it and drop the blanks.
    masonNames: str(r.mason_names).split("<br>").map((n) => n.trim()).filter(Boolean),
    // Kept in order, so index i is the share of the mason named at index i.
    masonSqm: (Array.isArray(r.mason_sqm) ? r.mason_sqm : []).map(num),
    projectSqm: numOrNull(r.project_sqm),
  }));
}

/**
 * One unit's builds waiting on one step: how many, their size, and how long they
 * have waited. The journey board's pending cards read this, so a card there and
 * the Territory Leads page count the same houses by the same rule.
 */
export type WaitingRow = {
  country: CountryName;
  /** The territory (Rwanda) or branch. */
  territory: string;
  reason: string;
  count: number;
  sqme: number;
  over30: number;
  oldest: number;
  /** Days waiting, in the board's four bands: up to 30, 31 to 60, 61 to 90, over 90. */
  ageBands: [number, number, number, number];
};

async function fetchWaitingByUnit(country: CountryName): Promise<WaitingRow[]> {
  const unitOf = country === "Rwanda" ? "j.territory" : "COALESCE(j.branch, 'Unassigned')";
  const hasUnit = country === "Rwanda" ? "AND j.territory IS NOT NULL" : "";
  const rows = await query<Record<string, unknown>>(
    `WITH ev AS (${STEPS}),
     o AS (
       SELECT o.opportunity_id, ${WAITING_FOR} AS waiting_for,
         DATE_DIFF(CURRENT_DATE(), ${WAITING_SINCE}, DAY) AS days_waiting
       FROM ${OPPS} o
       LEFT JOIN ${OPPORTUNITY} op ON op.id = o.opportunity_id
       LEFT JOIN ev ON ev.opportunity_id = o.opportunity_id
       WHERE o.location_country = @country AND ${IS_LIVE} AND ${IN_SCOPE}
     )
     SELECT ${unitOf} AS territory, o.waiting_for AS reason, COUNT(*) AS n,
       SUM(COALESCE(j.sqme, 0)) AS sqme,
       COUNTIF(o.days_waiting > 30) AS over30, MAX(o.days_waiting) AS oldest,
       COUNTIF(o.days_waiting <= 30 OR o.days_waiting IS NULL) AS b1,
       COUNTIF(o.days_waiting BETWEEN 31 AND 60) AS b2,
       COUNTIF(o.days_waiting BETWEEN 61 AND 90) AS b3,
       COUNTIF(o.days_waiting > 90) AS b4
     FROM ${JOURNEY} j
     JOIN o ON o.opportunity_id = j.opportunity_id
     WHERE j.country = @country ${hasUnit} AND o.waiting_for IS NOT NULL
     GROUP BY 1, 2`,
    { country },
  );
  return rows.map((r) => ({
    country, territory: str(r.territory), reason: str(r.reason), count: num(r.n), sqme: num(r.sqme),
    over30: num(r.over30), oldest: num(r.oldest), ageBands: [num(r.b1), num(r.b2), num(r.b3), num(r.b4)],
  }));
}

export const getWaitingByUnit = unstable_cache(fetchWaitingByUnit, ["territory-waiting-v3"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

export const getTerritoryBuilds = unstable_cache(fetchTerritoryBuilds, ["territory-builds-v24"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
