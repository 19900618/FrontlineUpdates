import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import type { CountryName } from "./workspaces";

/**
 * Quality (QA) for one country. The app is a thin reader of the company's own
 * cleaned evaluation table, which already carries the country, the branch, the
 * stage, the evaluator, the mason, the CSO and both the QA and the manager
 * decision:
 *   raw_data_from_salesforce.all_qa_evaluations_clean
 * Country is pushed into the scan itself, never filtered in the browser, so a
 * country's page can only ever read that country's rows.
 *
 * Pending work comes from the journey view, which knows where each job is and
 * how long it has waited there:
 *   salesforce.customer_journey_app_v2
 *
 * Uganda's evaluation rows carry the branch with a " Branch" suffix, and a few
 * districts that have no branch yet arrive as "<district>-TBD". The suffix is
 * stripped here with the same expression the capacity SQL uses on
 * branch_targets, so a branch is named the same on every page and a link from
 * one to another lands where it should. The -TBD rows are left as they are:
 * they are genuinely unassigned in Salesforce, and hiding that would be worse.
 *
 * A decision is one of Pass, Not Ready for Evaluation, or a rework instruction
 * (Repair minor issues, Redo, Repair Masking, Repair VX, Intervention is
 * needed, Red line house). Pass is a pass; "not ready" is a wasted visit, the
 * job was not finished; everything else is a fail. `primary_pass_flag` agrees
 * with that split on every row, which is why the wording below is safe.
 */
const QA = "`earth-enable-main.raw_data_from_salesforce.all_qa_evaluations_clean`";
/**
 * Rwanda is run by territory and the evaluation rows do not carry one, so they
 * reach it through the journey view on the opportunity: 6,244 of 6,246 September
 * evaluations land on a territory. Uganda and Kenya are run by branch, which the
 * evaluation row already has, and their journey rows mostly have no territory at
 * all, so for them the unit is the branch.
 */
const JOURNEY = "`earth-enable-main.salesforce.customer_journey_app_v2`";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

/** "Jinja Branch" -> "Jinja", matching every other page. */
const BRANCH = "COALESCE(NULLIF(TRIM(REGEXP_REPLACE(branch, r'\\s*Branch$', '')), ''), 'Unassigned')";
/**
 * The same branch, written against the evaluation table by name. The rows query joins
 * the journey view, which carries a branch of its own, so a bare `branch` there is
 * ambiguous and BigQuery refuses the query.
 */
const BRANCH_Q = "COALESCE(NULLIF(TRIM(REGEXP_REPLACE(q.branch, r'\\s*Branch$', '')), ''), 'Unassigned')";

/**
 * What counts as a QA check when the evaluations themselves are listed: one of the
 * three construction stages, carried out by QA.
 *
 * Whether it was QA is decided by the department on the QA Survey itself, not by
 * the department on the evaluator's contact record. They are different fields and
 * they disagree: the contact carries things like Operations, Field staff and
 * Temporary Worker, while the survey carries Quality Assurance or District
 * Construction Team, which is the split that matters. The clean table only has the
 * contact one, so the survey's department is read from the evaluation layer, joined
 * on the survey id. Every row joins.
 *
 * Reading the survey's department rather than the evaluator's job title also
 * catches the ones a job title misses: 1,012 District Construction Team
 * evaluations in Rwanda last month have no role on their contact at all.
 *
 * This narrows the listing only. The counts in the table above it still cover every
 * evaluation at every stage, by everyone.
 */
const EVALS = "`earth-enable-main.salesforce.qa_evals_all`";
/**
 * The mason on the job. The evaluation rows carry a mason_name column, but it is
 * empty on every evaluation at every stage, so the mason is read from the
 * opportunity itself, which has one row per job and names a mason on all but two
 * of last month's evaluated houses.
 */
const OPPS = "`earth-enable-main.raw_data_from_salesforce.all_opportunities_master`";
/** The varnish pipeline and the customer cases, for the table's other columns. */
const VARNISH = "`earth-enable-main.raw_data_from_salesforce.Varnish_movement_status`";
const CASES = "`earth-enable-main.raw_data_from_salesforce.all_cases_clean`";
const QA_CHECK_STAGES = ["Compaction", "Screed", "Prior Paint"];
const IS_QA_CHECK = `q.stage IN UNNEST(@stages)
      AND (e.department IS NULL
        OR (NOT CONTAINS_SUBSTR(e.department, 'District') AND NOT CONTAINS_SUBSTR(e.department, 'Construction')))`;

/** Compaction leads to screed, screed to prior paint, prior paint to the final check. */
const NEXT_STAGE = `CASE stage
  WHEN 'Compaction' THEN 'Screed'
  WHEN 'Screed' THEN 'Prior Paint'
  WHEN 'Prior Paint' THEN 'Final'
  END`;

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

/** Which cut of the evaluations a row counts: the whole country, or one branch, stage, evaluator or mason. */
export type QualityDim = "total" | "unit" | "branch" | "stage" | "evaluator" | "mason" | "month";

export type QualityGroup = {
  dim: QualityDim;
  name: string;
  evals: number;
  passed: number;
  /** A visit that found the job unfinished. Not a fail: a wasted trip. */
  notReady: number;
  failed: number;
  jobs: number;
  evaluators: number;
  masons: number;
  /** Evaluations a manager re-checked, and how often the two agreed. */
  spotChecked: number;
  agreed: number;
  avgDaysSignedToEval: number | null;
  /** The branch a territory belongs to, when all its checks agree on one. */
  parent: string | null;
};

/**
 * The other things worth knowing about a territory or branch, beside its checks.
 * Each comes from the source that owns it, keyed to the same unit name, so the
 * table can carry them without any of them being derived from the evaluations.
 */
export type QualityExtra = {
  dim: "unit" | "branch";
  name: string;
  /** Varnished, waiting period served, final evaluation not yet passed. A snapshot. */
  waitingFinal: number;
  /** Territory lead decisions paired with the QA decision that followed. */
  tlPairs: number;
  tlMatched: number;
  /** Customer cases raised in this window. */
  casesRaised: number;
  casesClosed: number;
  casesOpen: number;
};

export type QualityPending = {
  stage: string;
  jobs: number;
  avgDays: number;
  over60: number;
  over180: number;
};

/** One month of the country's record, for the six-month trend above the table. */
export type QualityTrend = { month: string; evals: number; passed: number; spotChecked: number; agreed: number };

export type QualityData = {
  groups: QualityGroup[];
  /**
   * Houses QA sent back in this window that nobody has cleared since: no district
   * evaluation has passed the same stage and no evaluation has happened at the
   * stage after it. The same rule the panel under a territory uses.
   */
  sentBackOutstanding: number;
  extras: QualityExtra[];
  trend: QualityTrend[];
  pending: QualityPending[];
};

const groupRow = (r: Record<string, unknown>): QualityGroup => ({
  dim: String(r.dim) as QualityDim,
  name: String(r.name),
  evals: num(r.evals),
  passed: num(r.passed),
  notReady: num(r.not_ready),
  failed: num(r.failed),
  jobs: num(r.jobs),
  evaluators: num(r.evaluators),
  masons: num(r.masons),
  spotChecked: num(r.spot_checked),
  agreed: num(r.agreed),
  avgDaysSignedToEval: numOrNull(r.avg_days_signed_to_eval),
  parent: strOrNull(r.parent),
});

/**
 * Every cut the page shows, in one query: the country total, then each branch,
 * stage, evaluator, mason and month. Each cut is counted from the rows
 * themselves, so a branch is never the sum of its evaluators.
 */
async function fetchQuality(
  country: CountryName, from: string, to: string,
  /** Narrow the outstanding-rework count to one branch or territory, as the page is. */
  unit: { level: "branch" | "territory"; name: string } | null = null,
): Promise<QualityData> {
  const unitName = unit?.name ?? "";
  const agg = `
      COUNT(*) AS evals,
      COUNTIF(primary_decision = 'Pass') AS passed,
      COUNTIF(primary_decision = 'Not Ready for Evaluation') AS not_ready,
      COUNTIF(primary_decision IS NOT NULL AND primary_decision NOT IN ('Pass', 'Not Ready for Evaluation')) AS failed,
      COUNT(DISTINCT opportunity_id) AS jobs,
      COUNT(DISTINCT evaluator_id) AS evaluators,
      COUNT(DISTINCT mason_id) AS masons,
      COUNTIF(SAFE_CAST(was_spot_checked AS INT64) = 1) AS spot_checked,
      COUNTIF(SAFE_CAST(decisions_match AS INT64) = 1) AS agreed,
      ROUND(AVG(days_signed_to_eval), 1) AS avg_days_signed_to_eval,
      -- The branch a territory sits in, for the line under its name. Named only when
      -- every one of its checks agrees; one territory this month spans two branches.
      IF(COUNT(DISTINCT ${BRANCH}) = 1, ANY_VALUE(${BRANCH}), NULL) AS parent`;

  // The unit a country is managed by: Rwanda's territory, else the branch itself.
  const unitExpr = country === "Rwanda" ? "j.territory" : BRANCH_Q;
  const unitJoin = country === "Rwanda"
    ? `LEFT JOIN ${JOURNEY} j ON j.opportunity_id = q.opportunity_id`
    : "";

  /** Reach a territory the same way the evaluations do: through the job's journey row. */
  const unitOf = (alias: string) =>
    country === "Rwanda" ? `jj.territory` : `COALESCE(NULLIF(TRIM(REGEXP_REPLACE(${alias}.branch, r'\\s*Branch$', '')), ''), 'Unassigned')`;
  const unitJoinOf = (alias: string) =>
    country === "Rwanda" ? `LEFT JOIN ${JOURNEY} jj ON jj.opportunity_id = ${alias}.opportunity_id` : "";
  const branchOf = (alias: string) =>
    `COALESCE(NULLIF(TRIM(REGEXP_REPLACE(${alias}.branch, r'\\s*Branch$', '')), ''), 'Unassigned')`;

  const [groups, extras, outstanding, trend, pending] = await Promise.all([
    query<Record<string, unknown>>(
      `
      WITH ev AS (
        SELECT q.*, ${unitExpr} AS unit_name
        FROM ${QA} q
        ${unitJoin}
        LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
        WHERE q.location_country = @country
          AND q.primary_eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
          AND ${IS_QA_CHECK}
      )
      SELECT 'total' AS dim, 'All' AS name, ${agg} FROM ev
      UNION ALL SELECT 'unit', unit_name, ${agg} FROM ev WHERE unit_name IS NOT NULL GROUP BY 2
      UNION ALL SELECT 'branch', ${BRANCH}, ${agg} FROM ev GROUP BY 2
      ORDER BY dim, evals DESC
    `,
      { country, from, to, stages: QA_CHECK_STAGES },
    ),
    // Waiting for final, TL agreement and customer cases, per unit and per branch.
    // Each is counted in the source that owns it and keyed to the unit name, so none
    // of them is derived from the evaluations and none can be summed out of them.
    query<Record<string, unknown>>(
      `
      WITH passed_final AS (
        SELECT DISTINCT opportunity_id FROM ${EVALS}
        WHERE is_pass AND CONTAINS_SUBSTR(LOWER(eval_stage_key), 'final')
      ),
      waiting AS (
        SELECT ${country === "Rwanda" ? "v.territory" : branchOf("v")} AS unit_name,
          ${branchOf("v")} AS branch_name, COUNT(*) AS n
        FROM ${VARNISH} v
        LEFT JOIN passed_final pf ON pf.opportunity_id = v.opportunity_id
        WHERE v.country = @country AND v.is_varnished AND v.ready_for_final_evaluation
          -- A house that has already passed a final evaluation is not waiting for one.
          -- The pipeline view's own flag lets one such house through, so it is named here.
          AND pf.opportunity_id IS NULL
        GROUP BY 1, 2
      ),
      -- A district evaluation and the QA evaluation immediately after it on the same
      -- house and stage, with nothing in between. The company's pairing view reaches
      -- past intervening evaluations, so the table would disagree with the scorecard
      -- that now counts consecutive pairs.
      ev_all AS (
        SELECT opportunity_id, eval_stage_key, eval_date, created_date, survey_id, is_pass, branch,
          (department IS NULL
            OR (NOT CONTAINS_SUBSTR(department, 'District') AND NOT CONTAINS_SUBSTR(department, 'Construction'))) AS is_qa
        FROM ${EVALS} WHERE country = @country
      ),
      adjacent AS (
        SELECT *, LAG(is_qa) OVER w AS prev_is_qa, LAG(is_pass) OVER w AS prev_is_pass
        FROM ev_all
        WINDOW w AS (PARTITION BY opportunity_id, eval_stage_key ORDER BY eval_date, created_date, survey_id)
      ),
      pairs AS (
        SELECT ${unitOf("m")} AS unit_name, ${branchOf("m")} AS branch_name,
          COUNT(*) AS n, COUNTIF(m.prev_is_pass = m.is_pass) AS matched
        FROM adjacent m
        ${unitJoinOf("m")}
        WHERE m.is_qa AND m.prev_is_qa = FALSE
          AND m.prev_is_pass IS NOT NULL AND m.is_pass IS NOT NULL
          AND m.eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
        GROUP BY 1, 2
      ),
      -- Open cases, whenever they were raised, which is what the scorecard counts.
      -- This used to count closures inside the window, so the table and the card
      -- carried two different meanings under one name.
      cases AS (
        SELECT ${unitOf("c")} AS unit_name, ${branchOf("c")} AS branch_name,
          COUNT(*) AS n, 0 AS closed
        FROM ${CASES} c
        ${unitJoinOf("c")}
        WHERE c.location_country = @country AND NOT c.case_is_closed
        GROUP BY 1, 2
      ),
      keyed AS (
        SELECT 'unit' AS dim, unit_name AS name, n AS waiting, 0 AS pairs, 0 AS matched, 0 AS raised, 0 AS closed FROM waiting
        UNION ALL SELECT 'branch', branch_name, n, 0, 0, 0, 0 FROM waiting
        UNION ALL SELECT 'unit', unit_name, 0, n, matched, 0, 0 FROM pairs
        UNION ALL SELECT 'branch', branch_name, 0, n, matched, 0, 0 FROM pairs
        UNION ALL SELECT 'unit', unit_name, 0, 0, 0, n, closed FROM cases
        UNION ALL SELECT 'branch', branch_name, 0, 0, 0, n, closed FROM cases
      )
      SELECT dim, name, SUM(waiting) AS waiting, SUM(pairs) AS pairs, SUM(matched) AS matched,
        SUM(raised) AS raised, SUM(closed) AS closed
      FROM keyed GROUP BY dim, name
    `,
      { country, from, to },
    ),
    // The country's outstanding rework, counted the same way the panel under a
    // territory counts its own.
    query<Record<string, unknown>>(
      `
      WITH ev AS (
        SELECT q.qa_survey_id, q.opportunity_id, q.stage, q.primary_decision, q.primary_eval_date,
          ${unit?.level === "territory" ? "oj.territory" : BRANCH_Q} AS unit_name,
          (e.department IS NULL
            OR (NOT CONTAINS_SUBSTR(e.department, 'District') AND NOT CONTAINS_SUBSTR(e.department, 'Construction'))) AS is_qa
        FROM ${QA} q
        ${unit?.level === "territory" ? `LEFT JOIN ${JOURNEY} oj ON oj.opportunity_id = q.opportunity_id` : ""}
        LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
        WHERE q.location_country = @country
      ),
      sent_back AS (
        SELECT *, ${NEXT_STAGE} AS next_stage FROM ev
        WHERE is_qa AND stage IN UNNEST(@stages)
          AND primary_decision IS NOT NULL
          AND primary_decision NOT IN ('Pass', 'Not Ready for Evaluation')
          AND primary_eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
          ${unit ? "AND unit_name = @unitName" : ""}
      ),
      cleared AS (
        SELECT f.qa_survey_id,
          MAX(IF(o.stage = f.stage AND NOT o.is_qa AND o.primary_decision = 'Pass'
                 AND o.primary_eval_date >= f.primary_eval_date, 1, 0)) AS district_passed_after,
          MAX(IF(o.stage = f.next_stage AND o.primary_eval_date >= f.primary_eval_date, 1, 0)) AS next_stage_done
        FROM sent_back f
        LEFT JOIN ev o ON o.opportunity_id = f.opportunity_id
        GROUP BY 1
      )
      SELECT COUNT(DISTINCT f.opportunity_id) AS n
      FROM sent_back f JOIN cleared c USING (qa_survey_id)
      WHERE c.district_passed_after = 0 AND c.next_stage_done = 0
    `,
      { country, from, to, stages: QA_CHECK_STAGES, unitName },
    ),

    // Six complete months up to the selected window's end, so the trend reads the
    // same whatever period is chosen, the way the design shows it.
    query<Record<string, unknown>>(
      `
      SELECT FORMAT_DATE('%Y-%m', primary_eval_date) AS month,
        COUNT(*) AS evals,
        COUNTIF(primary_decision = 'Pass') AS passed,
        COUNTIF(SAFE_CAST(was_spot_checked AS INT64) = 1) AS spot_checked,
        COUNTIF(SAFE_CAST(decisions_match AS INT64) = 1) AS agreed
      FROM ${QA}
      WHERE location_country = @country
        AND primary_eval_date > DATE_SUB(DATE_TRUNC(CAST(@to AS DATE), MONTH), INTERVAL 5 MONTH)
        AND primary_eval_date <= CAST(@to AS DATE)
      GROUP BY 1 ORDER BY 1
    `,
      { country, to },
    ),
    // Work waiting on a QA step: where the job sits now and how long it has been there.
    query<Record<string, unknown>>(
      `
      SELECT journey_stage AS stage, COUNT(*) AS jobs, ROUND(AVG(days_in_stage)) AS avg_days,
        COUNTIF(days_in_stage > 60) AS over_60, COUNTIF(days_in_stage > 180) AS over_180
      FROM ${JOURNEY}
      WHERE country = @country AND stage_class IN ('building', 'finishing')
      GROUP BY 1 ORDER BY jobs DESC
    `,
      { country },
    ),
  ]);

  return {
    groups: groups.map(groupRow),
    sentBackOutstanding: num(outstanding[0]?.n),
    extras: extras.map((r) => ({
      dim: String(r.dim) as "unit" | "branch",
      name: String(r.name),
      waitingFinal: num(r.waiting),
      tlPairs: num(r.pairs),
      tlMatched: num(r.matched),
      casesRaised: num(r.raised),
      casesClosed: num(r.closed),
      casesOpen: num(r.raised) - num(r.closed),
    })),
    trend: trend.map((r) => ({
      month: String(r.month),
      evals: num(r.evals),
      passed: num(r.passed),
      spotChecked: num(r.spot_checked),
      agreed: num(r.agreed),
    })),
    pending: pending.map((r) => ({
      stage: String(r.stage),
      jobs: num(r.jobs),
      avgDays: num(r.avg_days),
      over60: num(r.over_60),
      over180: num(r.over_180),
    })),
  };
}

export const getQuality = unstable_cache(fetchQuality, ["quality-v10"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/** One evaluation, for the drill-down beneath a branch, stage, evaluator or mason. */
/**
 * A house a QA evaluation sent back that nobody has cleared since.
 *
 * "Sent back" is a QA decision that is neither a pass nor a not-ready: a rework
 * instruction. It counts as still outstanding when, from that day onward:
 *   - no District or Construction evaluation has passed the same stage, and
 *   - no evaluation of any kind has happened at the stage after it.
 *
 * Either of those means the house moved on, so it is no longer waiting on the
 * rework. What is left is the work a territory still owes.
 */
export type SentBackHouse = {
  surveyId: string;
  opportunityId: string;
  job: string;
  stage: string;
  /** The stage the house would move to once this one clears. */
  nextStage: string | null;
  decision: string;
  date: string;
  /** Days since QA sent it back. */
  daysSince: number;
  branch: string | null;
  territory: string | null;
  cso: string | null;
  mason: string | null;
  evaluator: string;
  comment: string | null;
};

/**
 * The houses one territory or branch still owes rework on, longest-waiting first.
 *
 * Only the latest outstanding send-back is kept for a house, so a house appears
 * once however many times QA has been back to it.
 */
async function fetchSentBack(
  country: CountryName, from: string, to: string, dim: "unit" | "branch", name: string, limit: number,
): Promise<SentBackHouse[]> {
  const rw = country === "Rwanda";
  const unitCol = dim === "unit" && rw ? "j.territory" : BRANCH_Q;
  const join = rw ? `LEFT JOIN ${JOURNEY} j ON j.opportunity_id = q.opportunity_id` : "";

  const rows = await query<Record<string, unknown>>(
    `
    WITH ev AS (
      SELECT q.qa_survey_id, q.opportunity_id, q.opportunity_name, q.stage, q.primary_decision,
        q.primary_eval_date, q.evaluator_name, o.mason_name, q.cso_name, q.eval_comment,
        ${BRANCH_Q} AS branch_name,
        ${rw ? "j.territory" : "CAST(NULL AS STRING)"} AS territory_name,
        ${unitCol} AS unit_name,
        (e.department IS NULL
          OR (NOT CONTAINS_SUBSTR(e.department, 'District') AND NOT CONTAINS_SUBSTR(e.department, 'Construction'))) AS is_qa
      FROM ${QA} q
      ${join}
      LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
      LEFT JOIN ${OPPS} o ON o.opportunity_id = q.opportunity_id
      WHERE q.location_country = @country
    ),
    sent_back AS (
      SELECT *, ${NEXT_STAGE} AS next_stage FROM ev
      WHERE is_qa
        AND stage IN UNNEST(@stages)
        AND primary_decision IS NOT NULL
        AND primary_decision NOT IN ('Pass', 'Not Ready for Evaluation')
        AND primary_eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
        AND unit_name = @name
    ),
    -- What happened on the house from that day onward, which is what clears it.
    cleared AS (
      SELECT f.qa_survey_id,
        MAX(IF(o.stage = f.stage AND NOT o.is_qa AND o.primary_decision = 'Pass'
               AND o.primary_eval_date >= f.primary_eval_date, 1, 0)) AS district_passed_after,
        MAX(IF(o.stage = f.next_stage AND o.primary_eval_date >= f.primary_eval_date, 1, 0)) AS next_stage_done
      FROM sent_back f
      LEFT JOIN ev o ON o.opportunity_id = f.opportunity_id
      GROUP BY 1
    ),
    still AS (
      SELECT f.*, ROW_NUMBER() OVER (
        PARTITION BY f.opportunity_id ORDER BY f.primary_eval_date DESC, f.qa_survey_id) AS rn
      FROM sent_back f
      JOIN cleared c USING (qa_survey_id)
      WHERE c.district_passed_after = 0 AND c.next_stage_done = 0
    )
    SELECT qa_survey_id, opportunity_id, opportunity_name, stage, next_stage, primary_decision,
      CAST(primary_eval_date AS STRING) AS d,
      DATE_DIFF(CURRENT_DATE(), primary_eval_date, DAY) AS days_since,
      branch_name, territory_name, cso_name, mason_name, evaluator_name, eval_comment
    FROM still WHERE rn = 1
    ORDER BY days_since DESC, opportunity_name
    LIMIT @limit
  `,
    { country, from, to, name, limit, stages: QA_CHECK_STAGES },
  );

  return rows.map((r) => ({
    surveyId: String(r.qa_survey_id),
    opportunityId: String(r.opportunity_id),
    job: String(r.opportunity_name ?? ""),
    stage: String(r.stage),
    nextStage: strOrNull(r.next_stage),
    decision: String(r.primary_decision ?? "-"),
    date: String(r.d),
    daysSince: num(r.days_since),
    branch: strOrNull(r.branch_name),
    territory: strOrNull(r.territory_name),
    cso: strOrNull(r.cso_name),
    mason: strOrNull(r.mason_name),
    evaluator: String(r.evaluator_name ?? "Unnamed"),
    comment: strOrNull(r.eval_comment),
  }));
}

export const getSentBack = unstable_cache(fetchSentBack, ["quality-sent-back-v3"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
