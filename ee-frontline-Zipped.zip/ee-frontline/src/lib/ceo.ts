import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import type { CountryName } from "./workspaces";

/**
 * The CEO dashboard's data layer: three settled views, read as they are,
 * for one year. Nothing here derives a metric; the arithmetic the page
 * needs (the branch cost-to-serve budget, the USD conversion) is in the SQL.
 *
 *   SQM-E built        raw_data_from_salesforce.company_kpi_monthly
 *   Mason earnings     raw_data_from_salesforce.productive_masons_monthly,
 *                      against a flat monthly bar per country (in the query)
 *   Cost to serve      qb_reporting.country_financials (actual, closed months)
 *                      qb_reporting.country_financial_targets (budget, derived),
 *                      both in USD at qb_reporting.fx_rates_monthly
 *
 * country_financials is a view over the QuickBooks tables and takes 20 to
 * 30 seconds, so the year is cached for 15 minutes like every other page and
 * the cron keeps the current year warm.
 */
export type CeoSqme = {
  country: CountryName; month: string; built: number | null; target: number | null; paint: number | null; current: boolean;
};
export type CeoMason = {
  country: CountryName; month: string; masonsPaid: number;
  /** Average gross approved pay per mason paid in the month, local currency. */
  actual: number | null;
  /** The flat monthly bar, local currency. */
  target: number | null;
  current: boolean;
};
export type CeoCts = {
  country: CountryName; month: string; closed: boolean;
  /** The absolute country cost to serve in USD, only for a closed month. */
  actual: number | null;
  /** The absolute derived country budget in USD. */
  budget: number | null;
};
export type CeoData = {
  year: number;
  /** The months with a row, "YYYY-MM", January to the current month. */
  months: string[];
  sqme: CeoSqme[];
  masons: CeoMason[];
  cts: CeoCts[];
  syncedMs: number | null;
  builtAt: string;
};

const KPI = "`earth-enable-main.raw_data_from_salesforce.company_kpi_monthly`";
const MASONS = "`earth-enable-main.raw_data_from_salesforce.productive_masons_monthly`";
const FIN = "`earth-enable-main.qb_reporting.country_financials`";
const TARGETS = "`earth-enable-main.qb_reporting.country_financial_targets`";
const FX = "`earth-enable-main.qb_reporting.fx_rates_monthly`";
const OPP = "`earth-enable-main.salesforce.opportunity`";
const COUNTRIES = "('Rwanda', 'Uganda', 'Kenya')";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const num = (v: unknown): number => (v == null ? 0 : Number(v));
const country = (v: unknown): CountryName => String(v) as CountryName;

async function fetchCeoData(year: number): Promise<CeoData> {
  type R = Record<string, unknown>;
  const [sqme, masons, cts, sync] = await Promise.all([
    // sqme_built is floor plus plaster, weighted, by completion month; paint is
    // out of it by design and goes to the table under the row.
    query<R>(
      `SELECT country, FORMAT_DATE('%Y-%m', month) AS month, sqme_built, sqme_target, paint_sqme, is_current_month
       FROM ${KPI}
       WHERE year = @year AND NOT is_future_month AND country IN ${COUNTRIES}
       ORDER BY country, month`,
      { year },
    ),
    // Gross approved pay by timesheet end date, averaged per mason paid, in
    // the month, against a flat monthly bar per country. The bar is set
    // here, not read from the view's threshold column, on the CEO's
    // instruction (docs/ceo-dashboard.md, change 1 of 2026-09-28).
    query<R>(
      `WITH bars AS (
         SELECT * FROM UNNEST([
           STRUCT('Rwanda' AS country, 100000.0 AS monthly_bar),
           STRUCT('Uganda', 250000.0),
           STRUCT('Kenya', 10000.0)
         ])
       )
       SELECT m.country, FORMAT_DATE('%Y-%m', m.month) AS month, m.masons_paid,
         m.avg_pay AS actual, b.monthly_bar AS target,
         m.month = DATE_TRUNC(CURRENT_DATE(), MONTH) AS is_current_month
       FROM ${MASONS} m JOIN bars b USING (country)
       WHERE EXTRACT(YEAR FROM m.month) = @year AND m.month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
       ORDER BY m.country, m.month`,
      { year },
    ),
    // Country level on both sides: cts_country is (revenue - cogs - district
    // expense - country overheads) / sqme_built, the figure Looker shows, and
    // the budget is the same ratio over the country targets loaded from the
    // VG workbook (sql/country_financial_targets.sql), numerators and
    // denominators summed, never averaged. Global overheads are in neither.
    // Both are negative (a cost per SQM-E); the page plots the absolute
    // value, in USD at the month's rate from fx_rates_monthly, the way the
    // view derives cts_country_usd. A month whose books are not closed has
    // no actual. The targets and the rates both stop at December 2026.
    query<R>(
      `WITH f AS (
         SELECT country, month, books_closed = 1 AS closed, cts_country
         FROM ${FIN}
         WHERE year = @year AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH) AND country IN ${COUNTRIES}
       ),
       b AS (
         SELECT country, month,
           ( SUM(IF(metric = 'revenue',          target_value, 0))
           - SUM(IF(metric = 'cogs',             target_value, 0))
           - SUM(IF(metric = 'district_expense', target_value, 0))
           - SUM(IF(metric = 'country_expense',  target_value, 0)) )
           / NULLIF(SUM(IF(metric = 'sqme', target_value, 0)), 0) AS cts_country_budget
         FROM ${TARGETS}
         WHERE EXTRACT(YEAR FROM month) = @year AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH) AND country IN ${COUNTRIES}
         GROUP BY country, month
       )
       SELECT country, FORMAT_DATE('%Y-%m', month) AS month,
         COALESCE(f.closed, FALSE) AS closed,
         IF(f.closed, ABS(f.cts_country) / NULLIF(fx.rate_per_usd, 0), NULL) AS actual,
         ABS(b.cts_country_budget) / NULLIF(fx.rate_per_usd, 0) AS budget
       FROM f FULL OUTER JOIN b USING (country, month)
       LEFT JOIN ${FX} fx USING (country, month)
       ORDER BY country, month`,
      { year },
    ),
    query<R>(`SELECT UNIX_MILLIS(MAX(_fivetran_synced)) AS ms FROM ${OPP} WHERE NOT _fivetran_deleted`),
  ]);
  const months = [...new Set(sqme.map((r) => String(r.month)))].sort();
  return {
    year,
    months,
    sqme: sqme.map((r) => ({
      country: country(r.country), month: String(r.month), built: numOrNull(r.sqme_built), target: numOrNull(r.sqme_target),
      paint: numOrNull(r.paint_sqme), current: Boolean(r.is_current_month),
    })),
    masons: masons.map((r) => ({
      country: country(r.country), month: String(r.month), masonsPaid: num(r.masons_paid),
      actual: numOrNull(r.actual), target: numOrNull(r.target), current: Boolean(r.is_current_month),
    })),
    cts: cts.map((r) => ({
      country: country(r.country), month: String(r.month), closed: Boolean(r.closed), actual: numOrNull(r.actual), budget: numOrNull(r.budget),
    })),
    syncedMs: sync[0]?.ms == null ? null : Number(sync[0].ms),
    builtAt: new Date().toISOString(),
  };
}

/**
 * The callback is built from a fixed source string for the reason given in
 * capacity.ts: Next keys a cache entry on the callback's text, and the page
 * and the warm route are minified into different bundles, so a plain
 * function would give the cron and the visitor different entries.
 */
declare global {
  var __eeCeoFetch: ((year: number) => Promise<CeoData>) | undefined;
}
globalThis.__eeCeoFetch = fetchCeoData;
const entry = new Function("year", "return globalThis.__eeCeoFetch(year)") as (year: number) => Promise<CeoData>;

export const getCeoData = unstable_cache(entry, ["ceo-data-v4"], { revalidate: REVALIDATE, tags: ["dashboard"] });

/** The years the year filter offers: 2026, the first year with targets, to the current year. */
export function ceoYears(): number[] {
  const now = new Date().getUTCFullYear();
  const years: number[] = [];
  for (let y = now; y >= 2026; y--) years.push(y);
  return years.length ? years : [2026];
}
