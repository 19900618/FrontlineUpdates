import { unstable_cache } from "next/cache";
import { query } from "./bigquery";

/**
 * CANONICAL collections view — the app is a thin reader. All logic (product,
 * country-specific milestone threshold, SQM-E ÷3 for plaster, distance-to-
 * milestone, is_collected, deductions, non-collectable exclusions) is
 * precomputed in BigQuery. The app derives nothing.
 *   earth-enable-main.salesforce.collections_app_v1
 *
 * "Collected" is AMOUNT-based (paid >= threshold), NOT the milestone-date field:
 * the RW 100% date is badly under-stamped, so a date-null test would flag
 * thousands who have already paid. Amount is what's actually owed.
 */
const CVIEW = "`earth-enable-main.salesforce.collections_app_v1`";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

/** Local currency per country (SQM-E is the shared cross-country unit). */
export const CURRENCY: Record<string, string> = {
  Rwanda: "RWF",
  Uganda: "UGX",
  Kenya: "KES",
};

// ---------- summary: per country × location × product × signed-cohort ----------
// Backlog only (signed, not collected), split into 3 MECE piles:
//   never  = never paid a shilling (cash<=0)         → validate / likely dead
//   active = deposited, paid within last 90 days      → chase, still moving
//   stalled= deposited, silent 90+ days (or no date)  → re-engage / diagnose
// Rwanda drills by `territory`; Uganda/Kenya by `branch` (territory is empty there).
export type CollSummaryRow = {
  country: string;
  territory: string;
  branch: string;
  product: string; // "Floor" | "Plaster"
  cohort: string; // "2025+" | "pre-2025"
  backlog: number;
  backlog_sqme: number;
  owed: number;
  never: number;
  never_sqme: number;
  active: number;
  active_sqme: number;
  stalled: number;
  stalled_sqme: number;
};

async function fetchCollectionsSummary(): Promise<CollSummaryRow[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT
      country,
      COALESCE(NULLIF(TRIM(territory),''),'Unassigned') AS territory,
      COALESCE(NULLIF(TRIM(branch),''),'Unassigned') AS branch,
      product,
      IF(signed_year >= 2025, '2025+', 'pre-2025') AS cohort,
      COUNTIF(NOT is_collected) AS backlog,
      ROUND(SUM(IF(NOT is_collected, sqme, 0))) AS backlog_sqme,
      ROUND(SUM(IF(NOT is_collected, outstanding, 0))) AS owed,
      COUNTIF(NOT is_collected AND cash_paid <= 0) AS never,
      ROUND(SUM(IF(NOT is_collected AND cash_paid <= 0, sqme, 0))) AS never_sqme,
      COUNTIF(NOT is_collected AND cash_paid > 0 AND days_since_last_payment <= 90) AS active,
      ROUND(SUM(IF(NOT is_collected AND cash_paid > 0 AND days_since_last_payment <= 90, sqme, 0))) AS active_sqme,
      COUNTIF(NOT is_collected AND cash_paid > 0 AND (days_since_last_payment IS NULL OR days_since_last_payment > 90)) AS stalled,
      ROUND(SUM(IF(NOT is_collected AND cash_paid > 0 AND (days_since_last_payment IS NULL OR days_since_last_payment > 90), sqme, 0))) AS stalled_sqme
    FROM ${CVIEW}
    WHERE country IS NOT NULL
    GROUP BY country, territory, branch, product, cohort
  `);
  return rows.map((r) => ({
    country: String(r.country),
    territory: String(r.territory),
    branch: String(r.branch),
    product: String(r.product),
    cohort: String(r.cohort),
    backlog: num(r.backlog),
    backlog_sqme: num(r.backlog_sqme),
    owed: num(r.owed),
    never: num(r.never),
    never_sqme: num(r.never_sqme),
    active: num(r.active),
    active_sqme: num(r.active_sqme),
    stalled: num(r.stalled),
    stalled_sqme: num(r.stalled_sqme),
  }));
}
export const getCollectionsSummary = unstable_cache(fetchCollectionsSummary, ["coll-summary-v7"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

// ---------- backlog rows for one country (the call list + the sizer) ----------
export type CollRow = {
  id: string;
  customer: string | null;
  phone: string | null;
  cso: string | null;
  product: string;
  branch: string;
  district: string | null;
  territory: string | null;
  village: string | null;
  total: number;
  cash: number;
  outstanding: number;
  pct: number | null;
  distance: number; // local currency needed to cross the milestone
  sqme: number;
  days: number | null; // days since last payment
  year: number; // signed year
  signed: string; // signed date, 'YYYY-MM-DD'
};

async function fetchCollectionsBacklog(country: string): Promise<CollRow[]> {
  const rows = await query<Record<string, unknown>>(
    `
    SELECT
      opportunity_id, customer_name, customer_phone, cso_name, product,
      COALESCE(NULLIF(TRIM(branch),''),'Unassigned') AS branch,
      district, territory, village,
      total_amount, cash_paid, outstanding, pct_paid,
      distance_to_milestone, sqme, days_since_last_payment, signed_year,
      CAST(signed_date AS STRING) AS signed
    FROM ${CVIEW}
    WHERE NOT is_collected AND country = @country
    ORDER BY distance_to_milestone ASC
    LIMIT 9000
  `,
    { country },
  );
  return rows.map((r) => ({
    id: String(r.opportunity_id),
    customer: strOrNull(r.customer_name),
    phone: strOrNull(r.customer_phone),
    cso: strOrNull(r.cso_name),
    product: String(r.product),
    branch: String(r.branch),
    district: strOrNull(r.district),
    territory: strOrNull(r.territory),
    village: strOrNull(r.village),
    total: num(r.total_amount),
    cash: num(r.cash_paid),
    outstanding: num(r.outstanding),
    pct: numOrNull(r.pct_paid),
    distance: num(r.distance_to_milestone),
    sqme: num(r.sqme),
    days: numOrNull(r.days_since_last_payment),
    year: num(r.signed_year),
    signed: r.signed == null ? "" : String(r.signed),
  }));
}
export const getCollectionsBacklog = unstable_cache(fetchCollectionsBacklog, ["coll-backlog-v7"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
