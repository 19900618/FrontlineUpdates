/**
 * How a CSO productivity ratio reads against the standard. Kept separate from
 * cso.ts (which imports BigQuery) so client components can use it without
 * dragging server-only code into the browser bundle.
 */
export type Band = "above" | "at" | "below" | "well_below" | "none";

export function band(pct: number | null): Band {
  if (pct == null) return "none";
  if (pct >= 1.15) return "above";
  if (pct >= 1.0) return "at";
  if (pct >= 0.7) return "below";
  return "well_below";
}

// Two tiers sit under the standard so the colour can escalate, but they read with
// the same words: "below standard" is the message, the shade carries the severity.
export const BAND_LABEL: Record<Band, string> = {
  above: "Above standard",
  at: "At standard",
  below: "Below standard",
  well_below: "Below standard",
  none: "No target set",
};

export const BAND_COLOR: Record<Band, string> = {
  above: "var(--accent)",
  at: "var(--good)",
  below: "var(--warning)",
  well_below: "var(--critical)",
  none: "var(--text-muted)",
};
