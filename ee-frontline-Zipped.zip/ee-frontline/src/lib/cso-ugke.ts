import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import type { Country, UgkeBranchMonth, UgkeCsoMonth, UgkePending } from "./cso-ugke-types";

/**
 * Uganda & Kenya CSO performance. The app is a thin reader: every rule lives in
 * three Salesforce-direct views (see cso-ugke-types.ts for the rules themselves).
 *   earth-enable-main.salesforce.cso_performance_ugke_app_v1  one row per CSO per month
 *   earth-enable-main.salesforce.cso_branch_ugke_app_v1       builds and targets per branch per month
 *   earth-enable-main.salesforce.cso_pending_ugke_app_v1      each CSO's contracts awaiting payment now
 * Separate from the Rwanda views on purpose: the UG/KE business and targets differ.
 */
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

async function fetchUgkeCsoMonths(): Promise<UgkeCsoMonth[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT
      cso_id, cso_name, cso_phone, country,
      CAST(month AS STRING) AS month, month_label,
      branch, home_branch, is_away_from_home,
      position, is_ranked, supervisor, CAST(hire_date AS STRING) AS hire_date,
      sqme_sold, floor_sqme_sold, sqme_collected,
      contracts_sold_all, contracts_collected_all,
      contracts_sold, floor_sold, plaster_sold, contracts_collected, value_sold,
      paint_sold, paint_sold_all, paint_m2, paint_sqme,
      paint_collected, paint_collected_all, paint_collected_sqme, paint_value,
      donated, donated_all,
      has_targets, min_sales_sqme, min_coll_sqme,
      pct_sales_sqme_productivity, pct_coll_sqme_productivity,
      days_available, month_days, is_part_month, is_new_cso,
      is_active_staff, is_unverified_staff, is_current_month
    FROM \`earth-enable-main.salesforce.cso_performance_ugke_app_v1\`
    WHERE month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
    ORDER BY month DESC, sqme_sold DESC
  `);
  return rows.map((r) => ({
    csoId: String(r.cso_id),
    cso: r.cso_name == null ? "Unnamed" : String(r.cso_name),
    phone: strOrNull(r.cso_phone),
    country: String(r.country) as Country,
    month: String(r.month),
    monthLabel: String(r.month_label),
    branch: String(r.branch),
    homeBranch: String(r.home_branch),
    isAwayFromHome: Boolean(r.is_away_from_home),
    position: strOrNull(r.position),
    isRanked: Boolean(r.is_ranked),
    supervisor: strOrNull(r.supervisor),
    hireDate: strOrNull(r.hire_date),
    soldSqme: num(r.sqme_sold),
    soldFloorSqme: num(r.floor_sqme_sold),
    collectedSqme: num(r.sqme_collected),
    soldContracts: num(r.contracts_sold_all),
    collectedContracts: num(r.contracts_collected_all),
    sold: num(r.contracts_sold),
    soldFloor: num(r.floor_sold),
    soldPlaster: num(r.plaster_sold),
    collected: num(r.contracts_collected),
    valueSold: num(r.value_sold),
    paintSold: num(r.paint_sold),
    paintSoldContracts: num(r.paint_sold_all),
    paintM2: num(r.paint_m2),
    paintSqme: num(r.paint_sqme),
    paintCollected: num(r.paint_collected),
    paintCollectedContracts: num(r.paint_collected_all),
    paintCollectedSqme: num(r.paint_collected_sqme),
    paintValue: num(r.paint_value),
    donated: num(r.donated),
    donatedContracts: num(r.donated_all),
    hasTargets: Boolean(r.has_targets),
    minSoldSqme: numOrNull(r.min_sales_sqme),
    minCollectedSqme: numOrNull(r.min_coll_sqme),
    pctSoldSqme: numOrNull(r.pct_sales_sqme_productivity),
    pctCollectedSqme: numOrNull(r.pct_coll_sqme_productivity),
    daysAvailable: num(r.days_available),
    monthDays: num(r.month_days),
    isPartMonth: Boolean(r.is_part_month),
    isNewCso: Boolean(r.is_new_cso),
    isActiveStaff: Boolean(r.is_active_staff),
    isUnverifiedStaff: Boolean(r.is_unverified_staff),
    isCurrentMonth: Boolean(r.is_current_month),
  }));
}

export const getUgkeCsoMonths = unstable_cache(fetchUgkeCsoMonths, ["ugke-cso-months-v3"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

async function fetchUgkeBranchMonths(): Promise<UgkeBranchMonth[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT country, branch, CAST(month AS STRING) AS month,
      builds_sqme, sqme_target, builds_all, builds,
      paint_builds_sqme, paint_builds_all, paint_builds
    FROM \`earth-enable-main.salesforce.cso_branch_ugke_app_v1\`
    WHERE month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
  `);
  return rows.map((r) => ({
    country: String(r.country) as Country,
    branch: String(r.branch),
    month: String(r.month),
    buildsSqme: num(r.builds_sqme),
    sqmeTarget: numOrNull(r.sqme_target),
    buildsContracts: num(r.builds_all),
    builds: num(r.builds),
    paintBuildsSqme: num(r.paint_builds_sqme),
    paintBuildsContracts: num(r.paint_builds_all),
    paintBuilds: num(r.paint_builds),
  }));
}

export const getUgkeBranchMonths = unstable_cache(fetchUgkeBranchMonths, ["ugke-branch-v3"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

async function fetchUgkePending(): Promise<UgkePending[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT cso_id, pending_contracts, pending_sqme, pending_cash_to_milestone,
      oldest_pending_days, pending_under_90d, pending_over_1y
    FROM \`earth-enable-main.salesforce.cso_pending_ugke_app_v1\`
  `);
  return rows.map((r) => ({
    csoId: String(r.cso_id),
    contracts: num(r.pending_contracts),
    sqme: num(r.pending_sqme),
    cash: num(r.pending_cash_to_milestone),
    oldestDays: numOrNull(r.oldest_pending_days),
    under90d: num(r.pending_under_90d),
    over1y: num(r.pending_over_1y),
  }));
}

export const getUgkePending = unstable_cache(fetchUgkePending, ["ugke-pending-v2"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
