import { unstable_cache } from "next/cache";
import { gunzipSync, gzipSync } from "node:zlib";
import { query } from "./bigquery";
import { CAPACITY_MASON_WEEK_V2_BODY, CAPACITY_WEEK_V2_BODY, CSO_CASH_DAILY_V1_BODY } from "@/generated/sql";
import type { CapacityCountry } from "./capacity-ui";
import type {
  JourneyClient, JourneyFinishedRow, JourneyStock, JourneyStockRow, UnitLevel,
  WsCsoCash, WsCsoMonth, WsCsoPending, WsData, WsLevel, WsMason, WsRow,
} from "./workspace-types";

/**
 * The country workspaces' data layer. Thin reader: every rule lives in SQL.
 *
 * Three of the objects it reads are new and are defined in sql/:
 *   capacity_week_v2        the period grain (week sets and quarters) per level
 *   capacity_mason_week_v2  the individual masons for a place and period
 *   cso_cash_daily_app_v1   cash, revenue and commission per CSO per day
 * The service account can read BigQuery but cannot create objects there, so
 * until someone with rights runs those files the app runs the same SQL
 * inline, from src/generated/sql.ts (built from sql/ by
 * scripts/build-sql.mjs). Set CAPACITY_USE_FUNCTIONS=1 once the objects exist
 * and the app calls them by name instead: same text, same numbers.
 *
 * The other objects (customer_journey_app_v2, the CSO views) already exist.
 */
const USE_FUNCTIONS = process.env.CAPACITY_USE_FUNCTIONS === "1";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

const CAPACITY_SRC = USE_FUNCTIONS
  ? "`earth-enable-main.raw_data_from_salesforce.capacity_week_v2`(@country, CAST(@month AS DATE), CAST(@from AS DATE))"
  : `(${CAPACITY_WEEK_V2_BODY})`;
const MASON_SRC = USE_FUNCTIONS
  ? "`earth-enable-main.raw_data_from_salesforce.capacity_mason_week_v2`(@country, @level, @name, CAST(@start AS DATE), CAST(@end AS DATE), @weeks)"
  : `(${CAPACITY_MASON_WEEK_V2_BODY})`;
const CASH_SRC = USE_FUNCTIONS ? "`earth-enable-main.salesforce.cso_cash_daily_app_v1`" : `(${CSO_CASH_DAILY_V1_BODY})`;
const JOURNEY = "`earth-enable-main.salesforce.customer_journey_app_v2`";
const OPP = "`earth-enable-main.salesforce.opportunity`";

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));
const str = (v: unknown): string => (v == null ? "" : String(v));

// ---------------------------------------------------------------------------
// The period rows: every level for the selected month's sets, plus the
// whole-month row of every month from January and every quarter, so the
// trend, the period control and the ranking movement need no second call.
// ---------------------------------------------------------------------------
async function fetchWorkspaceRows(country: CapacityCountry, month: string, from: string): Promise<WsData> {
  const [rows, sync] = await Promise.all([
    query<Record<string, unknown>>(
      `
      SELECT
        country, level, name, parent, manager, region, n_territories,
        CAST(month AS STRING) AS month, month_label, week_key, n_weeks, is_quarter, is_whole_month, period_label,
        CAST(period_start AS STRING) AS period_start, CAST(period_end AS STRING) AS period_end, is_complete,
        has_targets, currency,
        contracts_sold, ROUND(sqme_sold, 1) AS sqme_sold, sold_then_paid, ROUND(pct_sold_then_paid, 4) AS pct_sold_then_paid,
        contracts_collected, ROUND(sqme_collected, 1) AS sqme_collected, collected_today,
        contracts_built, ROUND(sqme_built, 1) AS sqme_built, floors_built, plasters_built, other_built,
        paint_sold, ROUND(paint_sqme_sold, 1) AS paint_sqme_sold, paint_collected, ROUND(paint_sqme_collected, 1) AS paint_sqme_collected,
        paint_built, ROUND(paint_sqme_built, 1) AS paint_sqme_built,
        builds_on_time, builds_late, ROUND(pct_on_time, 4) AS pct_on_time,
        ROUND(revenue) AS revenue, ROUND(cash_received) AS cash_received, ROUND(revenue_target) AS revenue_target, ROUND(pct_of_revenue_target, 4) AS pct_of_revenue_target,
        qa_measured, qa_passed, ROUND(pct_qa_pass, 4) AS pct_qa_pass,
        masons_on_timesheet, masons_assigned, masons_total, masons_built, masons_paid, masons_productive, ROUND(pct_masons_productive, 4) AS pct_masons_productive,
        ROUND(mason_earnings) AS mason_earnings, ROUND(earnings_per_mason) AS earnings_per_mason, weekly_threshold,
        csos_active, min_csos, csos_short, units_short_csos,
        ROUND(contracts_per_cso, 3) AS contracts_per_cso, ROUND(usual_contracts_per_cso, 3) AS usual_contracts_per_cso,
        ROUND(build_target, 2) AS build_target, ROUND(sqme_target, 1) AS sqme_target, ROUND(sales_target, 2) AS sales_target, ROUND(sqme_sales_target, 1) AS sqme_sales_target,
        ROUND(min_masons, 2) AS min_masons, ROUND(masons_to_hire, 2) AS masons_to_hire, territories_short,
        ROUND(pct_of_build_target, 4) AS pct_of_build_target, ROUND(pct_of_sqme_target, 4) AS pct_of_sqme_target,
        ROUND(pct_of_sales_target, 4) AS pct_of_sales_target, ROUND(pct_of_sqme_sales_target, 4) AS pct_of_sqme_sales_target,
        ROUND(pct_of_coll_target, 4) AS pct_of_coll_target, ROUND(pct_of_sqme_coll_target, 4) AS pct_of_sqme_coll_target,
        ROUND(builds_per_mason, 3) AS builds_per_mason, ROUND(usual_builds_per_mason, 3) AS usual_builds_per_mason, ROUND(pct_build_productivity, 4) AS pct_build_productivity,
        collected_not_built, ROUND(waiting_per_mason, 2) AS waiting_per_mason,
        rank_sqme, rank_prev, rank_move,
        FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', built_at) AS built_at
      FROM ${CAPACITY_SRC}
      -- The manager level is not shown in the workspaces; everything else is.
      -- Single weeks of the two months before the asked-for month ride along
      -- so a five-week trend ending in it needs no second call.
      WHERE level != 'manager'
        AND (month = CAST(@month AS DATE) OR is_whole_month OR is_quarter
             OR (is_single_week AND month >= DATE_SUB(CAST(@month AS DATE), INTERVAL 2 MONTH)))
      ORDER BY level, name, month, week_key
    `,
      { country, month, from },
    ),
    query<Record<string, unknown>>(`SELECT UNIX_MILLIS(MAX(_fivetran_synced)) AS ms FROM ${OPP} WHERE NOT _fivetran_deleted`),
  ]);
  return {
    rows: rows.map((r): WsRow => ({
      country: str(r.country) as CapacityCountry,
      level: str(r.level) as WsLevel,
      name: str(r.name),
      parent: strOrNull(r.parent),
      manager: strOrNull(r.manager),
      region: strOrNull(r.region),
      nTerritories: num(r.n_territories),
      month: str(r.month),
      monthLabel: str(r.month_label),
      weekKey: str(r.week_key),
      nWeeks: num(r.n_weeks),
      isQuarter: Boolean(r.is_quarter),
      isWholeMonth: Boolean(r.is_whole_month),
      periodLabel: str(r.period_label),
      periodStart: str(r.period_start),
      periodEnd: str(r.period_end),
      isComplete: Boolean(r.is_complete),
      hasTargets: Boolean(r.has_targets),
      currency: str(r.currency),
      sold: num(r.contracts_sold),
      sqmeSold: num(r.sqme_sold),
      soldThenPaid: num(r.sold_then_paid),
      pctSoldThenPaid: numOrNull(r.pct_sold_then_paid),
      collected: num(r.contracts_collected),
      sqmeCollected: num(r.sqme_collected),
      collectedToday: num(r.collected_today),
      built: num(r.contracts_built),
      sqmeBuilt: num(r.sqme_built),
      paintSold: num(r.paint_sold),
      paintSqmeSold: num(r.paint_sqme_sold),
      paintCollected: num(r.paint_collected),
      paintSqmeCollected: num(r.paint_sqme_collected),
      paintBuilt: num(r.paint_built),
      paintSqmeBuilt: num(r.paint_sqme_built),
      floorsBuilt: num(r.floors_built),
      plastersBuilt: num(r.plasters_built),
      otherBuilt: num(r.other_built),
      buildsOnTime: num(r.builds_on_time),
      buildsLate: num(r.builds_late),
      pctOnTime: numOrNull(r.pct_on_time),
      revenue: num(r.revenue),
      cashReceived: num(r.cash_received),
      revenueTarget: numOrNull(r.revenue_target),
      pctRevenue: numOrNull(r.pct_of_revenue_target),
      qaMeasured: num(r.qa_measured),
      qaPassed: num(r.qa_passed),
      pctQaPass: numOrNull(r.pct_qa_pass),
      working: num(r.masons_on_timesheet),
      assigned: num(r.masons_assigned),
      totalMasons: num(r.masons_total),
      masonsBuilt: num(r.masons_built),
      masonsPaid: num(r.masons_paid),
      masonsProductive: num(r.masons_productive),
      pctMasonsProductive: numOrNull(r.pct_masons_productive),
      masonEarnings: num(r.mason_earnings),
      earningsPerMason: numOrNull(r.earnings_per_mason),
      weeklyThreshold: num(r.weekly_threshold),
      csosActive: num(r.csos_active),
      minCsos: numOrNull(r.min_csos),
      csosShort: numOrNull(r.csos_short),
      csosUnitsShort: num(r.units_short_csos),
      contractsPerCso: numOrNull(r.contracts_per_cso),
      usualContractsPerCso: numOrNull(r.usual_contracts_per_cso),
      buildTarget: numOrNull(r.build_target),
      sqmeTarget: numOrNull(r.sqme_target),
      salesTarget: numOrNull(r.sales_target),
      sqmeSalesTarget: numOrNull(r.sqme_sales_target),
      minMasons: numOrNull(r.min_masons),
      toHire: numOrNull(r.masons_to_hire),
      territoriesShort: num(r.territories_short),
      pctBuild: numOrNull(r.pct_of_build_target),
      pctSqme: numOrNull(r.pct_of_sqme_target),
      pctSales: numOrNull(r.pct_of_sales_target),
      pctSqmeSales: numOrNull(r.pct_of_sqme_sales_target),
      pctColl: numOrNull(r.pct_of_coll_target),
      pctSqmeColl: numOrNull(r.pct_of_sqme_coll_target),
      buildsPerMason: numOrNull(r.builds_per_mason),
      usualBuildsPerMason: numOrNull(r.usual_builds_per_mason),
      pctBuildProductivity: numOrNull(r.pct_build_productivity),
      collectedNotBuilt: num(r.collected_not_built),
      waitingPerMason: numOrNull(r.waiting_per_mason),
      rank: numOrNull(r.rank_sqme),
      rankPrev: numOrNull(r.rank_prev),
      rankMove: numOrNull(r.rank_move),
    })),
    builtAt: str(rows[0]?.built_at) || new Date().toISOString(),
    syncedMs: sync[0]?.ms == null ? null : Number(sync[0].ms),
  };
}

/**
 * Cached gzipped, like the capacity page: a Rwanda payload is a few MB as
 * JSON and Next refuses to cache anything over 2 MB. The callback is built
 * from a fixed source string for the same reason as capacity.ts: Next keys
 * the entry on the callback's text, and the page and the warm route are
 * minified into different bundles.
 */
declare global {
  var __eeWorkspaceFetchPacked: ((country: CapacityCountry, month: string, from: string) => Promise<string>) | undefined;
}
globalThis.__eeWorkspaceFetchPacked = async (country, month, from) =>
  gzipSync(JSON.stringify(await fetchWorkspaceRows(country, month, from))).toString("base64");
const packedEntry = new Function(
  "country", "month", "from",
  "return globalThis.__eeWorkspaceFetchPacked(country, month, from)",
) as (country: CapacityCountry, month: string, from: string) => Promise<string>;

const packed = unstable_cache(packedEntry, ["workspace-rows-v10"], { revalidate: REVALIDATE, tags: ["dashboard"] });

/** When Salesforce last synced into BigQuery, for pages that read no period rows. */
async function fetchSyncedMs(): Promise<number | null> {
  const r = await query<Record<string, unknown>>(`SELECT UNIX_MILLIS(MAX(_fivetran_synced)) AS ms FROM ${OPP} WHERE NOT _fivetran_deleted`);
  return r[0]?.ms == null ? null : Number(r[0].ms);
}
export const getSyncedMs = unstable_cache(fetchSyncedMs, ["workspace-synced-v2"], { revalidate: 600, tags: ["dashboard"] });

/**
 * The country's territories (Rwanda) or branches (Uganda, Kenya) for the
 * filter bar's dropdown on the pages whose payload does not list them: the
 * units with a target, which is what every page lists. Cached a day.
 */
async function fetchUnitNames(country: CapacityCountry): Promise<string[]> {
  const rows = country === "Rwanda"
    ? await query<{ name: string }>("SELECT DISTINCT territory AS name FROM `earth-enable-main.raw_data_from_salesforce.tl_bonus_targets` WHERE territory IS NOT NULL ORDER BY 1")
    : await query<{ name: string }>("SELECT DISTINCT branch AS name FROM `earth-enable-main.raw_data_from_salesforce.branch_capacity_targets` WHERE country = @country AND branch IS NOT NULL ORDER BY 1", { country });
  return rows.map((r) => String(r.name));
}
export const getUnitNames = unstable_cache(fetchUnitNames, ["workspace-units-v1"], { revalidate: 24 * 60 * 60, tags: ["dashboard"] });

export async function getWorkspaceData(country: CapacityCountry, month: string, from: string): Promise<WsData> {
  const p = await packed(country, month, from);
  return JSON.parse(gunzipSync(Buffer.from(p, "base64")).toString("utf8")) as WsData;
}

// ---------------------------------------------------------------------------
// Customer journey: the stock buckets now, and jobs finished per week, at
// every level at once (GROUPING SETS), so a median is right at each level.
// ---------------------------------------------------------------------------
const UNIT_EXPR: Record<CapacityCountry, string> = {
  Rwanda: "COALESCE(NULLIF(TRIM(territory),''),'Unassigned')",
  Uganda: "COALESCE(NULLIF(TRIM(branch),''),'Unassigned')",
  Kenya: "COALESCE(NULLIF(TRIM(branch),''),'Unassigned')",
};
const DISTRICT_EXPR = "COALESCE(NULLIF(TRIM(district),''),'Unassigned')";
const BUCKET_EXPR = `CASE
  WHEN app_bucket LIKE '3 %' THEN 'sold_not_paid'
  WHEN app_bucket LIKE '4 %' OR app_bucket LIKE '5 %' THEN 'paid_not_started'
  WHEN app_bucket LIKE '6 %' OR app_bucket LIKE '7 %' THEN 'building'
END`;

async function fetchJourneyStock(country: CapacityCountry): Promise<JourneyStock> {
  const unit = UNIT_EXPR[country];
  const levels = country === "Rwanda"
    ? `GROUPING SETS ((unit, bucket), (district, bucket), (bucket))`
    : `GROUPING SETS ((unit, bucket), (bucket))`;
  const levelExpr = country === "Rwanda"
    ? `CASE WHEN GROUPING(unit) = 0 THEN 'territory' WHEN GROUPING(district) = 0 THEN 'district' ELSE 'country' END`
    : `IF(GROUPING(unit) = 0, 'branch', 'country')`;
  const nameExpr = country === "Rwanda" ? `COALESCE(unit, district, @country)` : `COALESCE(unit, @country)`;
  const rateLevels = country === "Rwanda" ? `GROUPING SETS ((unit), (district), ())` : `GROUPING SETS ((unit), ())`;
  const [stock, finished] = await Promise.all([
    query<Record<string, unknown>>(
      `
      WITH j AS (
        SELECT ${unit} AS unit, ${DISTRICT_EXPR} AS district, ${BUCKET_EXPR} AS bucket,
          sqme, outstanding_amount, is_zero_paid, days_in_stage, materials_available, app_bucket
        FROM ${JOURNEY}
        WHERE country = @country AND app_bucket IS NOT NULL
      ),
      stock AS (
        SELECT ${levelExpr} AS level, ${nameExpr} AS name, bucket,
          COUNT(*) AS n, IFNULL(SUM(sqme), 0) AS sqme, IFNULL(SUM(outstanding_amount), 0) AS owed,
          COUNTIF(is_zero_paid) AS zero_paid,
          COUNTIF(bucket = 'paid_not_started' AND app_bucket LIKE '4 %') AS waiting_materials,
          APPROX_QUANTILES(days_in_stage, 2)[OFFSET(1)] AS median_days,
          IFNULL(MAX(days_in_stage), 0) AS oldest_days,
          COUNTIF(days_in_stage > 30) AS over30,
          COUNTIF(days_in_stage <= 30) AS a0, COUNTIF(days_in_stage BETWEEN 31 AND 60) AS a1,
          COUNTIF(days_in_stage BETWEEN 61 AND 90) AS a2, COUNTIF(days_in_stage > 90) AS a3
        FROM j
        WHERE bucket IS NOT NULL
        GROUP BY ${levels}
      ),
      -- The place's build rate: SQM-E completed over the last three whole months.
      rate AS (
        SELECT ${levelExpr} AS level, ${nameExpr} AS name, IFNULL(SUM(sqme), 0) AS sqme_built_3m
        FROM (
          SELECT ${unit} AS unit, ${DISTRICT_EXPR} AS district, sqme
          FROM ${JOURNEY}
          WHERE country = @country AND stage_code IN ('L', 'N')
            AND completed_date >= DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 3 MONTH)
            AND completed_date < DATE_TRUNC(CURRENT_DATE(), MONTH)
        )
        GROUP BY ${rateLevels}
      )
      SELECT s.*, IFNULL(r.sqme_built_3m, 0) AS sqme_built_3m,
        SAFE_DIVIDE(s.sqme, r.sqme_built_3m / 3) AS months_of_work
      FROM stock s
      LEFT JOIN rate r ON r.level = s.level AND r.name = s.name
    `,
      { country },
    ),
    query<Record<string, unknown>>(
      `
      WITH j AS (
        SELECT ${unit} AS unit, ${DISTRICT_EXPR} AS district,
          DATE_TRUNC(completed_date, MONTH) AS month,
          LEAST(CAST(CEIL(EXTRACT(DAY FROM completed_date) / 7) AS INT64), 4) AS week_no,
          sqme, product_family, DATE_DIFF(CURRENT_DATE(), completed_date, DAY) AS age
        FROM ${JOURNEY}
        WHERE country = @country AND completed_date >= DATE '2026-01-01' AND completed_date <= CURRENT_DATE()
          AND stage_code IN ('L', 'N')
      )
      SELECT ${levelExpr} AS level, ${nameExpr} AS name, CAST(month AS STRING) AS month, week_no,
        COUNT(*) AS n, IFNULL(SUM(sqme), 0) AS sqme,
        COUNTIF(product_family = 'floor') AS floors, COUNTIF(product_family = 'plaster') AS plasters,
        COUNTIF(age <= 30) AS a0, COUNTIF(age BETWEEN 31 AND 60) AS a1, COUNTIF(age BETWEEN 61 AND 90) AS a2, COUNTIF(age > 90) AS a3
      FROM j
      GROUP BY ${country === "Rwanda"
        ? "GROUPING SETS ((unit, month, week_no), (district, month, week_no), (month, week_no))"
        : "GROUPING SETS ((unit, month, week_no), (month, week_no))"}
    `,
      { country },
    ),
  ]);
  return {
    stock: stock.map((r): JourneyStockRow => ({
      level: str(r.level) as JourneyStockRow["level"], name: str(r.name), bucket: str(r.bucket) as JourneyStockRow["bucket"],
      n: num(r.n), sqme: num(r.sqme), owed: num(r.owed), zeroPaid: num(r.zero_paid), waitingMaterials: num(r.waiting_materials),
      medianDays: num(r.median_days), oldestDays: num(r.oldest_days), over30: num(r.over30), ageBands: [num(r.a0), num(r.a1), num(r.a2), num(r.a3)],
      sqmeBuilt3m: num(r.sqme_built_3m), monthsOfWork: numOrNull(r.months_of_work),
    })),
    finished: finished.map((r): JourneyFinishedRow => ({
      level: str(r.level) as JourneyFinishedRow["level"], name: str(r.name), month: str(r.month), weekNo: num(r.week_no),
      n: num(r.n), sqme: num(r.sqme), floors: num(r.floors), plasters: num(r.plasters),
      ageBands: [num(r.a0), num(r.a1), num(r.a2), num(r.a3)],
    })),
  };
}

export const getJourneyStock = unstable_cache(fetchJourneyStock, ["workspace-journey-v3"], { revalidate: REVALIDATE, tags: ["dashboard"] });

/** The customers in one bucket for one place. Finished takes the period's weeks. */
async function fetchJourneyClients(
  country: CapacityCountry, level: UnitLevel | "country", name: string, bucket: string, start: string, end: string, weeks: string,
): Promise<JourneyClient[]> {
  const unit = UNIT_EXPR[country];
  const where = level === "country" ? "TRUE" : level === "district" ? `${DISTRICT_EXPR} = @name` : `${unit} = @name`;
  const pick = bucket === "finished"
    ? `stage_code IN ('L', 'N') AND completed_date BETWEEN CAST(@start AS DATE) AND CAST(@end AS DATE)
       AND (@weeks = 'Q' OR CAST(LEAST(CAST(CEIL(EXTRACT(DAY FROM completed_date) / 7) AS INT64), 4) AS STRING) IN UNNEST(REGEXP_EXTRACT_ALL(@weeks, r'\\d')))`
    : `${BUCKET_EXPR} = @bucket`;
  const rows = await query<Record<string, unknown>>(
    `
    SELECT opportunity_id, COALESCE(customer_name, opportunity_label, 'Unknown') AS name, customer_phone, cso_name,
      ${unit} AS unit, product_family, IFNULL(sqme, 0) AS sqme, pct_paid, IFNULL(cash_paid, 0) AS cash_paid,
      IFNULL(total_amount, 0) AS total_amount, IFNULL(outstanding_amount, 0) AS outstanding_amount,
      days_in_stage, journey_stage, materials_available,
      CAST(signed_date AS STRING) AS signed_date, CAST(completed_date AS STRING) AS completed_date
    FROM ${JOURNEY}
    WHERE country = @country AND ${where} AND ${pick}
    ORDER BY days_in_stage DESC
    LIMIT 5000
  `,
    { country, name, bucket, start, end, weeks },
  );
  return rows.map((r) => ({
    id: str(r.opportunity_id), name: str(r.name), phone: strOrNull(r.customer_phone), cso: strOrNull(r.cso_name),
    unit: str(r.unit), product: str(r.product_family), sqme: num(r.sqme), pctPaid: numOrNull(r.pct_paid),
    cashPaid: num(r.cash_paid), totalAmount: num(r.total_amount), outstanding: num(r.outstanding_amount),
    daysInStage: num(r.days_in_stage), stage: str(r.journey_stage).replace(/^[A-Z]\s+/, ""),
    materialsAvailable: Boolean(r.materials_available), signedDate: strOrNull(r.signed_date), completedDate: strOrNull(r.completed_date),
  }));
}

export const getJourneyClients = unstable_cache(fetchJourneyClients, ["workspace-journey-list-v2"], { revalidate: REVALIDATE, tags: ["dashboard"] });

// ---------------------------------------------------------------------------
// CSOs: the two existing monthly views, normalised, plus the daily cash view.
// ---------------------------------------------------------------------------
async function fetchWorkspaceCsos(country: CapacityCountry): Promise<{ months: WsCsoMonth[]; pending: WsCsoPending[] }> {
  const rw = country === "Rwanda";
  const [months, pending] = await Promise.all([
    rw
      ? query<Record<string, unknown>>(`
        SELECT cso_id, cso_name, cso_phone, CAST(month AS STRING) AS month, month_label,
          COALESCE(NULLIF(TRIM(territory),''),'Unassigned') AS unit,
          COALESCE(NULLIF(TRIM(district),''),'Unassigned') AS district,
          home_territory AS home_unit, is_away_from_home, manager,
          contracts_sold, sqme_sold, contracts_collected, sqme_collected,
          has_targets, min_sales_contracts, min_sales_sqme, min_coll_contracts, min_coll_sqme,
          pct_sales_productivity AS pct_sold, pct_coll_productivity AS pct_collected,
          days_available, month_days, is_part_month, is_new_cso, is_active_staff, is_unverified_staff, is_current_month,
          TRUE AS is_ranked
        FROM \`earth-enable-main.salesforce.cso_performance_app_v1\`
        WHERE month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
      `)
      : query<Record<string, unknown>>(
        `
        SELECT cso_id, cso_name, cso_phone, CAST(month AS STRING) AS month, month_label,
          branch AS unit, branch AS district, home_branch AS home_unit, is_away_from_home, supervisor AS manager,
          contracts_sold, sqme_sold, contracts_collected, sqme_collected,
          has_targets, min_sales_contracts, min_sales_sqme, min_coll_contracts, min_coll_sqme,
          pct_sales_sqme_productivity AS pct_sold, pct_coll_sqme_productivity AS pct_collected,
          days_available, month_days, is_part_month, is_new_cso, is_active_staff, is_unverified_staff, is_current_month,
          is_ranked
        FROM \`earth-enable-main.salesforce.cso_performance_ugke_app_v1\`
        WHERE country = @country AND month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
      `,
        { country },
      ),
    query<Record<string, unknown>>(`
      SELECT cso_id, pending_contracts, pending_sqme, pending_cash_to_milestone, oldest_pending_days, pending_over_1y
      FROM \`earth-enable-main.salesforce.${rw ? "cso_pending_app_v1" : "cso_pending_ugke_app_v1"}\`
    `),
  ]);
  return {
    months: months.map((r): WsCsoMonth => ({
      csoId: str(r.cso_id), cso: r.cso_name == null ? "Unnamed" : str(r.cso_name), phone: strOrNull(r.cso_phone),
      month: str(r.month), monthLabel: str(r.month_label), unit: str(r.unit), district: str(r.district),
      homeUnit: strOrNull(r.home_unit), isAwayFromHome: Boolean(r.is_away_from_home), manager: strOrNull(r.manager),
      isRanked: Boolean(r.is_ranked), scoreBasis: rw ? "contracts" : "sqme",
      sold: num(r.contracts_sold), soldSqme: num(r.sqme_sold), collected: num(r.contracts_collected), collectedSqme: num(r.sqme_collected),
      minSold: numOrNull(r.min_sales_contracts), minSoldSqme: numOrNull(r.min_sales_sqme),
      minCollected: numOrNull(r.min_coll_contracts), minCollectedSqme: numOrNull(r.min_coll_sqme),
      pctSold: numOrNull(r.pct_sold), pctCollected: numOrNull(r.pct_collected), hasTargets: Boolean(r.has_targets),
      daysAvailable: num(r.days_available), monthDays: num(r.month_days), isPartMonth: Boolean(r.is_part_month),
      isNewCso: Boolean(r.is_new_cso), isActiveStaff: Boolean(r.is_active_staff), isUnverifiedStaff: Boolean(r.is_unverified_staff),
      isCurrentMonth: Boolean(r.is_current_month),
    })),
    pending: pending.map((r): WsCsoPending => ({
      csoId: str(r.cso_id), contracts: num(r.pending_contracts), sqme: num(r.pending_sqme), cash: num(r.pending_cash_to_milestone),
      oldestDays: numOrNull(r.oldest_pending_days), over1y: num(r.pending_over_1y),
    })),
  };
}

export const getWorkspaceCsos = unstable_cache(fetchWorkspaceCsos, ["workspace-csos-v2"], { revalidate: REVALIDATE, tags: ["dashboard"] });

/** Money per CSO for one day, that day's calendar week and the period, from the daily view. */
async function fetchCsoCash(country: CapacityCountry, day: string, weekStart: string, weekEnd: string, start: string, end: string): Promise<WsCsoCash[]> {
  const rows = await query<Record<string, unknown>>(
    `
    SELECT cso_id,
      SUM(IF(day = CAST(@day AS DATE), cash_received, 0)) AS day_cash,
      SUM(IF(day BETWEEN CAST(@weekStart AS DATE) AND CAST(@weekEnd AS DATE), cash_received, 0)) AS week_cash,
      SUM(IF(day BETWEEN CAST(@start AS DATE) AND CAST(@end AS DATE), cash_received, 0)) AS period_cash,
      SUM(IF(day = CAST(@day AS DATE), commission, 0)) AS day_commission,
      SUM(IF(day BETWEEN CAST(@start AS DATE) AND CAST(@end AS DATE), commission, 0)) AS period_commission,
      SUM(IF(day BETWEEN CAST(@start AS DATE) AND CAST(@end AS DATE), revenue_completed, 0)) AS period_revenue,
      MAX(IF(day BETWEEN CAST(@weekStart AS DATE) AND CAST(@weekEnd AS DATE), weekly_cash_target, NULL)) AS weekly_cash_target
    FROM ${CASH_SRC}
    WHERE country = @country
      AND day BETWEEN LEAST(CAST(@start AS DATE), CAST(@weekStart AS DATE), CAST(@day AS DATE))
               AND GREATEST(CAST(@end AS DATE), CAST(@weekEnd AS DATE), CAST(@day AS DATE))
    GROUP BY cso_id
  `,
    { country, day, weekStart, weekEnd, start, end },
  );
  return rows.map((r) => ({
    csoId: str(r.cso_id), dayCash: num(r.day_cash), weekCash: num(r.week_cash), periodCash: num(r.period_cash),
    dayCommission: num(r.day_commission), periodCommission: num(r.period_commission), periodRevenue: num(r.period_revenue),
    weeklyCashTarget: numOrNull(r.weekly_cash_target),
  }));
}

export const getCsoCash = unstable_cache(fetchCsoCash, ["workspace-cso-cash-v5"], { revalidate: REVALIDATE, tags: ["dashboard"] });

// ---------------------------------------------------------------------------
// Masons for one place and period.
// ---------------------------------------------------------------------------
async function fetchMasons(country: CapacityCountry, level: UnitLevel | "country", name: string, start: string, end: string, weeks: string): Promise<WsMason[]> {
  const rows = await query<Record<string, unknown>>(
    `
    SELECT mason_id, mason_name, unit, unit_parent, status, timesheets, builds_completed, sqme_completed, revenue,
      builds_on_time, builds_late, pct_on_time, jobs_in_hand, sqme_in_hand, weekly_rate, time_needed_weeks,
      earnings, currency, weekly_threshold, threshold, pct_of_threshold, is_productive,
      ARRAY(SELECT AS STRUCT CAST(w.week_start AS STRING) AS week_start, CAST(w.week_end AS STRING) AS week_end, w.week_label,
              w.is_complete, w.is_selected, w.earnings, w.threshold, w.pct_of_threshold, w.is_productive
            FROM UNNEST(weeks) w ORDER BY w.week_start) AS weeks,
      qa_measured, qa_passed, pct_qa_pass
    FROM ${MASON_SRC}
    ORDER BY sqme_completed DESC, mason_name
  `,
    { country, level, name, start, end, weeks },
  );
  return rows.map((r) => ({
    masonId: str(r.mason_id), masonName: str(r.mason_name), unit: strOrNull(r.unit), unitParent: strOrNull(r.unit_parent),
    status: str(r.status) as WsMason["status"], timesheets: num(r.timesheets), builds: num(r.builds_completed),
    sqmeCompleted: num(r.sqme_completed), revenue: num(r.revenue), buildsOnTime: num(r.builds_on_time), buildsLate: num(r.builds_late),
    pctOnTime: numOrNull(r.pct_on_time), jobsInHand: num(r.jobs_in_hand), sqmeInHand: num(r.sqme_in_hand),
    weeklyRate: numOrNull(r.weekly_rate), timeNeededWeeks: numOrNull(r.time_needed_weeks), earnings: num(r.earnings),
    currency: str(r.currency), weeklyThreshold: num(r.weekly_threshold), threshold: num(r.threshold),
    pctOfThreshold: numOrNull(r.pct_of_threshold), isProductive: Boolean(r.is_productive),
    weeks: ((r.weeks as Record<string, unknown>[]) ?? []).map((w) => ({
      weekStart: str(w.week_start), weekEnd: str(w.week_end), weekLabel: str(w.week_label),
      isComplete: Boolean(w.is_complete), isSelected: Boolean(w.is_selected), earnings: num(w.earnings),
      threshold: num(w.threshold), pctOfThreshold: numOrNull(w.pct_of_threshold), isProductive: Boolean(w.is_productive),
    })),
    qaMeasured: num(r.qa_measured), qaPassed: num(r.qa_passed), pctQaPass: numOrNull(r.pct_qa_pass),
  }));
}

export const getMasons = unstable_cache(fetchMasons, ["workspace-masons-v5"], { revalidate: REVALIDATE, tags: ["dashboard"] });
