/**
 * The capacity page's calendar: the four windows of each month (days 1-7,
 * 8-14, 15-21, 22 to month end) from FROM up to the current month, keeping
 * only weeks that have started. It used to be a BigQuery query that touched
 * no table, one serial round trip before the data could be fetched; this is
 * the same arithmetic in TypeScript. scripts/capacity-calendar-check.mjs
 * proves the two agree for every day since 2025.
 *
 * Dates are UTC throughout, because BigQuery's CURRENT_DATE() is UTC and the
 * capacity function decides is_complete_week on the same clock.
 * Client-safe: no server imports.
 */
export type CapacityWeek = {
  month: string; // 'YYYY-MM-01'
  monthLabel: string;
  weekNo: number;
  weekLabel: string;
  weekStart: string;
  weekEnd: string;
  isComplete: boolean;
  isCurrent: boolean;
};

export const CAPACITY_CALENDAR_FROM = "2026-01-01";

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

const iso = (d: Date): string => d.toISOString().slice(0, 10);
const utc = (day: string): Date => new Date(`${day}T00:00:00Z`);
const addDays = (d: Date, n: number): Date => new Date(d.getTime() + n * 86_400_000);
const pad2 = (n: number): string => String(n).padStart(2, "0");

/** Today's date in UTC as 'YYYY-MM-DD', the same day BigQuery's CURRENT_DATE() gives. */
export function todayUtc(): string {
  return iso(new Date());
}

/** The calendar as at `today` (UTC). Ordered by month, then week. */
export function capacityCalendar(today: string = todayUtc(), from: string = CAPACITY_CALENDAR_FROM): CapacityWeek[] {
  const todayD = utc(today);
  const out: CapacityWeek[] = [];
  const first = utc(from);
  let month = new Date(Date.UTC(first.getUTCFullYear(), first.getUTCMonth(), 1));
  const lastMonth = new Date(Date.UTC(todayD.getUTCFullYear(), todayD.getUTCMonth(), 1));
  while (month.getTime() <= lastMonth.getTime()) {
    const y = month.getUTCFullYear();
    const m = month.getUTCMonth();
    const lastDay = new Date(Date.UTC(y, m + 1, 0));
    for (let w = 1; w <= 4; w++) {
      const ws = addDays(month, (w - 1) * 7);
      const we = w === 4 ? lastDay : addDays(month, w * 7 - 1);
      if (ws.getTime() > todayD.getTime()) continue; // the week has not started
      out.push({
        month: iso(month),
        monthLabel: `${MONTHS[m]} ${y}`,
        weekNo: w,
        weekLabel: `W${w} (${pad2(ws.getUTCDate())}-${pad2(we.getUTCDate())} ${MONTHS[we.getUTCMonth()].slice(0, 3)})`,
        weekStart: iso(ws),
        weekEnd: iso(we),
        isComplete: we.getTime() < todayD.getTime(),
        isCurrent: ws.getTime() <= todayD.getTime() && we.getTime() >= todayD.getTime(),
      });
    }
    month = new Date(Date.UTC(y, m + 1, 1));
  }
  return out;
}
