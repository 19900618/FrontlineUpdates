/**
 * Uganda & Kenya CSO performance: the fields the pages need, read from three
 * Salesforce-direct views by cso-ugke.ts (one row per CSO per month, one per
 * branch per month, one per CSO for contracts awaiting payment). Client-safe:
 * no server imports.
 *
 * Rules:
 *   - SQM-E is the productivity basis (decided 2026-09-17). About 45% of UG and KE
 *     contracts are follow-on phases, each priced, paid and collected on its own, so
 *     counting jobs (phase 1) hid nearly half the work. SQM-E counts every phase.
 *   - Contracts are shown as volume in two forms: CONTRACTS (every phase, what
 *     Salesforce lists) and JOBS (phase 1, one per house).
 *   - Only floor and plaster are scored: the branch targets are set on them
 *     (company sqme_target = floor_target + plaster_target). Paint has no target
 *     and is shown as volume only.
 *   - Collected = the phase crossed its own payment gate: floor 50%, plaster 75%, paint 100%.
 *   - Standard per CSO: the month's own branch SQM-E target x 1.3 / establishment for
 *     sales, target / establishment for collections, pro-rated for days worked.
 *   - Donated (zero-value) contracts are shown but not scored.
 *   - Which roles are ranked is TENTATIVE (see isRanked).
 */
export type Country = "Uganda" | "Kenya";
export const COUNTRIES: Country[] = ["Uganda", "Kenya"];
export const CURRENCY: Record<Country, string> = { Uganda: "UGX", Kenya: "KES" };

/** CSOs each branch should have. */
export const ESTABLISHMENT: Record<Country, number> = { Uganda: 9, Kenya: 7 };

/** Floor's share of the SQM-E target (company_targets floor_target / sqme_target, Aug 2026). */
export const FLOOR_SHARE_TARGET: Record<Country, number> = { Uganda: 0.4, Kenya: 0.56 };

/** One CSO's activity in one month. */
export type UgkeCsoMonth = {
  csoId: string;
  cso: string;
  phone: string | null;
  country: Country;
  month: string; // 'YYYY-MM-01'
  monthLabel: string;
  /** Branch holding most of this month's work. */
  branch: string;
  /** Branch holding most of their work overall, so a profile does not hop between months. */
  homeBranch: string;
  isAwayFromHome: boolean;
  /** contact.staff_position_c as recorded (null when blank in Salesforce). */
  position: string | null;
  /** TENTATIVE: CSO, Sales Agent, Sales Rep and blank positions are ranked;
   *  team leaders and managers are not. Under review, expect it to change. */
  isRanked: boolean;
  /** contact.employee_s_supervisor_c, usually the Branch Manager. */
  supervisor: string | null;
  hireDate: string | null;

  // Scored: floor and plaster only, donated contracts excluded.
  /** Floor + plaster SQM-E signed, every phase. The sales score. */
  soldSqme: number;
  soldFloorSqme: number;
  /** Floor + plaster SQM-E whose phase reached its payment gate this month. The collections score. */
  collectedSqme: number;
  /** Floor + plaster contracts signed, every phase (what Salesforce lists). */
  soldContracts: number;
  /** Floor + plaster contracts that reached their gate this month, every phase. */
  collectedContracts: number;
  /** Floor + plaster JOBS signed: phase 1 contracts only, one per house. */
  sold: number;
  soldFloor: number;
  soldPlaster: number;
  /** Floor + plaster jobs (phase 1) that reached the gate this month. */
  collected: number;

  /** Contract value of the floor + plaster signed, every phase, local currency. */
  valueSold: number;

  // Not scored.
  /** Paint jobs (phase 1) signed. */
  paintSold: number;
  /** Paint contracts signed, every phase. */
  paintSoldContracts: number;
  paintM2: number;
  /** Paint m² x 0.333, the same weight as plaster. */
  paintSqme: number;
  /** Paint jobs (phase 1) that reached 100% paid this month. */
  paintCollected: number;
  /** Paint contracts that reached 100% paid this month, every phase. */
  paintCollectedContracts: number;
  paintCollectedSqme: number;
  /** Contract value of the paint signed, local currency. */
  paintValue: number;
  /** Donated or zero-value jobs (phase 1) signed. */
  donated: number;
  /** Donated or zero-value contracts signed, every phase. */
  donatedContracts: number;

  // The standard, pro-rated for days available.
  hasTargets: boolean;
  minSoldSqme: number | null;
  minCollectedSqme: number | null;
  /** SQM-E actual / standard: THE productivity scores. */
  pctSoldSqme: number | null;
  pctCollectedSqme: number | null;

  daysAvailable: number;
  monthDays: number;
  isPartMonth: boolean;
  isNewCso: boolean;
  isActiveStaff: boolean;
  isUnverifiedStaff: boolean;
  isCurrentMonth: boolean;
};

/** The build side of a branch in one month. Builds are compared with the month's own target, like Rwanda. */
export type UgkeBranchMonth = {
  country: Country;
  branch: string;
  month: string;
  /** Floor + plaster SQM-E completed this month, every phase. The builds score. */
  buildsSqme: number;
  sqmeTarget: number | null;
  /** Floor + plaster contracts completed this month, every phase. */
  buildsContracts: number;
  /** Floor + plaster jobs (phase 1) completed this month. */
  builds: number;
  /** Paint completed this month. No target: shown alongside, not scored. */
  paintBuildsSqme: number;
  paintBuildsContracts: number;
  paintBuilds: number;
};

/** A CSO's open follow-ups right now: contracts signed that have not crossed the payment gate. */
export type UgkePending = {
  csoId: string;
  /** Every phase. */
  contracts: number;
  sqme: number;
  /** Cash still needed to reach the gate, in local currency. */
  cash: number;
  oldestDays: number | null;
  under90d: number;
  over1y: number;
};
