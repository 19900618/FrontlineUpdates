/** Shared display + color helpers (no server-only imports — safe on the client). */
import type { ClientRow, Group } from "./data";

/** Backlog-ish groups hidden behind the toggle (client-safe constant). */
export const BACKLOG_GROUPS: Group[] = ["backlog", "promised"];

/** Full stage name = the view's journey_stage minus its leading letter code. */
export function stageName(journeyStage: string): string {
  return journeyStage.replace(/^[A-Z]\s+/, "").trim() || journeyStage;
}

/**
 * Punchy 2–3 word label for tight spots (heatmap headers). Keyed by stage_code
 * so it survives wording tweaks; falls back to the view's own name.
 */
const STAGE_SHORT: Record<string, string> = {
  O: "Promised",
  A: "DP paid '24/25",
  B: "Collecting '26",
  C: "Materials unknown",
  D: "Materials available",
  E: "Pre-house eval",
  F: "Excavation",
  G: "Compaction redo",
  H: "Screed / plaster",
  I: "Screed redo",
  J: "100% / delivery",
  K: "Delivered",
  M: "Needs repairs",
};
export function stageShort(stageCode: string, journeyStage?: string): string {
  return STAGE_SHORT[stageCode] ?? (journeyStage ? stageName(journeyStage) : stageCode);
}

/** Funnel-ordered groups shown as scorecards and board sections. */
export const GROUPS: { key: Group; label: string }[] = [
  { key: "collecting", label: "Collecting" },
  { key: "ready_to_build", label: "Ready to build" },
  { key: "building", label: "Building" },
  { key: "finishing", label: "Finishing" },
  { key: "repairs", label: "Repairs pending" },
];

export type GroupStat = {
  count: number;
  /** Equivalent square metres: floor 1.0, plaster / paint / ceiling plaster / repair 0.333. */
  sqme: number;
  rwf: number;
  zeroPaid: number;
  notFullyPaid: number;
  median: number;
  over30: number;
  oldest: number;
  ageBands: number[]; // [≤30, 31–60, 61–90, >90] days in stage
};

/** Aging bands for the stage health bar — green (fresh) → red (stuck). */
export const AGE_BANDS: { label: string; color: string }[] = [
  { label: "≤30 days", color: "var(--good)" },
  { label: "31–60 days", color: "var(--warning)" },
  { label: "61–90 days", color: "var(--serious)" },
  { label: "over 90 days", color: "var(--critical)" },
];

/**
 * The 8 simplified board buckets (matches the view's `app_bucket`). `key` is the
 * exact string the view emits; `label` is the friendly column title; hideable
 * ones (older cohorts + completed) can be toggled off the board. "Collected" is
 * split on Salesforce's Materials Available tick: unticked reads "materials
 * unknown", not "pending", because most territories do not record the tick.
 */
export const BUCKETS: { key: string; label: string; hideable: boolean }[] = [
  { key: "1 Signed, not collected (pre-2026)", label: "Signed, not collected (pre-2026)", hideable: true },
  { key: "2 Collected, not completed (pre-2026)", label: "Collected, not completed (pre-2026)", hideable: true },
  { key: "3 Signed, not collected (2026)", label: "Signed, not collected", hideable: false },
  { key: "4 Collected, materials unknown (2026)", label: "Collected, materials unknown", hideable: false },
  { key: "5 Collected, materials available", label: "Collected, materials available", hideable: false },
  { key: "6 Started, not varnished (2026)", label: "Started, not varnished", hideable: false },
  { key: "7 Varnished, not evaluated (2026)", label: "Varnished, not evaluated", hideable: false },
  { key: "8 Completed", label: "Completed", hideable: true },
];
export const HIDEABLE_BUCKETS = BUCKETS.filter((b) => b.hideable).map((b) => b.key);

/**
 * The four "pending" cards on the journey board. They do not come from the
 * view's app_bucket: each is a step from the Territory Leads waiting-for rule,
 * which reads the evaluation records rather than the result fields on the
 * opportunity. `reasons` are the waiting-for values the card adds up;
 * `qaSubject` is the QA task subject the same step is worked under, null where
 * QA has no task for it (a stock movement is the territory lead's alone). The
 * `stepBefore` is what the wait is measured from, for the drawer's column.
 */
export type PendingCard = { key: string; label: string; reasons: string[]; qaSubject: string | null; stepBefore: string; qaType?: string };
export const PENDING_CARDS: PendingCard[] = [
  { key: "P4", label: "Pending prior paint evaluation", reasons: ["Waiting for prior paint evaluation"], qaSubject: "Prior Paint/varnish", qaType: "Prior paint", stepBefore: "Payment gate reached" },
  { key: "P5", label: "Pending compaction evaluation", reasons: ["Waiting for compaction"], qaSubject: "Compaction Evaluation", qaType: "Compaction", stepBefore: "Insecticide moved" },
  { key: "P6", label: "Pending screed evaluation", reasons: ["Waiting for screed evaluation"], qaSubject: "Screed Evaluation", qaType: "Screed", stepBefore: "Compaction passed" },
  { key: "P7", label: "Pending varnish or paint movement", reasons: ["Waiting for varnish movement", "Waiting for paint movement"], qaSubject: null, stepBefore: "Last evaluation passed" },
];

/** Friendly label for an app_bucket value (strips the leading number). */
export function bucketLabel(key: string): string {
  return BUCKETS.find((b) => b.key === key)?.label ?? key.replace(/^\d+\s+/, "");
}

/**
 * Accent per bucket — a warm, on-brand family (not a rainbow). Backlog stays
 * neutral/quiet; the live funnel warms from gold → brand-orange → terracotta as
 * it progresses; completed is a calm sage. Keyed by the leading number.
 */
const BUCKET_COLOR: Record<string, string> = {
  // The pending cards sit between "collected" and "varnished" in the funnel, so they take its warm middle.
  P4: "#c9741f", P5: "#d9822b", P6: "#e08e3a", P7: "#c86a3a",
  "1": "#aab2c0", // pre-2026 signed — quiet slate
  "2": "#7f8896", // pre-2026 collected — slate
  "3": "#e0a52e", // collecting (2026) — warm gold
  "4": "#f3ac63", // collected, materials unknown — pale orange
  "5": "#ef8f3c", // collected, materials available — light orange, one step on
  "6": "#ee7203", // started, not varnished — brand orange (the hero)
  "7": "#b8501a", // varnished, not evaluated — terracotta
  "8": "#3f8f68", // completed — calm sage
};
export function bucketColor(key: string): string {
  return BUCKET_COLOR[key.charAt(0)] ?? "var(--accent-strong)";
}

/** Per-bucket stats computed client-side so they react to the search filter. */
export function computeBucketStats(clients: ClientRow[]): Record<string, GroupStat> {
  const by: Record<string, ClientRow[]> = {};
  for (const c of clients) if (c.app_bucket) (by[c.app_bucket] ??= []).push(c);
  const out: Record<string, GroupStat> = {};
  for (const [k, rows] of Object.entries(by)) {
    const days = rows.map((r) => r.days_in_stage).sort((a, b) => a - b);
    out[k] = {
      count: rows.length,
      sqme: rows.reduce((s, r) => s + (r.sqme ?? 0), 0),
      rwf: rows.reduce((s, r) => s + (r.outstanding_amount ?? 0), 0),
      zeroPaid: rows.filter((r) => r.is_zero_paid).length,
      notFullyPaid: rows.filter((r) => (r.pct_paid ?? 0) < 1).length,
      median: days.length ? days[Math.floor(days.length / 2)] : 0,
      over30: rows.filter((r) => r.days_in_stage > 30).length,
      oldest: rows.reduce((m, r) => Math.max(m, r.days_in_stage), 0),
      ageBands: [
        rows.filter((r) => r.days_in_stage <= 30).length,
        rows.filter((r) => r.days_in_stage > 30 && r.days_in_stage <= 60).length,
        rows.filter((r) => r.days_in_stage > 60 && r.days_in_stage <= 90).length,
        rows.filter((r) => r.days_in_stage > 90).length,
      ],
    };
  }
  return out;
}

/** Compact SQM-E: 12_400 -> "12.4k", 940 -> "940". One decimal only where it helps. */
export function fmtSqme(n: number): string {
  const v = Math.round(n);
  if (Math.abs(v) >= 10000) return (v / 1000).toFixed(1) + "k";
  return v.toLocaleString("en-US");
}

/** Compact RWF: 1_015_656 -> "1.0M", 1_130 -> "1K". */
export function fmtRWF(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (a >= 1e3) return Math.round(n / 1e3) + "K";
  return String(Math.round(n));
}

/**
 * Which team owns a stage, mirroring the "For DoLs" / "For TLs" split in the
 * existing Looker board:
 *   DoL  (sales & collections): Promised(0), Sale/DP(1,2), Collections-ready(3)
 *   TL   (construction & QA):   Pre-house(4) … Final eval(11), Need-repairs(14)
 *   closed (outcomes, not planning): Completed(12), Lost(13), Special(99)
 */
export type Lane = "dol" | "tl" | "closed";
export function laneFor(stageSort: number): Lane {
  if (stageSort <= 3) return "dol";
  if ((stageSort >= 4 && stageSort <= 11) || stageSort === 14) return "tl";
  return "closed";
}

/** Card color by how long a customer has sat in their stage (movement signal). */
export function agingColor(days: number): string {
  if (days > 90) return "var(--critical)";
  if (days > 60) return "var(--serious)";
  if (days > 30) return "var(--warning)";
  return "var(--good)";
}

/**
 * Plain-language stage name for field staff — no codes, no jargon. Keyed by the
 * stage code so it survives label tweaks in the view.
 */
const PLAIN: Record<string, string> = {
  "00": "Promised, not signed yet",
  "01": "Deposit paid, needs 50%",
  "02": "Deposit paid, needs 50%",
  "03": "Ready to build",
  "04": "Pre-house evaluation",
  "05": "Excavation & anti-termite",
  "06–07": "Screed / wood-float",
  "06-07": "Screed / wood-float",
  "08": "Screed QA check",
  "09": "Fully paid, awaiting build",
  "10": "Paint / varnish delivered",
  "11": "Awaiting final evaluation",
  "12": "Completed",
  "12b": "Completed (no final eval)",
  "13": "Lost",
  "14": "Needs repairs",
  "16": "Special case",
};

export function plainStage(journeyStage: string): string {
  const { code, label } = splitStage(journeyStage);
  return PLAIN[code] ?? label;
}

/** "00 · Promised (not yet contracted)" -> { code: "00", label: "Promised (not yet contracted)" } */
export function splitStage(journeyStage: string): { code: string; label: string } {
  const idx = journeyStage.indexOf("·");
  if (idx === -1) return { code: "", label: journeyStage };
  return {
    code: journeyStage.slice(0, idx).trim(),
    label: journeyStage.slice(idx + 1).trim(),
  };
}

/** Compact integer: 1284 -> "1,284". */
export function fmtInt(n: number): string {
  return n.toLocaleString("en-US");
}

/** 0.42 -> "42%". Null-safe. */
export function fmtPct(v: number | null): string {
  if (v == null) return "-";
  return `${Math.round(v * 100)}%`;
}

/** 125000 -> "125,000". Null-safe. */
export function fmtMoney(v: number | null): string {
  if (v == null) return "-";
  return Math.round(v).toLocaleString("en-US");
}

/** Digits only, for a tel: link. Keeps a leading +. */
export function telHref(phone: string | null): string | null {
  if (!phone) return null;
  const cleaned = phone.replace(/[^\d+]/g, "");
  return cleaned.length >= 7 ? `tel:${cleaned}` : null;
}

/**
 * Sequential blue ramp (matches --seq-* tokens). Maps a value in [0, max] to a
 * hex color, lightest = near zero. Uses a sqrt curve so mid-range counts stay
 * visible rather than washing out.
 */
const RAMP = [
  "#fff3e9", // below the 100 step, for very small non-zero counts
  "#ffe3cc",
  "#ffc79e",
  "#fca86e",
  "#f5843f",
  "#ee7203",
  "#c25a10",
  "#8f3f0c",
];

export function heatColor(value: number, max: number): string {
  if (value <= 0 || max <= 0) return "transparent";
  const t = Math.sqrt(value / max); // 0..1
  const i = Math.min(RAMP.length - 1, Math.max(1, Math.round(t * (RAMP.length - 1))));
  return RAMP[i];
}

/** White or ink text on a heat cell, by how dark the fill is. */
export function heatTextColor(value: number, max: number): string {
  if (value <= 0 || max <= 0) return "var(--text-muted)";
  const t = Math.sqrt(value / max);
  return t > 0.55 ? "#ffffff" : "var(--text-primary)";
}
