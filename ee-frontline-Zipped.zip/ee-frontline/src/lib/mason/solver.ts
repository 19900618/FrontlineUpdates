import type { Assignment, Config, Job, Mason, Priority } from "./types";

export const villageKey = (v: string) => (v ?? "").trim().toLowerCase();

/** Which masons hold which village. A village can be held by more than one mason. */
export function villageIndex(masons: Mason[]): Record<string, string[]> {
  const idx: Record<string, string[]> = {};
  for (const m of masons) for (const v of m.villages) (idx[villageKey(v)] ||= []).push(m.key);
  return idx;
}

/** Jobs that pass the eligibility rules (covered, paid enough, right product, not dead). */
export function eligibleJobs(jobs: Job[], cfg: Config): Job[] {
  const products = new Set(cfg.products);
  return jobs.filter(
    (j) =>
      !j.uncovered &&
      (j.paid ?? 0) >= cfg.minPaid &&
      products.has(j.product) &&
      (cfg.maxAgeDays <= 0 || (j.ageDays ?? 0) <= cfg.maxAgeDays),
  );
}

function scorer(priority: Priority): (j: Job) => number {
  switch (priority) {
    case "oldest": return (j) => j.ageDays ?? 0;
    case "mostPaid": return (j) => j.paid ?? 0;
    case "biggest": return (j) => j.sqm;
    case "balanced":
    default:
      return (j) => {
        const paid = j.paid ?? 0;
        const age = Math.min((j.ageDays ?? 0) / 730, 1);
        const size = Math.min(j.sqm / 60, 1);
        return paid * 100 + age * 25 + size * 10;
      };
  }
}

/**
 * Water-filling assignment: repeatedly give the mason furthest below their capacity target
 * the highest-priority job still free in their own villages. A mason who runs out drops out,
 * and the shortfall stays as a demand gap rather than being swallowed.
 */
export function solve(jobs: Job[], masons: Mason[], cfg: Config): Assignment {
  const score = scorer(cfg.priority);
  const pool = eligibleJobs(jobs, cfg).sort((a, b) => score(b) - score(a));

  const target = (m: Mason) => m.capacity ?? cfg.cap;
  const load: Record<string, number> = {};
  for (const m of masons) load[m.key] = 0;

  const free = new Set(pool.map((j) => j.id));
  const byId = new Map(pool.map((j) => [j.id, j]));

  // A mason can take any eligible job whose sub-unit (territory / district) they cover.
  const candidates: Record<string, string[]> = {};
  for (const m of masons) {
    const own = new Set(m.subs);
    candidates[m.key] = pool.filter((j) => own.has(j.sub)).map((j) => j.id);
  }

  const out: Record<string, string> = {};
  const exhausted = new Set<string>();

  for (;;) {
    let pick: Mason | null = null;
    let lowest = Infinity;
    for (const m of masons) {
      if (m.subs.length === 0 || exhausted.has(m.key)) continue;
      const filled = load[m.key] / target(m);
      if (filled >= 1) continue;
      if (filled < lowest) { lowest = filled; pick = m; }
    }
    if (!pick) break;

    let id = candidates[pick.key].find((i) => free.has(i));
    if (id === undefined) { exhausted.add(pick.key); continue; }

    free.delete(id);
    out[id] = pick.key;
    load[pick.key] += byId.get(id)!.sqm;
  }

  const assignment: Assignment = {};
  for (const j of jobs) assignment[j.id] = out[j.id] ?? null;
  return assignment;
}

export type Band = "starved" | "under" | "onTarget" | "over";
export function band(load: number, cap: number): Band {
  const r = cap > 0 ? load / cap : 0;
  if (r < 0.7) return "starved";
  if (r < 0.9) return "under";
  if (r <= 1.15) return "onTarget";
  return "over";
}
export const BAND_LABEL: Record<Band, string> = { starved: "Under-utilised", under: "Below target", onTarget: "At target", over: "Over target" };
export const BAND_COLOR: Record<Band, string> = {
  starved: "var(--critical)", under: "var(--warning)", onTarget: "var(--good)", over: "var(--accent)",
};
