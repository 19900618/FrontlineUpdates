import { unstable_cache } from "next/cache";
import { productClass } from "@/lib/product-class";
import { query, hasCredentials } from "../bigquery";
import { villageKey } from "./solver";
import type { Dataset, Job, Mason, VillageGap } from "./types";
import "server-only";

/**
 * Mason scheduler data on the Salesforce lineage (same as Collections / the journey).
 * Country-aware geography, matching the rest of the app:
 *   Rwanda      -> primary unit = District, sub-unit = Territory
 *   Uganda/Kenya-> primary unit = Branch (mapped from district), sub-unit = District
 * SQM-E = raw m² × weight (Floor 1.0, Plaster/Paint 0.333). The mason roster and their
 * territories come from TIMESHEETS submitted in the last 4 weeks (mason_timesheet_readable);
 * jobs come from the opportunities pipeline. Coverage is at territory (RW) / district (UG/KE) level.
 */
const LOOKBACK_MONTHS = 12;
const ACTIVE_DAYS = 28; // a mason is "active" if they filed a timesheet in the last 4 weeks
const DEFAULT_CAPACITY = 90; // target SQM-E per mason per month
const REVALIDATE = 300;

const OPP = "`earth-enable-main.salesforce.opportunity`";
const LOC = "`earth-enable-main.salesforce.location_c`";
const CON = "`earth-enable-main.salesforce.contact`";
const TS = "`earth-enable-main.raw_data_from_salesforce.mason_timesheet_readable`";

// Uganda district -> branch (from the collections source-of-truth map); RW/KE branch = district.
const branchCase = (col: string) => `CASE
  WHEN ${col} IN ('Jinja','Kamuli','Kampala','Mayuge','Buyende','Luuka','Buikwe') THEN 'Jinja'
  WHEN ${col} IN ('Sironko','Mbale','Qween','Buyaga','Kapchorwa','Bulambuli','Kadama','Tirinyi','Butebo','Budadiri','Budaka','Butaleja','Namisindwa','Manafwa','Bukedea') THEN 'Mbale'
  WHEN ${col} IN ('Masaka','Bukomansimbi','Kalungu','Mpigi','Sembabule','Rakai','Lwengo','Kyotera') THEN 'Masaka'
  WHEN ${col} IN ('Masindi','Hoima','Buliisa','Kikuube','Kiryandongo','Kyankwanzi') THEN 'Masindi'
  WHEN ${col} IN ('Iganga','Bugiri','Namutumba','Kaliro','Bugweri','Namayingo','Tororo','Busia','Kibuku') THEN 'Iganga'
  WHEN ${col} IN ('Ntungamo','Sheema','Mitoma','Bushenyi','Rukungiri','Rukiga') THEN 'Ntungamo'
  WHEN ${col} IN ('Luweero','Nakasongola','Nakaseke') THEN 'Luweero'
  WHEN ${col} IN ('Mbarara','Rwampara','Isingiro','Kiruhuura','Lyantonde') THEN 'Mbarara'
  WHEN ${col} IN ('Soroti','Serere','Kalaki','Kaberamaido','Amuria','Amuru','Kapelebyong','Katakwi','Ngora','Kumi') THEN 'Soroti'
  WHEN ${col} IN ('Ibanda','Kamwenge','Kazo','Kitagwenda') THEN 'Ibanda'
  ELSE ${col} END`;
const BRANCH = branchCase("L.district_c");

// The company's classification, from the one shared definition (sql/product_class.sql).
const CAT = productClass("prod");
const WEIGHT = `CASE WHEN product='Floor' THEN 1.0 WHEN product IN ('Plaster','Paint') THEN 1.0/3 ELSE 0 END`;
// sub-unit filter: Territory in Rwanda, District elsewhere
const SUB_FILTER = `(@sub = '' OR (@country = 'Rwanda' AND territory = @sub) OR (@country != 'Rwanda' AND district = @sub))`;

const JOBS_SQL = `
WITH base AS (
  SELECT o.id, o.name AS opp, COALESCE(cust.name, o.name) AS customer,
    L.name AS village, COALESCE(L.umudugudu_cell_c,'') AS cell, COALESCE(L.umudugudu_sector_c,'') AS sector,
    COALESCE(S.territory_c,'') AS territory, L.district_c AS district, ${BRANCH} AS branch,
    o.franchisee_mason_building_the_asset_c AS currentMasonId, mason.name AS currentMason, cso.name AS cso,
    o.total_square_meters_c AS raw_sqm, COALESCE(o.product_interest_c, o.new_product_interest_c) AS prod,
    o.customer_signed_date_c AS signedDate,
    COALESCE(SAFE_DIVIDE(o.total_cash_paid_c, NULLIF(o.total_payment_amount_c,0)),0) AS paid_raw
  FROM ${OPP} o
  LEFT JOIN ${LOC} L ON o.umudugudu_c = L.id
  LEFT JOIN ${LOC} S ON L.sector_c = S.id
  LEFT JOIN ${CON} cust ON o.customer_c = cust.id
  LEFT JOIN ${CON} mason ON o.franchisee_mason_building_the_asset_c = mason.id
  LEFT JOIN ${CON} cso ON o.signed_by_employee_c = cso.id
  WHERE o._fivetran_deleted = FALSE AND o.country_c = @country AND o.phase_c = '1'
    AND o.date_associated_project_completed_c IS NULL AND o.stage_name != 'Closed Lost'
),
cls AS ( SELECT *, ${CAT} AS product FROM base )
SELECT id, opp, customer, village, cell, sector, territory, district, product,
  ROUND(raw_sqm * ${WEIGHT}, 2) AS sqm, ${WEIGHT} AS weight, ROUND(raw_sqm, 2) AS rawSqm,
  ROUND(LEAST(paid_raw, 1.0), 3) AS paid, CAST(signedDate AS STRING) AS signedDate,
  DATE_DIFF(CURRENT_DATE(), signedDate, DAY) AS ageDays, currentMasonId, currentMason, cso
FROM cls
WHERE product IN ('Floor','Plaster','Paint') AND raw_sqm > 0 AND branch = @unit AND ${SUB_FILTER}
ORDER BY sqm DESC
`;

// Roster = masons who filed a timesheet in the last @activeDays days; territories come from those timesheets.
const MASONS_SQL = `
WITH ts AS (
  SELECT mason_id AS id, mason AS name, district, territory, umudugudu AS village,
    ${branchCase("district")} AS branch,
    CASE WHEN @country = 'Rwanda' THEN territory ELSE district END AS sub,
    sqm AS raw_sqm, end_date, COALESCE(product_interest, product_interest_new) AS prod
  FROM ${TS}
  WHERE NOT COALESCE(is_deleted, FALSE) AND NOT COALESCE(fivetran_deleted, FALSE)
    AND country = @country AND mason_id IS NOT NULL AND mason IS NOT NULL
    AND end_date >= DATE_SUB(CURRENT_DATE(), INTERVAL @activeDays DAY)
),
c AS ( SELECT *, ${CAT} AS product FROM ts )
SELECT id, ANY_VALUE(name) AS name, COUNT(*) AS completedJobs, ROUND(SUM(raw_sqm * ${WEIGHT}), 1) AS completedSqm,
  CAST(MAX(end_date) AS STRING) AS lastCompleted,
  ARRAY_AGG(DISTINCT territory IGNORE NULLS LIMIT 6) AS territories,
  ARRAY_AGG(DISTINCT sub IGNORE NULLS LIMIT 20) AS subsWorked,
  ARRAY_AGG(DISTINCT village IGNORE NULLS LIMIT 120) AS villagesWorked
FROM c
WHERE branch = @unit AND ${SUB_FILTER}
GROUP BY id
ORDER BY completedSqm DESC
`;

const UNITS_SQL = `
SELECT unit, COUNT(*) AS activeJobs FROM (
  SELECT ${BRANCH} AS unit
  FROM ${OPP} o JOIN ${LOC} L ON o.umudugudu_c = L.id
  WHERE o._fivetran_deleted = FALSE AND o.country_c = @country AND o.phase_c = '1'
    AND o.date_associated_project_completed_c IS NULL AND o.stage_name != 'Closed Lost' AND o.total_square_meters_c > 0
)
WHERE unit IS NOT NULL AND unit != '' GROUP BY unit HAVING activeJobs >= 20 ORDER BY activeJobs DESC
`;

const SUBS_SQL = `
SELECT DISTINCT sub FROM (
  SELECT ${BRANCH} AS unit,
    CASE WHEN @country = 'Rwanda' THEN COALESCE(S.territory_c,'') ELSE COALESCE(L.district_c,'') END AS sub
  FROM ${OPP} o JOIN ${LOC} L ON o.umudugudu_c = L.id LEFT JOIN ${LOC} S ON L.sector_c = S.id
  WHERE o._fivetran_deleted = FALSE AND o.country_c = @country AND o.phase_c = '1'
    AND o.date_associated_project_completed_c IS NULL AND o.stage_name != 'Closed Lost' AND o.total_square_meters_c > 0
)
WHERE unit = @unit AND sub IS NOT NULL AND sub != '' ORDER BY sub
`;

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const str = (v: unknown): string => (v == null ? "" : String(v));

type JobRow = Record<string, unknown>;
type MasonRow = {
  id: string; name: string | null; completedJobs: number; completedSqm: number;
  lastCompleted: string | null; territories: string[] | null; subsWorked: string[] | null; villagesWorked: string[] | null;
};

async function fetchDataset(country: string, unit: string, sub: string): Promise<Dataset> {
  const unitRows = await query<{ unit: string }>(UNITS_SQL, { country });
  const units = unitRows.map((r) => String(r.unit));
  const resolvedUnit = unit && units.includes(unit) ? unit : (units[0] ?? "");

  const [jobRows, masonRows, subRows] = await Promise.all([
    query<JobRow>(JOBS_SQL, { country, unit: resolvedUnit, sub }),
    query<MasonRow>(MASONS_SQL, { country, unit: resolvedUnit, sub, activeDays: ACTIVE_DAYS }),
    query<{ sub: string }>(SUBS_SQL, { country, unit: resolvedUnit }),
  ]);
  const subs = subRows.map((r) => String(r.sub)).filter(Boolean);

  const masons: Mason[] = masonRows
    .filter((r) => r.name != null && String(r.name).trim() !== "")
    .map((r) => ({
      id: r.id, key: r.id, name: String(r.name),
      territory: r.subsWorked?.[0] ?? r.territories?.[0] ?? "", villages: r.villagesWorked ?? [], subs: r.subsWorked ?? [], capacity: null as number | null,
      completedJobs: num(r.completedJobs), completedSqm: num(r.completedSqm),
      lastCompleted: r.lastCompleted ?? null, unallocated: (r.subsWorked ?? []).length === 0,
    }))
    .sort((a, b) => b.completedSqm - a.completedSqm);

  // Coverage is at the sub-unit level: a mason covers a whole territory (Rwanda) or district (UG/KE),
  // not just the individual villages they have worked. A job is uncovered when no mason works its sub-unit.
  const covered = new Set(masons.flatMap((m) => m.subs));

  const jobs: Job[] = jobRows.map((r) => {
    const sub = country === "Rwanda" ? str(r.territory) : str(r.district);
    return {
      id: str(r.id), opp: str(r.opp), customer: str(r.customer),
      village: str(r.village), cell: str(r.cell), sector: str(r.sector), territory: str(r.territory), sub,
      product: str(r.product), sqm: num(r.sqm), weight: num(r.weight), rawSqm: num(r.rawSqm),
      paid: r.paid == null ? null : num(r.paid),
      signedDate: r.signedDate == null ? null : str(r.signedDate),
      ageDays: r.ageDays == null ? null : num(r.ageDays),
      currentMasonId: r.currentMasonId == null ? null : str(r.currentMasonId),
      currentMason: r.currentMason == null ? null : str(r.currentMason),
      cso: r.cso == null ? null : str(r.cso),
      uncovered: sub === "" ? true : !covered.has(sub),
    };
  });

  const gapMap = new Map<string, VillageGap>();
  for (const j of jobs) {
    if (!j.uncovered) continue;
    const k = villageKey(j.village);
    const g = gapMap.get(k) ?? { village: j.village, sector: j.sector, territory: j.territory, jobs: 0, sqm: 0 };
    g.jobs += 1; g.sqm += j.sqm; gapMap.set(k, g);
  }
  const uncoveredVillages = [...gapMap.values()].map((g) => ({ ...g, sqm: Math.round(g.sqm * 10) / 10 })).sort((a, b) => b.sqm - a.sqm);

  const sum = (xs: Job[]) => Math.round(xs.reduce((s, j) => s + j.sqm, 0));
  const cov = jobs.filter((j) => !j.uncovered);
  const unc = jobs.filter((j) => j.uncovered);

  return {
    meta: {
      country, unit: resolvedUnit, sub, units, subs,
      generatedAt: new Date().toISOString(), live: true, warning: null,
      lookbackMonths: LOOKBACK_MONTHS, defaultCapacity: DEFAULT_CAPACITY,
      totalJobs: jobs.length, totalSqm: sum(jobs),
      coveredJobs: cov.length, coveredSqm: sum(cov), uncoveredJobs: unc.length, uncoveredSqm: sum(unc),
      villagesTotal: new Set(jobs.map((j) => villageKey(j.village))).size,
      villagesCovered: new Set(cov.map((j) => villageKey(j.village))).size,
      masonCount: masons.length, unallocatedMasons: masons.filter((m) => m.unallocated).length,
    },
    masons, jobs, uncoveredVillages,
  };
}

const cachedDataset = unstable_cache(fetchDataset, ["mason-dataset-v6"], { revalidate: REVALIDATE, tags: ["mason"] });

export async function getMasonDataset(country = "Rwanda", unit = "Kamonyi", sub = ""): Promise<Dataset> {
  if (!hasCredentials()) return emptyDataset(country, unit, sub, "No BigQuery credentials found.");
  try {
    return await cachedDataset(country, unit, sub);
  } catch (err) {
    return emptyDataset(country, unit, sub, `BigQuery read failed: ${err instanceof Error ? err.message : String(err)}`);
  }
}

function emptyDataset(country: string, unit: string, sub: string, warning: string): Dataset {
  return {
    meta: {
      country, unit, sub, units: [], subs: [],
      generatedAt: new Date().toISOString(), live: false, warning,
      lookbackMonths: LOOKBACK_MONTHS, defaultCapacity: DEFAULT_CAPACITY,
      totalJobs: 0, totalSqm: 0, coveredJobs: 0, coveredSqm: 0, uncoveredJobs: 0, uncoveredSqm: 0,
      villagesTotal: 0, villagesCovered: 0, masonCount: 0, unallocatedMasons: 0,
    },
    masons: [], jobs: [], uncoveredVillages: [],
  };
}
