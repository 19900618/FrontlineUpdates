export type Job = {
  id: string;
  opp: string;
  customer: string;
  village: string;
  cell: string;
  sector: string;
  territory: string;
  /** Coverage unit: Territory (Rwanda) or District (UG/KE). A mason covers whole sub-units. */
  sub: string;
  product: string; // "Floor" | "Plaster" | "Paint"
  /** SQM equivalent = raw m² × weight (Floor 1.0, Plaster/Paint 0.333). */
  sqm: number;
  weight: number;
  rawSqm: number;
  /** capped percentage paid (never exceeds 1.0). */
  paid: number | null;
  signedDate: string | null;
  ageDays: number | null;
  currentMasonId: string | null;
  currentMason: string | null;
  cso: string | null;
  /** True when no mason in the roster covers this job's village. */
  uncovered: boolean;
};

export type Mason = {
  id: string | null;
  key: string;
  name: string;
  territory: string;
  villages: string[];
  /** Sub-units this mason covers: Territories (Rwanda) or Districts (UG/KE). */
  subs: string[];
  capacity: number | null;
  completedJobs: number;
  completedSqm: number;
  lastCompleted: string | null;
  /** True when the mason is working but holds no villages. */
  unallocated: boolean;
};

export type VillageGap = { village: string; sector: string; territory: string; jobs: number; sqm: number };

export type Meta = {
  country: string;
  unit: string; // primary scope: District (Rwanda) or Branch (UG/KE)
  sub: string; // applied sub-filter ("" = all)
  units: string[]; // primary units in the country
  subs: string[]; // sub-units in the current unit
  generatedAt: string;
  live: boolean;
  warning: string | null;
  lookbackMonths: number;
  defaultCapacity: number;
  totalJobs: number;
  totalSqm: number;
  coveredJobs: number;
  coveredSqm: number;
  uncoveredJobs: number;
  uncoveredSqm: number;
  villagesTotal: number;
  villagesCovered: number;
  masonCount: number;
  unallocatedMasons: number;
};

export type Dataset = {
  meta: Meta;
  masons: Mason[];
  jobs: Job[];
  uncoveredVillages: VillageGap[];
};

export type Priority = "balanced" | "oldest" | "mostPaid" | "biggest";

export type Config = {
  cap: number;
  minPaid: number;
  products: string[];
  priority: Priority;
  maxAgeDays: number;
  sectorFallback: boolean;
};

export type Assignment = Record<string, string | null>;
