/**
 * Client-safe helpers for the capacity planning page. No server imports here so
 * the board and its children can use them without pulling BigQuery into the
 * browser bundle. Nothing in this file decides a threshold: those come from the
 * views. This file only formats and colours what the views already decided.
 */
import type { CapacityLevel, CapacityTrendRow } from "./capacity";

/**
 * The series colours used across the CSO module, so a reader learns each one
 * once: sales orange, collections blue, builds charcoal. The two hexes are the
 * only hardcoded colours the house style allows.
 */
export const SERIES_SALES = "#ee7203";
export const SERIES_COLL = "#2f6f9f";
export const SERIES_BUILDS = "var(--text-secondary)";

/**
 * The countries on the page. Rwanda is organised territory inside district,
 * grouped by manager; Uganda and Kenya have branches only. The logic is the
 * same everywhere, only the unit changes. Which unit, and the CSOs per unit,
 * are decided in the view; this only names the unit for the reader.
 */
export type CapacityCountry = "Rwanda" | "Uganda" | "Kenya";
export const CAPACITY_COUNTRIES: CapacityCountry[] = ["Rwanda", "Uganda", "Kenya"];
export const CAPACITY_CURRENCY: Record<CapacityCountry, string> = { Rwanda: "RWF", Uganda: "UGX", Kenya: "KES" };
export type UnitLevel = "territory" | "branch";
export const UNIT_LEVEL: Record<CapacityCountry, UnitLevel> = { Rwanda: "territory", Uganda: "branch", Kenya: "branch" };
export const currencyOf = (country: string): string => CAPACITY_CURRENCY[country as CapacityCountry] ?? "";
const CAPACITY_TZ: Record<CapacityCountry, string> = { Rwanda: "Africa/Kigali", Uganda: "Africa/Kampala", Kenya: "Africa/Nairobi" };

/** An ISO timestamp as "16 Sep, 10:30" in the country's own time zone, for the "Data as at" line. */
export function dataAsAt(iso: string, country: CapacityCountry): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: CAPACITY_TZ[country], day: "numeric", month: "short", hour: "2-digit", minute: "2-digit", hour12: false,
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("day")} ${get("month")}, ${get("hour")}:${get("minute")}`;
}

/** 'territory' -> 'territories', 'branch' -> 'branches', 'district' -> 'districts'; singular when n is 1. */
export function unitWord(level: string, n = 2): string {
  if (n === 1) return level;
  return level === "territory" ? "territories" : level === "branch" ? "branches" : `${level}s`;
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** '2026-09-07' -> '7 Sep'. Parsed by hand so the date never shifts with the viewer's timezone. */
export function dayMonth(iso: string): string {
  const [, m, d] = iso.split("-").map(Number);
  return `${d} ${MONTHS[m - 1]}`;
}

/** '2026-09-01'..'2026-09-07' -> '1-7 Sep'. */
export function dayRange(start: string, end: string): string {
  return `${Number(start.split("-")[2])}-${dayMonth(end)}`;
}

/** '2026-09-01'..'2026-09-07' -> '1-7', for narrow screens where the month is already in the label. */
export function dayRangeShort(start: string, end: string): string {
  return `${Number(start.split("-")[2])}-${Number(end.split("-")[2])}`;
}

/** 'W1' + 'Sep' from a trend row, for chart axes. */
export function weekShort(t: { weekNo: number; month: string }): string {
  return `W${t.weekNo} ${MONTHS[Number(t.month.split("-")[1]) - 1]}`;
}

export const pctText = (v: number | null): string => (v == null ? "-" : `${Math.round(v * 100)}%`);

/** Compact money with one decimal: 1_234_567 -> '1.2M', 26_510 -> '26.5K', 950 -> '950'. */
export function fmtK(n: number | null): string {
  if (n == null) return "-";
  const a = Math.abs(n);
  if (a >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (a >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return String(Math.round(n));
}

/** 1234.56 -> '1,235'. Null-safe. People and SQM-E are never shown with decimals. */
export function fmtWhole(n: number | null): string {
  return n == null ? "-" : Math.round(n).toLocaleString("en-US");
}

/** 2.35 -> '2.4'. Null-safe. For rates only, never headcounts. */
export function fmt1(n: number | null): string {
  return n == null ? "-" : (Math.round(n * 10) / 10).toLocaleString("en-US");
}

/**
 * How a figure reads against its target, in the status tokens every page uses:
 * green met it, amber came within 20%, red fell short.
 */
export type Perf = "hit" | "near" | "miss" | "none";
export const PERF_COLOR: Record<Perf, string> = {
  hit: "var(--good)",
  near: "var(--warning)",
  miss: "var(--critical)",
  none: "var(--border)",
};
export function perfOf(score: number | null): Perf {
  if (score == null) return "none";
  if (score >= 1) return "hit";
  if (score >= 0.8) return "near";
  return "miss";
}
export const perfColor = (score: number | null): string => PERF_COLOR[perfOf(score)];

/**
 * The last `n` single weeks for one level and name, ending at the week that
 * starts on `lastWeekStart`. Weeks run continuously across month ends because
 * the trend rows cover three months.
 */
export function trendWindow(
  trend: CapacityTrendRow[], level: CapacityLevel, name: string, lastWeekStart: string, n = 5,
): CapacityTrendRow[] {
  const series = trend
    .filter((t) => t.level === level && t.name === name)
    .sort((a, b) => a.weekStart.localeCompare(b.weekStart));
  const idx = series.findIndex((t) => t.weekStart === lastWeekStart);
  if (idx < 0) return [];
  return series.slice(Math.max(0, idx - n + 1), idx + 1);
}

/** A round axis ceiling: 37 -> 40, 0.83 -> 1, 128_000 -> 150_000. */
export function niceCeil(v: number): number {
  if (v <= 0) return 1;
  const p = 10 ** Math.floor(Math.log10(v));
  const f = v / p;
  const nice = f <= 1 ? 1 : f <= 1.5 ? 1.5 : f <= 2 ? 2 : f <= 3 ? 3 : f <= 4 ? 4 : f <= 5 ? 5 : f <= 8 ? 8 : 10;
  return nice * p;
}
