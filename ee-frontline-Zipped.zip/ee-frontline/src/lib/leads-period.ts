/**
 * The window every country page reads, resolved on the server so the page and its
 * drill-downs always agree. Dates are UTC, the clock BigQuery's CURRENT_DATE()
 * keeps and the one src/lib/capacity-calendar.ts uses. Client-safe: no server imports.
 *
 * A period is either a month, optionally narrowed to one of its four weeks, or a
 * quarter. Weeks are days 1-7, 8-14, 15-21 and 22 to the end of the month, the same
 * windows the capacity pages use, so "W3" means the same thing across the app. They
 * are not Monday-to-Sunday weeks: a month has exactly four, and the last one is
 * seven, eight, nine or ten days long depending on the month.
 */
import type { PeriodInfo } from "./period";

export type PeriodMode = "month" | "quarter";
export type Week = 1 | 2 | 3 | 4;

export type Period = {
  mode: PeriodMode;
  year: number;
  /** 1-12, on a month period. */
  month: number | null;
  /** null means the whole month. */
  week: Week | null;
  /** 1-4, on a quarter period. */
  quarter: number | null;
  from: string;
  to: string;
  /** "September 2026", "September 2026 · W3", "Q3 2026". */
  label: string;
  /** What the window covers, for the line under the heading. */
  range: string;
};

export const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
export const WEEKS: Week[] = [1, 2, 3, 4];

const iso = (d: Date): string => d.toISOString().slice(0, 10);
const utc = (day: string): Date => new Date(`${day}T00:00:00Z`);
export const todayUtc = (): string => iso(new Date());

/** Last day of a month, as a UTC date. */
const endOfMonth = (year: number, month: number): Date => new Date(Date.UTC(year, month, 0));

/** The first and last day of week n, where week 4 runs to the end of the month. */
export function weekWindow(year: number, month: number, week: Week): { from: string; to: string } {
  const last = endOfMonth(year, month).getUTCDate();
  const startDay = (week - 1) * 7 + 1;
  const endDay = week === 4 ? last : week * 7;
  const pad = (n: number) => String(n).padStart(2, "0");
  return { from: `${year}-${pad(month)}-${pad(startDay)}`, to: `${year}-${pad(month)}-${pad(Math.min(endDay, last))}` };
}

const pretty = (from: string, to: string): string => {
  const a = utc(from), b = utc(to);
  const day = (d: Date) => `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()].slice(0, 3)}`;
  if (from === to) return `${day(a)} ${a.getUTCFullYear()}`;
  return `${day(a)} to ${day(b)} ${b.getUTCFullYear()}`;
};

const int = (v: string | undefined, lo: number, hi: number): number | null => {
  if (!v || !/^\d+$/.test(v)) return null;
  const n = Number(v);
  return n >= lo && n <= hi ? n : null;
};

/**
 * Resolve a period from the URL. Anything missing or malformed falls back to the
 * whole of the current month, so a hand-edited URL can never produce an empty or
 * reversed window. The window is never clipped to today: asking for September
 * asks for all of September, and a month still running simply has no rows yet
 * for the days that have not happened.
 */
export function resolvePeriod(
  params: { mode?: string; year?: string; month?: string; week?: string; quarter?: string },
  today: string = todayUtc(),
): Period {
  const t = utc(today);
  const year = int(params.year, 2000, 2100) ?? t.getUTCFullYear();

  if (params.mode === "quarter") {
    const quarter = int(params.quarter, 1, 4) ?? Math.floor(t.getUTCMonth() / 3) + 1;
    const firstMonth = (quarter - 1) * 3 + 1;
    const from = `${year}-${String(firstMonth).padStart(2, "0")}-01`;
    const to = iso(endOfMonth(year, firstMonth + 2));
    return { mode: "quarter", year, month: null, week: null, quarter, from, to, label: `Q${quarter} ${year}`, range: pretty(from, to) };
  }

  const month = int(params.month, 1, 12) ?? t.getUTCMonth() + 1;
  const week = int(params.week, 1, 4) as Week | null;
  if (week) {
    const { from, to } = weekWindow(year, month, week);
    return {
      mode: "month", year, month, week, quarter: null, from, to,
      label: `${MONTHS[month - 1]} ${year} · W${week}`,
      range: pretty(from, to),
    };
  }
  const from = `${year}-${String(month).padStart(2, "0")}-01`;
  const to = iso(endOfMonth(year, month));
  return {
    mode: "month", year, month, week: null, quarter: null, from, to,
    label: `${MONTHS[month - 1]} ${year}`,
    range: pretty(from, to),
  };
}

/**
 * The shared period control's choice (src/lib/period.ts, URL `p` and `w`) in
 * this module's shape, so the Quality and Territory leads pages read the same
 * window as every other page. A whole month or a single week maps exactly; a
 * set of several weeks becomes the span from the first to the last, because
 * these pages' queries take one date range.
 */
export function leadsPeriodOf(info: PeriodInfo): Period {
  const year = Number(info.month.slice(0, 4));
  if (info.mode === "quarter") {
    const quarter = Math.floor((Number(info.month.slice(5, 7)) - 1) / 3) + 1;
    const firstMonth = (quarter - 1) * 3 + 1;
    const from = `${year}-${String(firstMonth).padStart(2, "0")}-01`;
    const to = iso(endOfMonth(year, firstMonth + 2));
    return { mode: "quarter", year, month: null, week: null, quarter, from, to, label: `Q${quarter} ${year}`, range: pretty(from, to) };
  }
  const month = Number(info.month.slice(5, 7));
  if (info.isWhole || info.weeks.length === 0) {
    const from = `${year}-${String(month).padStart(2, "0")}-01`;
    const to = iso(endOfMonth(year, month));
    return { mode: "month", year, month, week: null, quarter: null, from, to, label: `${MONTHS[month - 1]} ${year}`, range: pretty(from, to) };
  }
  if (info.weeks.length === 1) {
    const week = info.weeks[0] as Week;
    const { from, to } = weekWindow(year, month, week);
    return { mode: "month", year, month, week, quarter: null, from, to, label: `${MONTHS[month - 1]} ${year} · W${week}`, range: pretty(from, to) };
  }
  return { mode: "month", year, month, week: null, quarter: null, from: info.start, to: info.end, label: info.label, range: pretty(info.start, info.end) };
}

/** The period as query-string params, so a link carries exactly what is on screen. */
export function periodQuery(p: Partial<Period> & Pick<Period, "mode" | "year">): string {
  const q = new URLSearchParams({ mode: p.mode, year: String(p.year) });
  if (p.mode === "quarter") q.set("quarter", String(p.quarter ?? 1));
  else {
    q.set("month", String(p.month ?? 1));
    if (p.week) q.set("week", String(p.week));
  }
  return q.toString();
}

/** One step on the trend under the scorecards: a month or a quarter. */
export type Bucket = { key: string; label: string };

/**
 * The six periods ending with the one on screen, and the window that covers them.
 * The grain follows the picker, so choosing a quarter compares quarters rather
 * than dropping back to months. Buckets are listed here, not taken from the query,
 * so a period with no evaluations still draws as a gap instead of vanishing.
 */
export function trendWindow(period: Period, count = 6): { from: string; to: string; grain: PeriodMode; buckets: Bucket[] } {
  const buckets: Bucket[] = [];
  if (period.mode === "quarter") {
    let y = period.year, q = period.quarter ?? 1;
    for (let i = 0; i < count; i++) {
      buckets.unshift({ key: `${y}-Q${q}`, label: `Q${q} ${y}` });
      q -= 1;
      if (q === 0) { q = 4; y -= 1; }
    }
    const firstMonth = (Number(buckets[0].key.slice(-1)) - 1) * 3 + 1;
    const from = `${buckets[0].key.slice(0, 4)}-${String(firstMonth).padStart(2, "0")}-01`;
    return { from, to: period.to, grain: "quarter", buckets };
  }
  let y = period.year, m = period.month ?? 1;
  for (let i = 0; i < count; i++) {
    buckets.unshift({ key: `${y}-${String(m).padStart(2, "0")}`, label: `${MONTHS[m - 1].slice(0, 3)} ${y}` });
    m -= 1;
    if (m === 0) { m = 12; y -= 1; }
  }
  // The trend always covers whole months, even when the page is showing one week.
  const to = iso(endOfMonth(period.year, period.month ?? 1));
  return { from: `${buckets[0].key}-01`, to, grain: "month", buckets };
}
