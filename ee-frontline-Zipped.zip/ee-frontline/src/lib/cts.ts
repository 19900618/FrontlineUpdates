import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import type { CountryName } from "./workspaces";

/**
 * The Cost to serve page's data layer (docs/cts-page-and-revenue.md, item 1).
 * Thin reader over the two QuickBooks views Looker reads, one year, all
 * three countries in one cache entry:
 *
 *   Country   qb_reporting.country_financials  -> cts_country (closed months)
 *             qb_reporting.country_financial_targets -> the budget, derived:
 *             (revenue - cogs - district_expense - country_expense) / sqme,
 *             numerators and denominators summed per country and month
 *   Branch    qb_reporting.branch_financials -> cost_to_serve and
 *             cost_to_serve_target, read as they are
 *
 * Every figure comes back in local currency and in USD at the month's
 * rate_per_usd (qb_reporting.fx_rates_monthly, the budget rates), so the
 * page's currency toggle picks a column and never recomputes. Cost to serve
 * is negative in the data; the absolute value is carried so the charts read
 * as a cost. A month whose books are not closed has no actual. Year to date
 * is the sum of the closed months' burn over the sum of their SQM-E (in USD:
 * the sum of each month's burn at its own rate), never an average of months;
 * that is what gives Rwanda's 5.3.
 *
 * The country figure is the one the CEO dashboard and Looker (9c, 9d) show;
 * the branch figure is a different, lower number (district costs only, before
 * country overheads) and is labelled as such on the page.
 *
 * Both views are computed over the QuickBooks transaction tables and take
 * about 30 seconds each, so the year is one cache entry kept warm by the cron
 * (/api/capacity/warm), on the same 15-minute cache as the CEO dashboard so
 * the two pages never disagree. The materialisation that would make them
 * fast is written (sql/qb_financials_tables.sql) but needs rights the app's
 * service account does not have.
 */
export type CtsRow = {
  /** "YYYY-MM", or "YTD" for the year-to-date row. */
  month: string;
  closed: boolean;
  /** Local currency units per USD for the month; null when fx_rates_monthly has none. */
  rate: number | null;
  /** The absolute cost to serve per SQM-E; null when the books are open or nothing was built. */
  actualLocal: number | null;
  actualUsd: number | null;
  /** The absolute budget or target per SQM-E. */
  budgetLocal: number | null;
  budgetUsd: number | null;
};
export type CtsBranch = { branch: string; rows: CtsRow[]; ytd: CtsRow | null };
export type CtsCountry = {
  country: CountryName;
  currency: string;
  rows: CtsRow[];
  ytd: CtsRow | null;
  branches: CtsBranch[];
};
export type CtsData = {
  year: number;
  /** "YYYY-MM", January to the current month. */
  months: string[];
  countries: Record<CountryName, CtsCountry>;
  builtAt: string;
};

const FIN = "`earth-enable-main.qb_reporting.country_financials`";
const TARGETS = "`earth-enable-main.qb_reporting.country_financial_targets`";
const BRANCH = "`earth-enable-main.qb_reporting.branch_financials`";
const FX = "`earth-enable-main.qb_reporting.fx_rates_monthly`";
const COUNTRIES = "('Rwanda', 'Uganda', 'Kenya')";
const CURRENCY: Record<CountryName, string> = { Rwanda: "RWF", Uganda: "UGX", Kenya: "KES" };
const REVALIDATE = 900; // 15 min, the CEO dashboard's cache, so the two pages agree

/** The country layer: one row per country and month, plus a YTD row per country over the closed months. */
export const CTS_COUNTRY_SQL = `
WITH f AS (
  SELECT country, month, books_closed = 1 AS closed, rate_per_usd,
    revenue - cogs - district_expense - country_expense AS burn, sqme_built, cts_country
  FROM ${FIN}
  WHERE year = @year AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH) AND country IN ${COUNTRIES}
),
b AS (
  SELECT country, month,
    SUM(IF(metric = 'revenue', target_value, 0)) - SUM(IF(metric = 'cogs', target_value, 0))
      - SUM(IF(metric = 'district_expense', target_value, 0)) - SUM(IF(metric = 'country_expense', target_value, 0)) AS burn_target,
    NULLIF(SUM(IF(metric = 'sqme', target_value, 0)), 0) AS sqme_target
  FROM ${TARGETS}
  WHERE EXTRACT(YEAR FROM month) = @year AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH) AND country IN ${COUNTRIES}
  GROUP BY country, month
),
m AS (
  SELECT COALESCE(f.country, b.country) AS country, COALESCE(f.month, b.month) AS month,
    COALESCE(f.closed, FALSE) AS closed,
    COALESCE(f.rate_per_usd, fx.rate_per_usd) AS rate,
    IF(f.closed, f.burn, NULL) AS burn, IF(f.closed, f.sqme_built, NULL) AS sqme,
    IF(f.closed, ABS(f.cts_country), NULL) AS actual,
    b.burn_target, b.sqme_target, ABS(b.burn_target / b.sqme_target) AS budget
  FROM f FULL OUTER JOIN b USING (country, month)
  LEFT JOIN ${FX} fx ON fx.country = COALESCE(f.country, b.country) AND fx.month = COALESCE(f.month, b.month)
)
SELECT country, FORMAT_DATE('%Y-%m', month) AS month, closed, rate,
  actual AS actual_local, actual / NULLIF(rate, 0) AS actual_usd,
  budget AS budget_local, budget / NULLIF(rate, 0) AS budget_usd
FROM m
UNION ALL
-- Year to date over the closed months: burn summed over SQM-E summed, each month's burn at its own rate.
SELECT country, 'YTD', TRUE, NULL,
  ABS(SAFE_DIVIDE(SUM(burn), SUM(sqme))), ABS(SAFE_DIVIDE(SUM(burn / NULLIF(rate, 0)), SUM(sqme))),
  ABS(SAFE_DIVIDE(SUM(burn_target), SUM(sqme_target))), ABS(SAFE_DIVIDE(SUM(burn_target / NULLIF(rate, 0)), SUM(sqme_target)))
FROM m WHERE closed GROUP BY country
ORDER BY country, month`;

/** The branch layer, read as the view carries it: one row per branch and month, plus a YTD row per branch. */
export const CTS_BRANCH_SQL = `
WITH m AS (
  SELECT country, branch, month, books_closed = 1 AS closed, rate_per_usd AS rate,
    IF(books_closed = 1, ABS(cost_to_serve), NULL) AS actual, ABS(cost_to_serve_target) AS target,
    IF(books_closed = 1, burn, NULL) AS burn, IF(books_closed = 1, sqme_built, NULL) AS sqme,
    burn_target, NULLIF(sqme_target, 0) AS sqme_target
  FROM ${BRANCH}
  WHERE year = @year AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH) AND country IN ${COUNTRIES}
)
SELECT country, branch, FORMAT_DATE('%Y-%m', month) AS month, closed, rate,
  actual AS actual_local, actual / NULLIF(rate, 0) AS actual_usd,
  target AS budget_local, target / NULLIF(rate, 0) AS budget_usd
FROM m
UNION ALL
SELECT country, branch, 'YTD', TRUE, NULL,
  ABS(SAFE_DIVIDE(SUM(burn), SUM(sqme))), ABS(SAFE_DIVIDE(SUM(burn / NULLIF(rate, 0)), SUM(sqme))),
  ABS(SAFE_DIVIDE(SUM(burn_target), SUM(sqme_target))), ABS(SAFE_DIVIDE(SUM(burn_target / NULLIF(rate, 0)), SUM(sqme_target)))
FROM m WHERE closed GROUP BY country, branch
ORDER BY country, branch, month`;

const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const row = (r: Record<string, unknown>): CtsRow => ({
  month: String(r.month), closed: Boolean(r.closed), rate: numOrNull(r.rate),
  actualLocal: numOrNull(r.actual_local), actualUsd: numOrNull(r.actual_usd),
  budgetLocal: numOrNull(r.budget_local), budgetUsd: numOrNull(r.budget_usd),
});

/** January to the current month of `year` (every month of a past year). */
export function ctsMonths(year: number, now = new Date()): string[] {
  const last = year < now.getUTCFullYear() ? 12 : year > now.getUTCFullYear() ? 0 : now.getUTCMonth() + 1;
  return Array.from({ length: last }, (_, i) => `${year}-${String(i + 1).padStart(2, "0")}`);
}

async function fetchCtsData(year: number): Promise<CtsData> {
  type R = Record<string, unknown>;
  const [country, branch] = await Promise.all([query<R>(CTS_COUNTRY_SQL, { year }), query<R>(CTS_BRANCH_SQL, { year })]);
  const months = ctsMonths(year);
  const countries = {} as Record<CountryName, CtsCountry>;
  for (const c of ["Rwanda", "Uganda", "Kenya"] as CountryName[]) {
    const mine = country.filter((r) => r.country === c).map(row);
    const byMonth = new Map(mine.map((r) => [r.month, r]));
    const branches = new Map<string, CtsRow[]>();
    for (const r of branch.filter((x) => x.country === c)) {
      const name = String(r.branch);
      if (!branches.has(name)) branches.set(name, []);
      branches.get(name)!.push(row(r));
    }
    const blank = (month: string): CtsRow => ({ month, closed: false, rate: null, actualLocal: null, actualUsd: null, budgetLocal: null, budgetUsd: null });
    countries[c] = {
      country: c, currency: CURRENCY[c],
      rows: months.map((m) => byMonth.get(m) ?? blank(m)),
      ytd: byMonth.get("YTD") ?? null,
      branches: [...branches.entries()].map(([name, rows]) => {
        const by = new Map(rows.map((r) => [r.month, r]));
        return { branch: name, rows: months.map((m) => by.get(m) ?? blank(m)), ytd: by.get("YTD") ?? null };
      }).sort((a, b) => a.branch.localeCompare(b.branch)),
    };
  }
  return { year, months, countries, builtAt: new Date().toISOString() };
}

/** The callback is a fixed source string for the reason given in capacity.ts: the page and the cron must share the entry. */
declare global {
  var __eeCtsFetch: ((year: number) => Promise<CtsData>) | undefined;
}
globalThis.__eeCtsFetch = fetchCtsData;
const entry = new Function("year", "return globalThis.__eeCtsFetch(year)") as (year: number) => Promise<CtsData>;

export const getCtsData = unstable_cache(entry, ["cts-data-v1"], { revalidate: REVALIDATE, tags: ["dashboard"] });

/** The year the page shows: the current one. The targets and the rates cover 2026 only. */
export const ctsYear = (): number => new Date().getUTCFullYear();
