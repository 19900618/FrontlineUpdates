import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import type { CountryName } from "./workspaces";

/**
 * The QA officer's side of a pending evaluation: the tasks still open for it.
 * A task is the unit of QA work in Salesforce; an evaluation is what closes it.
 * This is the Individual QA page's own rule, read the same way it reads it:
 *
 *   salesforce.QA Tasks Only    one row per task, with the house, the officer
 *                               it sits on, when it was raised and when it was
 *                               due. Open means task_is_closed is false and the
 *                               status is Not Started or In Progress (Not Ready
 *                               for Evaluation is left out).
 *
 * Two flags are added for the person working the list. A task whose house has
 * already been evaluated at that step BY QA, or whose house is finished or lost,
 * is one that should be closed rather than done; the list says so instead of
 * hiding it, because hiding it is how such tasks stay open for a year. An
 * evaluation by a territory lead or construction staff does not count: the QA
 * task is still theirs to do. Who did it is the department on the QA survey,
 * the Quality pages' own rule (a blank department is QA; District or
 * Construction is not).
 */
const TASKS = "`earth-enable-main.salesforce.QA Tasks Only`";
const QA = "`earth-enable-main.raw_data_from_salesforce.all_qa_evaluations_clean`";
/** The survey's own department, which says who evaluated. */
const EVALS = "`earth-enable-main.salesforce.qa_evals_all`";
const IS_QA = `(e.department IS NULL
  OR (NOT CONTAINS_SUBSTR(e.department, 'District') AND NOT CONTAINS_SUBSTR(e.department, 'Construction')))`;
const JOURNEY = "`earth-enable-main.salesforce.customer_journey_app_v2`";
const OPPORTUNITY = "`earth-enable-main.salesforce.opportunity`";
const LOCATION = "`earth-enable-main.salesforce.location_c`";
const REVALIDATE = 900;

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const str = (v: unknown): string => (v == null ? "" : String(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

/** The task subjects the three pending cards ask about, and the QA stage each one is closed by. */
export const TASK_SUBJECTS: Record<string, string> = {
  "Prior Paint/varnish": "Prior Paint",
  "Compaction Evaluation": "Compaction",
  "Screed Evaluation": "Screed",
};
// Fixed literals from the map above, never user input.
const STAGE_OF_SUBJECT = `CASE t.task_subject ${Object.entries(TASK_SUBJECTS).map(([s, st]) => `WHEN '${s}' THEN '${st}'`).join(" ")} END`;

export type PendingTask = {
  taskId: string;
  subject: string;
  house: string;
  opportunityId: string | null;
  customer: string | null;
  /** Branch (Uganda, Kenya) or district (Rwanda) on the house's location. */
  unit: string | null;
  /**
   * The territory (Rwanda) or branch (Uganda, Kenya) the journey board filters on,
   * so the list follows the board's selection. Read from the journey view as the
   * board reads it; a house no longer on the journey falls back to its own
   * location. "" when neither has one.
   */
  territory: string;
  officer: string | null;
  officerId: string | null;
  createdOn: string | null;
  dueOn: string | null;
  daysPending: number;
  overdue: boolean;
  status: string;
  /** The house is still on the journey board (not completed or lost). */
  houseLive: boolean;
  /** QA has already evaluated this step on the house: the task is stale. A territory lead's evaluation does not count. */
  houseEvaluated: boolean;
  houseStage: string | null;
  /** Raw square metres of the house's contract, from the journey. */
  rawSqm: number | null;
};

/** Every open task of the three pending types, so the drawer can filter by type. */
async function fetchPendingTasks(country: CountryName): Promise<PendingTask[]> {
  // The board's own unit: j.territory in Rwanda, COALESCE(j.branch, 'Unassigned') elsewhere.
  const unitOf = country === "Rwanda"
    ? "COALESCE(j.territory, s.territory_c)"
    : "COALESCE(j.branch, NULLIF(TRIM(l.branch_c), ''), l.district_c, 'Unassigned')";
  const rows = await query<Record<string, unknown>>(
    `WITH done AS (
       -- Evaluated at this step by QA. A territory lead's evaluation is not QA's.
       SELECT DISTINCT q.opportunity_id, q.stage
       FROM ${QA} q
       LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
       WHERE q.location_country = @country AND q.stage IN UNNEST(@stages) AND ${IS_QA}
     )
     SELECT t.task_id, t.task_subject, t.task_status, t.opportunity_id, t.opportunity_name,
       t.location_name, COALESCE(NULLIF(TRIM(t.location_branch), ''), t.location_district) AS unit,
       t.task_employee_surveyor_name, t.task_employee_surveyor_id,
       CAST(DATE(t.task_created_date) AS STRING) AS created_on,
       CAST(t.task_activity_date AS STRING) AS due_on,
       t.pending_days, t.is_task_overdue,
       j.stage_code IS NOT NULL AND j.stage_code NOT IN ('L', 'N', 'P', 'Q') AS house_live,
       d.opportunity_id IS NOT NULL AS house_evaluated,
       j.journey_stage, j.raw_sqm, ${unitOf} AS unit_name
     FROM ${TASKS} t
     LEFT JOIN ${JOURNEY} j ON j.opportunity_id = t.opportunity_id
     LEFT JOIN ${OPPORTUNITY} op ON op.id = t.opportunity_id
     LEFT JOIN ${LOCATION} l ON l.id = op.umudugudu_c
     LEFT JOIN ${LOCATION} s ON s.id = l.sector_c
     LEFT JOIN done d ON d.opportunity_id = t.opportunity_id AND d.stage = ${STAGE_OF_SUBJECT}
     WHERE t.location_country = @country AND NOT t.task_is_closed AND t.task_subject IN UNNEST(@subjects)
       -- Only work QA can do now. A task marked Not Ready for Evaluation is not counted.
       AND t.task_status IN ('Not Started', 'In Progress')
     ORDER BY t.pending_days DESC, t.task_id
     LIMIT 9000`,
    { country, subjects: Object.keys(TASK_SUBJECTS), stages: Object.values(TASK_SUBJECTS) },
  );
  return rows.map((r) => ({
    taskId: str(r.task_id),
    subject: str(r.task_subject),
    house: str(r.opportunity_name),
    opportunityId: strOrNull(r.opportunity_id),
    customer: strOrNull(r.location_name),
    unit: strOrNull(r.unit),
    territory: str(r.unit_name),
    officer: strOrNull(r.task_employee_surveyor_name),
    officerId: strOrNull(r.task_employee_surveyor_id),
    createdOn: strOrNull(r.created_on),
    dueOn: strOrNull(r.due_on),
    daysPending: num(r.pending_days),
    overdue: Boolean(r.is_task_overdue),
    status: str(r.task_status),
    houseLive: Boolean(r.house_live),
    houseEvaluated: Boolean(r.house_evaluated),
    houseStage: strOrNull(r.journey_stage),
    rawSqm: r.raw_sqm == null ? null : Number(r.raw_sqm),
  }));
}

export const getPendingTasks = unstable_cache(fetchPendingTasks, ["journey-pending-tasks-v5"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
