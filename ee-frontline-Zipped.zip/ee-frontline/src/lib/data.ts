import { unstable_cache } from "next/cache";
import { query } from "./bigquery";

/**
 * CANONICAL view — the app is a thin reader. All classification (stage_class,
 * queue_owner, days_in_stage, is_zero_paid, outstanding_amount, cleanup flags)
 * is precomputed here. The app performs NO stage/class derivation of its own.
 *   earth-enable-main.salesforce.customer_journey_app_v2
 * v2 splits "collected, not started" on Salesforce's Materials Available tick
 * (floor and wall alike) and renumbers the board buckets 1-8.
 */
const VIEW = "`earth-enable-main.salesforce.customer_journey_app_v2`";
const OPP = "`earth-enable-main.salesforce.opportunity`";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

// Branch is resolved inside the view (customer_journey_app_v2) straight from
// Salesforce's own location_c.branch_c field, so the app just reads it. No
// app-side branch remapping (e.g. Kyankwanzi -> Masindi is handled in the view).
const BRANCH_EXPR = `COALESCE(NULLIF(TRIM(branch),''),'Unassigned')`;

/**
 * When Salesforce was last synced into BigQuery (Fivetran). This is the TRUE data
 * freshness — the real ceiling, not the app's 30-min cache. Returns epoch millis.
 */
async function fetchLastSync(): Promise<number | null> {
  const [row] = await query<Record<string, unknown>>(
    `SELECT UNIX_MILLIS(MAX(_fivetran_synced)) AS ms FROM ${OPP} WHERE NOT _fivetran_deleted`,
  );
  return row?.ms == null ? null : Number(row.ms);
}
export const getLastSync = unstable_cache(fetchLastSync, ["last-sync-v2"], {
  revalidate: 300, // check freshness every 5 min
  tags: ["dashboard"],
});

/** stage_class values straight from the view. */
export type Group =
  | "collecting"
  | "ready_to_build"
  | "building"
  | "finishing"
  | "repairs"
  | "backlog"
  | "promised";

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

// ---------- heatmap matrix (country × location × app_bucket) ----------
// Rwanda uses `territory`; Uganda/Kenya use `branch` (their territory is empty).
export type MatrixRow = {
  country: string;
  territory: string;
  branch: string;
  app_bucket: string;
  n: number;
  over30: number;
  /** SQM-E in this cell: equivalent square metres, floor 1.0 and everything else 0.333. */
  sqme: number;
};

async function fetchMatrix(): Promise<MatrixRow[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT
      COALESCE(country,'Unknown') AS country,
      COALESCE(NULLIF(TRIM(territory),''),'Unassigned') AS territory,
      ${BRANCH_EXPR} AS branch,
      app_bucket,
      COUNT(*) AS n,
      COUNTIF(days_in_stage > 30) AS over30,
      IFNULL(SUM(sqme),0) AS sqme
    FROM ${VIEW}
    WHERE app_bucket IS NOT NULL
    GROUP BY country, territory, branch, app_bucket
  `);
  return rows.map((r) => ({
    country: String(r.country),
    territory: String(r.territory),
    branch: String(r.branch),
    app_bucket: String(r.app_bucket),
    n: num(r.n),
    over30: num(r.over30),
    sqme: num(r.sqme),
  }));
}

/** Location dimension per country: Rwanda drills by territory, UG/KE by branch. */
export type LocDim = "territory" | "branch";
export const locColumn = (dim: LocDim): string =>
  dim === "branch"
    ? BRANCH_EXPR
    : "COALESCE(NULLIF(TRIM(territory),''),'Unassigned')";

// ---------- country scorecard summary ----------
export type GroupAgg = {
  country: string;
  bucket: string;
  count: number;
  sqme: number;
  rwf_outstanding: number;
  zero_paid: number;
  not_fully_paid: number;
  median_days: number;
  over30: number;
  oldest_days: number;
  age_0_30: number;
  age_31_60: number;
  age_61_90: number;
  age_90p: number;
};
export type MonthAgg = { country: string; this_month: number; last_month: number };
export type Summary = { groups: GroupAgg[]; months: MonthAgg[] };

async function fetchSummary(): Promise<Summary> {
  const groups = await query<Record<string, unknown>>(`
    SELECT COALESCE(country,'Unknown') AS country, app_bucket,
      COUNT(*) AS count,
      IFNULL(SUM(sqme),0) AS sqme,
      IFNULL(SUM(outstanding_amount),0) AS rwf_outstanding,
      COUNTIF(is_zero_paid) AS zero_paid,
      COUNTIF(pct_paid < 1) AS not_fully_paid,
      APPROX_QUANTILES(days_in_stage,2)[OFFSET(1)] AS median_days,
      COUNTIF(days_in_stage > 30) AS over30,
      MAX(days_in_stage) AS oldest_days,
      COUNTIF(days_in_stage <= 30) AS age_0_30,
      COUNTIF(days_in_stage BETWEEN 31 AND 60) AS age_31_60,
      COUNTIF(days_in_stage BETWEEN 61 AND 90) AS age_61_90,
      COUNTIF(days_in_stage > 90) AS age_90p
    FROM ${VIEW}
    WHERE app_bucket IS NOT NULL
    GROUP BY country, app_bucket
  `);
  const months = await query<Record<string, unknown>>(`
    SELECT COALESCE(country,'Unknown') AS country,
      COUNTIF(completed_date BETWEEN DATE_TRUNC(CURRENT_DATE(), MONTH) AND CURRENT_DATE()) AS this_month,
      COUNTIF(completed_date BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH)
                  AND DATE_ADD(DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH),
                               INTERVAL DATE_DIFF(CURRENT_DATE(), DATE_TRUNC(CURRENT_DATE(), MONTH), DAY) DAY)) AS last_month
    FROM ${VIEW}
    WHERE completed_date IS NOT NULL
    GROUP BY country
  `);
  return {
    groups: groups.map((r) => ({
      country: String(r.country),
      bucket: String(r.app_bucket),
      count: num(r.count),
      sqme: num(r.sqme),
      rwf_outstanding: num(r.rwf_outstanding),
      zero_paid: num(r.zero_paid),
      not_fully_paid: num(r.not_fully_paid),
      median_days: num(r.median_days),
      over30: num(r.over30),
      oldest_days: num(r.oldest_days),
      age_0_30: num(r.age_0_30),
      age_31_60: num(r.age_31_60),
      age_61_90: num(r.age_61_90),
      age_90p: num(r.age_90p),
    })),
    months: months.map((r) => ({
      country: String(r.country),
      this_month: num(r.this_month),
      last_month: num(r.last_month),
    })),
  };
}

// ---------- per-territory client list (non-terminal) ----------
export type ClientRow = {
  opportunity_id: string;
  opportunity_label: string | null;
  customer_name: string | null;
  phone: string | null;
  cso_name: string | null;
  country: string;
  branch: string;
  district: string | null;
  territory: string;
  track: string;
  product_family: string;
  /** Square metres on the contract, as Salesforce holds them. */
  raw_sqm: number;
  /** SQM-E: raw_sqm weighted floor 1.0, plaster/paint/ceiling/repair 0.333. */
  sqme: number;
  stage_code: string;
  journey_stage: string;
  grp: Group;
  app_bucket: string;
  queue_owner: string | null;
  days_in_stage: number;
  signed_date: string | null;
  pct_paid: number | null;
  cash_paid: number;
  total_amount: number;
  outstanding_amount: number;
  is_zero_paid: boolean;
  materials_available: boolean;
  materials_confirmed_date: string | null;
};

async function fetchTerritoryClients(country: string, dim: LocDim, name: string): Promise<ClientRow[]> {
  const rows = await query<Record<string, unknown>>(
    `
    SELECT
      opportunity_id, opportunity_label, customer_name, customer_phone AS phone, cso_name,
      COALESCE(country,'Unknown') AS country, ${BRANCH_EXPR} AS branch, district,
      COALESCE(NULLIF(TRIM(territory),''),'Unassigned') AS territory, track, product_family,
      IFNULL(raw_sqm,0) AS raw_sqm, IFNULL(sqme,0) AS sqme,
      stage_code, journey_stage, stage_class, app_bucket, queue_owner, days_in_stage,
      CAST(signed_date AS STRING) AS signed_date,
      pct_paid, IFNULL(cash_paid,0) AS cash_paid, IFNULL(total_amount,0) AS total_amount,
      IFNULL(outstanding_amount,0) AS outstanding_amount, is_zero_paid,
      materials_available, CAST(materials_confirmed_date AS STRING) AS materials_confirmed_date
    FROM ${VIEW}
    WHERE app_bucket IS NOT NULL
      AND COALESCE(country,'Unknown') = @country
      AND ${locColumn(dim)} = @name
    ORDER BY app_bucket, days_in_stage DESC
    LIMIT 5000
  `,
    { country, name },
  );
  return rows.map((r) => ({
    opportunity_id: String(r.opportunity_id),
    opportunity_label: strOrNull(r.opportunity_label),
    customer_name: strOrNull(r.customer_name),
    phone: strOrNull(r.phone),
    cso_name: strOrNull(r.cso_name),
    country: String(r.country),
    branch: String(r.branch),
    district: strOrNull(r.district),
    territory: String(r.territory),
    track: String(r.track),
    product_family: String(r.product_family),
    raw_sqm: num(r.raw_sqm),
    sqme: num(r.sqme),
    stage_code: String(r.stage_code),
    journey_stage: String(r.journey_stage),
    grp: String(r.stage_class) as Group,
    app_bucket: String(r.app_bucket),
    queue_owner: strOrNull(r.queue_owner),
    days_in_stage: num(r.days_in_stage),
    signed_date: strOrNull(r.signed_date),
    pct_paid: numOrNull(r.pct_paid),
    cash_paid: num(r.cash_paid),
    total_amount: num(r.total_amount),
    outstanding_amount: num(r.outstanding_amount),
    is_zero_paid: Boolean(r.is_zero_paid),
    materials_available: Boolean(r.materials_available),
    materials_confirmed_date: strOrNull(r.materials_confirmed_date),
  }));
}

// ---------- per-territory completed this/last month (same day-span) ----------
async function fetchTerritoryMonths(country: string, dim: LocDim, name: string): Promise<{ this_month: number; last_month: number }> {
  const [row] = await query<Record<string, unknown>>(
    `
    SELECT
      COUNTIF(completed_date BETWEEN DATE_TRUNC(CURRENT_DATE(), MONTH) AND CURRENT_DATE()) AS this_month,
      COUNTIF(completed_date BETWEEN DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH)
                  AND DATE_ADD(DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 MONTH),
                               INTERVAL DATE_DIFF(CURRENT_DATE(), DATE_TRUNC(CURRENT_DATE(), MONTH), DAY) DAY)) AS last_month
    FROM ${VIEW}
    WHERE completed_date IS NOT NULL
      AND COALESCE(country,'Unknown') = @country
      AND ${locColumn(dim)} = @name
  `,
    { country, name },
  );
  return { this_month: num(row?.this_month), last_month: num(row?.last_month) };
}

export const getTerritoryMonths = unstable_cache(fetchTerritoryMonths, ["view-months-v11"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

export const getMatrix = unstable_cache(fetchMatrix, ["view-matrix-v12"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
export const getSummary = unstable_cache(fetchSummary, ["view-summary-v11"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
export const getTerritoryClients = unstable_cache(fetchTerritoryClients, ["view-clients-v13"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
