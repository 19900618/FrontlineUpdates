import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import { productClass } from "./product-class";
import type { CountryName } from "./workspaces";

/**
 * The four Quality scorecards for one country and one window.
 *
 * Each one is counted from the company's own evaluation layer rather than
 * re-derived here, so a figure on the page can be traced to the rows behind it:
 *
 *   salesforce.qa_evals_all
 *     every evaluation, with the evaluator's department, their position, the
 *     stage, and the decision in both vocabularies: the word (Pass, Redo,
 *     Repair minor issues) and the Decision V2 letter (A, B, C, D).
 *
 *   raw_data_from_salesforce.Varnish_movement_status
 *     one row per job in the varnish pipeline, carrying the waiting period the
 *     product requires: 7 days for Floor, 1 day for Plaster.
 *
 *   raw_data_from_salesforce.all_cases_clean
 *     customer cases, with the date raised, the date closed and the status.
 *
 * Country is pushed into every scan, never filtered afterwards, so a country's
 * page can only read that country's rows.
 */
const EVALS = "`earth-enable-main.salesforce.qa_evals_all`";
const VARNISH = "`earth-enable-main.raw_data_from_salesforce.Varnish_movement_status`";
const CASES = "`earth-enable-main.raw_data_from_salesforce.all_cases_clean`";
const CLEAN = "`earth-enable-main.raw_data_from_salesforce.all_qa_evaluations_clean`";
const OPPORTUNITY = "`earth-enable-main.salesforce.opportunity`";
/** The job's product on the company's classification (sql/product_class.sql), not the QA table's own column. */
const PRODUCT_OF_OPP = productClass("COALESCE(o.product_interest_c, o.new_product_interest_c)");
const JOURNEY = "`earth-enable-main.salesforce.customer_journey_app_v2`";

const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

/**
 * Houses that have already passed a final evaluation. The pipeline view's own
 * ready flag lets one such house through, and a house that has passed is not
 * waiting, so it is excluded here by name.
 */
const PASSED_FINAL = `SELECT DISTINCT opportunity_id FROM ${EVALS}
  WHERE is_pass AND CONTAINS_SUBSTR(LOWER(eval_stage_key), 'final')`;

/**
 * Is this evaluation a QA evaluation?
 *
 * The rule the business gave: a District or Construction department is not QA,
 * and a blank department is. The table already carries that rule as
 * `is_qa_department`, and it is written out here so the page and the source
 * cannot drift apart.
 *
 * Worth knowing when reading the number: Department only began to be filled in
 * in April 2026 (0% of evaluations before then, about 70% now), and since then
 * 10,565 evaluations by staff whose position is Territory Lead still have a
 * blank or "Quality Assurance" department, so they count as QA here. The page
 * says so under the scorecard.
 */
const IS_QA = `(q.department IS NULL
  OR (NOT CONTAINS_SUBSTR(q.department, 'District') AND NOT CONTAINS_SUBSTR(q.department, 'Construction')))`;

/**
 * Which construction stage an evaluation belongs to. The stage names carry
 * variants -- "Screed Evaluation Standard", "screed_evaluation_Hybrid",
 * "Redo screed evaluation - Hybrid" -- so they are matched on the word, not on
 * an exact list that a new variant would silently fall out of.
 */
const STAGE_GROUP = `CASE
  WHEN CONTAINS_SUBSTR(LOWER(q.eval_stage_key), 'compaction') THEN 'compaction'
  WHEN CONTAINS_SUBSTR(LOWER(q.eval_stage_key), 'screed') THEN 'screed'
  WHEN CONTAINS_SUBSTR(LOWER(q.eval_stage_key), 'prior_paint') THEN 'prior_paint'
  ELSE NULL END`;

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const str = (v: unknown): string => (v == null ? "" : String(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

/** Scorecard 1. One row per product, plus the country total. */
export type FirstEval = {
  product: string;
  /** Jobs whose required first QA evaluations all fall in this window. */
  jobs: number;
  passed: number;
  /** Jobs that failed because a required stage did not pass first time. */
  failed: number;
};

/**
 * Scorecard 2. Houses ready for their final evaluation right now: varnished, the
 * waiting period served, and the final evaluation not yet passed. Houses still
 * inside the waiting period and houses that have already passed are not counted.
 */
export type FinalEval = {
  product: string;
  ready: number;
  /** Days the product must wait after varnish before the final evaluation. */
  waitDays: number;
};

/**
 * Scorecard 3. The one disagreement worth acting on: the territory lead passed the
 * house and the QA evaluation that followed sent it back.
 */
export type Matching = {
  /** Pairs where the territory lead and the QA evaluation reached the same verdict. */
  matched: number;
  /** Pairs where the territory lead passed the house and QA sent it back. */
  tlPassQaFail: number;
  /** Pairs in the window where both the TL and the QA decision are known. */
  pairs: number;
};

/**
 * Scorecard 4. Every customer case still open, whenever it was raised. Unlike the
 * rest of the page this is not a window: a case opened in March and never closed is
 * open now, and dropping it for being raised in another month would hide the work.
 */
export type Cases = { stillOpen: number };

export type Scorecards = {
  firstEval: FirstEval[];
  finalEval: FinalEval[];
  matching: Matching;
  cases: Cases;
};

/**
 * Scorecard 1, "Passed first QA evaluation".
 *
 * A Floor job passes when the first QA Compaction evaluation and the first QA
 * Screed evaluation both passed. A Plaster job passes when the first QA Prior
 * Paint evaluation passed. "First" means the first evaluation QA did at that
 * stage, so a District evaluation that came earlier is skipped rather than
 * counted, and a re-evaluation that came later cannot rescue a first failure.
 *
 * A job lands in the window on the day it finished the evaluations its product
 * requires -- for Floor the later of its two firsts -- so every job is counted
 * once, in one period, on the day the answer became known.
 */

/** Narrow the page to one branch or one territory. null is the whole country. */
export type Unit = { level: "branch" | "territory"; name: string } | null;

/**
 * The branch as every page spells it, read off whichever table is being scanned.
 */
const branchOf = (alias: string) =>
  `COALESCE(NULLIF(TRIM(REGEXP_REPLACE(${alias}.branch, r'\\s*Branch$', '')), ''), 'Unassigned')`;

/**
 * The join and the condition that narrow a scan to the chosen unit.
 *
 * A branch is on every source already. A territory is not: it lives on the job's
 * journey row, the same place the rest of the app reads it from, so asking for one
 * adds that join. With no unit chosen both come back empty and the SQL is exactly
 * what it was.
 */
function unitScope(unit: Unit, alias: string, oppCol = "opportunity_id"): { join: string; where: string } {
  if (!unit) return { join: "", where: "" };
  if (unit.level === "branch") return { join: "", where: `AND ${branchOf(alias)} = @unitName` };
  return {
    join: `LEFT JOIN ${JOURNEY} uj ON uj.opportunity_id = ${alias}.${oppCol}`,
    where: "AND uj.territory = @unitName",
  };
}

const firstEvalSql = (unit: Unit) => {
  const u = unitScope(unit, "q");
  return `
  WITH qa AS (
    SELECT q.opportunity_id, ${STAGE_GROUP} AS stage_group, q.eval_date, q.created_date, q.survey_id, q.is_pass
    FROM ${EVALS} q
    ${u.join}
    WHERE q.country = @country AND ${IS_QA} AND ${STAGE_GROUP} IS NOT NULL
    ${u.where}
  ),
  ranked AS (
    SELECT *, ROW_NUMBER() OVER (
      PARTITION BY opportunity_id, stage_group ORDER BY eval_date, created_date, survey_id
    ) AS rn
    FROM qa
  ),
  firsts AS (
    SELECT opportunity_id,
      MAX(IF(stage_group = 'compaction', eval_date, NULL)) AS compaction_date,
      MAX(IF(stage_group = 'compaction', is_pass, NULL)) AS compaction_pass,
      MAX(IF(stage_group = 'screed', eval_date, NULL)) AS screed_date,
      MAX(IF(stage_group = 'screed', is_pass, NULL)) AS screed_pass,
      MAX(IF(stage_group = 'prior_paint', eval_date, NULL)) AS paint_date,
      MAX(IF(stage_group = 'prior_paint', is_pass, NULL)) AS paint_pass
    FROM ranked WHERE rn = 1 GROUP BY opportunity_id
  ),
  product AS (
    SELECT c.opportunity_id, ANY_VALUE(${PRODUCT_OF_OPP}) AS product
    FROM ${CLEAN} c JOIN ${OPPORTUNITY} o ON o.id = c.opportunity_id
    WHERE c.location_country = @country GROUP BY c.opportunity_id
  ),
  judged AS (
    SELECT f.opportunity_id, p.product,
      CASE WHEN p.product = 'Floor' THEN GREATEST(f.compaction_date, f.screed_date) ELSE f.paint_date END AS decided_on,
      CASE WHEN p.product = 'Floor' THEN (f.compaction_pass AND f.screed_pass) ELSE f.paint_pass END AS passed
    FROM firsts f JOIN product p USING (opportunity_id)
    WHERE (p.product = 'Floor' AND f.compaction_date IS NOT NULL AND f.screed_date IS NOT NULL)
       OR (p.product = 'Plaster' AND f.paint_date IS NOT NULL)
  )
  SELECT product, COUNT(*) AS jobs, COUNTIF(passed) AS passed, COUNTIF(NOT passed) AS failed
  FROM judged
  WHERE decided_on BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
  GROUP BY product ORDER BY jobs DESC`;
};

/**
 * Scorecard 3, "TL and QA matching".
 *
 * The pairing view already holds a territory-lead evaluation beside the QA
 * evaluation that followed it on the same job and stage, so the sequence is the
 * real one rather than any two evaluations on the same job. Its decisions arrive
 * already reduced to Pass or Fail, which is exactly the rule asked for: Decision
 * V2 C and D are both a fail, so "Repair minor issues" against "Redo" is a match.
 *
 * Only pairs where both decisions are known are counted. A QA evaluation that no
 * territory lead had looked at first is not a disagreement, and the view records
 * 4,469 of those as mismatches; they are reported separately as `noTl` instead.
 */

/**
 * A district evaluation and the QA evaluation that came straight after it, on the
 * same house and the same stage, with nothing in between.
 *
 * The company's own pairing view is not used for this. It reaches past intervening
 * evaluations: on Kamana Leonidas-1-1 it paired a territory lead's pass from 16 June
 * with a QA rework instruction from 24 September, 100 days later, although a
 * district evaluator had passed the same stage on the 24th itself. Comparing those
 * two says nothing about whether the district and QA agreed.
 *
 * LAG over the stage's own evaluations gives the one immediately before, so a pair
 * is always consecutive. Across Rwanda last month that takes the average gap from
 * months to 1.1 days, and it finds the pairs in Uganda and Kenya that the view
 * reported as none at all.
 *
 * Pass or fail comes from `is_pass`, which already reads both decision vocabularies,
 * so Decision V2 C against D is two fails and therefore a match.
 */
const ADJACENT_PAIRS = `
  WITH ev AS (
    SELECT opportunity_id, opportunity_name, eval_stage, eval_stage_key, eval_date, created_date,
      survey_id, evaluator_name, decision_word, is_pass, comment, branch,
      (department IS NULL
        OR (NOT CONTAINS_SUBSTR(department, 'District') AND NOT CONTAINS_SUBSTR(department, 'Construction'))) AS is_qa
    FROM ${EVALS} WHERE country = @country
  ),
  adjacent AS (
    SELECT *,
      LAG(is_qa) OVER w AS prev_is_qa,
      LAG(is_pass) OVER w AS prev_is_pass,
      LAG(decision_word) OVER w AS prev_decision,
      LAG(evaluator_name) OVER w AS prev_evaluator,
      LAG(eval_date) OVER w AS prev_date
    FROM ev
    WINDOW w AS (PARTITION BY opportunity_id, eval_stage_key ORDER BY eval_date, created_date, survey_id)
  ),
  pairs AS (
    SELECT * FROM adjacent
    WHERE is_qa AND prev_is_qa = FALSE
      AND prev_is_pass IS NOT NULL AND is_pass IS NOT NULL
      AND eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
  )`;

const matchingSql = (unit: Unit) => {
  const u = unitScope(unit, "p");
  return `${ADJACENT_PAIRS}
  SELECT
    COUNTIF(p.prev_is_pass = p.is_pass) AS matched,
    COUNTIF(p.prev_is_pass AND NOT p.is_pass) AS tl_pass_qa_fail,
    COUNT(*) AS pairs
  FROM pairs p
  ${u.join}
  WHERE TRUE ${u.where}`;
};

async function fetchScorecards(country: CountryName, from: string, to: string, unit: Unit = null): Promise<Scorecards> {
  const unitName = unit?.name ?? "";
  const uc = unitScope(unit, "c");
  /** The chosen unit as a condition, so it can narrow a COUNTIF rather than a scan. */
  const unitPredicate = !unit ? "TRUE"
    : unit.level === "territory"
      ? "v.territory = @unitName"
      : `${branchOf("v")} = @unitName`;
  const [firstEval, finalEval, matching, cases] = await Promise.all([
    query<Record<string, unknown>>(firstEvalSql(unit), { country, from, to, unitName }),

    // Scorecard 2. Houses ready for their final evaluation as things stand now:
    // varnished, the waiting period served, final evaluation not yet passed. The
    // view holds the jobs that have not finished, so it has no window of its own.
    query<Record<string, unknown>>(
      `WITH passed_final AS (${PASSED_FINAL})
       SELECT v.product,
         COUNTIF(v.is_varnished AND v.ready_for_final_evaluation AND pf.opportunity_id IS NULL
                 AND ${unitPredicate}) AS ready,
         MAX(v.final_eval_wait_days) AS wait_days
       FROM ${VARNISH} v
       LEFT JOIN passed_final pf ON pf.opportunity_id = v.opportunity_id
       WHERE v.country = @country
       GROUP BY v.product ORDER BY v.product`,
      { country, unitName },
    ),

    query<Record<string, unknown>>(matchingSql(unit), { country, from, to, unitName }),

    // Scorecard 4. Every case still open, whenever it was raised: see the type above.
    query<Record<string, unknown>>(
      `SELECT COUNT(*) AS still_open FROM ${CASES} c
       ${uc.join}
       WHERE c.location_country = @country
         AND NOT c.case_is_closed
         ${uc.where}`,
      { country, unitName },
    ),
  ]);

  const c = cases[0] ?? {};
  const m = matching[0] ?? {};
  return {
    firstEval: firstEval.map((r) => ({
      product: str(r.product), jobs: num(r.jobs), passed: num(r.passed), failed: num(r.failed),
    })),
    finalEval: finalEval.map((r) => ({
      product: str(r.product), ready: num(r.ready), waitDays: num(r.wait_days),
    })),
    matching: { matched: num(m.matched), tlPassQaFail: num(m.tl_pass_qa_fail), pairs: num(m.pairs) },
    cases: { stillOpen: num(c.still_open) },
  };
}

export const getScorecards = unstable_cache(fetchScorecards, ["quality-scorecards-v9"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/** One step on the trend under the scorecards. */
export type ScoreTrend = {
  key: string;
  firstJobs: number;
  firstPassed: number;
  pairs: number;
  matched: number;
};

/**
 * The two headline rates over the six periods ending with the one on screen:
 * the share of houses that passed their first QA evaluation, and the share of
 * territory-lead decisions the following QA evaluation agreed with.
 *
 * Both are counted exactly the way their scorecard counts them, over the same
 * window, so a point on the line and the card above it can never disagree. The
 * grain follows the picker: months against months, quarters against quarters.
 */
async function fetchScoreTrend(
  country: CountryName, grain: "month" | "quarter", from: string, to: string, unit: Unit = null,
): Promise<ScoreTrend[]> {
  const unitName = unit?.name ?? "";
  const uq = unitScope(unit, "q");
  const um = unitScope(unit, "p");
  const bucket = (col: string) =>
    grain === "quarter"
      ? `CONCAT(CAST(EXTRACT(YEAR FROM ${col}) AS STRING), '-Q', CAST(EXTRACT(QUARTER FROM ${col}) AS STRING))`
      : `FORMAT_DATE('%Y-%m', ${col})`;

  const [firsts, pairs] = await Promise.all([
    query<Record<string, unknown>>(
      `
      WITH qa AS (
        SELECT q.opportunity_id, ${STAGE_GROUP} AS stage_group, q.eval_date, q.created_date, q.survey_id, q.is_pass
        FROM ${EVALS} q
        ${uq.join}
        WHERE q.country = @country AND ${IS_QA} AND ${STAGE_GROUP} IS NOT NULL
        ${uq.where}
      ),
      ranked AS (
        SELECT *, ROW_NUMBER() OVER (
          PARTITION BY opportunity_id, stage_group ORDER BY eval_date, created_date, survey_id) AS rn
        FROM qa
      ),
      firsts AS (
        SELECT opportunity_id,
          MAX(IF(stage_group = 'compaction', eval_date, NULL)) AS compaction_date,
          MAX(IF(stage_group = 'compaction', is_pass, NULL)) AS compaction_pass,
          MAX(IF(stage_group = 'screed', eval_date, NULL)) AS screed_date,
          MAX(IF(stage_group = 'screed', is_pass, NULL)) AS screed_pass,
          MAX(IF(stage_group = 'prior_paint', eval_date, NULL)) AS paint_date,
          MAX(IF(stage_group = 'prior_paint', is_pass, NULL)) AS paint_pass
        FROM ranked WHERE rn = 1 GROUP BY opportunity_id
      ),
      product AS (
        SELECT c.opportunity_id, ANY_VALUE(${PRODUCT_OF_OPP}) AS product
        FROM ${CLEAN} c JOIN ${OPPORTUNITY} o ON o.id = c.opportunity_id
        WHERE c.location_country = @country GROUP BY c.opportunity_id
      ),
      judged AS (
        SELECT
          CASE WHEN p.product = 'Floor' THEN GREATEST(f.compaction_date, f.screed_date) ELSE f.paint_date END AS decided_on,
          CASE WHEN p.product = 'Floor' THEN (f.compaction_pass AND f.screed_pass) ELSE f.paint_pass END AS passed
        FROM firsts f JOIN product p USING (opportunity_id)
        WHERE (p.product = 'Floor' AND f.compaction_date IS NOT NULL AND f.screed_date IS NOT NULL)
           OR (p.product = 'Plaster' AND f.paint_date IS NOT NULL)
      )
      SELECT ${bucket("decided_on")} AS k, COUNT(*) AS jobs, COUNTIF(passed) AS passed
      FROM judged
      WHERE decided_on BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
      GROUP BY k`,
      { country, from, to, unitName },
    ),
    query<Record<string, unknown>>(
      `${ADJACENT_PAIRS}
       SELECT ${bucket("p.eval_date")} AS k,
         COUNT(*) AS pairs,
         COUNTIF(p.prev_is_pass = p.is_pass) AS matched
       FROM pairs p
       ${um.join}
       WHERE TRUE ${um.where}
       GROUP BY k`,
      { country, from, to, unitName },
    ),
  ]);

  const byKey = new Map<string, ScoreTrend>();
  const at = (k: string): ScoreTrend => {
    let row = byKey.get(k);
    if (!row) { row = { key: k, firstJobs: 0, firstPassed: 0, pairs: 0, matched: 0 }; byKey.set(k, row); }
    return row;
  };
  for (const r of firsts) { const row = at(str(r.k)); row.firstJobs = num(r.jobs); row.firstPassed = num(r.passed); }
  for (const r of pairs) { const row = at(str(r.k)); row.pairs = num(r.pairs); row.matched = num(r.matched); }
  return [...byKey.values()];
}

export const getScoreTrend = unstable_cache(fetchScoreTrend, ["quality-score-trend-v4"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/** Which months and quarters actually have evaluations, so the picker offers only real ones. */
export type Calendar = { years: number[]; minDate: string; maxDate: string; months: string[] };

async function fetchCalendar(): Promise<Calendar> {
  const rows = await query<Record<string, unknown>>(
    `SELECT FORMAT_DATE('%Y-%m', eval_date) AS m, MIN(eval_date) AS mn, MAX(eval_date) AS mx
     FROM ${EVALS} WHERE eval_date IS NOT NULL GROUP BY m ORDER BY m`,
  );
  const months = rows.map((r) => str(r.m));
  const years = [...new Set(months.map((m) => Number(m.slice(0, 4))))].sort((a, b) => b - a);
  return {
    months,
    years,
    minDate: months.length ? `${months[0]}-01` : "",
    maxDate: months.length ? `${months[months.length - 1]}-01` : "",
  };
}

export const getCalendar = unstable_cache(fetchCalendar, ["quality-calendar-v2"], {
  revalidate: 6 * 60 * 60,
  tags: ["dashboard"],
});

/**
 * One record behind a scorecard. The three lists answer different questions, so a
 * field is filled in where its list has something to put there and null where it
 * does not, rather than each list carrying its own shape through the API.
 */
export type ScorecardRow = {
  id: string;
  /** The house, by the name the opportunity carries. */
  job: string;
  /** Floor or Plaster on a varnish row; the evaluation stage on a matching row. */
  product: string | null;
  branch: string | null;
  territory: string | null;
  cso: string | null;
  /** The territory lead on a matching row; the branch manager on a varnish row. */
  lead: string | null;
  /** Varnish movement, the territory lead's evaluation, or the day a case was raised. */
  date: string | null;
  /** The QA evaluation that followed, where there is one. */
  qaDate: string | null;
  /** What the territory lead said, the case status, or where the house stands. */
  status: string | null;
  qaDecision: string | null;
  qaEvaluator: string | null;
  /** Days since varnish moved, or days a case has been open. */
  daysOpen: number | null;
  /** Days past the point the final evaluation was due. */
  daysOverdue: number | null;
  /** The evaluator's comment, or the case's subject. */
  note: string | null;
};

/** Which list to read. Each one has a single, fixed meaning now. */
export type ScorecardDim = "final-eval" | "matching" | "cases";

/**
 * The records behind one scorecard. Each list is exactly what its card counts,
 * with no wider set behind it:
 *
 *   final-eval  houses ready for their final evaluation: varnished, the waiting
 *               period served (7 days for Floor, 1 for Plaster) and the final
 *               evaluation not yet passed. Houses still inside the waiting period
 *               and houses that have already passed are not in the view at all.
 *   matching    only where the territory lead passed the house and the QA
 *               evaluation that followed sent it back.
 *   cases       only cases raised in the window that are still open.
 */
async function fetchScorecardRows(
  country: CountryName, from: string, to: string, dim: ScorecardDim, limit: number, unit: Unit = null,
): Promise<ScorecardRow[]> {
  const unitName = unit?.name ?? "";
  let sql: string;
  if (dim === "final-eval") {
    sql = `
      WITH passed_final AS (${PASSED_FINAL})
      SELECT v.opportunity_id AS id, v.opportunity_name AS job, v.product, v.branch, v.territory,
        CAST(NULL AS STRING) AS cso, CAST(NULL AS STRING) AS lead,
        CAST(v.varnish_movement_date AS STRING) AS d, CAST(NULL AS STRING) AS qa_date,
        v.movement_status AS status, CAST(NULL AS STRING) AS qa_decision, CAST(NULL AS STRING) AS qa_evaluator,
        v.days_since_varnish_movement AS days_open,
        v.days_since_varnish_movement - v.final_eval_wait_days AS days_overdue,
        CONCAT('Waits ', CAST(v.final_eval_wait_days AS STRING), ' days after varnish · now at ', v.gating_stage) AS note
      FROM ${VARNISH} v
      LEFT JOIN passed_final pf ON pf.opportunity_id = v.opportunity_id
      WHERE v.country = @country AND v.is_varnished AND v.ready_for_final_evaluation
        AND pf.opportunity_id IS NULL
        ${unit ? (unit.level === "territory"
          ? "AND v.territory = @unitName"
          : `AND ${branchOf("v")} = @unitName`) : ""}
      ORDER BY v.varnish_movement_date DESC, job LIMIT @limit`;
  } else if (dim === "matching") {
    sql = `${ADJACENT_PAIRS}
      SELECT p.survey_id AS id, p.opportunity_name AS job, p.eval_stage AS product,
        p.branch, j.territory, CAST(NULL AS STRING) AS cso, p.prev_evaluator AS lead,
        CAST(p.prev_date AS STRING) AS d, CAST(p.eval_date AS STRING) AS qa_date,
        p.prev_decision AS status, p.decision_word AS qa_decision,
        p.evaluator_name AS qa_evaluator,
        DATE_DIFF(p.eval_date, p.prev_date, DAY) AS days_open, CAST(NULL AS INT64) AS days_overdue,
        p.comment AS note
      FROM pairs p
      LEFT JOIN ${JOURNEY} j ON j.opportunity_id = p.opportunity_id
      WHERE p.prev_is_pass AND NOT p.is_pass
        ${unit ? (unit.level === "territory"
          ? "AND j.territory = @unitName"
          : `AND ${branchOf("p")} = @unitName`) : ""}
      ORDER BY p.eval_date DESC, job LIMIT @limit`;
  } else {
    // The journey row is joined whatever the filter, because the list names the
    // territory now and not only when it is being filtered by one.
    const where = !unit ? ""
      : unit.level === "territory"
        ? "AND uj.territory = @unitName"
        : `AND ${branchOf("c")} = @unitName`;
    sql = `
      SELECT c.case_id AS id, COALESCE(c.opportunity_name, c.case_number) AS job,
        c.simplified_product_interest AS product, c.branch,
        uj.territory AS territory,
        CAST(NULL AS STRING) AS cso, CAST(NULL AS STRING) AS lead,
        CAST(c.case_created_date AS STRING) AS d, CAST(NULL AS STRING) AS qa_date,
        c.case_status AS status, c.case_number AS qa_decision, c.case_specific_issue AS qa_evaluator,
        DATE_DIFF(CURRENT_DATE(), c.case_created_date, DAY) AS days_open,
        CAST(NULL AS INT64) AS days_overdue,
        c.case_subject AS note
      FROM ${CASES} c
      LEFT JOIN ${JOURNEY} uj ON uj.opportunity_id = c.opportunity_id
      WHERE c.location_country = @country
        AND NOT c.case_is_closed
        ${where}
      ORDER BY c.case_created_date DESC, job LIMIT @limit`;
  }

  const rows = await query<Record<string, unknown>>(sql, { country, from, to, limit, unitName });
  return rows.map((r) => ({
    id: str(r.id),
    job: str(r.job),
    product: strOrNull(r.product),
    branch: strOrNull(r.branch),
    territory: strOrNull(r.territory),
    cso: strOrNull(r.cso),
    lead: strOrNull(r.lead),
    date: strOrNull(r.d),
    qaDate: strOrNull(r.qa_date),
    status: strOrNull(r.status),
    qaDecision: strOrNull(r.qa_decision),
    qaEvaluator: strOrNull(r.qa_evaluator),
    daysOpen: numOrNull(r.days_open),
    daysOverdue: numOrNull(r.days_overdue),
    note: strOrNull(r.note),
  }));
}

export const getScorecardRows = unstable_cache(fetchScorecardRows, ["quality-scorecard-rows-v8"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
