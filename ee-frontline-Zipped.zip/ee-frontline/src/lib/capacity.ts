import { unstable_cache } from "next/cache";
import { gunzipSync, gzipSync } from "node:zlib";
import { query } from "./bigquery";
import { capacityCalendar, type CapacityWeek } from "./capacity-calendar";
import type { CapacityCountry } from "./capacity-ui";

/**
 * Capacity planning reads two table functions and nothing else. Every
 * threshold, ranking rule and sentence of diagnosis is decided in BigQuery so
 * this page, the monthly capacity view and the Looker dashboard cannot
 * disagree:
 *   raw_data_from_salesforce.capacity_week(country, month)            (country x level x name x week set)
 *   raw_data_from_salesforce.capacity_mason_week(level, name, week_end) (mason x week for one place)
 * Both are computed on read, so the page is as current as the Fivetran sync
 * and nothing has to be rebuilt. The country and month are pushed into the
 * function so only that country's units and the seven months around the
 * selected month are computed. Source SQL for both is in sql/. The views
 * territory_capacity_week_v1 and territory_mason_week_v1 are the same
 * functions called with NULLs, for ad hoc use.
 *
 * Both carry a `level`. Rwanda is organised territory inside district, with a
 * manager grouping, so its levels are territory, district, manager and
 * country. Uganda and Kenya have branches only, so their levels are branch
 * and country. Every distinct count is computed in the function at its own
 * level, because a mason or a CSO working two units is one person, so the
 * app never adds counts across units. It picks the row it needs.
 *
 * Within a month the single weeks are week_key '1'..'4'; the other eleven keys
 * ('12', '134', '1234' ...) are every combination, each with its own distinct
 * counts, so the app never adds distinct counts across weeks either.
 */
const FN = "`earth-enable-main.raw_data_from_salesforce.capacity_week`";
const MASON_FN = "`earth-enable-main.raw_data_from_salesforce.capacity_mason_week`";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

export type CapacityLevel = "territory" | "district" | "manager" | "branch" | "country";
/** The levels a roster exists for: the unit of management, and Rwanda's districts. */
export type RosterLevel = "territory" | "district" | "branch";

/**
 * The calendar is pure date arithmetic (days 1-7, 8-14, 15-21, 22 to month
 * end), computed in TypeScript so the page never waits on a BigQuery round
 * trip just to list the weeks. scripts/capacity-calendar-check.mjs proves it
 * matches the query it replaced.
 */
export type { CapacityWeek } from "./capacity-calendar";

export function getCapacityCalendar(): CapacityWeek[] {
  return capacityCalendar();
}

/**
 * The month a manager should land on: the one holding the last complete week.
 * On the 1st to the 7th that is the previous month, which is right, because
 * the week in progress is never a fair read.
 */
export function defaultCapacityMonth(calendar: CapacityWeek[]): string {
  const complete = [...calendar].reverse().find((w) => w.isComplete);
  return complete?.month ?? calendar[calendar.length - 1]?.month ?? "";
}

/**
 * One level x name for one week set, with the four-week comparison and focus
 * state as at the latest complete week on or before the set's last week.
 */
export type CapacityRow = {
  country: CapacityCountry;
  level: CapacityLevel;
  name: string;
  /** District for a Rwanda territory. Null at every other level and for a branch. */
  parent: string | null;
  /** Set for Rwanda territories only. */
  manager: string | null;
  /** Units under this row: 1 for a territory or branch. */
  nTerritories: number;
  month: string;
  weekKey: string;
  nWeeks: number;
  isSingleWeek: boolean;
  weekLabel: string;
  weekEnd: string;
  isComplete: boolean;
  hasTargets: boolean;
  sold: number;
  collected: number;
  built: number;
  sqmeBuilt: number;
  /** Working: distinct masons with a timesheet starting in the window. */
  working: number;
  /** Assigned: distinct masons with a live job at the window's end and no timesheet in it. Exclusive of working. */
  assigned: number;
  totalMasons: number;
  masonsBuilt: number;
  /** Distinct masons with approved pay in the window. */
  masonsPaid: number;
  /** Approved gross pay by end date, the bonus basis. */
  masonEarnings: number;
  earningsPerMason: number | null;
  /** Approved timesheet lines over all lines for the set's last week, per country. Low while the week settles. */
  approvalRate: number | null;
  /** Distinct CSOs who signed or collected a contract in the window, at this level. */
  csosActive: number;
  /** CSOs this row should have: the country's CSOs per unit times its targeted units. */
  minCsos: number | null;
  /** Each unit's own CSO shortfall floored at zero, then summed. Never netted. */
  csosShort: number | null;
  csosUnitsShort: number;
  buildTargetWeek: number | null;
  sqmeTargetWeek: number | null;
  salesTargetWeek: number | null;
  minMasons: number | null;
  /** Each unit's own shortfall after working and assigned, floored at zero, then summed. Never netted. */
  toHire: number | null;
  territoriesShort: number;
  pctBuild: number | null;
  pctSqme: number | null;
  pctSales: number | null;
  pctColl: number | null;
  buildsPerMason: number | null;
  /** Builds one mason should complete in this many weeks: the monthly standard scaled to the set. Null without a target. */
  usualBuildsPerMason: number | null;
  pctBuildProductivity: number | null;
  buildCollRatio: number | null;
  collectedNotBuilt: number;
  constraintType: string;
  constraintReading: string;
  diagnosis: string | null;
  focusAsOf: string | null;
  weeks4w: number | null;
  masons4w: number | null;
  masonsPrev4w: number | null;
  epm4w: number | null;
  epmPrev4w: number | null;
  pctBuild4w: number | null;
  pctBuildPrev4w: number | null;
  built4w: number | null;
  target4w: number | null;
  sqmeBuilt4w: number | null;
  sqmeTarget4w: number | null;
  pctSqme4w: number | null;
  pctSqmePrev4w: number | null;
  sqmeGap4w: number | null;
  sqmeGapPrev4w: number | null;
  sold4w: number | null;
  salesTarget4w: number | null;
  pctSales4w: number | null;
  pctSalesPrev4w: number | null;
  coll4w: number | null;
  pctColl4w: number | null;
  pctCollPrev4w: number | null;
  focusRank: number | null;
  isFocus: boolean;
  focusWeeks: number;
  isNewFocus: boolean;
  trigMasons: boolean;
  trigEarnings: boolean;
  weakest4w: string | null;
  takeaway: string;
};

/** One level x name, one single week: the series behind sparklines and the deep dive trends. */
export type CapacityTrendRow = {
  level: CapacityLevel;
  name: string;
  month: string;
  weekNo: number;
  weekStart: string;
  weekEnd: string;
  weekLabel: string;
  isComplete: boolean;
  working: number;
  masonsBuilt: number;
  masonsPaid: number;
  /** Approved gross pay by end date, the bonus basis. */
  masonEarnings: number;
  earningsPerMason: number | null;
  approvalRate: number | null;
  built: number;
};

export type CapacityData = {
  /** Every row for the selected month at every level: up to 66 names x 15 week sets for Rwanda. */
  rows: CapacityRow[];
  /** Single weeks for the selected month and the two before it, so a five-week window ending anywhere in the month is available across month ends. */
  trend: CapacityTrendRow[];
  /** When the function ran, as an ISO timestamp. The page prints it as "Data as at". */
  builtAt: string;
};

/**
 * One call to the function for the selected country and month. It returns
 * that month and the six before it, so the month rows and the trend rows
 * come from the same computation. Fetched per country and month rather than
 * for everything because a year of this grain is several megabytes, and
 * field staff open this on phones.
 */
async function fetchCapacityData(country: CapacityCountry, month: string): Promise<CapacityData> {
  const rows = await query<Record<string, unknown>>(
    `
    SELECT
      country, level, name, parent, manager, n_territories, CAST(month AS STRING) AS month,
      week_key, n_weeks, is_single_week, week_no, week_label,
      CAST(week_start AS STRING) AS week_start, CAST(week_end AS STRING) AS week_end,
      is_complete_week, has_targets,
      contracts_sold, contracts_collected, contracts_built, sqme_built,
      masons_on_timesheet, masons_assigned, masons_total, masons_built, masons_paid, mason_earnings, earnings_per_mason, approval_rate,
      csos_active, min_csos, csos_short, units_short_csos,
      build_target_week, sqme_target_week, sales_target_week, min_masons, masons_to_hire, territories_short,
      pct_of_build_target, pct_of_sqme_target, pct_of_sales_target, pct_of_coll_target,
      builds_per_mason, usual_builds_per_mason, pct_build_productivity, build_coll_ratio,
      collected_not_built, constraint_type, constraint_reading, diagnosis,
      CAST(focus_as_of AS STRING) AS focus_as_of, weeks_4w,
      masons_4w, masons_prev_4w, epm_4w, epm_prev_4w, built_4w, target_4w, pct_build_4w, pct_build_prev_4w,
      sqme_built_4w, sqme_target_4w, pct_sqme_4w, pct_sqme_prev_4w, sqme_gap_4w, sqme_gap_prev_4w,
      sold_4w, sales_target_4w, pct_sales_4w, pct_sales_prev_4w, coll_4w, pct_coll_4w, pct_coll_prev_4w,
      focus_rank, is_focus, focus_weeks, is_new_focus, trig_masons, trig_earnings, weakest_4w, takeaway,
      FORMAT_TIMESTAMP('%Y-%m-%dT%H:%M:%SZ', built_at) AS built_at
    FROM ${FN}(@country, CAST(@month AS DATE))
    WHERE month = CAST(@month AS DATE)
       OR (is_single_week AND month >= DATE_SUB(CAST(@month AS DATE), INTERVAL 2 MONTH))
    ORDER BY level, name, month, n_weeks, week_key
  `,
    { country, month },
  );
  const all = rows.map((r) => ({
    row: {
      country: String(r.country) as CapacityCountry,
      level: String(r.level) as CapacityLevel,
      name: String(r.name),
      parent: strOrNull(r.parent),
      manager: strOrNull(r.manager),
      nTerritories: num(r.n_territories),
      month: String(r.month),
      weekKey: String(r.week_key),
      nWeeks: num(r.n_weeks),
      isSingleWeek: Boolean(r.is_single_week),
      weekLabel: String(r.week_label),
      weekEnd: String(r.week_end),
      isComplete: Boolean(r.is_complete_week),
      hasTargets: Boolean(r.has_targets),
      sold: num(r.contracts_sold),
      collected: num(r.contracts_collected),
      built: num(r.contracts_built),
      sqmeBuilt: num(r.sqme_built),
      working: num(r.masons_on_timesheet),
      assigned: num(r.masons_assigned),
      totalMasons: num(r.masons_total),
      masonsBuilt: num(r.masons_built),
      masonsPaid: num(r.masons_paid),
      masonEarnings: num(r.mason_earnings),
      earningsPerMason: numOrNull(r.earnings_per_mason),
      approvalRate: numOrNull(r.approval_rate),
      csosActive: num(r.csos_active),
      minCsos: numOrNull(r.min_csos),
      csosShort: numOrNull(r.csos_short),
      csosUnitsShort: num(r.units_short_csos),
      buildTargetWeek: numOrNull(r.build_target_week),
      sqmeTargetWeek: numOrNull(r.sqme_target_week),
      salesTargetWeek: numOrNull(r.sales_target_week),
      minMasons: numOrNull(r.min_masons),
      toHire: numOrNull(r.masons_to_hire),
      territoriesShort: num(r.territories_short),
      pctBuild: numOrNull(r.pct_of_build_target),
      pctSqme: numOrNull(r.pct_of_sqme_target),
      pctSales: numOrNull(r.pct_of_sales_target),
      pctColl: numOrNull(r.pct_of_coll_target),
      buildsPerMason: numOrNull(r.builds_per_mason),
      usualBuildsPerMason: numOrNull(r.usual_builds_per_mason),
      pctBuildProductivity: numOrNull(r.pct_build_productivity),
      buildCollRatio: numOrNull(r.build_coll_ratio),
      collectedNotBuilt: num(r.collected_not_built),
      constraintType: String(r.constraint_type),
      constraintReading: String(r.constraint_reading),
      diagnosis: strOrNull(r.diagnosis),
      focusAsOf: strOrNull(r.focus_as_of),
      weeks4w: numOrNull(r.weeks_4w),
      masons4w: numOrNull(r.masons_4w),
      masonsPrev4w: numOrNull(r.masons_prev_4w),
      epm4w: numOrNull(r.epm_4w),
      epmPrev4w: numOrNull(r.epm_prev_4w),
      pctBuild4w: numOrNull(r.pct_build_4w),
      pctBuildPrev4w: numOrNull(r.pct_build_prev_4w),
      built4w: numOrNull(r.built_4w),
      target4w: numOrNull(r.target_4w),
      sqmeBuilt4w: numOrNull(r.sqme_built_4w),
      sqmeTarget4w: numOrNull(r.sqme_target_4w),
      pctSqme4w: numOrNull(r.pct_sqme_4w),
      pctSqmePrev4w: numOrNull(r.pct_sqme_prev_4w),
      sqmeGap4w: numOrNull(r.sqme_gap_4w),
      sqmeGapPrev4w: numOrNull(r.sqme_gap_prev_4w),
      sold4w: numOrNull(r.sold_4w),
      salesTarget4w: numOrNull(r.sales_target_4w),
      pctSales4w: numOrNull(r.pct_sales_4w),
      pctSalesPrev4w: numOrNull(r.pct_sales_prev_4w),
      coll4w: numOrNull(r.coll_4w),
      pctColl4w: numOrNull(r.pct_coll_4w),
      pctCollPrev4w: numOrNull(r.pct_coll_prev_4w),
      focusRank: numOrNull(r.focus_rank),
      isFocus: Boolean(r.is_focus),
      focusWeeks: num(r.focus_weeks),
      isNewFocus: Boolean(r.is_new_focus),
      trigMasons: Boolean(r.trig_masons),
      trigEarnings: Boolean(r.trig_earnings),
      weakest4w: strOrNull(r.weakest_4w),
      takeaway: String(r.takeaway ?? ""),
    } satisfies CapacityRow,
    trend: {
      level: String(r.level) as CapacityLevel,
      name: String(r.name),
      month: String(r.month),
      weekNo: num(r.week_no),
      weekStart: String(r.week_start),
      weekEnd: String(r.week_end),
      weekLabel: String(r.week_label),
      isComplete: Boolean(r.is_complete_week),
      working: num(r.masons_on_timesheet),
      masonsBuilt: num(r.masons_built),
      masonsPaid: num(r.masons_paid),
      masonEarnings: num(r.mason_earnings),
      earningsPerMason: numOrNull(r.earnings_per_mason),
      approvalRate: numOrNull(r.approval_rate),
      built: num(r.contracts_built),
    } satisfies CapacityTrendRow,
    builtAt: String(r.built_at ?? ""),
  }));
  return {
    rows: all.filter((x) => x.row.month === month).map((x) => x.row),
    trend: all.filter((x) => x.row.isSingleWeek).map((x) => x.trend),
    builtAt: all[0]?.builtAt ?? new Date().toISOString(),
  };
}

/**
 * Every computation of a month, as it starts, so the warm route can tell a
 * cached return from a real query, wait for a background refresh it set off
 * before taking the next month, and prove its concurrency. The registry
 * lives on the global, like the fetch below, because each route is built
 * with its own copy of this module and only one copy's fetch is installed:
 * a per-module registry would miss computes run through another copy.
 */
export type CapacityCompute = {
  country: CapacityCountry;
  month: string;
  startedAt: number;
  /** Settles when the query has finished, never rejects: `error` says how it went. */
  done: Promise<void>;
  ms?: number;
  error?: string;
};
type ComputeRegistry = { watchers: Set<(compute: CapacityCompute) => void>; inFlight: number };
declare global {
  var __eeCapacityComputes: ComputeRegistry | undefined;
  var __eeCapacityFetchPacked: ((country: CapacityCountry, month: string) => Promise<string>) | undefined;
}
const registry: ComputeRegistry = (globalThis.__eeCapacityComputes ??= { watchers: new Set(), inFlight: 0 });
export function watchCapacityComputes(watcher: (compute: CapacityCompute) => void): () => void {
  registry.watchers.add(watcher);
  return () => registry.watchers.delete(watcher);
}
export function capacityComputesInFlight(): number {
  return registry.inFlight;
}

/**
 * The cached form is the month's data gzipped and base64'd, not the object:
 * a full Rwanda month is 2.4 MB as JSON and Next refuses to cache anything
 * over 2 MB, which left every visit to a complete month running the
 * ten-second function. Packed it is about 300 KB. Lossless, so the numbers
 * are exactly the query's.
 */
async function fetchCapacityDataPacked(country: CapacityCountry, month: string): Promise<string> {
  let finish!: () => void;
  const compute: CapacityCompute = { country, month, startedAt: Date.now(), done: new Promise<void>((resolve) => { finish = resolve; }) };
  registry.inFlight += 1;
  for (const watcher of registry.watchers) watcher(compute);
  try {
    return gzipSync(JSON.stringify(await fetchCapacityData(country, month))).toString("base64");
  } catch (err) {
    compute.error = err instanceof Error ? err.message : String(err);
    throw err;
  } finally {
    registry.inFlight -= 1;
    compute.ms = Date.now() - compute.startedAt;
    finish();
  }
}

/**
 * unstable_cache keys an entry on the callback's own source text. The page
 * and /api/capacity/warm are built into separate bundles and minified
 * differently, so the same function gave them different keys and the cron
 * warmed entries the page never read. A callback made from a fixed source
 * string has the same text in every bundle; it reaches the real fetch
 * through a global set by this module, which both bundles load.
 */
globalThis.__eeCapacityFetchPacked = fetchCapacityDataPacked;
const packedCacheEntry = new Function(
  "country",
  "month",
  "return globalThis.__eeCapacityFetchPacked(country, month)",
) as (country: CapacityCountry, month: string) => Promise<string>;

/**
 * Two cache tiers, one query. The current month and the two before it move
 * with every Fivetran sync and keep the 30-minute cache. Older months change
 * rarely (a late timesheet approval, a corrected date) and are refreshed once
 * a day, so the cron can keep every month warm at a fraction of the cost.
 * Same function, same numbers; only the refresh cadence differs, and the page
 * prints the data timestamp either way. A month crosses into the older tier
 * on the 1st, when its key changes, and the next cron tick fills it.
 */
export const RECENT_MONTHS = 3;
export type CapacityTier = "recent" | "older";
export const TIER_REVALIDATE: Record<CapacityTier, number> = { recent: REVALIDATE, older: 24 * 60 * 60 };

/** Every month the page offers, oldest first. Dynamic: a new month appears on its 1st. */
export function capacityMonths(): string[] {
  return [...new Set(capacityCalendar().map((w) => w.month))];
}

export function capacityTier(month: string): CapacityTier {
  return capacityMonths().slice(-RECENT_MONTHS).includes(month) ? "recent" : "older";
}

const packedByTier: Record<CapacityTier, (country: CapacityCountry, month: string) => Promise<string>> = {
  recent: unstable_cache(packedCacheEntry, ["capacity-data-v5"], { revalidate: TIER_REVALIDATE.recent, tags: ["dashboard"] }),
  older: unstable_cache(packedCacheEntry, ["capacity-data-older-v5"], { revalidate: TIER_REVALIDATE.older, tags: ["dashboard"] }),
};

export async function getCapacityData(country: CapacityCountry, month: string): Promise<CapacityData> {
  const packed = await packedByTier[capacityTier(month)](country, month);
  return JSON.parse(gunzipSync(Buffer.from(packed, "base64")).toString("utf8")) as CapacityData;
}

/**
 * One mason in one place in one week, scored on the company's productive rule:
 * approved gross pay against the country's weekly threshold times the
 * Wednesdays in the window. The rule and the threshold are applied in the
 * function, not here.
 */
export type MasonWeek = {
  masonId: string;
  masonName: string;
  month: string;
  weekNo: number;
  weekStart: string;
  weekEnd: string;
  weekLabel: string;
  isComplete: boolean;
  wednesdays: number;
  timesheets: number;
  /** Approved, gross, by end date, in the country's currency. */
  earnings: number;
  builds: number;
  /** RWF, UGX or KES. */
  currency: string;
  weeklyThreshold: number;
  threshold: number;
  pctOfThreshold: number | null;
  isProductive: boolean;
};

/**
 * The roster behind one deep dive: every mason with a timesheet, approved pay
 * or a completed build in that territory, district or branch in the weeks up
 * to `weekEnd`. The function computes only that place and the 45 days up to
 * the date, which always covers five week windows (the longest run of five
 * is 38 days); the board keeps the last five.
 */
async function fetchMasonRoster(level: RosterLevel, name: string, weekEnd: string): Promise<MasonWeek[]> {
  const rows = await query<Record<string, unknown>>(
    `
    SELECT mason_id, mason_name, CAST(month AS STRING) AS month, week_no,
      CAST(week_start AS STRING) AS week_start, CAST(week_end AS STRING) AS week_end, week_label,
      is_complete_week, wednesdays, timesheets, earnings, builds_completed,
      currency, weekly_threshold, threshold, pct_of_threshold, is_productive
    FROM ${MASON_FN}(@level, @name, CAST(@weekEnd AS DATE))
    WHERE week_end <= CAST(@weekEnd AS DATE)
      AND week_end > DATE_SUB(CAST(@weekEnd AS DATE), INTERVAL 45 DAY)
    ORDER BY mason_name, week_start
  `,
    { level, name, weekEnd },
  );
  return rows.map((r) => ({
    masonId: String(r.mason_id),
    masonName: String(r.mason_name),
    month: String(r.month),
    weekNo: num(r.week_no),
    weekStart: String(r.week_start),
    weekEnd: String(r.week_end),
    weekLabel: String(r.week_label),
    isComplete: Boolean(r.is_complete_week),
    wednesdays: num(r.wednesdays),
    timesheets: num(r.timesheets),
    earnings: num(r.earnings),
    builds: num(r.builds_completed),
    currency: String(r.currency),
    weeklyThreshold: num(r.weekly_threshold),
    threshold: num(r.threshold),
    pctOfThreshold: numOrNull(r.pct_of_threshold),
    isProductive: Boolean(r.is_productive),
  }));
}

export const getMasonRoster = unstable_cache(fetchMasonRoster, ["capacity-roster-v5"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
