import { BigQuery } from "@google-cloud/bigquery";
import { existsSync } from "node:fs";
import "server-only";

const LOCAL_KEY = "gcp-key.json";

/**
 * A single, lazily-created BigQuery client.
 *
 * Credentials resolution (first match wins):
 *   1. GCP_SERVICE_ACCOUNT_KEY  — the full service-account JSON as a string.
 *      Use this on Vercel (paste the JSON into one env var).
 *   2. GOOGLE_APPLICATION_CREDENTIALS — path to a key file (Google's standard).
 *   3. ./gcp-key.json in the project root — easiest for local dev; git-ignored.
 *
 * The browser never imports this file (`server-only` enforces that), so the
 * key material stays on the server.
 */
export const GCP_PROJECT_ID = process.env.GCP_PROJECT_ID ?? "earth-enable-main";

let client: BigQuery | null = null;

export function bq(): BigQuery {
  if (client) return client;

  const inlineKey = process.env.GCP_SERVICE_ACCOUNT_KEY;
  if (inlineKey) {
    const credentials = JSON.parse(inlineKey);
    client = new BigQuery({ projectId: GCP_PROJECT_ID, credentials });
    return client;
  }

  // Falls back to GOOGLE_APPLICATION_CREDENTIALS, or ./gcp-key.json if present.
  const keyFilename =
    process.env.GOOGLE_APPLICATION_CREDENTIALS ??
    (existsSync(LOCAL_KEY) ? LOCAL_KEY : undefined);

  client = new BigQuery({ projectId: GCP_PROJECT_ID, keyFilename });
  return client;
}

// BQ_LOG=1 prints one line per query with BigQuery's own timing, slot-ms
// and cache-hit flag, so a page load can be costed without the job log
// (the app's service account cannot read INFORMATION_SCHEMA.JOBS). Off by
// default: the logged path fetches job metadata, which the plain path skips.
const LOG_QUERIES = process.env.BQ_LOG === "1";

/** Run a parameterised, read-only query and return typed rows. */
export async function query<T>(
  sql: string,
  params: Record<string, unknown> = {},
): Promise<T[]> {
  if (!LOG_QUERIES) {
    const [rows] = await bq().query({
      query: sql,
      params,
      location: "US",
    });
    return rows as T[];
  }
  const t0 = Date.now();
  const [job] = await bq().createQueryJob({ query: sql, params, location: "US" });
  const [rows] = await job.getQueryResults();
  const [meta] = await job.getMetadata();
  const s = meta.statistics ?? {};
  const q = s.query ?? {};
  const source = /FROM\s+`?([\w.`-]+)`?/i.exec(sql)?.[1] ?? "?";
  console.log(
    `[bq] ${source} rows=${rows.length} total=${Date.now() - t0}ms bq=${Number(s.endTime) - Number(s.startTime)}ms ` +
      `slotMs=${q.totalSlotMs ?? 0} billedMB=${Math.round(Number(q.totalBytesBilled ?? 0) / 1e6)} cacheHit=${q.cacheHit ?? false}`,
  );
  return rows as T[];
}

/** True when a service account is configured in this environment. */
export function hasCredentials(): boolean {
  return Boolean(
    process.env.GCP_SERVICE_ACCOUNT_KEY ||
      process.env.GOOGLE_APPLICATION_CREDENTIALS ||
      existsSync(LOCAL_KEY),
  );
}
