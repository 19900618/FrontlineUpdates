import { unstable_cache } from "next/cache";
import { query } from "./bigquery";
import type { CountryName } from "./workspaces";

/**
 * Each QA officer's own record: what they evaluated in the window, how it went,
 * and what is still sitting on their list.
 *
 * Evaluations come from the same table and the same QA rule as the Quality
 * overview, so the two pages cannot disagree. A QA evaluation is one whose QA
 * Survey department is neither District nor Construction, a blank department
 * counting as QA:
 *   raw_data_from_salesforce.all_qa_evaluations_clean, for the evaluation
 *   salesforce.qa_evals_all, for that department and the evaluator's position
 *
 * Pending work is the QA task list, which is where an evaluation lives before
 * anyone does it:
 *   salesforce.QA Tasks Only
 * It carries who it is on, the job, the stage, when it was raised, how long it
 * has waited and whether it is overdue, so nothing here has to be reconstructed.
 */
const CLEAN = "`earth-enable-main.raw_data_from_salesforce.all_qa_evaluations_clean`";
const EVALS = "`earth-enable-main.salesforce.qa_evals_all`";
const TASKS = "`earth-enable-main.salesforce.QA Tasks Only`";
/** The staff record, for whether someone still works here. */
const CONTACT = "`earth-enable-main.salesforce.contact`";

const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

/** The same rule the overview uses, read from the QA Survey rather than the contact. */
const IS_QA = `(e.department IS NULL
  OR (NOT CONTAINS_SUBSTR(e.department, 'District') AND NOT CONTAINS_SUBSTR(e.department, 'Construction')))`;

/**
 * Who belongs on this roster: staff whose position names them as QA, and not as a
 * manager or as call centre. That keeps Quality Auditor, QA Officer, Junior QA
 * Officer, Quality Assurance Officer, Assistant, Coordinator, Team Leader and
 * Production Quality Assurance Officer. It drops QA Manager, Quality Auditor
 * Manager, Quality Assurance Junior Manager and Quality Assurance - Call Center,
 * along with every role outside the team: Territory Lead, District operation
 * Lead, Trainer, Construction and the rest.
 *
 * Call is matched on its own rather than on the full phrase: the only two
 * positions containing it are the call centre ones, and both belong out.
 *
 * This is a narrower question than whether an evaluation was a QA evaluation.
 * The overview asks the second; this page asks the first, so some of the checks
 * the overview counts were done by people who are not on this roster. The page
 * says how many rather than letting the two quietly disagree.
 */
/**
 * Still on the staff. Everything else the contact records -- terminated, resigned,
 * inactive, eligible for rehire -- is someone who has left, and a roster of who is
 * doing QA work should not carry them. The task list exposes the same field, so
 * both halves of a person's row are held to it.
 */
const IS_ACTIVE = (col: string) => `${col} = 'Active'`;

const IS_QA_TEAM = (col: string) =>
  `((CONTAINS_SUBSTR(UPPER(${col}), 'QUALITY') OR CONTAINS_SUBSTR(UPPER(${col}), 'QA'))
    AND NOT CONTAINS_SUBSTR(UPPER(${col}), 'MANAGER')
    AND NOT CONTAINS_SUBSTR(UPPER(${col}), 'CALL'))`;

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const str = (v: unknown): string => (v == null ? "" : String(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

import { QA_STAGES, type QaStage } from "./quality-stages";
export { QA_STAGES, type QaStage };

export type QaOfficer = {
  id: string;
  name: string;
  /** Their position in Salesforce, e.g. Quality Auditor, QA Officer. */
  position: string | null;
  branch: string | null;
  evals: number;
  passed: number;
  failed: number;
  notReady: number;
  /** Evaluations at each stage, in the QA_STAGES order. */
  byStage: Record<QaStage, number>;
  jobs: number;
  /** Days they did at least one evaluation, for a per-working-day rate. */
  activeDays: number;
  /** Open tasks on their name right now. Not filtered by the window: see below. */
  pending: number;
  pendingOverdue: number;
  /** Days the oldest open task has waited. */
  oldestPending: number | null;
  /** The open tasks split by the step each one is for. */
  pendingByStep: { step: string; n: number }[];
  /** Tasks they closed inside the window, and how many inside two days. */
  tasksDone: number;
  tasksOnTime: number;
};

/** One task still waiting on someone. */
export type QaTask = {
  taskId: string;
  subject: string;
  stage: string | null;
  job: string;
  opportunityId: string | null;
  customer: string | null;
  branch: string | null;
  officer: string | null;
  officerId: string | null;
  createdOn: string | null;
  dueOn: string | null;
  pendingDays: number;
  overdue: boolean;
  status: string;
};

export type QaIndividual = {
  officers: QaOfficer[];
  /** QA work done by, or sitting on, staff who are not on the QA team. */
  outsideTeam: { people: number; evals: number; threeStage: number; pending: number };
};

const stageMap = (r: Record<string, unknown>): Record<QaStage, number> => ({
  Compaction: num(r.s_compaction),
  Screed: num(r.s_screed),
  "Prior Paint": num(r.s_prior_paint),
  Final: num(r.s_final),
  "Pre-House": num(r.s_pre_house),
  Other: num(r.s_other),
});

/**
 * Every QA officer who either evaluated something in the window or has an open
 * task, with both sides of their record.
 *
 * The two halves are counted on different clocks on purpose. Evaluations belong
 * to the window. Open tasks do not: a task raised in March and still untouched is
 * pending now, and dropping it because it was not created this month would hide
 * exactly the work that most needs looking at. Only tasks raised on or before the
 * window's end are counted, so looking back at an old period does not show work
 * that did not exist yet.
 */
async function fetchQaIndividual(country: CountryName, from: string, to: string): Promise<QaIndividual> {
  const [rows, outside, outsideTasks] = await Promise.all([
    query<Record<string, unknown>>(
      `
      WITH ev AS (
        SELECT q.evaluator_id, q.evaluator_name, q.stage, q.primary_decision, q.primary_eval_date,
               q.opportunity_id, q.branch, e.staff_position
        FROM ${CLEAN} q
        LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
        JOIN ${CONTACT} ct ON ct.id = q.evaluator_id
        WHERE q.location_country = @country
          AND q.primary_eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
          AND ${IS_QA}
          AND q.evaluator_id IS NOT NULL
          AND ${IS_ACTIVE("ct.employee_status_c")}
      ),
      done AS (
        SELECT evaluator_id AS id,
          ANY_VALUE(evaluator_name) AS name,
          ANY_VALUE(staff_position) AS position,
          ANY_VALUE(COALESCE(NULLIF(TRIM(REGEXP_REPLACE(branch, r'\\s*Branch$', '')), ''), 'Unassigned')) AS branch,
          COUNT(*) AS evals,
          COUNTIF(primary_decision = 'Pass') AS passed,
          COUNTIF(primary_decision = 'Not Ready for Evaluation') AS not_ready,
          COUNTIF(primary_decision IS NOT NULL AND primary_decision NOT IN ('Pass', 'Not Ready for Evaluation')) AS failed,
          COUNTIF(stage = 'Compaction') AS s_compaction,
          COUNTIF(stage = 'Screed') AS s_screed,
          COUNTIF(stage = 'Prior Paint') AS s_prior_paint,
          COUNTIF(stage = 'Final') AS s_final,
          COUNTIF(stage = 'Pre-House') AS s_pre_house,
          COUNTIF(stage NOT IN ('Compaction', 'Screed', 'Prior Paint', 'Final', 'Pre-House')) AS s_other,
          COUNT(DISTINCT opportunity_id) AS jobs,
          COUNT(DISTINCT primary_eval_date) AS active_days
        FROM ev GROUP BY 1
      ),
      -- On time is the company's own rule, already on the task list: closed on or
      -- before the task's due date. Read from completed_on_time rather than redone
      -- here, so this page and anything else reading that flag cannot drift apart.
      completed AS (
        SELECT task_employee_surveyor_id AS id,
          COUNT(*) AS done,
          COUNTIF(completed_on_time = 1) AS on_time
        FROM ${TASKS}
        WHERE location_country = @country AND task_is_closed
          AND task_employee_surveyor_id IS NOT NULL
          AND task_completed_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
          AND ${IS_ACTIVE("employee_status")}
        GROUP BY 1
      ),
      open_tasks AS (
        SELECT task_employee_surveyor_id AS id,
          ANY_VALUE(task_employee_surveyor_name) AS name,
          ANY_VALUE(task_employee_surveyor_position) AS position,
          COUNT(*) AS pending,
          COUNTIF(is_task_overdue) AS overdue,
          MAX(pending_days) AS oldest,
          -- What the open work actually is. The subject is the step the task is for.
          COUNTIF(task_subject = 'Compaction Evaluation') AS t_compaction,
          COUNTIF(task_subject = 'Screed Evaluation') AS t_screed,
          COUNTIF(task_subject = 'Prior Paint/varnish') AS t_prior_paint,
          COUNTIF(task_subject = 'Final Evaluation') AS t_final,
          COUNTIF(task_subject = 'Pre-House Assessment') AS t_pre_house,
          COUNTIF(task_subject NOT IN ('Compaction Evaluation', 'Screed Evaluation',
            'Prior Paint/varnish', 'Final Evaluation', 'Pre-House Assessment')
            OR task_subject IS NULL) AS t_other
        FROM ${TASKS}
        WHERE location_country = @country
          AND NOT task_is_closed
          AND task_employee_surveyor_id IS NOT NULL
          AND DATE(task_created_date) <= CAST(@to AS DATE)
          AND ${IS_ACTIVE("employee_status")}
        GROUP BY 1
      )
      SELECT COALESCE(d.id, t.id, k.id) AS id,
        COALESCE(d.name, t.name) AS name,
        COALESCE(d.position, t.position) AS position,
        d.branch,
        COALESCE(d.evals, 0) AS evals, COALESCE(d.passed, 0) AS passed,
        COALESCE(d.failed, 0) AS failed, COALESCE(d.not_ready, 0) AS not_ready,
        COALESCE(d.s_compaction, 0) AS s_compaction, COALESCE(d.s_screed, 0) AS s_screed,
        COALESCE(d.s_prior_paint, 0) AS s_prior_paint, COALESCE(d.s_final, 0) AS s_final,
        COALESCE(d.s_pre_house, 0) AS s_pre_house, COALESCE(d.s_other, 0) AS s_other,
        COALESCE(d.jobs, 0) AS jobs, COALESCE(d.active_days, 0) AS active_days,
        COALESCE(t.pending, 0) AS pending, COALESCE(t.overdue, 0) AS overdue, t.oldest,
        COALESCE(t.t_compaction, 0) AS t_compaction, COALESCE(t.t_screed, 0) AS t_screed,
        COALESCE(t.t_prior_paint, 0) AS t_prior_paint, COALESCE(t.t_final, 0) AS t_final,
        COALESCE(t.t_pre_house, 0) AS t_pre_house, COALESCE(t.t_other, 0) AS t_other,
        COALESCE(k.done, 0) AS tasks_done, COALESCE(k.on_time, 0) AS tasks_on_time
      FROM done d
      FULL OUTER JOIN open_tasks t ON t.id = d.id
      LEFT JOIN completed k ON k.id = COALESCE(d.id, t.id)
      WHERE COALESCE(d.name, t.name) IS NOT NULL
        AND ${IS_QA_TEAM("COALESCE(d.position, t.position)")}
      ORDER BY evals DESC, pending DESC
    `,
      { country, from, to },
    ),

    // QA evaluations done by people who are not on the QA team, which the overview
    // counts and this roster does not.
    query<Record<string, unknown>>(
      `SELECT COUNT(DISTINCT q.evaluator_id) AS people, COUNT(*) AS evals,
         COUNTIF(q.stage IN ('Compaction', 'Screed', 'Prior Paint')) AS three_stage
       FROM ${CLEAN} q
       LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
       WHERE q.location_country = @country
         AND q.primary_eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
         AND ${IS_QA}
         AND q.evaluator_id IS NOT NULL
         AND NOT ${IS_QA_TEAM("e.staff_position")}`,
      { country, from, to },
    ),

    // Open tasks sitting on someone who is not on the QA team.
    query<Record<string, unknown>>(
      `SELECT COUNT(*) AS pending FROM ${TASKS}
       WHERE location_country = @country AND NOT task_is_closed
         AND task_employee_surveyor_id IS NOT NULL
         AND DATE(task_created_date) <= CAST(@to AS DATE)
         AND NOT ${IS_QA_TEAM("task_employee_surveyor_position")}`,
      { country, to },
    ),
  ]);

  const o = outside[0] ?? {};
  return {
    officers: rows.map((r) => ({
      id: str(r.id),
      name: str(r.name),
      position: strOrNull(r.position),
      branch: strOrNull(r.branch),
      evals: num(r.evals),
      passed: num(r.passed),
      failed: num(r.failed),
      notReady: num(r.not_ready),
      byStage: stageMap(r),
      jobs: num(r.jobs),
      activeDays: num(r.active_days),
      pending: num(r.pending),
      pendingOverdue: num(r.overdue),
      oldestPending: numOrNull(r.oldest),
      pendingByStep: [
        { step: "Compaction", n: num(r.t_compaction) },
        { step: "Screed", n: num(r.t_screed) },
        { step: "Prior paint", n: num(r.t_prior_paint) },
        { step: "Final", n: num(r.t_final) },
        { step: "Pre-house", n: num(r.t_pre_house) },
        { step: "Other", n: num(r.t_other) },
      ].filter((x) => x.n > 0),
      tasksDone: num(r.tasks_done),
      tasksOnTime: num(r.tasks_on_time),
    })),
    outsideTeam: {
      people: num(o.people),
      evals: num(o.evals),
      threeStage: num(o.three_stage),
      pending: num(outsideTasks[0]?.pending),
    },
  };
}

export const getQaIndividual = unstable_cache(fetchQaIndividual, ["qa-individual-v8"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/** The open tasks on one officer, oldest first. */
async function fetchQaTasks(country: CountryName, to: string, officerId: string, limit: number): Promise<QaTask[]> {
  const who = "task_employee_surveyor_id = @officerId";
  const rows = await query<Record<string, unknown>>(
    `SELECT task_id, task_subject, task_type, task_status, opportunity_id, opportunity_name,
       location_name, location_branch, task_employee_surveyor_name, task_employee_surveyor_id,
       CAST(DATE(task_created_date) AS STRING) AS created_on,
       CAST(task_activity_date AS STRING) AS due_on,
       pending_days, is_task_overdue
     FROM ${TASKS}
     WHERE location_country = @country AND NOT task_is_closed
       AND DATE(task_created_date) <= CAST(@to AS DATE)
       AND ${who}
     ORDER BY pending_days DESC, task_id
     LIMIT @limit`,
    { country, to, officerId, limit },
  );
  return rows.map((r) => ({
    taskId: str(r.task_id),
    subject: str(r.task_subject),
    stage: strOrNull(r.task_subject),
    job: str(r.opportunity_name),
    opportunityId: strOrNull(r.opportunity_id),
    customer: strOrNull(r.location_name),
    branch: strOrNull(r.location_branch),
    officer: strOrNull(r.task_employee_surveyor_name),
    officerId: strOrNull(r.task_employee_surveyor_id),
    createdOn: strOrNull(r.created_on),
    dueOn: strOrNull(r.due_on),
    pendingDays: num(r.pending_days),
    overdue: Boolean(r.is_task_overdue),
    status: str(r.task_status),
  }));
}

export const getQaTasks = unstable_cache(fetchQaTasks, ["qa-tasks-v2"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/** One evaluation an officer did, for the drill-down under a stage. */
export type QaOfficerEval = {
  surveyId: string;
  date: string;
  stage: string;
  decision: string;
  passed: boolean;
  job: string;
  mason: string | null;
  branch: string | null;
  comment: string | null;
};

/** What one officer did in the window, optionally at one stage only, newest first. */
async function fetchQaOfficerEvals(
  country: CountryName, from: string, to: string, officerId: string, stage: string, limit: number,
): Promise<QaOfficerEval[]> {
  const atStage = stage === "" ? "" :
    stage === "Other"
      ? "AND q.stage NOT IN ('Compaction', 'Screed', 'Prior Paint', 'Final', 'Pre-House')"
      : "AND q.stage = @stage";
  const rows = await query<Record<string, unknown>>(
    `SELECT q.qa_survey_id, CAST(q.primary_eval_date AS STRING) AS d, q.stage, q.primary_decision,
       SAFE_CAST(q.primary_pass_flag AS INT64) AS pass_flag, q.opportunity_name, q.mason_name,
       COALESCE(NULLIF(TRIM(REGEXP_REPLACE(q.branch, r'\\s*Branch$', '')), ''), 'Unassigned') AS branch,
       q.eval_comment
     FROM ${CLEAN} q
     LEFT JOIN ${EVALS} e ON e.survey_id = q.qa_survey_id
     WHERE q.location_country = @country
       AND q.primary_eval_date BETWEEN CAST(@from AS DATE) AND CAST(@to AS DATE)
       AND ${IS_QA}
       AND q.evaluator_id = @officerId
       ${atStage}
     ORDER BY q.primary_eval_date DESC, q.qa_survey_id
     LIMIT @limit`,
    { country, from, to, officerId, stage, limit },
  );
  return rows.map((r) => ({
    surveyId: str(r.qa_survey_id),
    date: str(r.d),
    stage: str(r.stage),
    decision: str(r.primary_decision ?? "-"),
    passed: num(r.pass_flag) === 1,
    job: str(r.opportunity_name),
    mason: strOrNull(r.mason_name),
    branch: strOrNull(r.branch),
    comment: strOrNull(r.eval_comment),
  }));
}

export const getQaOfficerEvals = unstable_cache(fetchQaOfficerEvals, ["qa-officer-evals-v2"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
