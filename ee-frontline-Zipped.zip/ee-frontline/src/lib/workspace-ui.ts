/**
 * Client-safe helpers for the country workspaces: picking rows out of the
 * period payload, wording the unit, formatting money. Nothing here decides a
 * threshold or recomputes a metric; the views did that.
 */
import type { CapacityWeek } from "./capacity-calendar";
import type { CapacityCountry } from "./capacity-ui";
import { CAPACITY_CURRENCY, UNIT_LEVEL } from "./capacity-ui";
import type { PeriodInfo, Scope } from "./period";
import type { UnitLevel, WsData, WsRow } from "./workspace-types";

export const SERIES_SALES = "#ee7203";
export const SERIES_COLL = "#2f6f9f";
export const SERIES_BUILDS = "var(--text-secondary)";
export const SERIES_QA = "#6a5a8c";

/** The country's unit of management, and what Rwanda calls the level above it. */
export function unitLevelOf(country: CapacityCountry): UnitLevel { return UNIT_LEVEL[country]; }
export const hasBranchToggle = (country: CapacityCountry) => country === "Rwanda";

/** 'territory' -> 'territory' / 'territories'; the district level reads "branch" in Rwanda, as the company calls it. */
export function unitWord(level: string, n = 2): string {
  const one = level === "district" ? "branch" : level;
  if (n === 1) return one;
  return one === "territory" ? "territories" : one === "branch" ? "branches" : `${one}s`;
}
export const levelTitle = (level: string) => (level === "district" ? "Branch" : level.charAt(0).toUpperCase() + level.slice(1));

export const currencyOf = (country: CapacityCountry) => CAPACITY_CURRENCY[country];

/** The territories (Rwanda) or branches (Uganda, Kenya) in the payload, for the filter bar's dropdown. */
export function unitsOf(data: WsData): string[] {
  const unit = unitLevelOf(data.rows[0]?.country ?? "Rwanda");
  return [...new Set(data.rows.filter((r) => r.level === unit).map((r) => r.name))].sort();
}

/** 'RWF 41.2M', 'UGX 18K', 'KES 950'. */
export function money(n: number | null | undefined, currency: string): string {
  if (n == null) return "-";
  const a = Math.abs(n);
  if (a >= 1e9) return `${currency} ${(n / 1e9).toFixed(1)}B`;
  if (a >= 1e6) return `${currency} ${(n / 1e6).toFixed(1)}M`;
  if (a >= 1e3) return `${currency} ${Math.round(n / 1e3)}K`;
  return `${currency} ${Math.round(n)}`;
}

export const pctText = (v: number | null | undefined): string => (v == null ? "-" : `${Math.round(v * 100)}%`);
export const whole = (n: number | null | undefined): string => (n == null ? "-" : Math.round(n).toLocaleString("en-US"));
export const one = (n: number | null | undefined): string => (n == null ? "-" : (Math.round(n * 10) / 10).toLocaleString("en-US"));

/** Green met it, amber within 20%, clay below. Performance against target only. */
export type Tone = "good" | "near" | "bad" | "none";
export function toneOf(pct: number | null | undefined): Tone {
  if (pct == null) return "none";
  if (pct >= 1) return "good";
  if (pct >= 0.8) return "near";
  return "bad";
}
export const TONE_COLOR: Record<Tone, string> = {
  good: "var(--good)", near: "var(--warning)", bad: "var(--critical)", none: "var(--text-muted)",
};

/** Plural-safe "N contracts". */
export const count = (n: number, word: string, plural = `${word}s`) => `${whole(n)} ${n === 1 ? word : plural}`;

/** "8,541 SQM-E to go" or "Target reached". */
export function toGo(actual: number, target: number | null, word: string): string {
  if (target == null) return "no target set";
  const d = target - actual;
  return d > 0 ? `${whole(d)} ${word} to go` : "Target reached";
}

// ---------------------------------------------------------------------------
// Picking rows out of the payload.
// ---------------------------------------------------------------------------

/** The row for the selected period at one level and name. */
export function periodRow(rows: WsRow[], period: PeriodInfo, level: string, name: string): WsRow | undefined {
  return rows.find((r) => r.level === level && r.name === name && r.month === period.month && r.weekKey === period.weekKey);
}

/** The head of the page: the scope's own row, else the country's. */
export function headRow(rows: WsRow[], period: PeriodInfo, country: CapacityCountry, scope: Scope): WsRow | undefined {
  return scope ? periodRow(rows, period, scope.level, scope.name) : periodRow(rows, period, "country", country);
}

/**
 * The rows the table lists: every unit (or every Rwanda district with the
 * toggle), a district's territories when a district is the scope, or the
 * scoped unit alone.
 */
export function tableRows(rows: WsRow[], period: PeriodInfo, country: CapacityCountry, scope: Scope, dim: UnitLevel): WsRow[] {
  const unit = unitLevelOf(country);
  const inPeriod = rows.filter((r) => r.month === period.month && r.weekKey === period.weekKey);
  if (!scope) return inPeriod.filter((r) => r.level === (dim === "district" ? "district" : unit));
  if (scope.level === "district") return inPeriod.filter((r) => r.level === "territory" && r.parent === scope.name);
  return inPeriod.filter((r) => r.level === scope.level && r.name === scope.name);
}

/** The level the table lists for a scope and toggle. */
export function tableLevel(country: CapacityCountry, scope: Scope, dim: UnitLevel): UnitLevel {
  if (!scope) return dim === "district" ? "district" : unitLevelOf(country);
  return scope.level === "district" ? "territory" : scope.level;
}

/** Whole-month rows for one level and name, January of the period's year to the fetched month. */
export function trendRows(rows: WsRow[], period: PeriodInfo, level: string, name: string): WsRow[] {
  const jan = `${period.month.slice(0, 4)}-01-01`;
  return rows
    .filter((r) => r.isWholeMonth && r.level === level && r.name === name && r.month >= jan && r.month <= period.fetchMonth)
    .sort((a, b) => a.month.localeCompare(b.month));
}

/** Contracts that crossed the payment gate today, read from whichever row holds today. */
export function collectedToday(rows: WsRow[], level: string, name: string): number {
  const today = new Date().toISOString().slice(0, 10);
  const cur = rows.find((r) => r.isWholeMonth && r.level === level && r.name === name && r.periodStart <= today && r.periodEnd >= today);
  return cur?.collectedToday ?? 0;
}

/** The whole-month row for a level and name in one month. */
export function monthRow(rows: WsRow[], month: string, level: string, name: string): WsRow | undefined {
  return rows.find((r) => r.isWholeMonth && r.level === level && r.name === name && r.month === month);
}

/** The last N complete calendar weeks, oldest first. */
export function lastCompleteWeeks(calendar: CapacityWeek[], n = 5): CapacityWeek[] {
  return calendar.filter((w) => w.isComplete).slice(-n);
}

/** The single-week row for a level and name in one calendar week, if the payload holds it. */
export function weekRow(rows: WsRow[], level: string, name: string, w: CapacityWeek): WsRow | undefined {
  return rows.find((r) => r.level === level && r.name === name && r.month === w.month && r.weekKey === String(w.weekNo));
}

/** The names of the N units furthest behind on a score, for the "Bottom 5" mark. Never marks a list of five or fewer. */
export function bottomN(rows: WsRow[], score: (r: WsRow) => number | null, n = 5): Set<string> {
  if (rows.length <= n) return new Set();
  const scored = rows.filter((r) => score(r) != null).sort((a, b) => (score(a) as number) - (score(b) as number));
  return new Set(scored.slice(0, n).map((r) => r.name));
}

/** '▲ 4', '▼ 2', or a dash. */
export function movementText(move: number | null): { text: string; color: string } {
  if (move == null || move === 0) return { text: "–", color: "var(--text-muted)" };
  return move > 0 ? { text: `▲ ${move}`, color: "var(--good)" } : { text: `▼ ${Math.abs(move)}`, color: "var(--critical)" };
}

/** ISO date to '16 Sep'. */
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export function dayMonth(iso: string): string {
  const [, m, d] = iso.split("-").map(Number);
  return `${d} ${MON[m - 1]}`;
}
export function dayMonthYear(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return `${d} ${MON[m - 1]} ${y}`;
}

/** The freshness line every page carries: when Salesforce last synced, and when these figures were computed. */
export function freshnessLine(syncedMs: number | null, builtAt: string): string {
  if (syncedMs == null) return "Salesforce sync time unknown · figures refresh every 15 minutes";
  const asOf = new Date(syncedMs).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC" });
  const lagMin = Math.max(0, Math.round((Date.now() - syncedMs) / 60000));
  const lag = lagMin < 90 ? `${lagMin} min` : `~${Math.round(lagMin / 60)}h`;
  const computed = new Date(builtAt);
  const at = Number.isNaN(computed.getTime()) ? "" : ` · figures computed ${computed.toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "UTC" })} UTC`;
  return `Salesforce data synced ${lag} ago (${asOf} UTC) · figures refresh every 15 minutes${at}`;
}
