import { unstable_cache } from "next/cache";
import { query } from "./bigquery";

/**
 * CANONICAL CSO view — the app is a thin reader. All productivity logic lives in
 * BigQuery and mirrors the company's existing capacity model
 * (raw_data_from_salesforce.territory_capacity_monthly), so numbers reconcile
 * with what TLs already see:
 *
 *   sales productivity      = contracts sold      / (build_target x 1.3 / 5 CSOs)
 *   collections productivity= contracts collected / (build_target / 5 CSOs)
 *   "collected"             = Floor at 50% paid, Plaster/Paint at 100% paid
 *   targets are the month's own (this month's work vs this month's target)
 *   contracts count phase 1 only (one job = one build, like build_target);
 *   SQM-E counts every phase, because sqme_target is set on all phases
 *
 * Built straight off the Salesforce tables, not all_opportunities_master.
 *   earth-enable-main.salesforce.cso_performance_app_v1
 */
const VIEW = "`earth-enable-main.salesforce.cso_performance_app_v1`";
const REVALIDATE = 900; // 15 min, matching the 15-minute Fivetran sync

const num = (v: unknown): number => (v == null ? 0 : Number(v));
const numOrNull = (v: unknown): number | null => (v == null ? null : Number(v));
const strOrNull = (v: unknown): string | null => (v == null ? null : String(v));

/** One CSO's activity in one month, with the per-person standard for that month. */
export type CsoMonth = {
  csoId: string;
  cso: string;
  phone: string | null;
  month: string; // 'YYYY-MM-01'
  monthLabel: string;
  territory: string;
  district: string;
  /** Stable assignment tethered to the staff record / their overall history,
   *  as opposed to `territory` which is wherever they worked THIS month. */
  homeTerritory: string | null;
  assignedDistrict: string | null;
  isAwayFromHome: boolean;
  manager: string | null;
  sold: number;
  soldSqme: number;
  collected: number;
  collectedSqme: number;
  hasTargets: boolean;
  /** Days the CSO could actually work this month, and that over the month length. */
  daysAvailable: number;
  monthDays: number;
  /** True when they did not have the whole month (joined mid-month, or month in progress). */
  isPartMonth: boolean;
  /** Hired within the two months before this one. */
  isNewCso: boolean;
  /** Currently employed. Leavers keep their history but are hidden by default. */
  isActiveStaff: boolean;
  /** Duplicate stub contact (no status, no hire date). Hidden by default. */
  isUnverifiedStaff: boolean;
  isCurrentMonth: boolean;
  /** Per-CSO monthly bar in contracts, PRO-RATED for days actually worked. */
  minSold: number | null;
  minCollected: number | null;
  /** Actual / standard. 1.0 = exactly at the bar. Null when no target. */
  pctSold: number | null;
  pctCollected: number | null;
};

/**
 * Every CSO-month from 2026 on. Small enough (roughly 250 CSOs x 12 months) to
 * ship once and let both pages filter it client-side, which keeps the month
 * picker and the individual trend instant.
 */
async function fetchCsoMonths(): Promise<CsoMonth[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT
      cso_id, cso_name, cso_phone,
      CAST(month AS STRING) AS month, month_label,
      COALESCE(NULLIF(TRIM(territory),''),'Unassigned') AS territory,
      COALESCE(NULLIF(TRIM(district),''),'Unassigned') AS district,
      manager, home_territory, assigned_district, is_away_from_home,
      contracts_sold, sqme_sold, contracts_collected, sqme_collected,
      has_targets, days_available, month_days, is_part_month, is_new_cso,
      is_current_month, is_active_staff, is_unverified_staff,
      min_sales_contracts, min_coll_contracts,
      pct_sales_productivity, pct_coll_productivity
    FROM ${VIEW}
    WHERE month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
    ORDER BY month DESC, contracts_sold DESC
  `);
  return rows.map((r) => ({
    csoId: String(r.cso_id),
    cso: r.cso_name == null ? "Unnamed" : String(r.cso_name),
    phone: strOrNull(r.cso_phone),
    month: String(r.month),
    monthLabel: String(r.month_label),
    territory: String(r.territory),
    district: String(r.district),
    manager: strOrNull(r.manager),
    homeTerritory: strOrNull(r.home_territory),
    assignedDistrict: strOrNull(r.assigned_district),
    isAwayFromHome: Boolean(r.is_away_from_home),
    sold: num(r.contracts_sold),
    soldSqme: num(r.sqme_sold),
    collected: num(r.contracts_collected),
    collectedSqme: num(r.sqme_collected),
    hasTargets: Boolean(r.has_targets),
    daysAvailable: num(r.days_available),
    monthDays: num(r.month_days),
    isPartMonth: Boolean(r.is_part_month),
    isNewCso: Boolean(r.is_new_cso),
    isActiveStaff: Boolean(r.is_active_staff),
    isUnverifiedStaff: Boolean(r.is_unverified_staff),
    isCurrentMonth: Boolean(r.is_current_month),
    minSold: numOrNull(r.min_sales_contracts),
    minCollected: numOrNull(r.min_coll_contracts),
    pctSold: numOrNull(r.pct_sales_productivity),
    pctCollected: numOrNull(r.pct_coll_productivity),
  }));
}

export const getCsoMonths = unstable_cache(fetchCsoMonths, ["cso-months-v8"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/**
 * A CSO's open follow-up load right now: contracts they signed that still have
 * not crossed the payment gate. Uses the same rich test as the Collections
 * module (paid to threshold OR milestone date OR construction progressed), NOT
 * a null milestone date, which overstates the backlog roughly 8x.
 */
export type CsoPending = {
  csoId: string;
  contracts: number;
  sqme: number;
  cash: number;
  oldestDays: number | null;
  under90d: number;
  over1y: number;
};

async function fetchCsoPending(): Promise<CsoPending[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT cso_id, pending_contracts, pending_sqme, pending_cash_to_milestone,
           oldest_pending_days, pending_under_90d, pending_over_1y
    FROM \`earth-enable-main.salesforce.cso_pending_app_v1\`
  `);
  return rows.map((r) => ({
    csoId: String(r.cso_id),
    contracts: num(r.pending_contracts),
    sqme: num(r.pending_sqme),
    cash: num(r.pending_cash_to_milestone),
    oldestDays: numOrNull(r.oldest_pending_days),
    under90d: num(r.pending_under_90d),
    over1y: num(r.pending_over_1y),
  }));
}

export const getCsoPending = unstable_cache(fetchCsoPending, ["cso-pending-v3"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

// Band helpers live in ./cso-bands so client components can import them without
// pulling this module (and BigQuery with it) into the browser bundle.

/**
 * Territory x month rollup for the overview page. The overview never shows an
 * individual, so shipping ~1,600 per-CSO rows to the browser was ~1.3MB of
 * payload for a page that only ever groups them. This collapses it to a few
 * hundred rows. Split by current_staff so the "include leavers" toggle still
 * works client-side without a second round trip.
 */
export type CsoTerritoryMonth = {
  month: string;
  monthLabel: string;
  territory: string;
  district: string;
  currentStaff: boolean;
  csos: number;
  sold: number;
  collected: number;
  soldSqme: number;
  collectedSqme: number;
  minSold: number;
  minCollected: number;
  minSoldSqme: number;
  minCollectedSqme: number;
  isCurrentMonth: boolean;
};

async function fetchCsoTerritoryMonths(): Promise<CsoTerritoryMonth[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT
      CAST(month AS STRING) AS month, ANY_VALUE(month_label) AS month_label,
      COALESCE(NULLIF(TRIM(territory),''),'Unassigned') AS territory,
      COALESCE(NULLIF(TRIM(district),''),'Unassigned') AS district,
      is_active_staff AND NOT is_unverified_staff AS current_staff,
      COUNT(*) AS csos,
      SUM(contracts_sold) AS sold,
      SUM(contracts_collected) AS collected,
      ROUND(SUM(sqme_sold)) AS sold_sqme,
      ROUND(SUM(sqme_collected)) AS collected_sqme,
      ROUND(SUM(IF(has_targets, min_sales_contracts, 0)),2) AS min_sold,
      ROUND(SUM(IF(has_targets, min_coll_contracts, 0)),2) AS min_collected,
      ROUND(SUM(IF(has_targets, min_sales_sqme, 0)),1) AS min_sold_sqme,
      ROUND(SUM(IF(has_targets, min_coll_sqme, 0)),1) AS min_collected_sqme,
      LOGICAL_OR(is_current_month) AS is_current_month
    FROM ${VIEW}
    WHERE month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
    GROUP BY month, territory, district, current_staff
    ORDER BY month
  `);
  return rows.map((r) => ({
    month: String(r.month),
    monthLabel: String(r.month_label),
    territory: String(r.territory),
    district: String(r.district),
    currentStaff: Boolean(r.current_staff),
    csos: num(r.csos),
    sold: num(r.sold),
    collected: num(r.collected),
    soldSqme: num(r.sold_sqme),
    collectedSqme: num(r.collected_sqme),
    minSold: num(r.min_sold),
    minCollected: num(r.min_collected),
    minSoldSqme: num(r.min_sold_sqme),
    minCollectedSqme: num(r.min_collected_sqme),
    isCurrentMonth: Boolean(r.is_current_month),
  }));
}

export const getCsoTerritoryMonths = unstable_cache(fetchCsoTerritoryMonths, ["cso-territory-v5"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/**
 * Territory capacity: the build side of the chain, plus the headcount each
 * territory is supposed to have. CSOs sell, customers pay, masons build — a
 * territory missing target because it has 10 masons instead of 15 is a
 * different problem from one whose masons are underproducing.
 * Keyed by territory x month; merged with the CSO rollup in the UI.
 */
export type TerritoryCapacity = {
  month: string;
  territory: string;
  district: string;
  manager: string | null;
  builds: number;
  buildTarget: number | null;
  pctBuildTarget: number | null;
  masons: number;
  minMasons: number | null;
  buildsPerMason: number | null;
  pctBuildProductivity: number | null;
  minCsos: number;
};

async function fetchTerritoryCapacity(): Promise<TerritoryCapacity[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT CAST(month AS STRING) AS month, territory, district, manager,
      builds_completed, build_target, pct_of_build_target,
      masons_active, min_masons, builds_per_mason, pct_build_productivity, min_csos
    FROM \`earth-enable-main.salesforce.territory_capacity_app_v1\`
    WHERE month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
  `);
  return rows.map((r) => ({
    month: String(r.month),
    territory: String(r.territory),
    district: String(r.district),
    manager: strOrNull(r.manager),
    builds: num(r.builds_completed),
    buildTarget: numOrNull(r.build_target),
    pctBuildTarget: numOrNull(r.pct_of_build_target),
    masons: num(r.masons_active),
    minMasons: numOrNull(r.min_masons),
    buildsPerMason: numOrNull(r.builds_per_mason),
    pctBuildProductivity: numOrNull(r.pct_build_productivity),
    minCsos: num(r.min_csos) || 5,
  }));
}

export const getTerritoryCapacity = unstable_cache(fetchTerritoryCapacity, ["territory-capacity-v4"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});

/**
 * Distinct CSO headcount at each level. Counted separately per level because a
 * CSO can cover more than one territory, so per-territory counts cannot be
 * summed without counting one person twice — which is exactly how the capacity
 * planning dashboard reports Bugesera as 10 when 9 people worked there.
 */
export type CsoHeadcount = {
  level: "territory" | "district" | "country";
  name: string;
  month: string;
  currentStaff: boolean;
  csos: number;
};

async function fetchCsoHeadcount(): Promise<CsoHeadcount[]> {
  const rows = await query<Record<string, unknown>>(`
    SELECT level, name, CAST(month AS STRING) AS month, current_staff, csos
    FROM \`earth-enable-main.salesforce.cso_headcount_app_v1\`
    WHERE month >= DATE '2026-01-01' AND month <= DATE_TRUNC(CURRENT_DATE(), MONTH)
  `);
  return rows.map((r) => ({
    level: String(r.level) as CsoHeadcount["level"],
    name: String(r.name),
    month: String(r.month),
    currentStaff: Boolean(r.current_staff),
    csos: num(r.csos),
  }));
}

export const getCsoHeadcount = unstable_cache(fetchCsoHeadcount, ["cso-headcount-v2"], {
  revalidate: REVALIDATE,
  tags: ["dashboard"],
});
