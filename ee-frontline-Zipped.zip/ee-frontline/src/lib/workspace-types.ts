/**
 * The rows the country workspaces read. Client-safe: types and small
 * constants only, no BigQuery. Every figure here was decided in SQL
 * (sql/capacity_week_v2.sql, sql/capacity_mason_week_v2.sql,
 * sql/cso_cash_daily_app_v1.sql, salesforce.customer_journey_app_v2 and the
 * CSO views). The pages pick rows and format them; they never recompute a
 * metric.
 */
import type { CapacityCountry } from "./capacity-ui";

export type WsLevel = "territory" | "district" | "manager" | "branch" | "country";
export type UnitLevel = "territory" | "district" | "branch";

/** One level x name for one period (a week set in a month, or a quarter). */
export type WsRow = {
  country: CapacityCountry;
  level: WsLevel;
  name: string;
  parent: string | null;
  manager: string | null;
  /** Rwanda: the sales managers' two-way split, named by compass region. Null elsewhere. */
  region: string | null;
  nTerritories: number;
  month: string;
  monthLabel: string;
  weekKey: string;
  nWeeks: number;
  isQuarter: boolean;
  isWholeMonth: boolean;
  periodLabel: string;
  periodStart: string;
  periodEnd: string;
  isComplete: boolean;
  hasTargets: boolean;
  currency: string;
  sold: number;
  /** Every sqme* figure is Floor plus Plaster only, the scored products. */
  sqmeSold: number;
  soldThenPaid: number;
  pctSoldThenPaid: number | null;
  collected: number;
  sqmeCollected: number;
  collectedToday: number;
  built: number;
  sqmeBuilt: number;
  /** Paint beside the scored figures: contracts (phase 1) and SQM-E. Never inside sqme*. */
  paintSold: number;
  paintSqmeSold: number;
  paintCollected: number;
  paintSqmeCollected: number;
  paintBuilt: number;
  paintSqmeBuilt: number;
  floorsBuilt: number;
  plastersBuilt: number;
  otherBuilt: number;
  buildsOnTime: number;
  buildsLate: number;
  pctOnTime: number | null;
  /** Contract value of the builds completed in the period. Never cash. */
  revenue: number;
  /** Payments received in the period, on any contract of the unit. */
  cashReceived: number;
  revenueTarget: number | null;
  pctRevenue: number | null;
  qaMeasured: number;
  qaPassed: number;
  pctQaPass: number | null;
  working: number;
  assigned: number;
  totalMasons: number;
  masonsBuilt: number;
  masonsPaid: number;
  masonsProductive: number;
  pctMasonsProductive: number | null;
  masonEarnings: number;
  earningsPerMason: number | null;
  weeklyThreshold: number;
  csosActive: number;
  minCsos: number | null;
  csosShort: number | null;
  csosUnitsShort: number;
  /** Contracts signed per active CSO, and the standard: sales target over the CSO requirement. */
  contractsPerCso: number | null;
  usualContractsPerCso: number | null;
  buildTarget: number | null;
  sqmeTarget: number | null;
  salesTarget: number | null;
  sqmeSalesTarget: number | null;
  minMasons: number | null;
  toHire: number | null;
  territoriesShort: number;
  pctBuild: number | null;
  pctSqme: number | null;
  pctSales: number | null;
  pctSqmeSales: number | null;
  pctColl: number | null;
  pctSqmeColl: number | null;
  buildsPerMason: number | null;
  usualBuildsPerMason: number | null;
  pctBuildProductivity: number | null;
  collectedNotBuilt: number;
  waitingPerMason: number | null;
  rank: number | null;
  rankPrev: number | null;
  rankMove: number | null;
};

export type WsData = {
  rows: WsRow[];
  /** When the function ran, as an ISO timestamp. */
  builtAt: string;
  /** When Salesforce last synced into BigQuery, epoch millis, or null. */
  syncedMs: number | null;
};

/** The four customer buckets of the Sales and collections page. */
export type JourneyBucket = "sold_not_paid" | "paid_not_started" | "building" | "finished";
export const JOURNEY_BUCKETS: { key: JourneyBucket; label: string }[] = [
  { key: "sold_not_paid", label: "Sold, not paid" },
  { key: "paid_not_started", label: "Paid, build not started" },
  { key: "building", label: "Build in progress" },
  { key: "finished", label: "Finished this period" },
];

/** A stock bucket for one level x name, as it stands now. */
export type JourneyStockRow = {
  level: UnitLevel | "country";
  name: string;
  bucket: "sold_not_paid" | "paid_not_started" | "building";
  n: number;
  sqme: number;
  owed: number;
  zeroPaid: number;
  /** Paid, materials not yet confirmed available. */
  waitingMaterials: number;
  medianDays: number;
  /** The longest wait in the bucket, in days. */
  oldestDays: number;
  over30: number;
  ageBands: [number, number, number, number];
  /** SQM-E this place completed over the last three whole months, and the bucket's SQM-E at that rate. */
  sqmeBuilt3m: number;
  monthsOfWork: number | null;
};

/** Jobs finished in one calendar week for one level x name. Summable across weeks. */
export type JourneyFinishedRow = {
  level: UnitLevel | "country";
  name: string;
  month: string;
  weekNo: number;
  n: number;
  sqme: number;
  floors: number;
  plasters: number;
  /** Days since completion: up to 30, 31 to 60, 61 to 90, over 90. */
  ageBands: [number, number, number, number];
};

export type JourneyStock = { stock: JourneyStockRow[]; finished: JourneyFinishedRow[] };

/** One customer in a bucket list. */
export type JourneyClient = {
  id: string;
  name: string;
  phone: string | null;
  cso: string | null;
  unit: string;
  product: string;
  sqme: number;
  pctPaid: number | null;
  cashPaid: number;
  totalAmount: number;
  outstanding: number;
  daysInStage: number;
  stage: string;
  materialsAvailable: boolean;
  signedDate: string | null;
  completedDate: string | null;
};

/**
 * One CSO in one month, normalised across the Rwanda and the Uganda & Kenya
 * views. `pctSold` and `pctCollected` are the country's scoring basis:
 * contracts in Rwanda, SQM-E in Uganda and Kenya (about 45% of their
 * contracts are follow-on phases). Both units are always carried.
 */
export type WsCsoMonth = {
  csoId: string;
  cso: string;
  phone: string | null;
  month: string;
  monthLabel: string;
  /** The territory (Rwanda) or branch (Uganda, Kenya) holding most of the month's work. */
  unit: string;
  /** Rwanda: the district. Uganda and Kenya: the branch again. */
  district: string;
  homeUnit: string | null;
  isAwayFromHome: boolean;
  manager: string | null;
  isRanked: boolean;
  scoreBasis: "contracts" | "sqme";
  sold: number;
  soldSqme: number;
  collected: number;
  collectedSqme: number;
  minSold: number | null;
  minSoldSqme: number | null;
  minCollected: number | null;
  minCollectedSqme: number | null;
  pctSold: number | null;
  pctCollected: number | null;
  hasTargets: boolean;
  daysAvailable: number;
  monthDays: number;
  isPartMonth: boolean;
  isNewCso: boolean;
  isActiveStaff: boolean;
  isUnverifiedStaff: boolean;
  isCurrentMonth: boolean;
};

export type WsCsoPending = {
  csoId: string;
  contracts: number;
  sqme: number;
  cash: number;
  oldestDays: number | null;
  over1y: number;
};

/** Money for one CSO: the chosen day, its week, and the period. */
export type WsCsoCash = {
  csoId: string;
  dayCash: number;
  weekCash: number;
  periodCash: number;
  dayCommission: number;
  periodCommission: number;
  periodRevenue: number;
  weeklyCashTarget: number | null;
};

/** One mason in one place over one period, from capacity_mason_week_v2. */
export type WsMason = {
  masonId: string;
  masonName: string;
  unit: string | null;
  unitParent: string | null;
  status: "Working" | "Assigned, not started";
  timesheets: number;
  builds: number;
  sqmeCompleted: number;
  /** Contract value of every phase completed in the period, local currency: the mason's share of Revenue. */
  revenue: number;
  buildsOnTime: number;
  buildsLate: number;
  pctOnTime: number | null;
  jobsInHand: number;
  sqmeInHand: number;
  weeklyRate: number | null;
  timeNeededWeeks: number | null;
  earnings: number;
  currency: string;
  weeklyThreshold: number;
  threshold: number;
  pctOfThreshold: number | null;
  isProductive: boolean;
  weeks: {
    weekStart: string;
    weekEnd: string;
    weekLabel: string;
    isComplete: boolean;
    isSelected: boolean;
    earnings: number;
    threshold: number;
    pctOfThreshold: number | null;
    isProductive: boolean;
  }[];
  qaMeasured: number;
  qaPassed: number;
  pctQaPass: number | null;
};
