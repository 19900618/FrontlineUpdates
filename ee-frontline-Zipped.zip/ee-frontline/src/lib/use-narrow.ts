"use client";

import { useEffect, useState } from "react";

/**
 * True on phone-width screens. Used where a media query is not enough because
 * the geometry itself has to change: an SVG viewBox scales its text down with
 * the drawing, so a chart sized for a laptop renders ~5px labels on a phone.
 * Starts false so the server and first client render agree.
 */
export function useNarrow(maxWidthPx = 640): boolean {
  const [narrow, setNarrow] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${maxWidthPx}px)`);
    const sync = () => setNarrow(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, [maxWidthPx]);
  return narrow;
}
