"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { PendingTask } from "@/lib/journey-pending";
import type { TerritoryBuild } from "@/lib/territory";
import { PENDING_CARDS, fmtInt, fmtSqme, type GroupStat } from "@/lib/format";
import { DataTable, type Col } from "./ws/primitives";
import Spinner from "./Spinner";

type Role = "tl" | "qa";
const PAGE = 25;
/** The three QA task types behind the pending cards, by Salesforce task subject. */
const TYPES = PENDING_CARDS.filter((c) => c.qaSubject).map((c) => ({ subject: c.qaSubject!, label: c.qaType ?? c.qaSubject! }));
const typeOf = (subject: string) => TYPES.find((t) => t.subject === subject)?.label ?? subject;

/**
 * The drawer a pending card opens: the same step from two sides. Territory
 * lead: the houses waiting for the evaluation, by the Territory Leads rule.
 * QA officer: the QA tasks still open for it, by the Individual QA rule. The
 * two are different sets on purpose (a waiting house usually has no task yet,
 * an old task is often on a house already evaluated), so each tab carries its
 * own count and its own filters. It slides in over the board rather than
 * replacing it, so the territory, search and scroll on the board are kept.
 */
export default function PendingDrawer({ country, cardKey, territory, dim, stat, onClose }: {
  country: string; cardKey: string; territory: string; dim: "territory" | "branch"; stat: GroupStat | undefined; onClose: () => void;
}) {
  const card = PENDING_CARDS.find((c) => c.key === cardKey)!;
  const [role, setRole] = useState<Role>("tl");
  const [tl, setTl] = useState<TerritoryBuild[] | null>(null);
  const [qa, setQa] = useState<PendingTask[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [unit, setUnit] = useState(territory);
  const [officer, setOfficer] = useState("");
  const [type, setType] = useState(card.qaSubject ?? "");

  // Each side is fetched once, when its tab is first opened.
  useEffect(() => {
    if ((role === "tl" && tl) || (role === "qa" && qa)) return;
    let live = true;
    const qs = new URLSearchParams({ country, card: cardKey, role });
    fetch(`/api/journey/pending?${qs}`)
      .then(async (r) => {
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? r.statusText);
        if (!live) return;
        if (role === "tl") setTl(j.rows as TerritoryBuild[]); else setQa(j.rows as PendingTask[]);
      })
      .catch((e) => { if (live) setError(e instanceof Error ? e.message : String(e)); });
    return () => { live = false; };
  }, [role, country, cardKey, tl, qa]);

  // Escape closes, as on every drawer.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const q = search.trim().toLowerCase();
  const hit = useCallback((...parts: (string | null | undefined)[]) => !q || parts.some((p) => (p ?? "").toLowerCase().includes(q)), [q]);

  const tlRows = useMemo(() => (tl ?? []).filter((r) => (!unit || r.territory === unit) && hit(r.job, r.customer, r.cso, r.mason)), [tl, unit, hit]);
  const qaRows = useMemo(() => {
    return (qa ?? []).filter((r) => (!unit || r.territory === unit) && (!officer || (r.officerId ?? "") === officer) && (!type || r.subject === type) && hit(r.house, r.customer, r.officer));
  }, [qa, unit, officer, type, hit]);
  // The QA list follows the board's territory or branch as the houses list does.
  const qaInUnit = useMemo(() => (qa ?? []).filter((r) => !unit || r.territory === unit), [qa, unit]);
  const typeCount = useMemo(() => qaInUnit.filter((r) => !type || r.subject === type).length, [qaInUnit, type]);

  const units = useMemo(() => [...new Set([...(tl ?? []).map((r) => r.territory), ...(qa ?? []).map((r) => r.territory), ...(unit ? [unit] : [])])].filter(Boolean).sort(), [tl, qa, unit]);
  const officers = useMemo(() => {
    const m = new Map<string, { name: string; n: number }>();
    for (const r of qaInUnit) { const k = r.officerId ?? ""; const cur = m.get(k) ?? { name: r.officer ?? "Nobody's name", n: 0 }; cur.n += 1; m.set(k, cur); }
    return [...m.entries()].sort((a, b) => b[1].n - a[1].n);
  }, [qaInUnit]);
  const stale = useMemo(() => qaInUnit.filter((r) => (!type || r.subject === type) && (r.houseEvaluated || !r.houseLive)).length, [qaInUnit, type]);

  const unitWord = dim === "branch" ? "Branch" : "Territory";
  const tlCols: Col<TerritoryBuild>[] = [
    { key: "house", header: "House", mobile: "title", sort: (r) => r.job, copy: (r) => r.job, cell: (r) => (
      <span className="block"><span className="font-medium" style={{ color: "var(--text-primary)" }}>{r.job}</span>
        {r.customer && <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{r.customer}</span>}</span>) },
    { key: "unit", header: unitWord, sort: (r) => r.territory, cell: (r) => r.territory },
    { key: "product", header: "Product", sort: (r) => r.product, cell: (r) => r.product ?? "-" },
    { key: "sqm", header: "SQM", right: true, sort: (r) => r.rawSqm, copy: (r) => (r.rawSqm == null ? "" : Math.round(r.rawSqm)), cell: (r) => (r.rawSqm == null ? "-" : <span className="tabular-nums">{fmtInt(Math.round(r.rawSqm))}</span>) },
    { key: "paid", header: "Paid", right: true, sort: (r) => r.pctPaid, copy: (r) => (r.pctPaid == null ? "" : Math.round(r.pctPaid * 100)), cell: (r) => (r.pctPaid == null ? "-" : `${Math.round(r.pctPaid * 100)}%`) },
    { key: "since", header: card.stepBefore, sort: (r) => r.waitingSince, cell: (r) => r.waitingSince ?? "-" },
    { key: "days", header: "Days waiting", right: true, sort: (r) => r.daysWaiting, cell: (r) => (
      <span style={{ color: (r.daysWaiting ?? 0) > 30 ? "var(--critical)" : "inherit", fontWeight: (r.daysWaiting ?? 0) > 30 ? 600 : 400 }}>{r.daysWaiting == null ? "-" : fmtInt(r.daysWaiting)}</span>) },
    { key: "cso", header: "CSO", sort: (r) => r.cso, cell: (r) => r.cso ?? "-" },
    { key: "mason", header: "Mason", sort: (r) => r.mason, cell: (r) => r.mason ?? "-" },
  ];
  const qaCols: Col<PendingTask>[] = [
    { key: "house", header: "House", mobile: "title", sort: (r) => r.house, copy: (r) => r.house, cell: (r) => (
      <span className="block"><span className="font-medium" style={{ color: "var(--text-primary)" }}>{r.house}</span>
        {r.customer && <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{r.customer}</span>}</span>) },
    { key: "unit", header: dim === "branch" ? "Branch" : "District", sort: (r) => r.unit, cell: (r) => r.unit ?? "-" },
    { key: "type", header: "Task type", sort: (r) => typeOf(r.subject), copy: (r) => typeOf(r.subject), cell: (r) => typeOf(r.subject) },
    { key: "sqm", header: "SQM", right: true, sort: (r) => r.rawSqm, copy: (r) => (r.rawSqm == null ? "" : Math.round(r.rawSqm)), cell: (r) => (r.rawSqm == null ? "-" : <span className="tabular-nums">{fmtInt(Math.round(r.rawSqm))}</span>) },
    { key: "officer", header: "QA officer", sort: (r) => r.officer, cell: (r) => r.officer ?? <span style={{ color: "var(--text-muted)" }}>nobody</span> },
    { key: "raised", header: "Raised", sort: (r) => r.createdOn, cell: (r) => r.createdOn ?? "-" },
    { key: "due", header: "Due", sort: (r) => r.dueOn, cell: (r) => r.dueOn ?? "-" },
    { key: "days", header: "Days pending", right: true, sort: (r) => r.daysPending, cell: (r) => (
      <span style={{ color: r.overdue ? "var(--critical)" : "inherit", fontWeight: r.overdue ? 600 : 400 }}>{fmtInt(r.daysPending)}{r.overdue ? " · overdue" : ""}</span>) },
    { key: "status", header: "Status", sort: (r) => r.status, cell: (r) => r.status },
  ];

  const loading = role === "tl" ? !tl : !qa;
  const rows = role === "tl" ? tlRows.length : qaRows.length;
  const total = role === "tl" ? (tl?.length ?? stat?.count ?? 0) : typeCount;

  return (
    <div className="fixed inset-0 z-40 flex justify-end" role="dialog" aria-modal="true" aria-label={card.label}>
      <button type="button" aria-label="Close" onClick={onClose} className="flex-1" style={{ background: "rgba(0,0,0,0.35)" }} />
      <aside className="flex h-full w-full max-w-4xl flex-col overflow-hidden shadow-2xl" style={{ background: "var(--page)" }}>
        <header className="flex items-start justify-between gap-3 border-b px-5 py-4" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
          <div className="min-w-0">
            <h2 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>{card.label}</h2>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              {country}{territory ? ` · ${territory}` : ""}{stat ? ` · ${fmtInt(stat.count)} houses, ${fmtSqme(stat.sqme)} SQM-E` : ""}
            </p>
          </div>
          <button type="button" onClick={onClose} className="rounded-md border px-2.5 py-1 text-sm" style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>Close</button>
        </header>

        {/* A stock movement has no QA task, so its drawer is the territory lead's list alone, without the role tabs. */}
        {card.qaSubject && (
        <div className="flex flex-wrap gap-1.5 border-b px-5 py-3" style={{ borderColor: "var(--border)" }}>
          <RoleTab on={role === "tl"} onClick={() => setRole("tl")} label="Territory lead" sub={`${fmtInt(tl?.length ?? stat?.count ?? 0)} houses waiting`} />
          <RoleTab on={role === "qa"} onClick={() => setRole("qa")} label="QA officer" sub={qa ? `${fmtInt(qaInUnit.filter((r) => r.subject === card.qaSubject).length)} ${card.qaType?.toLowerCase() ?? ""} tasks open` : "tasks open"} />
        </div>
        )}

        <div className="flex flex-wrap items-center gap-2 px-5 py-3">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={role === "tl" ? "Search house, customer, CSO, mason…" : "Search house, customer, officer…"}
            className="min-h-9 w-full rounded-md border px-3 py-1.5 text-sm sm:w-64" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
          {units.length > 1 && (
            <Pick label={unitWord} value={unit} onChange={setUnit} options={[["", `All ${unitWord.toLowerCase() === "branch" ? "branches" : "territories"}`], ...units.map((u) => [u, u] as [string, string])]} />
          )}
          {role === "qa" && officers.length > 0 && (
            <Pick label="QA officer" value={officer} onChange={setOfficer} options={[["", "Everyone"], ...officers.map(([id, o]) => [id, `${o.name} (${o.n})`] as [string, string])]} />
          )}
          {role === "qa" && <Pick label="Type" value={type} onChange={setType} options={[["", "All types"], ...TYPES.map((t) => [t.subject, `${t.label} (${fmtInt(qaInUnit.filter((r) => r.subject === t.subject).length)})`] as [string, string])]} />}
        </div>

        <div className="flex-1 overflow-y-auto px-5 pb-6">
          {error && <p className="text-sm" style={{ color: "var(--critical)" }}>Could not load: {error}</p>}
          {!error && loading && <p className="py-8 text-center text-sm" style={{ color: "var(--text-muted)" }}><Spinner label="Loading…" /></p>}
          {!error && !loading && role === "tl" && (
            <DataTable rows={tlRows} cols={tlCols} keyOf={(r) => r.opportunityId} pageSize={PAGE} copyName="houses waiting"
              empty="No house is waiting for this step."
              note={<Summary text={`${fmtInt(rows)} of ${fmtInt(total)} houses shown · ${fmtInt(tlRows.filter((r) => (r.daysWaiting ?? 0) > 30).length)} waiting over 30 days · oldest ${fmtInt(tlRows.reduce((m, r) => Math.max(m, r.daysWaiting ?? 0), 0))} days. Houses by the Territory Leads rule: the step before is done and this evaluation is not on record.`} />} />
          )}
          {!error && !loading && role === "qa" && (
            <DataTable rows={qaRows} cols={qaCols} keyOf={(r) => r.taskId} pageSize={PAGE} copyName="QA tasks"
              empty="No QA task of this type is open."
              note={<Summary text={`${fmtInt(rows)} of ${fmtInt(total)} tasks shown · ${fmtInt(qaRows.filter((r) => r.overdue).length)} overdue · ${fmtInt(stale)} of these open tasks sit on a house already evaluated or no longer live and can be closed. Open tasks marked Not Started or In Progress, whatever their age. Tasks marked Not Ready for Evaluation are left out.`} />} />
          )}
        </div>
      </aside>
    </div>
  );
}

function RoleTab({ on, onClick, label, sub }: { on: boolean; onClick: () => void; label: string; sub: string }) {
  return (
    <button type="button" onClick={onClick} aria-pressed={on} className="rounded-md border px-3 py-1.5 text-left"
      style={{ background: on ? "var(--accent-strong)" : "var(--surface)", borderColor: on ? "var(--accent-strong)" : "var(--border)", color: on ? "#fff" : "var(--text-secondary)" }}>
      <span className="block text-sm font-medium">{label}</span>
      <span className="block text-xs" style={{ opacity: 0.85 }}>{sub}</span>
    </button>
  );
}

function Pick({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: [string, string][] }) {
  return (
    <label className="flex items-center gap-1.5 text-sm" style={{ color: "var(--text-secondary)" }}>
      <span style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="min-h-9 rounded-md border px-2 py-1 text-sm"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
      </select>
    </label>
  );
}

function Summary({ text }: { text: string }) {
  return <p className="text-xs" style={{ color: "var(--text-muted)" }}>{text}</p>;
}
