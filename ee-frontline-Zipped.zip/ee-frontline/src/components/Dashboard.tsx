"use client";

import { useEffect, useMemo, useState } from "react";
import type { MatrixRow, ClientRow, Summary } from "@/lib/data";
import { BUCKETS, PENDING_CARDS, computeBucketStats, fmtInt, type GroupStat } from "@/lib/format";
import type { WaitingRow } from "@/lib/territory";
import Scorecards from "./Scorecards";
import PendingDrawer from "./PendingDrawer";
import Heatmap, { type StageCol } from "./Heatmap";
import StageBoard from "./StageBoard";
import ClientExport from "./ClientExport";
import Spinner from "./Spinner";

// Fixed country order for the filter: Rwanda, then Uganda, then Kenya.
const COUNTRY_ORDER = ["Rwanda", "Uganda", "Kenya"];
// Placeholder the queries emit for a record with no territory/branch. Never shown.
const UNASSIGNED = "Unassigned";

/**
 * The Journey board. On its own at /toolkit it carries a country dropdown and
 * a territory dropdown. Inside a country workspace the same component is
 * rendered `embedded`: the country is fixed, the territory comes from the
 * workspace's filter bar (`location`, `onLocation`), the page header is the
 * workspace's own, and a `bucket` can be opened from a link. Everything else,
 * the cards, the search, the toggles, the grid and the board, is the one
 * component.
 */
export default function Dashboard({
  matrix,
  summary,
  waiting = [],
  generatedAt,
  fixedCountry,
  location,
  onLocation,
  initialBucket,
  embedded = false,
}: {
  matrix: MatrixRow[];
  summary: Summary;
  /**
   * The Territory Leads waiting-for rows, every unit and reason, for the pending
   * cards. Every country's rows may be passed; the board keeps the one on screen.
   */
  waiting?: WaitingRow[];
  generatedAt: string;
  /** Inside a workspace: the country is chosen already, so the dropdown goes. */
  fixedCountry?: string;
  /** Inside a workspace: the territory or branch from the filter bar, "" for all. */
  location?: string;
  onLocation?: (name: string) => void;
  /** A bucket to open on arrival (a link from the capacity backlog). */
  initialBucket?: string | null;
  /** No page header: the workspace draws its own title and freshness line. */
  embedded?: boolean;
}) {
  // Rwanda → Uganda → Kenya; drop the "Unknown" country bucket entirely.
  const countries = useMemo(() => {
    const present = new Set(matrix.map((r) => r.country).filter((c) => c && c !== "Unknown"));
    const known = COUNTRY_ORDER.filter((c) => present.has(c));
    const extra = [...present].filter((c) => !COUNTRY_ORDER.includes(c)).sort();
    return [...known, ...extra];
  }, [matrix]);
  const [ownCountry, setCountry] = useState(countries.includes("Rwanda") ? "Rwanda" : countries[0] ?? "Rwanda");
  const country = fixedCountry ?? ownCountry;
  const [ownTerritory, setOwnTerritory] = useState("");
  // The workspace owns the territory when it passes one; otherwise the board's own dropdown does.
  const territory = onLocation ? (location ?? "") : ownTerritory;
  const setTerritory = (v: string) => { if (onLocation) onLocation(v); else setOwnTerritory(v); };
  const [search, setSearch] = useState("");
  const [selectedBucket, setSelectedBucket] = useState<string | null>(
    () => (initialBucket && BUCKETS.some((b) => b.key === initialBucket) ? initialBucket : null));
  // Which pending card's drawer is open, if any.
  const [pendingOpen, setPendingOpen] = useState<string | null>(null);
  const [showBacklog, setShowBacklog] = useState(false); // buckets 1 & 2 (pre-2026)
  const [showCompleted, setShowCompleted] = useState(() => initialBucket?.startsWith("8") ?? false); // bucket 8
  // What the heatmap counts: jobs on the board, or their size in SQM-E. The
  // scorecards always show both, so this only switches the grid below them.
  const [unit, setUnit] = useState<"jobs" | "sqme">("jobs");

  const [clients, setClients] = useState<ClientRow[]>([]);
  const [months, setMonths] = useState({ thisM: 0, lastM: 0 });
  const [loading, setLoading] = useState(false);

  // Rwanda drills by territory; Uganda/Kenya by branch (their territory is empty).
  const dim = country === "Rwanda" ? "territory" : "branch";
  // Records with no location are dropped from the picker (branch and territory alike).
  const locations = useMemo(
    () =>
      Array.from(
        new Set(
          matrix
            .filter((r) => r.country === country)
            .map((r) => (dim === "branch" ? r.branch : r.territory))
            .filter((loc) => loc !== UNASSIGNED),
        ),
      ).sort(),
    [matrix, country, dim],
  );

  // The pending cards: the country's waiting-for rows, narrowed to the territory
  // on screen, added up per card. A card that spans two reasons (varnish or
  // paint movement) adds both.
  const pendingStats = useMemo(() => {
    const out: Record<string, GroupStat> = {};
    const rows = waiting.filter((w) => w.country === country && (!territory || w.territory === territory));
    for (const card of PENDING_CARDS) {
      const mine = rows.filter((w) => card.reasons.includes(w.reason));
      out[card.key] = {
        count: mine.reduce((a, w) => a + w.count, 0),
        sqme: mine.reduce((a, w) => a + w.sqme, 0),
        rwf: 0, zeroPaid: 0, notFullyPaid: 0, median: 0,
        over30: mine.reduce((a, w) => a + w.over30, 0),
        oldest: mine.reduce((a, w) => Math.max(a, w.oldest), 0),
        ageBands: [0, 1, 2, 3].map((i) => mine.reduce((a, w) => a + w.ageBands[i], 0)),
      };
    }
    return out;
  }, [waiting, country, territory]);

  // bucket keys to show — backlog (1,2) and completed (8) are opt-in
  const visible = useMemo(
    () =>
      BUCKETS.filter((b) => {
        const n = b.key.charAt(0);
        if (n === "1" || n === "2") return showBacklog;
        if (n === "8") return showCompleted;
        return true;
      }).map((b) => b.key),
    [showBacklog, showCompleted],
  );

  useEffect(() => {
    if (!territory) {
      setClients([]);
      return;
    }
    let cancelled = false;
    setLoading(true);
    fetch(`/api/territory?country=${encodeURIComponent(country)}&dim=${dim}&name=${encodeURIComponent(territory)}`)
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        setClients(d.clients ?? []);
        setMonths({ thisM: d.completedThisMonth ?? 0, lastM: d.completedLastMonth ?? 0 });
      })
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [country, dim, territory]);

  const searched = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return clients;
    return clients.filter((c) =>
      `${c.opportunity_label ?? ""} ${c.customer_name ?? ""} ${c.phone ?? ""} ${c.cso_name ?? ""}`.toLowerCase().includes(q),
    );
  }, [clients, search]);

  // scorecard stats + month deltas (territory = live from clients; overview = summary)
  const { stats, completedThis, completedLast } = useMemo(() => {
    if (territory) {
      return { stats: computeBucketStats(searched), completedThis: months.thisM, completedLast: months.lastM };
    }
    const stats: Record<string, GroupStat> = {};
    for (const g of summary.groups.filter((x) => x.country === country)) {
      stats[g.bucket] = {
        count: g.count,
        sqme: g.sqme,
        rwf: g.rwf_outstanding,
        zeroPaid: g.zero_paid,
        notFullyPaid: g.not_fully_paid,
        median: g.median_days,
        over30: g.over30,
        oldest: g.oldest_days,
        ageBands: [g.age_0_30, g.age_31_60, g.age_61_90, g.age_90p],
      };
    }
    const m = summary.months.find((x) => x.country === country);
    return { stats, completedThis: m?.this_month ?? 0, completedLast: m?.last_month ?? 0 };
  }, [territory, searched, summary, country, months]);

  const backlogCount = (stats[BUCKETS[0].key]?.count ?? 0) + (stats[BUCKETS[1].key]?.count ?? 0);
  const completedKey = BUCKETS.find((b) => b.key.startsWith("8"))?.key ?? "";
  const completedCount = stats[completedKey]?.count ?? 0;

  const boardClients = useMemo(
    () => searched.filter((c) => visible.includes(c.app_bucket) && (!selectedBucket || c.app_bucket === selectedBucket)),
    [searched, visible, selectedBucket],
  );

  // overview heatmap from matrix (country-scoped), bucket columns
  const heat = useMemo(() => {
    const rows = matrix.filter(
      (r) =>
        r.country === country &&
        visible.includes(r.app_bucket) &&
        (!selectedBucket || r.app_bucket === selectedBucket) &&
        (dim === "branch" ? r.branch : r.territory) !== UNASSIGNED,
    );
    const counts = new Map<string, number>();
    const rowTotals = new Map<string, number>();
    const colTotals = new Map<string, number>();
    const present = new Set<string>();
    for (const r of rows) {
      const loc = dim === "branch" ? r.branch : r.territory;
      const v = unit === "sqme" ? r.sqme : r.n;
      present.add(r.app_bucket);
      counts.set(`${loc}|${r.app_bucket}`, (counts.get(`${loc}|${r.app_bucket}`) ?? 0) + v);
      rowTotals.set(loc, (rowTotals.get(loc) ?? 0) + v);
      colTotals.set(r.app_bucket, (colTotals.get(r.app_bucket) ?? 0) + v);
    }
    const stages: StageCol[] = BUCKETS.filter((b) => present.has(b.key)).map((b) => ({ bucket: b.key, label: b.label }));
    const terrRows = Array.from(rowTotals.keys()).sort((a, b) => (rowTotals.get(b) ?? 0) - (rowTotals.get(a) ?? 0));
    return { stages, counts, rowTotals, colTotals, terrRows };
  }, [matrix, country, dim, visible, selectedBucket, unit]);

  return (
    <div className={embedded ? "flex flex-col gap-4" : "mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6"}>
      <header className="flex flex-wrap items-end justify-between gap-2">
        {!embedded && (
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>Customer journey</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>{generatedAt}</p>
          </div>
        )}
        <div className="flex flex-wrap items-center gap-2">
          {!fixedCountry && <Select label="Country" value={country} options={countries} onChange={(v) => { setCountry(v); setTerritory(""); setSelectedBucket(null); }} />}
          {!onLocation && <Select label={dim === "branch" ? "Branch" : "Territory"} value={territory} options={["", ...locations]} optionLabel={(v) => (v === "" ? (dim === "branch" ? "All branches" : "All territories") : v)} onChange={(v) => { setTerritory(v); setSelectedBucket(null); }} />}
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, phone, CSO…" className="min-h-11 w-full rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-auto" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
          <Check label={`Show backlog (${fmtInt(backlogCount)})`} checked={showBacklog} onChange={() => setShowBacklog((v) => !v)} />
          <Check label={`Show completed (${fmtInt(completedCount)})`} checked={showCompleted} onChange={() => setShowCompleted((v) => !v)} />
        </div>
      </header>

      {/* "Started, not varnished" stays in the grid below as the funnel's own column, but
          as a card it is replaced by the four pending steps it was hiding. */}
      <Scorecards
        stats={stats}
        visible={visible.filter((k) => !k.startsWith("6"))}
        completedThisMonth={completedThis}
        completedLastMonth={completedLast}
        selected={selectedBucket}
        onSelect={(b) => setSelectedBucket((cur) => (cur === b ? null : b))}
        pending={pendingStats}
        onPending={setPendingOpen}
      />
      {pendingOpen && (
        <PendingDrawer key={`${pendingOpen}|${country}`} country={country} cardKey={pendingOpen} territory={territory}
          dim={dim} stat={pendingStats[pendingOpen]} onClose={() => setPendingOpen(null)} />
      )}

      {territory ? (
        loading ? (
          <p className="flex items-center justify-center py-12 text-sm" style={{ color: "var(--text-muted)" }}>
            <Spinner label={`Loading ${territory}…`} />
          </p>
        ) : (
          <div className="flex flex-col gap-3">
            <ClientExport clients={boardClients} country={country} location={territory} column={selectedBucket} />
            <StageBoard clients={boardClients} />
          </div>
        )
      ) : (
        <>
          <div className="flex items-center justify-end gap-2 text-sm" style={{ color: "var(--text-muted)" }}>
            <span>Grid shows</span>
            <UnitToggle value={unit} onChange={setUnit} />
          </div>
          <Heatmap territories={heat.terrRows} stages={heat.stages} counts={heat.counts} rowTotals={heat.rowTotals} colTotals={heat.colTotals} unit={unit} onSelect={setTerritory} />
          <p className="text-center text-sm" style={{ color: "var(--text-muted)" }}>Pick a {dim === "branch" ? "branch" : "territory"} (or click a row) to open its board.</p>
        </>
      )}
    </div>
  );
}

/** Jobs or SQM-E for the heatmap. Two buttons, so it reads without explanation. */
function UnitToggle({ value, onChange }: { value: "jobs" | "sqme"; onChange: (v: "jobs" | "sqme") => void }) {
  const opts: { key: "jobs" | "sqme"; label: string; title: string }[] = [
    { key: "jobs", label: "Jobs", title: "How many jobs sit in each column" },
    { key: "sqme", label: "SQM-E", title: "Their size in equivalent square metres: a floor counts its full area, plaster, paint and repairs a third" },
  ];
  return (
    <span className="flex overflow-hidden rounded-md border" style={{ borderColor: "var(--border)" }}>
      {opts.map((o) => (
        <button
          key={o.key}
          type="button"
          title={o.title}
          onClick={() => onChange(o.key)}
          className="px-2.5 py-1.5 text-sm"
          style={{
            background: value === o.key ? "var(--accent-strong)" : "var(--surface)",
            color: value === o.key ? "#fff" : "var(--text-secondary)",
          }}
        >
          {o.label}
        </button>
      ))}
    </span>
  );
}

function Check({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <button
      type="button"
      onClick={onChange}
      className="flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-sm"
      style={{ background: "var(--surface)", borderColor: checked ? "var(--accent-strong)" : "var(--border)", color: checked ? "var(--text-primary)" : "var(--text-secondary)" }}
    >
      <span
        className="grid h-4 w-4 place-items-center rounded text-[11px] font-bold leading-none"
        style={{ background: checked ? "var(--accent-strong)" : "transparent", border: checked ? "none" : "1px solid var(--border)", color: "#fff" }}
      >
        {checked ? "✓" : ""}
      </span>
      {label}
    </button>
  );
}

function Select({ label, value, options, onChange, optionLabel }: { label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string }) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => (
          <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>
        ))}
      </select>
    </label>
  );
}
