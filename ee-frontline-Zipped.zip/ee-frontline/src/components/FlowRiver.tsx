"use client";

import { fmtInt } from "@/lib/format";
import { useNarrow } from "@/lib/use-narrow";
import { MAIN_IDX, stepOf, type FlowPick, type FlowSummary, type MovePair } from "@/lib/journey-flow-shared";

type Props = {
  summary: FlowSummary;
  pick: FlowPick;
  onSelect: (to: number, from: number | null) => void;
  endLabel: string;
  before: string;
};

/**
 * The hero chart: the journey as a line of steps, with the period's movement drawn as
 * arrows between them. Arrow thickness follows how many customers moved; each box shows
 * how many were waiting at that step when the period ended. Customers who jumped a step
 * (most often starting the build before paying enough) arc over the top, and lost
 * contracts drop into a tray underneath. A Sankey was the starting idea, but the journey
 * is a straight line, so a free Sankey would be one thick ribbon; this keeps the line and
 * only draws the jumps. Phones and tablets get the same story as a vertical list.
 */
export default function FlowRiver(props: Props) {
  const narrow = useNarrow(900);
  return narrow ? <FlowList {...props} /> : <FlowSvg {...props} />;
}

const CHAIN: [number, number][] = [[1, 2], [2, 4], [4, 5], [5, 6]];
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

function delta(n: number, prev: number, lostStep = false): { text: string; color: string } {
  const d = n - prev;
  if (d === 0) return { text: n === 0 ? "" : "no change", color: "var(--text-muted)" };
  const up = d > 0;
  return { text: `${up ? "▲" : "▼"} ${fmtInt(Math.abs(d))}`, color: up !== lostStep ? "var(--good)" : "var(--critical)" };
}

const typical = (d: number | null) =>
  d == null ? "" : d === 0 ? "usually same day" : `usually ${fmtInt(d)} day${d === 1 ? "" : "s"}`;

function jumpText(from: number, to: number, n: number): string {
  if (from === 1 && to === 4) return `${fmtInt(n)} started before paying enough`;
  if (from === 4 && to === 6) return `${fmtInt(n)} completed with no delivery date`;
  if ((from === 2 || from === 3) && to === 5) return `${fmtInt(n)} delivered with no start date`;
  return `${fmtInt(n)} jumped from ${stepOf(from)?.short} to ${stepOf(to)?.short}`;
}

function tip(p: MovePair | undefined, n: number, what: string, before: string) {
  const days = p?.medianDays != null && n > 0 ? ` Usually ${p.medianDays} days after the step before.` : "";
  return `${fmtInt(n)} ${what}. ${cap(before)}: ${fmtInt(p?.prev ?? 0)}.${days} Click to list them.`;
}

// ---------------- desktop: SVG ----------------

const W = 1240, NW = 140, NH = 96, NY = 126, X0 = 100;
const GAP = (W - X0 - 5 * NW - 16) / 4;
const MID = NY + NH / 2;
const nodeX = (i: number) => X0 + i * (NW + GAP);

function FlowSvg({ summary, pick, onSelect, endLabel, before }: Props) {
  const pair = (to: number, from: number | null) => summary.pairs.find((p) => p.to === to && p.from === from);
  const total = (k: number) => summary.totals.find((t) => t.to === k);
  const waiting = (k: number) => summary.stock.find((s) => s.pos === k);

  const jumps = summary.pairs.filter(
    (p) => p.n > 0 && p.from != null && p.to !== 9 && p.to !== 3 && MAIN_IDX[p.to] - MAIN_IDX[p.from] >= 2,
  );
  const lost = summary.pairs.filter((p) => p.to === 9 && p.n > 0 && p.from != null);
  const matIn = pair(3, 2);
  const matOut = pair(4, 3);
  const showMat = (matIn?.n ?? 0) + (matOut?.n ?? 0) + (waiting(3)?.atEnd ?? 0) > 0;
  const entry = pair(1, null);

  const maxN = Math.max(
    1, entry?.n ?? 0, ...CHAIN.map(([f, t]) => pair(t, f)?.n ?? 0),
    ...jumps.map((j) => j.n), ...lost.map((l) => l.n), matIn?.n ?? 0, matOut?.n ?? 0,
  );
  const thick = (n: number) => (n > 0 ? 3 + 30 * Math.sqrt(n / maxN) : 0);
  const on = (to: number, from: number | null) => !pick || (pick.to === to && (pick.from == null || pick.from === from));
  const look = (active: boolean) => ({ opacity: active ? 1 : 0.16, transition: "opacity .15s", cursor: "pointer" });
  const keys = (to: number, from: number | null) => (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelect(to, from); }
  };

  /** A straight arrow along the main line, from x1 to x2. */
  const band = (id: string, x1: number, x2: number, p: MovePair | undefined, to: number, from: number | null, what: string) => {
    const n = p?.n ?? 0;
    const t = thick(n);
    const half = Math.max(t, 4) / 2;
    const cx = (x1 + x2) / 2;
    const d = delta(n, p?.prev ?? 0);
    const head = 13;
    const shape = `M${x1},${MID - t / 2} H${x2 - head} V${MID - t / 2 - 5} L${x2},${MID} L${x2 - head},${MID + t / 2 + 5} V${MID + t / 2} H${x1} Z`;
    return (
      <g key={id} role="button" tabIndex={0} aria-label={`${fmtInt(n)} ${what}`} onClick={() => onSelect(to, from)} onKeyDown={keys(to, from)} style={look(on(to, from))}>
        <title>{tip(p, n, what, before)}</title>
        <rect x={x1} y={MID - 44} width={x2 - x1} height={88} fill="transparent" />
        {n > 0 ? (
          <path d={shape} style={{ fill: stepOf(to)?.color, fillOpacity: 0.62 }} />
        ) : (
          <line x1={x1 + 4} x2={x2 - 4} y1={MID} y2={MID} style={{ stroke: "var(--text-muted)", strokeWidth: 1.5, strokeDasharray: "3 4" }} />
        )}
        <text x={cx} y={MID - half - 10} textAnchor="middle" style={{ fill: "var(--text-primary)", fontSize: 21, fontWeight: 650 }}>{fmtInt(n)}</text>
        <text x={cx} y={MID + half + 17} textAnchor="middle" style={{ fill: d.color, fontSize: 11.5, fontWeight: 500 }}>{d.text}</text>
        {p?.medianDays != null && n > 0 && (
          <text x={cx} y={MID + half + 31} textAnchor="middle" style={{ fill: "var(--text-muted)", fontSize: 11 }}>{typical(p.medianDays)}</text>
        )}
      </g>
    );
  };

  /** A box on the main line: who was waiting there when the period ended. */
  const node = (k: number, i: number) => {
    const s = stepOf(k)!;
    const x = nodeX(i);
    const w = waiting(k);
    const done = k === 6;
    const change = (w?.atEnd ?? 0) - (w?.atStart ?? 0);
    const picked = pick?.to === k && pick.from == null;
    return (
      <g key={`node${k}`} role="button" tabIndex={0} aria-label={s.name} onClick={() => onSelect(k, null)} onKeyDown={keys(k, null)}
        style={look(!pick || pick.to === k)}>
        <title>
          {done
            ? `${fmtInt(w?.atEnd ?? 0)} jobs completed by ${endLabel}. ${s.hint} Click to list this period's completions.`
            : `${fmtInt(w?.atEnd ?? 0)} customers were at "${s.name}" on ${endLabel} (${change >= 0 ? "+" : "−"}${fmtInt(Math.abs(change))} over the period). ${s.hint} Click to list who arrived in this period.`}
        </title>
        <rect x={x} y={NY} width={NW} height={NH} rx={10}
          style={{ fill: "var(--surface)", stroke: picked ? "var(--accent-strong)" : "rgba(26,22,19,.16)", strokeWidth: picked ? 2 : 1 }} />
        <rect x={x + 12} y={NY + 11} width={26} height={4} rx={2} style={{ fill: s.color }} />
        {s.lines.map((l, j) => (
          <text key={j} x={x + 12} y={NY + 32 + j * 15} style={{ fill: "var(--text-primary)", fontSize: 13, fontWeight: 600 }}>{l}</text>
        ))}
        <text x={x + 12} y={NY + 74} style={{ fill: "var(--text-primary)", fontSize: 22, fontWeight: 650 }}>{fmtInt(w?.atEnd ?? 0)}</text>
        {!done && change !== 0 && (
          <text x={x + NW - 12} y={NY + 74} textAnchor="end" style={{ fill: "var(--text-muted)", fontSize: 11 }}>
            {change > 0 ? "+" : "−"}{fmtInt(Math.abs(change))}
          </text>
        )}
        <text x={x + 12} y={NY + 89} style={{ fill: "var(--text-muted)", fontSize: 11 }}>
          {done ? `completed by ${endLabel}` : `waiting on ${endLabel}`}
        </text>
      </g>
    );
  };

  // The side step needs room under the line; without it the lost tray moves up.
  const H = showMat ? 392 : 328;
  const trayY = H - 40;
  const trayX1 = nodeX(1) + NW / 2 - 24;
  const trayX2 = nodeX(3) + NW / 2 + 24;
  const lostTotal = total(9);
  const lostDelta = delta(lostTotal?.n ?? 0, lostTotal?.prev ?? 0, true);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="group" aria-label="Customer journey flow for the period">
      {/* customers who jumped a step: arcs over the top */}
      {jumps.map((a) => {
        const i = MAIN_IDX[a.from!];
        const j = MAIN_IDX[a.to];
        const xa = nodeX(i) + NW * 0.72;
        const xb = nodeX(j) + NW * 0.28;
        const h = 46 + 26 * (j - i - 2) + (i % 2) * 18;
        const t = thick(a.n);
        const color = stepOf(a.to)?.color;
        const path = `M${xa},${NY} C${xa},${NY - h} ${xb},${NY - h} ${xb},${NY - 9}`;
        return (
          <g key={`jump${a.from}-${a.to}`} role="button" tabIndex={0} onClick={() => onSelect(a.to, a.from)} onKeyDown={keys(a.to, a.from)} style={look(on(a.to, a.from))}>
            <title>{tip(a, a.n, `customers went straight from "${stepOf(a.from)?.name}" to "${stepOf(a.to)?.name}"`, before)}</title>
            <path d={path} style={{ fill: "none", stroke: "transparent", strokeWidth: Math.max(t, 18) }} />
            <path d={path} style={{ fill: "none", stroke: color, strokeOpacity: 0.5, strokeWidth: t }} />
            <path d={`M${xb - 6},${NY - 11} L${xb},${NY - 1} L${xb + 6},${NY - 11} Z`} style={{ fill: color }} />
            <text x={(xa + xb) / 2} y={NY - 0.75 * h - t / 2 - 7} textAnchor="middle" style={{ fill: "var(--text-secondary)", fontSize: 12, fontWeight: 500 }}>
              {jumpText(a.from!, a.to, a.n)}
            </text>
          </g>
        );
      })}

      {/* new contracts, then the main line */}
      {band("entry", 8, X0, entry, 1, null, "contracts signed")}
      {CHAIN.map(([f, t]) => band(`b${f}-${t}`, nodeX(MAIN_IDX[f]) + NW, nodeX(MAIN_IDX[t]), pair(t, f), t, f,
        `customers moved from "${stepOf(f)?.name}" to "${stepOf(t)?.name}"`))}

      {/* materials ready: an optional side step between paid and started */}
      {showMat && (() => {
        const cx = (nodeX(1) + nodeX(2) + NW) / 2;
        const sw = 122, sh = 50, sy = NY + NH + 24;
        const xin = nodeX(1) + NW - 14;
        const xout = nodeX(2) + 14;
        const nIn = matIn?.n ?? 0, nOut = matOut?.n ?? 0;
        const pin = `M${xin},${NY + NH} C${xin},${sy + sh / 2} ${xin},${sy + sh / 2} ${cx - sw / 2},${sy + sh / 2}`;
        const pout = `M${cx + sw / 2},${sy + sh / 2} C${xout},${sy + sh / 2} ${xout},${sy + sh / 2} ${xout},${NY + NH}`;
        return (
          <g>
            <g role="button" tabIndex={0} onClick={() => onSelect(3, 2)} onKeyDown={keys(3, 2)} style={look(on(3, 2))}>
              <title>{tip(matIn, nIn, "paid customers had materials ready", before)}</title>
              <path d={pin} style={{ fill: "none", stroke: "transparent", strokeWidth: 16 }} />
              <path d={pin} style={{ fill: "none", stroke: stepOf(3)?.color, strokeOpacity: 0.6, strokeWidth: Math.max(2, thick(nIn)) }} />
              <text x={xin - 8} y={sy + 6} textAnchor="end" style={{ fill: "var(--text-secondary)", fontSize: 12, fontWeight: 600 }}>{fmtInt(nIn)}</text>
            </g>
            <g role="button" tabIndex={0} onClick={() => onSelect(4, 3)} onKeyDown={keys(4, 3)} style={look(on(4, 3))}>
              <title>{tip(matOut, nOut, "customers with materials ready started building", before)}</title>
              <path d={pout} style={{ fill: "none", stroke: "transparent", strokeWidth: 16 }} />
              <path d={pout} style={{ fill: "none", stroke: stepOf(4)?.color, strokeOpacity: 0.6, strokeWidth: Math.max(2, thick(nOut)) }} />
              <text x={xout + 8} y={sy + 6} style={{ fill: "var(--text-secondary)", fontSize: 12, fontWeight: 600 }}>{fmtInt(nOut)}</text>
            </g>
            <g role="button" tabIndex={0} onClick={() => onSelect(3, null)} onKeyDown={keys(3, null)} style={look(!pick || pick.to === 3)}>
              <title>{`${fmtInt(waiting(3)?.atEnd ?? 0)} paid customers had materials ready and were waiting to start on ${endLabel}.`}</title>
              <rect x={cx - sw / 2} y={sy} width={sw} height={sh} rx={8} style={{ fill: "var(--surface)", stroke: stepOf(3)?.color, strokeDasharray: "4 3" }} />
              <text x={cx} y={sy + 20} textAnchor="middle" style={{ fill: "var(--text-primary)", fontSize: 12, fontWeight: 600 }}>Materials ready</text>
              <text x={cx} y={sy + 37} textAnchor="middle" style={{ fill: "var(--text-muted)", fontSize: 11 }}>{fmtInt(waiting(3)?.atEnd ?? 0)} waiting</text>
            </g>
          </g>
        );
      })()}

      {/* lost contracts drop into the tray */}
      {lost.map((l) => {
        const xs = nodeX(MAIN_IDX[l.from!]) + NW / 2;
        const xt = Math.min(Math.max(xs, trayX1 + 26), trayX2 - 26);
        const path = `M${xs},${NY + NH} C${xs},${trayY - 30} ${xt},${NY + NH + 40} ${xt},${trayY}`;
        return (
          <g key={`lost${l.from}`} role="button" tabIndex={0} onClick={() => onSelect(9, l.from)} onKeyDown={keys(9, l.from)} style={look(on(9, l.from))}>
            <title>{tip(l, l.n, `customers were lost after "${stepOf(l.from)?.name}"`, before)}</title>
            <path d={path} style={{ fill: "none", stroke: "transparent", strokeWidth: 16 }} />
            <path d={path} style={{ fill: "none", stroke: "var(--critical)", strokeOpacity: 0.45, strokeWidth: Math.max(2, thick(l.n)) }} />
            <text x={xs + 8} y={NY + NH + 17} style={{ fill: "var(--critical)", fontSize: 11.5, fontWeight: 600 }}>{fmtInt(l.n)}</text>
          </g>
        );
      })}
      <g role="button" tabIndex={0} onClick={() => onSelect(9, null)} onKeyDown={keys(9, null)} style={look(!pick || pick.to === 9)}>
        <title>{`${fmtInt(lostTotal?.n ?? 0)} contracts marked Closed Lost in this period. ${cap(before)}: ${fmtInt(lostTotal?.prev ?? 0)}.`}</title>
        <rect x={trayX1} y={trayY} width={trayX2 - trayX1} height={30} rx={15}
          style={{ fill: "rgba(208,59,59,.07)", stroke: "rgba(208,59,59,.35)" }} />
        <text x={(trayX1 + trayX2) / 2} y={trayY + 20} textAnchor="middle" style={{ fontSize: 13 }}>
          <tspan style={{ fill: "var(--text-secondary)", fontWeight: 600 }}>Lost: {fmtInt(lostTotal?.n ?? 0)}</tspan>
          {lostDelta.text && <tspan dx={8} style={{ fill: lostDelta.color, fontSize: 11.5 }}>{lostDelta.text}</tspan>}
        </text>
      </g>

      {[1, 2, 4, 5, 6].map((k, i) => node(k, i))}
    </svg>
  );
}

// ---------------- phones and tablets: a vertical list ----------------

function FlowList({ summary, pick, onSelect, endLabel, before }: Props) {
  const waiting = (k: number) => summary.stock.find((s) => s.pos === k)?.atEnd ?? 0;
  const showMat = (summary.totals.find((t) => t.to === 3)?.n ?? 0) + waiting(3) > 0;
  const steps: [number, string][] = [
    [1, "contracts signed"],
    [2, "paid enough to build"],
    ...(showMat ? ([[3, "had materials ready"]] as [number, string][]) : []),
    [4, "builds started"],
    [5, "varnish or paint deliveries"],
    [6, "jobs completed"],
  ];
  return (
    <div className="flex flex-col">
      {steps.map(([k, what]) => (
        <div key={k} className="flex flex-col">
          <MoveRow k={k} what={what} summary={summary} pick={pick} onSelect={onSelect} before={before} />
          <WaitRow k={k} count={waiting(k)} endLabel={endLabel} />
        </div>
      ))}
      <MoveRow k={9} what="lost" summary={summary} pick={pick} onSelect={onSelect} before={before} />
    </div>
  );
}

function MoveRow({ k, what, summary, pick, onSelect, before }: {
  k: number;
  what: string;
  summary: FlowSummary;
  pick: FlowPick;
  onSelect: (to: number, from: number | null) => void;
  before: string;
}) {
  const s = stepOf(k)!;
  const t = summary.totals.find((x) => x.to === k);
  const n = t?.n ?? 0;
  const d = delta(n, t?.prev ?? 0, k === 9);
  const jumps = summary.pairs.filter((p) => p.to === k && p.n > 0 && p.from != null && k !== 9 && MAIN_IDX[k] - MAIN_IDX[p.from] >= 2);
  return (
    <button type="button" onClick={() => onSelect(k, null)}
      className="flex w-full items-stretch gap-3 py-2 pl-3 text-left" style={{ opacity: !pick || pick.to === k ? 1 : 0.35 }}>
      <span className="flex w-5 shrink-0 flex-col items-center">
        <span className="w-1.5 flex-1 rounded-full" style={{ background: s.color, opacity: n > 0 ? 0.6 : 0.2 }} />
        <span className="text-xs leading-none" style={{ color: s.color }}>▼</span>
      </span>
      <span className="flex flex-col gap-0.5">
        <span>
          <b className="text-xl tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(n)}</b>{" "}
          <span className="text-sm" style={{ color: "var(--text-secondary)" }}>{what}</span>
        </span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
          {d.text && <span style={{ color: d.color }}>{d.text} vs {before}</span>}
          {t?.medianDays != null && n > 0 && k !== 1 ? `${d.text ? " · " : ""}${typical(t.medianDays)}` : ""}
        </span>
        {jumps.map((p) => (
          <span key={p.from} className="text-xs" style={{ color: "var(--text-secondary)" }}>incl. {jumpText(p.from!, k, p.n)}</span>
        ))}
      </span>
    </button>
  );
}

function WaitRow({ k, count, endLabel }: { k: number; count: number; endLabel: string }) {
  const s = stepOf(k)!;
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2.5"
      style={{ borderColor: "var(--border)", borderLeft: `4px solid ${s.color}`, background: "var(--surface)" }}>
      <span className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{s.name}</span>
      <span className="text-right">
        <b className="text-lg tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(count)}</b>
        <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{k === 6 ? `completed by ${endLabel}` : `waiting on ${endLabel}`}</span>
      </span>
    </div>
  );
}
