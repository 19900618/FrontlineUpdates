"use client";

import Spinner from "./Spinner";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import type { CollRow } from "@/lib/collections";
import { fmtInt, telHref } from "@/lib/format";
import ExportButtons from "@/components/ExportButtons";
import { stamp, type Cell } from "@/lib/export";

const CURRENCY: Record<string, string> = { Rwanda: "RWF", Uganda: "UGX", Kenya: "KES" };
const ALL = "All";
// Placeholder for a record with no territory/branch. Never offered as a filter.
const UNASSIGNED = "Unassigned";

type Seg = "active" | "stalled" | "never";
function segOf(r: CollRow): Seg {
  if (r.cash <= 0) return "never";
  return r.days != null && r.days <= 90 ? "active" : "stalled";
}
const SEG_LABEL: Record<string, string> = { All: "All segments", active: "Active", stalled: "Stalled", never: "Never paid" };

function fmtK(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (a >= 1e3) return Math.round(n / 1e3) + "K";
  return String(Math.round(n));
}

function csvCell(v: string | number | null): string {
  const s = v == null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export type ListInitial = {
  country: string;
  product: "All" | "Floor" | "Plaster";
  seg: string;
  from: string;
  to: string;
  within: number;
  loc: string;
};

export default function CollectionsList({ initial }: { initial: ListInitial }) {
  const [country, setCountry] = useState(initial.country);
  const [product, setProduct] = useState(initial.product);
  const [seg, setSeg] = useState(initial.seg);
  const [from, setFrom] = useState(initial.from);
  const [to, setTo] = useState(initial.to);
  const [threshold, setThreshold] = useState(initial.within);
  const [location, setLocation] = useState(initial.loc);
  const [search, setSearch] = useState("");
  const [generatedAt, setGeneratedAt] = useState("");

  const [rows, setRows] = useState<CollRow[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => { setGeneratedAt(new Date().toLocaleString()); }, []);

  const ccy = CURRENCY[country] ?? "";
  const dim: "territory" | "branch" = country === "Rwanda" ? "territory" : "branch";
  const locOf = (r: CollRow) =>
    dim === "territory" ? (r.territory && r.territory.trim() ? r.territory : "Unassigned") : r.branch || "Unassigned";

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/collections?country=${encodeURIComponent(country)}`)
      .then((r) => r.json())
      .then((d) => { if (!cancelled) setRows(d.rows ?? []); })
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [country]);

  // Records with no location are dropped from the picker (branch and territory alike).
  const locations = useMemo(
    () => [ALL, ...Array.from(new Set(rows.map(locOf))).filter((l) => l !== UNASSIGNED).sort()],
    [rows, dim],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows
      .filter((r) => {
        if (from && r.signed && r.signed < from) return false;
        if (to && r.signed && r.signed > to) return false;
        if (product !== "All" && r.product !== product) return false;
        if (seg !== ALL && segOf(r) !== seg) return false;
        if (location !== ALL && locOf(r) !== location) return false;
        if (threshold > 0 && r.distance > threshold) return false;
        if (q && !`${r.customer ?? ""} ${r.phone ?? ""} ${r.cso ?? ""} ${r.village ?? ""}`.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => a.distance - b.distance);
  }, [rows, from, to, product, seg, location, threshold, search, dim]);

  const totSqme = filtered.reduce((s, r) => s + r.sqme, 0);
  const totCash = filtered.reduce((s, r) => s + r.distance, 0);

  const scope = [
    country,
    seg !== ALL ? SEG_LABEL[seg] : "All segments",
    product !== "All" ? product : "All products",
    location !== ALL ? location : `All ${dim === "territory" ? "territories" : "branches"}`,
    `Signed ${from || "start"} to ${to || "today"}`,
    threshold > 0 ? `within ${fmtK(threshold)} ${ccy} of milestone` : "any gap",
  ].join("  ·  ");

  /** One shape feeding both the CSV download and the Sheets paste. */
  const exportHeaders = ["Customer", "Phone", "Product", "SQM-E", dim === "territory" ? "Territory" : "Branch",
    "District", "Village", "Signed date", "% paid", `Cash paid (${ccy})`, `Total contract (${ccy})`,
    `Owe to milestone (${ccy})`, `Owe total (${ccy})`, "Days since last payment", "Segment", "CSO",
    "Called?", "Outcome", "Promise-to-pay date", "Notes"];

  const exportRows: Cell[][] = filtered.map((r) => [
    r.customer ?? "", r.phone ?? "", r.product, Math.round(r.sqme), r.territory || r.branch || "",
    r.district ?? "", r.village ?? "", r.signed ?? "",
    r.pct == null ? "" : `${Math.round(r.pct * 100)}%`,
    Math.round(r.cash), Math.round(r.total), Math.round(r.distance), Math.round(r.outstanding),
    r.days == null ? "" : r.days, SEG_LABEL[segOf(r)], r.cso ?? "", "", "", "", "",
  ]);

  const exportName = `follow-up_${[country, seg !== ALL ? seg : "", location !== ALL ? location : ""]
    .filter(Boolean).join("_").replace(/\s+/g, "-")}_${stamp()}`;

  return (
    <div className="mx-auto flex max-w-[85rem] flex-col gap-4 p-4 sm:p-6">
      {/* toolbar — screen only */}
      <div className="no-print flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <Link href="/toolkit/collections" className="text-sm hover:underline" style={{ color: "var(--accent-ink)" }}>← Collections backlog</Link>
          <ExportButtons filename={exportName} headers={exportHeaders} rows={exportRows} onPrint={() => window.print()} />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select label="Country" value={country} options={["Rwanda", "Uganda", "Kenya"]} onChange={(v) => { setCountry(v); setLocation(ALL); }} />
          <Select label={dim === "territory" ? "Territory" : "Branch"} value={location} options={locations} onChange={setLocation} />
          <Select label="Segment" value={seg} options={["All", "active", "stalled", "never"]} optionLabel={(o) => SEG_LABEL[o]} onChange={setSeg} />
          <Select label="Product" value={product} options={["All", "Floor", "Plaster"]} onChange={(v) => setProduct(v as typeof product)} />
          <label className="flex items-center gap-1.5 text-sm" style={{ color: "var(--text-secondary)" }}>
            <span style={{ color: "var(--text-muted)" }}>Signed</span>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="rounded-md border px-2 py-1.5 text-sm" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
            <span style={{ color: "var(--text-muted)" }}>to</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="rounded-md border px-2 py-1.5 text-sm" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
          </label>
          <label className="flex items-center gap-1.5 text-sm" style={{ color: "var(--text-secondary)" }}>
            <span style={{ color: "var(--text-muted)" }}>Max gap</span>
            <input type="number" value={threshold} min={0} step={1000} onChange={(e) => setThreshold(Math.max(0, Number(e.target.value) || 0))}
              className="w-24 rounded-md border px-2 py-1.5 text-right text-sm tabular-nums" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
            <span style={{ color: "var(--text-muted)" }}>{ccy} {threshold === 0 ? "(all)" : ""}</span>
          </label>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, phone, CSO, village…"
            className="min-h-11 w-full flex-1 rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-auto sm:min-w-48" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
        </div>
      </div>

      {/* report — printed / exported */}
      <div id="print-area" className="flex flex-col gap-3">
        <div>
          <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>Follow-up list{seg !== ALL ? ` · ${SEG_LABEL[seg]}` : ""}</h1>
          <p className="mt-0.5 text-sm" style={{ color: "var(--text-muted)" }}>{scope}</p>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            <b style={{ color: "var(--accent-ink)" }}>{fmtInt(filtered.length)}</b> customers · <b>{fmtInt(totSqme)}</b> SQM-E · collect <b>{fmtK(totCash)} {ccy}</b> to convert
            {generatedAt ? <span style={{ color: "var(--text-muted)" }}> · generated {generatedAt}</span> : null}
          </p>
        </div>

        {loading ? (
          <p className="flex items-center justify-center py-12 text-sm" style={{ color: "var(--text-muted)" }}>
            <Spinner label={`Loading ${country}…`} />
          </p>
        ) : filtered.length === 0 ? (
          <p className="py-12 text-center text-sm" style={{ color: "var(--text-muted)" }}>No customers match. Loosen the filters above.</p>
        ) : (
          <div className="hidden overflow-x-auto rounded-lg border md:block print:block" style={{ borderColor: "var(--border)" }}>
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: "var(--surface)", color: "var(--text-muted)" }}>
                  <Th>#</Th><Th>Customer</Th><Th>Phone</Th><Th>Product</Th><Th right>SQM-E</Th><Th>{dim === "territory" ? "Territory" : "Branch"}</Th>
                  <Th right>Paid</Th><Th right>Owe to milestone</Th><Th right>Owe total</Th>
                  <Th right>Last paid</Th><Th right>Signed</Th><Th>Segment</Th><Th>CSO</Th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 500).map((r, i) => (
                  <tr key={r.id} style={{ borderTop: "1px solid var(--border)" }}>
                    <Td><span style={{ color: "var(--text-muted)" }}>{i + 1}</span></Td>
                    <Td><span className="font-medium" style={{ color: "var(--text-primary)" }}>{r.customer ?? "-"}</span></Td>
                    <Td><span className="tabular-nums" style={{ color: "var(--text-secondary)" }}>{r.phone ?? "-"}</span></Td>
                    <Td>{r.product}</Td>
                    <Td right><span className="tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(Math.round(r.sqme))}</span></Td>
                    <Td><span style={{ color: "var(--text-secondary)" }}>{r.territory || r.branch}</span>{r.village ? <span style={{ color: "var(--text-muted)" }}> · {r.village}</span> : null}</Td>
                    <Td right>{r.pct == null ? "-" : `${Math.round(r.pct * 100)}%`}</Td>
                    <Td right><b className="tabular-nums" style={{ color: "var(--accent-ink)" }}>{fmtInt(r.distance)}</b></Td>
                    <Td right><span className="tabular-nums" style={{ color: "var(--text-secondary)" }}>{fmtInt(r.outstanding)}</span></Td>
                    <Td right><span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{r.days == null ? "-" : `${fmtInt(r.days)}d`}</span></Td>
                    <Td right><span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{r.signed || "-"}</span></Td>
                    <Td>{segChip(r)}</Td>
                    <Td><span style={{ color: "var(--text-muted)" }}>{r.cso ?? "-"}</span></Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Phones get a call-list card per customer: 13 columns is unusable at 390px,
            and this is the screen a CSO actually holds while phoning people. */}
        {!loading && filtered.length > 0 && (
          <div className="flex flex-col gap-2 md:hidden print:hidden">
            {filtered.slice(0, 500).map((r, i) => {
              const tel = telHref(r.phone);
              return (
                <div key={r.id} className="rounded-lg border p-3" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <span className="block truncate font-medium" style={{ color: "var(--text-primary)" }}>
                        {i + 1}. {r.customer ?? "-"}
                      </span>
                      <span className="block truncate text-xs" style={{ color: "var(--text-muted)" }}>
                        {r.territory || r.branch}{r.village ? ` · ${r.village}` : ""} · {r.product}
                      </span>
                    </div>
                    {segChip(r)}
                  </div>

                  <div className="mt-2 flex items-baseline gap-x-4 gap-y-1 text-sm">
                    <span>
                      <b className="tabular-nums" style={{ color: "var(--accent-ink)" }}>{fmtInt(r.distance)}</b>
                      <span className="text-xs" style={{ color: "var(--text-muted)" }}> {ccy} to milestone</span>
                    </span>
                    <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
                      {r.pct == null ? "-" : `${Math.round(r.pct * 100)}% paid`}
                    </span>
                    <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                      {fmtInt(Math.round(r.sqme))} SQM-E
                    </span>
                  </div>

                  <div className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
                    Signed {r.signed || "-"}
                    {r.days != null && ` · last paid ${fmtInt(r.days)}d ago`}
                    {r.cso && ` · ${r.cso}`}
                  </div>

                  {tel && (
                    <a href={tel}
                      className="mt-3 flex min-h-11 items-center justify-center rounded-md text-sm font-medium text-white"
                      style={{ background: "var(--accent-strong)" }}>
                      Call {r.phone}
                    </a>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {filtered.length > 500 && (
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>Table shows the closest 500 of {fmtInt(filtered.length)}. Both export options include all of them.</p>
        )}
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          Amounts in {ccy}. “Owe to milestone” is the amount required to reach the {country === "Rwanda" ? "50% floor / 100% plaster" : "50% floor / 75% plaster"} payment threshold. “Last paid” is days since the last payment.
        </p>
      </div>
    </div>
  );
}

function segChip(r: CollRow) {
  const s = segOf(r);
  const c = s === "active" ? "var(--good)" : s === "stalled" ? "var(--warning)" : "var(--text-muted)";
  return <span className="whitespace-nowrap rounded-full px-2 py-0.5 text-xs font-medium" style={{ background: `color-mix(in srgb, ${c} 18%, transparent)`, color: "var(--text-primary)" }}>{SEG_LABEL[s]}</span>;
}

function Th({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <th className={`px-3 py-2 font-medium ${right ? "text-right" : "text-left"}`}>{children}</th>;
}
function Td({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <td className={`px-3 py-2 ${right ? "text-right tabular-nums" : "text-left"}`}>{children}</td>;
}

function Select({ label, value, options, onChange, optionLabel }: { label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string }) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}
