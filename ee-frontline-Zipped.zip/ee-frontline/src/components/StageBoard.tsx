"use client";

import type { ClientRow } from "@/lib/data";
import { agingColor, BUCKETS, bucketColor, fmtInt, fmtPct, fmtSqme, telHref } from "@/lib/format";

export default function StageBoard({ clients }: { clients: ClientRow[] }) {
  // group by app_bucket
  const byBucket: Record<string, ClientRow[]> = {};
  for (const c of clients) {
    if (!c.app_bucket) continue;
    (byBucket[c.app_bucket] ??= []).push(c);
  }
  // columns in canonical bucket order, only those present
  const columns = BUCKETS.filter((b) => byBucket[b.key]?.length).map((b) => ({
    key: b.key,
    label: b.label,
    rows: [...byBucket[b.key]].sort((a, z) => z.days_in_stage - a.days_in_stage),
    sqme: byBucket[b.key].reduce((s, c) => s + (c.sqme ?? 0), 0),
  }));

  if (columns.length === 0) {
    return (
      <p className="py-12 text-center text-sm" style={{ color: "var(--text-muted)" }}>
        No clients match the current filters.
      </p>
    );
  }

  return (
    <div className="flex gap-3 overflow-x-auto pb-2">
      {columns.map((col) => {
        const color = bucketColor(col.key);
        return (
        <div
          key={col.key}
          className="flex w-72 shrink-0 flex-col overflow-hidden rounded-lg border"
          style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${color}` }}
        >
          <div
            className="border-b px-3 py-2.5"
            style={{ borderColor: "var(--border)", background: `color-mix(in srgb, ${color} 9%, var(--surface))` }}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="truncate text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
                {col.label}
              </span>
              <span
                className="shrink-0 rounded-full px-2 py-0.5 text-xs font-bold tabular-nums"
                style={{ background: `color-mix(in srgb, ${color} 22%, transparent)`, color: "var(--text-primary)" }}
              >
                {fmtInt(col.rows.length)}
              </span>
            </div>
            <div className="mt-0.5 text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>
              {fmtSqme(col.sqme)} SQM-E
            </div>
          </div>
          <div className="flex max-h-[32rem] flex-col gap-1.5 overflow-y-auto p-2">
            {col.rows.map((c) => (
              <Card key={c.opportunity_id} c={c} />
            ))}
          </div>
        </div>
        );
      })}
    </div>
  );
}

function Card({ c }: { c: ClientRow }) {
  const tel = telHref(c.phone);
  const color = agingColor(c.days_in_stage); // ≤30 green · 31–60 amber · 61–90 orange · >90 red
  const name = c.customer_name || c.opportunity_label || "Unknown";
  return (
    <div
      className="rounded-md border p-2"
      style={{ background: "var(--surface)", borderColor: "var(--border)", borderLeft: `3px solid ${color}` }}
    >
      <div className="flex items-start justify-between gap-2">
        <span className="min-w-0 truncate text-sm font-medium" style={{ color: "var(--text-primary)" }} title={name}>
          {name}
        </span>
        <span
          className="shrink-0 rounded px-1.5 py-0.5 text-xs font-semibold tabular-nums text-white"
          style={{ background: color }}
          title="days in stage"
        >
          {fmtInt(c.days_in_stage)}d
        </span>
      </div>
      {/* Numbers on one line, name of the CSO on the next: both stay readable in a 18rem column. */}
      <div className="mt-1 flex items-center gap-2 whitespace-nowrap text-xs" style={{ color: "var(--text-muted)" }}>
        <span className="tabular-nums">{fmtPct(c.pct_paid)} paid</span>
        <span className="tabular-nums" title={`${fmtInt(Math.round(c.raw_sqm))} m² on the contract`}>· {fmtSqme(c.sqme)} SQM-E</span>
        {tel && (
          <a href={tel} className="ml-auto shrink-0 font-medium hover:underline" style={{ color: "var(--accent-ink)" }}>
            ☎ Call
          </a>
        )}
      </div>
      {c.cso_name && (
        <div className="truncate text-xs" style={{ color: "var(--text-muted)" }} title={c.cso_name}>
          {c.cso_name}
        </div>
      )}
    </div>
  );
}
