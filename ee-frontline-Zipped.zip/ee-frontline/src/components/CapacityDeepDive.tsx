"use client";

import Spinner from "./Spinner";

import { useEffect, useMemo, useState } from "react";
import type { CapacityRow, CapacityTrendRow, MasonWeek, RosterLevel } from "@/lib/capacity";
import {
  currencyOf, dayMonth, dayRange, dayRangeShort, fmt1, fmtK, fmtWhole, niceCeil, pctText, perfColor, perfOf, unitWord, weekShort, SERIES_BUILDS, SERIES_COLL, SERIES_SALES,
} from "@/lib/capacity-ui";
import { fmtInt } from "@/lib/format";
import { useNarrow } from "@/lib/use-narrow";

/**
 * Four weeks: the two charts show exactly this many, and the roster shows the
 * weeks the picker has selected up to it. The focus cards keep their own
 * five-week sparkline, which is a different question.
 */
export const DEEP_DIVE_WEEKS = 4;

/**
 * One territory, district or branch, expanded in place beneath the row or
 * card that was tapped. Shows the two trends that put it on the list, the backlog that
 * says whether building or selling is the real problem, and the masons
 * themselves. Never a modal: field staff lose their place in overlays, which
 * is why the CSO page moved off them too.
 */
export default function CapacityDeepDive({
  row,
  window: win,
  onClose,
}: {
  row: CapacityRow;
  window: CapacityTrendRow[];
  onClose: () => void;
}) {
  const last = win[win.length - 1];
  const weekEnd = last?.weekEnd ?? row.weekEnd;
  const where = row.level === "territory"
    ? `${row.parent}${row.manager ? ` · manager ${row.manager}` : ""}`
    : row.level === "district" ? `${row.nTerritories} territories` : row.country;
  const canRoster = row.level === "territory" || row.level === "district" || row.level === "branch";
  const currency = currencyOf(row.country);

  return (
    <div className="border-l-2 p-5" style={{ background: "var(--page)", borderColor: "var(--accent-strong)" }}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{row.name}</h3>
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>
            {where} · {row.constraintReading}{row.diagnosis ? ` · ${row.diagnosis}` : ""}
          </p>
        </div>
        <button type="button" onClick={onClose} className="no-print rounded-md border px-2.5 py-1 text-sm"
          style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>
          Collapse
        </button>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Collected but not built" value={fmtInt(row.collectedNotBuilt)} tone={SERIES_COLL}
          sub={`Paid to the build gate in the last 12 months, no completed build, as at ${dayMonth(weekEnd)}. Work waiting for masons.`} />
        <Stat label="Masons working" value={fmtInt(row.working)} tone={SERIES_BUILDS}
          sub="Masons with at least one timesheet starting in the selected weeks." />
        <Stat label="Masons assigned" value={fmtInt(row.assigned)} tone={SERIES_BUILDS}
          sub={`Masons with a live job at ${dayMonth(weekEnd)} and no timesheet in the selected weeks.`} />
        <Stat label="Masons to hire" value={fmtWhole(row.toHire)} tone={SERIES_BUILDS}
          sub={row.level === "territory" || row.level === "branch"
            ? (row.minMasons == null ? "No requirement set for the month." : `Against the ${fmtWhole(row.minMasons)} masons this ${row.level} needs for the month, after the ${fmtInt(row.working)} working and ${fmtInt(row.assigned)} assigned.`)
            : `Each territory's own shortfall after its working and assigned masons, added up against the month's requirement. ${row.territoriesShort} of ${row.nTerritories} ${unitWord("territory", row.nTerritories)} are short.`} />
      </div>

      <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-2">
        <WeekChart title="Masons appearing on timesheet" axis="masons"
          points={win.map((t) => ({ label: weekShort(t), start: t.weekStart, end: t.weekEnd, value: t.masonsPaid, complete: t.isComplete }))}
          color={SERIES_BUILDS} format={(v) => fmtInt(Math.round(v))} />
        <WeekChart title="Earnings per mason" axis={`${currency} per mason`}
          points={win.map((t) => ({ label: weekShort(t), start: t.weekStart, end: t.weekEnd, value: t.earningsPerMason ?? 0, complete: t.isComplete }))}
          color={SERIES_SALES} format={fmtK} settling={settlingNote(win)} />
      </div>

      {canRoster && (
        <Roster key={`${row.level}|${row.name}|${weekEnd}`} level={row.level as RosterLevel} name={row.name}
          weeks={win} currency={currency} row={row} />
      )}

      <p className="mt-4 text-xs" style={{ color: "var(--text-muted)" }}>
        Earnings are approved gross pay, the same basis as the mason bonus. Trends run over the selected week and the three before it, crossing month ends.
      </p>
    </div>
  );
}

/** The stat tile idiom from the individual CSO page: label, big value, top rule in the series colour, muted line. */
function Stat({ label, value, sub, tone }: { label: string; value: string; sub: string; tone: string }) {
  return (
    <div className="rounded-md border p-3" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${tone}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 text-2xl font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{value}</div>
      <span className="mt-1 block text-xs" style={{ color: "var(--text-muted)" }}>{sub}</span>
    </div>
  );
}

/**
 * One series over the current week and the four before it. Same idiom as the
 * CSO history chart: area, line, dots, labelled axes, and a geometry switch on
 * phones so the labels stay readable. A hollow last dot means that week is
 * still in progress.
 */
function WeekChart({ title, axis, points, color, format, settling }: {
  title: string;
  axis: string;
  points: { label: string; start: string; end: string; value: number; complete: boolean }[];
  color: string;
  format: (v: number) => string;
  /** A line under the chart saying how settled the newest week's pay is. */
  settling?: string | null;
}) {
  const narrow = useNarrow();
  if (points.length < 2) return null;
  // Room under the plot for three lines: the week, its dates, and the axis name.
  const W = narrow ? 380 : 560, H = narrow ? 250 : 224;
  const padL = narrow ? 50 : 56, padR = 16, padT = 30, padB = narrow ? 66 : 60;
  const fs = narrow ? 13 : 10.5, fsSub = narrow ? 11 : 9.5;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const yMax = niceCeil(Math.max(...points.map((p) => p.value)) * 1.1);
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => t * yMax);
  const x = (i: number) => padL + (i * plotW) / (points.length - 1);
  const y = (v: number) => padT + plotH * (1 - v / yMax);
  const line = points.map((p, i) => `${i === 0 ? "M" : "L"}${x(i)},${y(p.value)}`).join("");
  const area = `${line}L${x(points.length - 1)},${padT + plotH}L${x(0)},${padT + plotH}Z`;
  const gid = `cap-${title.replace(/\W+/g, "-")}`;
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h4 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{title}</h4>
        <span className="flex items-center gap-1.5 text-xs" style={{ color: "var(--text-muted)" }}>
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />{axis} by week
        </span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="mt-1 w-full" style={{ maxHeight: narrow ? 260 : 236, overflow: "visible" }} role="img" aria-label={`${title}, ${axis} by week`}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.16" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <text x={padL - 8} y={padT - 10} textAnchor="end" fontSize={fs} fill="var(--text-muted)">{axis}</text>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeWidth="1" opacity={t === 0 ? 0.9 : 0.45} />
            <text x={padL - 8} y={y(t) + 4} textAnchor="end" fontSize={fs} fill="var(--text-muted)">{format(t)}</text>
          </g>
        ))}
        <path d={area} fill={`url(#${gid})`} />
        <path d={line} fill="none" stroke={color} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />
        {points.map((p, i) => (
          <g key={p.label}>
            <circle cx={x(i)} cy={y(p.value)} r={i === points.length - 1 ? 5 : 3.5}
              fill={p.complete ? color : "var(--surface)"} stroke={p.complete ? "var(--surface)" : color} strokeWidth="2">
              <title>{`${p.label}: ${format(p.value)}${p.complete ? "" : ", in progress"}`}</title>
            </circle>
            <text x={x(i)} y={y(p.value) - 10} textAnchor="middle" fontSize={fs} fontWeight={600} fill="var(--text-primary)">
              {format(p.value)}
            </text>
            <text x={x(i)} y={padT + plotH + 16} textAnchor="middle" fontSize={fs}
              fill={i === points.length - 1 ? "var(--text-primary)" : "var(--text-muted)"} fontWeight={i === points.length - 1 ? 600 : 400}>
              {p.label}{p.complete ? "" : "*"}
            </text>
            <text x={x(i)} y={padT + plotH + 16 + fsSub + 3} textAnchor="middle" fontSize={fsSub} fill="var(--text-muted)">
              ({narrow ? dayRangeShort(p.start, p.end) : dayRange(p.start, p.end)})
            </text>
          </g>
        ))}
        <text x={padL + plotW / 2} y={H - 4} textAnchor="middle" fontSize={fs} fill="var(--text-muted)">week</text>
      </svg>
      {!points[points.length - 1].complete && (
        <p className="text-[11px]" style={{ color: "var(--text-muted)" }}>* week in progress, shown but not compared.</p>
      )}
      {settling && <p className="text-[11px]" style={{ color: "var(--text-muted)" }}>{settling}</p>}
    </div>
  );
}

/**
 * Approved pay lands late, so the newest week always reads low until
 * approvals catch up. Say how far along it is, with the real rate, rather
 * than a generic warning. Older weeks are named only when one is still short.
 */
function settlingNote(win: CapacityTrendRow[]): string | null {
  const last = win[win.length - 1];
  if (!last || last.approvalRate == null) return null;
  const earlier = win.slice(0, -1).map((t) => t.approvalRate).filter((v): v is number => v != null);
  const lowEarlier = earlier.length ? Math.min(...earlier) : null;
  const latest = `${weekShort(last)} is still settling: ${pctText(last.approvalRate)} of its timesheets are approved so far.`;
  return lowEarlier == null ? latest
    : `${latest} Earlier weeks ${lowEarlier >= 0.995 ? "are fully approved" : `are ${pctText(lowEarlier)} to 100% approved`}.`;
}

type RosterLine = { id: string; name: string; byWeek: Map<string, MasonWeek>; earnings: number; builds: number };

/**
 * One row per mason with a five-window form guide, the same pills as the
 * individual CSO page: each pill is that week's approved pay against the
 * productive bar, the current window outlined. Green met it, amber came within
 * 20%, red fell short, grey means no approved pay that week. The bar itself
 * comes from the view. Fetched when the deep dive opens. The parent keys this
 * on place and week end, so a new selection mounts a fresh roster in its
 * loading state instead of resetting state in an effect.
 *
 * Two windows, on purpose. The form guide and Approved pay always cover the
 * four weeks up to the last one selected, so a mason's recent record reads the
 * same however the picker is set. Builds and Target cover only the weeks
 * selected, so they answer "how is this week going" and move together: one
 * week selected is one week of builds against a target of 1. Both windows end
 * at the same week and roll across month ends. Target is the view's own
 * `usual_builds_per_mason`, the month's standard per mason scaled to the weeks
 * selected; the standard comes from the target tables, never a number typed
 * here.
 */
function Roster({ level, name, weeks, currency, row }: {
  level: RosterLevel; name: string; weeks: CapacityTrendRow[]; currency: string; row: CapacityRow;
}) {
  const weekEnd = weeks[weeks.length - 1]?.weekEnd;
  // Pay and the form guide: the whole window. Builds and Target: the weeks selected.
  const buildWeeks = useMemo(() => weeks.slice(-Math.min(row.nWeeks, weeks.length)), [weeks, row.nWeeks]);
  const [rows, setRows] = useState<MasonWeek[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!weekEnd) return;
    let live = true;
    fetch(`/api/capacity/roster?level=${level}&name=${encodeURIComponent(name)}&weekEnd=${weekEnd}`)
      .then(async (r) => {
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? r.statusText);
        if (live) setRows(j.rows as MasonWeek[]);
      })
      .catch((e) => { if (live) setError(e instanceof Error ? e.message : String(e)); });
    return () => { live = false; };
  }, [level, name, weekEnd]);

  const lines = useMemo<RosterLine[]>(() => {
    if (!rows) return [];
    const payKeys = new Set(weeks.map((w) => w.weekStart));
    const buildKeys = new Set(buildWeeks.map((w) => w.weekStart));
    const by = new Map<string, RosterLine>();
    for (const r of rows) {
      if (!payKeys.has(r.weekStart)) continue;
      const l = by.get(r.masonId) ?? { id: r.masonId, name: r.masonName, byWeek: new Map(), earnings: 0, builds: 0 };
      l.byWeek.set(r.weekStart, r);
      l.earnings += r.earnings;
      if (buildKeys.has(r.weekStart)) l.builds += r.builds;
      by.set(r.masonId, l);
    }
    return Array.from(by.values()).sort((a, b) => b.earnings - a.earnings || a.name.localeCompare(b.name));
  }, [rows, weeks, buildWeeks]);

  const weekly = rows?.[0]?.weeklyThreshold;
  const span = weeks.length === 1 ? "this week" : `the last ${weeks.length} weeks`;
  const buildSpan = buildWeeks.length === 1 ? "this week" : `the last ${buildWeeks.length} weeks`;
  // The month's standard per mason over the weeks selected, rescaled only if the window is short of history.
  const buildTarget = row.usualBuildsPerMason == null || row.nWeeks === 0
    ? null
    : (row.usualBuildsPerMason / row.nWeeks) * buildWeeks.length;

  return (
    <div className="mt-5 rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 border-b p-4" style={{ borderColor: "var(--border)" }}>
        <h4 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
          Mason roster{rows ? ` · ${lines.length} masons` : ""}
        </h4>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
          {`${weeks.length === 1 ? "This week" : `Last ${weeks.length} weeks`}, oldest on the left, current window outlined. Each pill is that week's approved pay against the productive bar`}
          {weekly ? `, ${fmtInt(weekly)} ${currency} for each Wednesday in the week` : ""}. A dot means no approved pay that week. Hover a pill for its dates.
        </span>
      </div>
      {error && <p className="p-4 text-sm" style={{ color: "var(--critical)" }}>Could not load the roster: {error}</p>}
      {!rows && !error && (
        <p className="p-4 text-sm" style={{ color: "var(--text-muted)" }}><Spinner label="Loading masons…" /></p>
      )}
      {rows && lines.length === 0 && <p className="p-4 text-sm" style={{ color: "var(--text-muted)" }}>No mason had a timesheet, approved pay or a build here in {weeks.length === 1 ? "this week" : "these weeks"}.</p>}
      {lines.length > 0 && (
        <table className="w-full text-sm">
          <thead className="hidden sm:table-header-group">
            <tr style={{ color: "var(--text-muted)", borderBottom: "1px solid var(--border)" }}>
              <th className="px-3 py-2 text-left text-xs font-medium">Mason</th>
              <th className="px-3 py-2 text-right text-xs font-medium">
                <span className="block">Target</span>
                <span className="block font-normal" style={{ color: "var(--text-muted)" }}>{`(builds, ${buildSpan})`}</span>
              </th>
              <th className="px-3 py-2 text-right text-xs font-medium">
                <span className="block">Builds</span>
                <span className="block font-normal" style={{ color: "var(--text-muted)" }}>{`(total, ${buildSpan})`}</span>
              </th>
              <th className="px-3 py-2 text-left text-xs font-medium">{`Productive, ${span}`}</th>
              <th className="px-3 py-2 text-right text-xs font-medium">
                <span className="block">Approved pay</span>
                <span className="block font-normal" style={{ color: "var(--text-muted)" }}>{`(total, ${span})`}</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => (
              <tr key={l.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2 sm:table-row sm:p-0"
                style={{ borderTop: "1px solid var(--border)", color: "var(--text-secondary)" }}>
                <td className="basis-full font-medium sm:basis-auto sm:px-3 sm:py-2" style={{ color: "var(--text-primary)" }}>{l.name}</td>
                <td className="text-xs tabular-nums sm:px-3 sm:py-2 sm:text-right sm:text-sm" style={{ color: "var(--text-muted)" }}>
                  {buildTarget == null ? "-" : fmt1(buildTarget)}<span className="sm:hidden">{" target"}</span>
                </td>
                <td className="text-xs tabular-nums sm:px-3 sm:py-2 sm:text-right sm:text-sm">
                  {l.builds} {l.builds === 1 ? "build" : "builds"}<span className="sm:hidden">{` ${buildSpan}`}</span>
                </td>
                <td className="sm:px-3 sm:py-2">
                  <span className="flex items-center gap-1">
                    {weeks.map((w, i) => {
                      const m = l.byWeek.get(w.weekStart);
                      const score = m && m.earnings > 0 ? m.pctOfThreshold : null;
                      const res = perfOf(score);
                      return (
                        <span key={w.weekStart}
                          // The days a pill covers live in the tooltip, so the block stays light.
                          title={`${w.weekLabel}: ${m && m.earnings > 0 ? `${fmtK(m.earnings)} ${currency} of ${fmtK(m.threshold)}` : "no approved pay"}`}
                          className="grid h-5 min-w-9 place-items-center rounded px-1 text-[11px] font-semibold tabular-nums"
                          style={{
                            background: perfColor(score),
                            color: res === "none" ? "var(--text-muted)" : "#fff",
                            // The current window is the one that matters most.
                            outline: i === weeks.length - 1 ? "2px solid var(--text-primary)" : "none",
                            outlineOffset: "1px",
                          }}>
                          {score == null ? "·" : pctText(score)}
                        </span>
                      );
                    })}
                  </span>
                </td>
                <td className="text-xs tabular-nums sm:px-3 sm:py-2 sm:text-right sm:text-sm">
                  {fmtK(l.earnings)} {currency}<span className="sm:hidden">{` ${span}`}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
