"use client";

import type { CapacityRow, CapacityTrendRow } from "@/lib/capacity";
import { fmtK, fmtWhole, pctText, trendWindow, unitWord, SERIES_BUILDS, SERIES_COLL, SERIES_SALES, type UnitLevel } from "@/lib/capacity-ui";
import CapacityDeepDive, { DEEP_DIVE_WEEKS } from "@/components/CapacityDeepDive";
import type { OpenKey } from "@/components/CapacityBoard";

const CARDS_PER_MANAGER = 4;

/**
 * The answer band. For each manager (for the whole country where there are
 * no managers), the units furthest behind their SQM-E target over the last
 * four complete weeks, largest gap first, at most four, never padded. A
 * country with three branches shows all three, ranked. The view decides who
 * is in focus; this ranks and draws.
 * Each card carries one set of bars, one trend and one sentence, on a fixed
 * set of rows so four cards read as a set. Tapping a card opens the deep dive
 * beneath the row of cards.
 */
export default function CapacityCards({
  rows,
  unit,
  currency,
  trend,
  lastWeekStart,
  byManager,
  open,
  onOpen,
  onClose,
}: {
  rows: CapacityRow[];
  /** The country's unit of management: territory or branch. */
  unit: UnitLevel;
  currency: string;
  trend: CapacityTrendRow[];
  lastWeekStart: string;
  byManager: boolean;
  open: OpenKey | null;
  onOpen: (name: string) => void;
  onClose: () => void;
}) {
  const groups = new Map<string, CapacityRow[]>();
  for (const r of rows) {
    const k = byManager ? r.manager ?? "Unassigned" : rows[0]?.manager ?? "";
    (groups.get(k) ?? groups.set(k, []).get(k)!).push(r);
  }

  return (
    <>
      {Array.from(groups.entries()).sort(([a], [b]) => a.localeCompare(b)).map(([manager, rs]) => {
        const top = rs.filter((r) => r.isFocus).sort((a, b) => (b.sqmeGap4w ?? 0) - (a.sqmeGap4w ?? 0)).slice(0, CARDS_PER_MANAGER);
        const openRow = open?.from === "cards" && open.level === unit ? top.find((r) => r.name === open.name) : undefined;
        const watch = rs.filter((r) => !r.isFocus && (r.trigMasons || r.trigEarnings)).sort((a, b) => a.name.localeCompare(b.name));
        return (
          <section key={manager || "all"} className="rounded-lg border p-5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
            <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
                {manager ? `${manager} · ` : ""}{rs.length} {unitWord(unit, rs.length)} · furthest behind target
              </h2>
              <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                Showing {top.length} of {rs.filter((r) => r.isFocus).length} in focus · ranked by SQM-E behind target over the last 4 complete weeks
              </span>
            </div>
            <p className="mt-0.5 text-xs" style={{ color: "var(--text-muted)" }}>
              Each bar is the last four weeks against that target. Tap a card for the deep dive.
            </p>
            {top.length === 0 ? (
              <p className="mt-4 text-sm" style={{ color: "var(--text-muted)" }}>
                No {unit} here is behind its SQM-E target over the last four complete weeks.
              </p>
            ) : (
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
                {top.map((r) => (
                  <Card key={r.name} row={r} spark={trendWindow(trend, unit, r.name, lastWeekStart)}
                    open={openRow?.name === r.name} onOpen={() => onOpen(r.name)} />
                ))}
              </div>
            )}
            {openRow && (
              <div className="mt-3 overflow-hidden rounded-lg border" style={{ borderColor: "var(--border)" }}>
                <CapacityDeepDive row={openRow} window={trendWindow(trend, unit, openRow.name, lastWeekStart, DEEP_DIVE_WEEKS)} onClose={onClose} />
              </div>
            )}
            {watch.length > 0 && (
              <p className="mt-4 text-sm" style={{ color: "var(--text-secondary)" }}>
                Also worth watching: {watch.map((r) => watchPhrase(r, currency)).join("; ")}.
              </p>
            )}
          </section>
        );
      })}
    </>
  );
}

/** Real numbers, four weeks against the four before. The 20% rule stays in the view. */
function watchPhrase(r: CapacityRow, currency: string): string {
  const parts: string[] = [];
  if (r.trigMasons) parts.push(`masons down from ${fmtWhole(r.masonsPrev4w)} to ${fmtWhole(r.masons4w)}`);
  if (r.trigEarnings) parts.push(`earnings per mason down from ${fmtK(r.epmPrev4w)} to ${fmtK(r.epm4w)} ${currency}`);
  return `${r.name}, ${parts.join(" and ")}`;
}

/** The takeaway is the point of the card, so it takes the status colour of the weakest link. */
function takeawayColor(r: CapacityRow): string {
  const worst = [r.pctSqme4w, r.pctSales4w, r.pctColl4w].filter((v): v is number => v != null)
    .reduce<number | null>((lo, v) => (lo == null ? v : Math.min(lo, v)), null);
  if (worst == null || worst >= 1) return "var(--text-muted)";
  return worst < 0.7 ? "var(--critical)" : "var(--warning)";
}

function Card({ row: r, spark, open, onOpen }: { row: CapacityRow; spark: CapacityTrendRow[]; open: boolean; onOpen: () => void }) {
  const lastIncomplete = spark.length > 0 && !spark[spark.length - 1].isComplete;
  const masons = spark.map((t) => t.working);
  const pillColor = r.isNewFocus ? "var(--accent-strong)" : "var(--text-muted)";
  return (
    <button type="button" onClick={onOpen} aria-expanded={open}
      className="grid grid-rows-[auto_auto_auto_1fr] gap-3 rounded-lg border p-4 text-left"
      style={{
        background: "var(--surface)",
        borderColor: open ? "var(--accent-strong)" : "var(--border)",
        boxShadow: open ? "0 0 0 1px var(--accent-strong)" : "none",
      }}>
      {/* Row 1: name on one line, standing pill, and a line that is always reserved for the recovery figure. */}
      <div>
        <div className="flex items-start justify-between gap-2">
          <span className="min-w-0 truncate text-sm font-semibold leading-tight" style={{ color: "var(--text-primary)" }} title={r.name}>{r.name}</span>
          <span className="shrink-0 rounded px-1.5 py-0.5 text-[11px] font-semibold"
            style={{ background: `color-mix(in srgb, ${pillColor} 16%, transparent)`, color: "var(--text-primary)" }}>
            {r.isNewFocus ? "New this week" : `On focus ${r.focusWeeks} weeks`}
          </span>
        </div>
        <div className="flex items-baseline justify-between gap-2 text-xs" style={{ color: "var(--text-muted)" }}>
          <span className="truncate">{r.parent}</span>
          <span className="min-h-4 shrink-0 tabular-nums">
            {r.focusWeeks >= 2 && r.sqmeGapPrev4w != null ? `was ${fmtWhole(r.sqmeGapPrev4w)} behind, now ${fmtWhole(r.sqmeGap4w)}` : ""}
          </span>
        </div>
      </div>

      {/* Row 2: the three bars on one scale. Actual numbers under Built only. */}
      <div className="flex flex-col gap-1.5">
        <MiniBar label="Built" pct={r.pctSqme4w} tone={SERIES_BUILDS} />
        <div className="pl-[5.5rem] text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>
          {fmtWhole(r.sqmeBuilt4w)} of {fmtWhole(r.sqmeTarget4w)} SQM-E
        </div>
        <MiniBar label="Sold" pct={r.pctSales4w} tone={SERIES_SALES} />
        <MiniBar label="Collected" pct={r.pctColl4w} tone={SERIES_COLL} />
      </div>

      {/* Row 3: one mason sparkline, end values only. */}
      <div className="flex items-center gap-2">
        <span className="w-20 shrink-0 text-xs" style={{ color: "var(--text-muted)" }}>Masons</span>
        <Spark values={masons} hollowLast={lastIncomplete} />
        <span className="text-xs font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>
          {masons.length > 1 ? `${masons[0]} → ${masons[masons.length - 1]}` : masons[0] ?? "-"}
          {masons.length > 1 && <span className="font-normal" style={{ color: "var(--text-muted)" }}>{` (over ${masons.length} weeks)`}</span>}
        </span>
      </div>

      {/* Row 4: the takeaway, one line naming the constraint. */}
      <p className="self-end text-xs font-medium leading-snug" style={{ color: takeawayColor(r) }}>{r.takeaway}</p>
    </button>
  );
}

/** The same MiniBar as the CSO overview, which does not export it. */
function MiniBar({ label, pct, tone }: { label: string; pct: number | null; tone: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-20 shrink-0 text-xs" style={{ color: "var(--text-muted)" }}>{label}</span>
      <span className="h-2 flex-1 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: tone }} />
      </span>
      <span className="w-10 shrink-0 text-right text-xs font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</span>
    </div>
  );
}

/** Five points, no axes: two end values and the shape between them. Hollow last point when that week is in progress. */
function Spark({ values, hollowLast }: { values: number[]; hollowLast: boolean }) {
  const W = 88, H = 26, pad = 3;
  if (values.length < 2) return <div className="h-[26px] flex-1" />;
  const max = Math.max(1, ...values);
  const x = (i: number) => pad + (i * (W - 2 * pad)) / (values.length - 1);
  const y = (v: number) => H - pad - (v / max) * (H - 2 * pad);
  const d = values.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  const last = values.length - 1;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-[26px] w-[88px] shrink-0" aria-hidden>
      <path d={d} fill="none" stroke={SERIES_BUILDS} strokeWidth="1.75" strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={x(last)} cy={y(values[last])} r="2.6" fill={hollowLast ? "var(--surface)" : SERIES_BUILDS} stroke={SERIES_BUILDS} strokeWidth="1.5" />
    </svg>
  );
}
