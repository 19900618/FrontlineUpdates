"use client";

import { Fragment, useMemo, useState } from "react";
import Link from "next/link";
import type { CsoMonth, CsoPending } from "@/lib/cso";
import { band, BAND_COLOR, BAND_LABEL } from "@/lib/cso-bands";
import { fmtInt, telHref } from "@/lib/format";
import { useNarrow } from "@/lib/use-narrow";
import ExportButtons from "@/components/ExportButtons";
import { stamp, type Cell } from "@/lib/export";

const ALL = "All";
/** Same two identities as the overview, so colour means one thing across the module. */
const SERIES_SALES = "#ee7203";
const SERIES_COLL = "#2f6f9f";
const SPARK_MONTHS = 6;
const FORM_MONTHS = 5;

type SortKey = "rank" | "sales" | "collections" | "pending" | "sold" | "collected" | "name";
const SORT_LABEL: Record<SortKey, string> = {
  rank: "Weakest overall first",
  sales: "Lowest sales productivity",
  collections: "Lowest collections productivity",
  pending: "Most open follow-ups",
  sold: "Most sold",
  collected: "Most collected",
  name: "Name",
};

/**
 * Performance grade. Deliberately mixes the absolute target with the peer
 * distribution: almost nobody clears the raw target, so grading on it alone would
 * mark the whole roster "at risk" and tell a manager nothing.
 */
type Grade = "top" | "above" | "below" | "support" | "none";
const GRADE_LABEL: Record<Grade, string> = {
  top: "Top performer",
  above: "Above average",
  below: "Below average",
  support: "Needs support",
  none: "No target",
};
const GRADE_COLOR: Record<Grade, string> = {
  top: "var(--good)",
  above: "#2f6f9f",
  below: "var(--warning)",
  support: "var(--critical)",
  none: "var(--text-muted)",
};

const quantile = (sorted: number[], q: number): number =>
  sorted.length === 0 ? 0 : sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * q))];

/** One number per CSO: the mean of the two ratios they are held to. */
function scoreOf(m: CsoMonth): number | null {
  const parts = [m.pctSold, m.pctCollected].filter((v): v is number => v != null);
  return parts.length ? parts.reduce((s, v) => s + v, 0) / parts.length : null;
}

const pctText = (v: number | null) => (v == null ? "-" : `${Math.round(v * 100)}%`);

function fmtK(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (a >= 1e3) return Math.round(n / 1e3) + "K";
  return String(Math.round(n));
}

/** Everything the table needs about one CSO in the selected month. */
type Row = {
  m: CsoMonth;
  history: CsoMonth[];
  spark: (number | null)[];
  atTarget: number;
  scored: number;
  pending: CsoPending | null;
  /** Mean of the two ratios, the single number the grade and rank come from. */
  score: number | null;
  grade: Grade;
  rankInTerritory: number;
  territorySize: number;
  isNew: boolean;
  /** Short, actionable reasons: what a manager should do about this person. */
  tags: string[];
  /** Last few months as W/D/L, oldest first, like a league form guide. */
  form: { month: string; label: string; result: FormResult; score: number | null }[];
};

/**
 * Colour band for a month's target achievement. Letters (W/D/L) were replaced
 * with the actual percentage: people kept asking what they stood for, and a
 * number answers "how far off" as well as "did they hit it".
 *   at/above target -> green, 80-99% -> amber, under 80% -> red.
 */
type FormResult = "hit" | "near" | "miss" | "none";
const FORM_COLOR: Record<FormResult, string> = {
  hit: "var(--good)",
  near: "var(--warning)",
  miss: "var(--critical)",
  none: "var(--border)",
};
function formOf(score: number | null): FormResult {
  if (score == null) return "none";
  if (score >= 1) return "hit";
  if (score >= 0.8) return "near";
  return "miss";
}

/** Direction of travel over the sparkline window. */
function direction(spark: (number | null)[]): "up" | "down" | "flat" {
  const v = spark.filter((x) => x != null) as number[];
  if (v.length < 3) return "flat";
  const first = v[0], last = v[v.length - 1];
  if (last > first * 1.1) return "up";
  if (last < first * 0.9) return "down";
  return "flat";
}

function buildTags(m: CsoMonth, pending: CsoPending | null, spark: (number | null)[], isNew: boolean): string[] {
  const tags: string[] = [];
  const s = m.pctSold, c = m.pctCollected;
  // Part month comes first: it changes how every other number should be read.
  if (m.isPartMonth) tags.push(`Part month (${m.daysAvailable} of ${m.monthDays} days)`);
  if (m.isAwayFromHome) tags.push(`Worked in ${m.territory}`);
  // Contracts count new jobs only; a month of follow-on (phase 2+) sales has
  // SQM-E but no contracts, and is not a month without sales.
  if (m.sold === 0 && m.soldSqme === 0) tags.push("No sales this month");
  if (s != null && c != null) {
    if (s - c > 0.3) tags.push("Signing, not collecting");
    else if (c - s > 0.3) tags.push("Collecting, not signing");
  }
  const dir = direction(spark);
  if (dir === "down") tags.push("Declining");
  if (dir === "up") tags.push("Improving");
  if (pending && pending.over1y >= 5) tags.push(`${pending.over1y} stale follow-ups`);
  if (isNew) tags.push("New CSO");
  return tags.slice(0, 3);
}

export default function CsoIndividual({ rows, pending }: { rows: CsoMonth[]; pending: CsoPending[] }) {
  const months = useMemo(() => Array.from(new Set(rows.map((r) => r.month))).sort(), [rows]);
  const monthLabel = useMemo(() => {
    const m = new Map<string, string>();
    for (const r of rows) m.set(r.month, r.monthLabel);
    return m;
  }, [rows]);

  // Open on the last COMPLETE month; the month in progress always reads low.
  const defaultMonth = useMemo(() => {
    const complete = [...months].reverse().find((m) => rows.some((r) => r.month === m && r.hasTargets && !r.isCurrentMonth));
    return complete ?? months[months.length - 1] ?? "";
  }, [months, rows]);

  const [month, setMonth] = useState(defaultMonth);
  const [district, setDistrict] = useState(ALL);
  const [territory, setTerritory] = useState(ALL);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortKey>("rank");
  const [grade, setGrade] = useState<Grade | "all">("all");
  const [includeLeavers, setIncludeLeavers] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);

  const pendingBy = useMemo(() => new Map(pending.map((p) => [p.csoId, p])), [pending]);
  const historyBy = useMemo(() => {
    const m = new Map<string, CsoMonth[]>();
    for (const r of rows) (m.get(r.csoId) ?? m.set(r.csoId, []).get(r.csoId)!).push(r);
    for (const list of m.values()) list.sort((a, b) => a.month.localeCompare(b.month));
    return m;
  }, [rows]);

  // Leavers and duplicate stub contacts are off by default: they are phantom
  // bottom performers that no manager can act on.
  const monthRows = useMemo(
    () => rows.filter((r) => r.month === month && (includeLeavers || (r.isActiveStaff && !r.isUnverifiedStaff))),
    [rows, month, includeLeavers],
  );

  const districts = useMemo(
    () => [ALL, ...Array.from(new Set(monthRows.map((r) => r.district))).filter((d) => d !== "Unassigned").sort()],
    [monthRows],
  );
  const territories = useMemo(
    () => [ALL, ...Array.from(new Set(monthRows.filter((r) => district === ALL || r.district === district).map((r) => r.territory))).filter((t) => t !== "Unassigned").sort()],
    [monthRows, district],
  );

  /** Rank inside a territory is computed over the whole month, not the filtered view. */
  const territoryRanks = useMemo(() => {
    const groups = new Map<string, { id: string; score: number }[]>();
    for (const r of monthRows) {
      const sc = scoreOf(r);
      if (sc == null) continue;
      (groups.get(r.territory) ?? groups.set(r.territory, []).get(r.territory)!).push({ id: r.csoId, score: sc });
    }
    const rank = new Map<string, { rank: number; size: number }>();
    for (const list of groups.values()) {
      list.sort((a, b) => b.score - a.score);
      list.forEach((x, i) => rank.set(x.id, { rank: i + 1, size: list.length }));
    }
    return rank;
  }, [monthRows]);

  /** Grade cut-points come from the whole month's distribution, so filtering the
   * table does not silently re-grade the people left in it. */
  const cuts = useMemo(() => {
    const scores = monthRows.map(scoreOf).filter((s): s is number => s != null).sort((a, b) => a - b);
    return { q25: quantile(scores, 0.25), median: quantile(scores, 0.5) };
  }, [monthRows]);

  const allRows: Row[] = useMemo(() => {
    return monthRows.map((m): Row => {
      const history = (historyBy.get(m.csoId) ?? []).filter((h) => h.month <= month);
      const window = history.slice(-SPARK_MONTHS);
      const scoredMonths = window.filter((h) => h.pctSold != null);
      const spark = window.map((h) => h.pctSold);
      const p = pendingBy.get(m.csoId) ?? null;
      const score = scoreOf(m);
      const isNew = m.isNewCso;
      const r = territoryRanks.get(m.csoId);

      let grade: Grade = "none";
      if (score != null) {
        if (score >= 1) grade = "top";
        else if (score <= cuts.q25) grade = "support";
        else if (score >= cuts.median) grade = "above";
        else grade = "below";
      }

      return {
        m, history, spark,
        atTarget: scoredMonths.filter((h) => (h.pctSold ?? 0) >= 1).length,
        scored: scoredMonths.length,
        pending: p,
        form: history.slice(-FORM_MONTHS).map((h) => {
          const sc = scoreOf(h);
          return { month: h.month, label: h.monthLabel, result: formOf(sc), score: sc };
        }),
        score, grade,
        rankInTerritory: r?.rank ?? 0,
        territorySize: r?.size ?? 0,
        isNew,
        tags: buildTags(m, p, spark, isNew),
      };
    });
  }, [monthRows, historyBy, pendingBy, month, months, territoryRanks, cuts]);

  const gradeCounts = useMemo(() => {
    const c: Record<Grade, number> = { top: 0, above: 0, below: 0, support: 0, none: 0 };
    for (const r of allRows) c[r.grade]++;
    return c;
  }, [allRows]);

  const listed: Row[] = useMemo(() => {
    const q = search.trim().toLowerCase();
    const out = allRows.filter((r) => {
      if (district !== ALL && r.m.district !== district) return false;
      if (territory !== ALL && r.m.territory !== territory) return false;
      if (grade !== "all" && r.grade !== grade) return false;
      if (q && !`${r.m.cso} ${r.m.territory} ${r.m.district}`.toLowerCase().includes(q)) return false;
      return true;
    });
    const by: Record<SortKey, (a: Row, b: Row) => number> = {
      rank: (a, b) => (a.score ?? 99) - (b.score ?? 99),
      sales: (a, b) => (a.m.pctSold ?? 99) - (b.m.pctSold ?? 99),
      collections: (a, b) => (a.m.pctCollected ?? 99) - (b.m.pctCollected ?? 99),
      pending: (a, b) => (b.pending?.contracts ?? 0) - (a.pending?.contracts ?? 0),
      sold: (a, b) => b.m.sold - a.m.sold,
      collected: (a, b) => b.m.collected - a.m.collected,
      name: (a, b) => a.m.cso.localeCompare(b.m.cso),
    };
    return [...out].sort(by[sort]);
  }, [allRows, district, territory, grade, search, sort]);

  /** Peer medians for a territory in the selected month, for the expanded row. */
  const medianFor = useMemo(() => {
    const cache = new Map<string, { n: number; medSold: number; medColl: number }>();
    return (terr: string) => {
      const hit = cache.get(terr);
      if (hit) return hit;
      const p = monthRows.filter((r) => r.territory === terr);
      const med = (xs: number[]) => {
        const a = [...xs].sort((x, y) => x - y);
        return a.length ? a[Math.floor(a.length / 2)] : 0;
      };
      const out = { n: p.length, medSold: med(p.map((x) => x.sold)), medColl: med(p.map((x) => x.collected)) };
      cache.set(terr, out);
      return out;
    };
  }, [monthRows]);

  const exportHeaders = ["CSO", "Home territory", "District", "Standing", "Rank in territory",
    "Contracts sold", "Sales target", "Sales % of target",
    "Contracts collected", "Collections target", "Collections % of target",
    "SQM-E sold", "Open follow-ups", "Cash to collect (RWF)", "Follow-ups over a year",
    "Months at target", "Months scored", "Flags"];

  const exportRows: Cell[][] = listed.map((r) => [
    r.m.cso, r.m.homeTerritory ?? r.m.territory, r.m.district, GRADE_LABEL[r.grade],
    r.territorySize > 0 ? `${r.rankInTerritory} of ${r.territorySize}` : "",
    r.m.sold, r.m.minSold == null ? "" : Math.round(r.m.minSold),
    r.m.pctSold == null ? "" : Math.round(r.m.pctSold * 100),
    r.m.collected, r.m.minCollected == null ? "" : Math.round(r.m.minCollected),
    r.m.pctCollected == null ? "" : Math.round(r.m.pctCollected * 100),
    Math.round(r.m.soldSqme),
    r.pending?.contracts ?? 0, r.pending?.cash ?? 0, r.pending?.over1y ?? 0,
    r.atTarget, r.scored, r.tags.join("; "),
  ]);

  const exportName = `cso-performance_${(monthLabel.get(month) ?? month).replace(/\s+/g, "-")}_${stamp()}`;

  return (
    <div className="mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6">
      <header className="flex flex-col gap-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>RW individual CSO performance</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              Every CSO against the same per-person standard. Select anyone to see their history.
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Link href="/toolkit/cso" className="text-sm hover:underline" style={{ color: "var(--accent-ink)" }}>← RW CSO performance overview</Link>
            <ExportButtons filename={exportName} headers={exportHeaders} rows={exportRows} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select label="Month" value={month} options={[...months].reverse()} optionLabel={(m) => monthLabel.get(m) ?? m} onChange={setMonth} />
          <Select label="District" value={district} options={districts} onChange={(v) => { setDistrict(v); setTerritory(ALL); }} />
          <Select label="Territory" value={territory} options={territories} onChange={setTerritory} />
          <Select label="Sort by" value={sort} options={Object.keys(SORT_LABEL)} optionLabel={(s) => SORT_LABEL[s as SortKey]} onChange={(v) => setSort(v as SortKey)} />
          <button type="button" onClick={() => setIncludeLeavers((v) => !v)}
            className="rounded-md border px-2.5 py-1.5 text-sm"
            style={{
              background: "var(--surface)",
              borderColor: includeLeavers ? "var(--accent-strong)" : "var(--border)",
              color: includeLeavers ? "var(--text-primary)" : "var(--text-secondary)",
            }}>
            {includeLeavers ? "Including leavers" : "Current staff only"}
          </button>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search CSO, territory…"
            className="min-h-11 w-full flex-1 rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-auto sm:min-w-48"
            style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
        </div>
      </header>

      <section className="rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b p-4" style={{ borderColor: "var(--border)" }}>
          <div className="flex flex-wrap items-center gap-2">
            <GradeChip label="Everyone" count={allRows.length} on={grade === "all"} color="var(--text-secondary)" onClick={() => setGrade("all")} />
            {(["top", "above", "below", "support"] as Grade[]).map((g) => (
              <GradeChip key={g} label={GRADE_LABEL[g]} count={gradeCounts[g]} on={grade === g}
                color={GRADE_COLOR[g]} onClick={() => setGrade(grade === g ? "all" : g)} />
            ))}
          </div>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>
            Graded against target and against peers this month. Select a row for full history.
          </span>
        </div>
        <div className="hidden overflow-x-auto md:block print:block">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ color: "var(--text-muted)", borderBottom: "1px solid var(--border)" }}>
                <Th>CSO</Th>
                <Th>Standing</Th>
                <Th>Sales this month</Th>
                <Th>Collections this month</Th>
                <Th right>Open follow-ups</Th>
                <Th right>At target</Th>
                <Th>% of target (last {FORM_MONTHS} months)</Th>
              </tr>
            </thead>
            <tbody>
              {listed.map((r) => (
                <Fragment key={r.m.csoId}>
                <tr onClick={() => setSelected((cur) => (cur === r.m.csoId ? null : r.m.csoId))}
                  style={{
                    borderTop: "1px solid var(--border)", cursor: "pointer",
                    background: r.m.csoId === selected
                      ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)"
                      : r.grade === "top" ? "color-mix(in srgb, var(--good) 5%, transparent)"
                      : r.grade === "support" ? "color-mix(in srgb, var(--critical) 5%, transparent)"
                      : "transparent",
                  }}>
                  <Td>
                    <span className="flex items-stretch gap-2.5">
                      <span className="w-0.5 shrink-0 rounded-full" style={{ background: GRADE_COLOR[r.grade] }} />
                      <span className="min-w-0">
                        <span className="block truncate font-medium leading-tight" style={{ color: "var(--text-primary)" }}>{r.m.cso}</span>
                        <span className="block text-xs" style={{ color: "var(--text-muted)" }}>
                          {r.m.homeTerritory ?? r.m.territory}
                          {r.territorySize > 0 && ` · #${r.rankInTerritory} of ${r.territorySize}`}
                        </span>
                      </span>
                    </span>
                  </Td>
                  <Td>
                    <span className="inline-block rounded px-1.5 py-0.5 text-xs font-semibold"
                      style={{ background: `color-mix(in srgb, ${GRADE_COLOR[r.grade]} 16%, transparent)`, color: "var(--text-primary)" }}>
                      {GRADE_LABEL[r.grade]}
                    </span>
                    {r.tags.length > 0 && (
                      <span className="mt-1 flex flex-wrap gap-1">
                        {r.tags.map((t) => (
                          <span key={t} className="rounded px-1.5 py-0.5 text-[11px]"
                            style={{ border: "1px solid var(--border)", color: "var(--text-secondary)" }}>{t}</span>
                        ))}
                      </span>
                    )}
                  </Td>
                  <Td><Cell actual={r.m.sold} target={r.m.minSold} pct={r.m.pctSold} tone={SERIES_SALES} extra={`${fmtInt(Math.round(r.m.soldSqme))} SQM-E`} /></Td>
                  <Td><Cell actual={r.m.collected} target={r.m.minCollected} pct={r.m.pctCollected} tone={SERIES_COLL} extra={`${fmtInt(Math.round(r.m.collectedSqme))} SQM-E`} /></Td>
                  <Td right>
                    {r.pending && r.pending.contracts > 0 ? (
                      <>
                        <span className="block font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(r.pending.contracts)}</span>
                        <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{fmtK(r.pending.cash)} RWF</span>
                        {r.pending.over1y > 0 && (
                          <span className="block text-xs" style={{ color: "var(--warning)" }}>{fmtInt(r.pending.over1y)} over a year</span>
                        )}
                      </>
                    ) : (
                      <span style={{ color: "var(--text-muted)" }}>-</span>
                    )}
                  </Td>
                  <Td right>
                    {r.scored > 0 ? (
                      <>
                        <span className="block font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{r.atTarget} of {r.scored}</span>
                        <span className="block text-xs" style={{ color: "var(--text-muted)" }}>months</span>
                      </>
                    ) : <span style={{ color: "var(--text-muted)" }}>-</span>}
                  </Td>
                  <Td><Form form={r.form} /></Td>
                </tr>
                {r.m.csoId === selected && (
                  <tr>
                    <td colSpan={7} className="p-0">
                      <CsoDetail row={r} month={month} peers={medianFor(r.m.territory)}
                        history={historyBy.get(r.m.csoId) ?? []} onClose={() => setSelected(null)} />
                    </td>
                  </tr>
                )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>

        {/* Phones get stacked cards; the same row tap expands the same detail. */}
        <div className="flex flex-col md:hidden">
          {listed.map((r) => (
            <div key={r.m.csoId} className="border-t" style={{ borderColor: "var(--border)" }}>
              <button type="button"
                onClick={() => setSelected((cur) => (cur === r.m.csoId ? null : r.m.csoId))}
                className="w-full border-l-4 p-4 text-left"
                style={{
                  borderLeftColor: GRADE_COLOR[r.grade],
                  background: r.m.csoId === selected ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)" : "transparent",
                }}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <span className="block truncate font-medium" style={{ color: "var(--text-primary)" }}>{r.m.cso}</span>
                    <span className="block text-xs" style={{ color: "var(--text-muted)" }}>
                      {r.m.homeTerritory ?? r.m.territory}
                      {r.territorySize > 0 && ` · #${r.rankInTerritory} of ${r.territorySize}`}
                    </span>
                  </div>
                  <span className="shrink-0 rounded px-1.5 py-0.5 text-[11px] font-semibold"
                    style={{ background: `color-mix(in srgb, ${GRADE_COLOR[r.grade]} 16%, transparent)`, color: "var(--text-primary)" }}>
                    {GRADE_LABEL[r.grade]}
                  </span>
                </div>

                <div className="mt-3 grid grid-cols-2 gap-3">
                  <Cell actual={r.m.sold} target={r.m.minSold} pct={r.m.pctSold} tone={SERIES_SALES} extra="sold" />
                  <Cell actual={r.m.collected} target={r.m.minCollected} pct={r.m.pctCollected} tone={SERIES_COLL} extra="collected" />
                </div>

                <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                  <Form form={r.form} />
                  <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                    {r.pending && r.pending.contracts > 0
                      ? `${fmtInt(r.pending.contracts)} open · ${fmtK(r.pending.cash)} RWF`
                      : "No open follow-ups"}
                  </span>
                </div>

                {r.tags.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {r.tags.map((t) => (
                      <span key={t} className="rounded px-1.5 py-0.5 text-[11px]"
                        style={{ border: "1px solid var(--border)", color: "var(--text-secondary)" }}>{t}</span>
                    ))}
                  </div>
                )}
              </button>

              {r.m.csoId === selected && (
                <CsoDetail row={r} month={month} peers={medianFor(r.m.territory)}
                  history={historyBy.get(r.m.csoId) ?? []} onClose={() => setSelected(null)} />
              )}
            </div>
          ))}
        </div>

        {listed.length === 0 && (
          <p className="p-8 text-center text-sm" style={{ color: "var(--text-muted)" }}>No CSOs match these filters.</p>
        )}
      </section>

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        Only CSOs with activity in the month appear here, so this is the working population rather than the full payroll. Open follow-ups are contracts they signed that have not yet crossed the payment gate, counted the same way as the Collections module: paid to threshold, or a milestone date, or construction already started.
      </p>
    </div>
  );
}

/** Actual against target, with the bar reading as proportion of target. */
function Cell({ actual, target, pct, tone, extra }: { actual: number; target: number | null; pct: number | null; tone: string; extra: string }) {
  return (
    <div className="flex min-w-40 flex-col gap-1">
      <span className="flex items-baseline gap-1.5">
        <span className="font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(actual)}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>of {target == null ? "-" : Math.round(target)}</span>
        <span className="ml-auto text-xs font-medium tabular-nums" style={{ color: "var(--text-secondary)" }}>{pctText(pct)}</span>
      </span>
      <span className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: tone }} />
      </span>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>{extra}</span>
    </div>
  );
}

/** The expanded row: full context for one CSO, shown in place. */
function CsoDetail({ row, month, peers, history, onClose }: {
  row: Row;
  month: string;
  peers: { n: number; medSold: number; medColl: number };
  history: CsoMonth[];
  onClose: () => void;
}) {
  const m = row.m;
  return (
    <div className="border-l-2 p-5" style={{ background: "var(--page)", borderColor: "var(--accent-strong)" }}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{m.cso}</h3>
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>
            {m.homeTerritory ?? m.territory} · {m.assignedDistrict ?? m.district}
            {row.territorySize > 0 && ` · #${row.rankInTerritory} of ${row.territorySize} in territory`}
            {m.manager ? ` · manager ${m.manager}` : ""}
            {m.phone ? " · " : ""}
            {m.phone && (
              <a href={telHref(m.phone) ?? undefined} className="hover:underline" style={{ color: "var(--accent-ink)" }}>{m.phone}</a>
            )}
          </p>
          {m.isAwayFromHome && (
            <p className="mt-0.5 text-xs" style={{ color: "var(--warning)" }}>
              This month&apos;s work was in {m.territory}, outside their usual territory.
            </p>
          )}
        </div>
        <button type="button" onClick={onClose} className="rounded-md border px-2.5 py-1 text-sm"
          style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>
          Collapse
        </button>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Sales productivity" pct={m.pctSold} tone={SERIES_SALES}
          sub={`${fmtInt(m.sold)} sold of ${m.minSold == null ? "-" : Math.round(m.minSold)} target`} />
        <Stat label="Collections productivity" pct={m.pctCollected} tone={SERIES_COLL}
          sub={`${fmtInt(m.collected)} collected of ${m.minCollected == null ? "-" : Math.round(m.minCollected)} target`} />
        <Plain label="Open follow-ups"
          value={row.pending ? fmtInt(row.pending.contracts) : "0"}
          sub={row.pending
            ? `${fmtInt(Math.round(row.pending.sqme))} SQM-E · ${fmtK(row.pending.cash)} RWF to collect`
            : "Nothing outstanding"} />
        <Plain label="Territory median"
          value={`${peers.medSold} sold`}
          sub={`${peers.medColl} collected · ${peers.n} CSOs`} />
      </div>

      <CsoTrend trend={history} selected={month} />
    </div>
  );
}

/**
 * League-style form guide: one pill per month, oldest on the left. W met the
 * target, D came close, L fell well short. Faster to read across a long table
 * than a sparkline, and it says what "good" was rather than just the shape.
 */
function Form({ form }: { form: { month: string; label: string; result: FormResult; score: number | null }[] }) {
  if (form.length === 0) return <span className="text-xs" style={{ color: "var(--text-muted)" }}>no history</span>;
  const pad: FormResult[] = Array(Math.max(0, FORM_MONTHS - form.length)).fill("none");
  return (
    <span className="flex items-center gap-1">
      {pad.map((_, i) => (
        <span key={`pad${i}`} className="grid h-5 min-w-9 place-items-center rounded px-1 text-[11px] font-semibold"
          style={{ background: "var(--border)", color: "var(--text-muted)" }}>·</span>
      ))}
      {form.map((f, i) => (
        <span key={f.month}
          title={`${f.label}: ${pctText(f.score)} of target`}
          className="grid h-5 min-w-9 place-items-center rounded px-1 text-[11px] font-semibold tabular-nums"
          style={{
            background: FORM_COLOR[f.result],
            color: "#fff",
            // The most recent month is the one that matters most.
            outline: i === form.length - 1 ? "2px solid var(--text-primary)" : "none",
            outlineOffset: "1px",
          }}>
          {pctText(f.score)}
        </span>
      ))}
    </span>
  );
}

/** This CSO's two ratios across every month we hold, against the standard. */
function CsoTrend({ trend, selected }: { trend: CsoMonth[]; selected: string }) {
  const narrow = useNarrow();
  const all = trend.filter((t) => t.pctSold != null || t.pctCollected != null);
  const pts = narrow ? all.slice(-5) : all;
  if (pts.length < 2) return null;

  const W = narrow ? 380 : 800;
  const H = narrow ? 210 : 180;
  const padL = narrow ? 40 : 46, padR = narrow ? 16 : 22, padT = 16, padB = narrow ? 32 : 30;
  const fs = narrow ? 13 : 10.5;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const rawMax = Math.max(...pts.flatMap((d) => [d.pctSold ?? 0, d.pctCollected ?? 0]));
  const yMax = Math.max(1.25, Math.ceil((rawMax * 1.08) / 0.25) * 0.25);
  const step = yMax > 3 ? 1 : 0.5;
  const ticks: number[] = [];
  for (let t = 0; t <= yMax + 1e-9; t += step) ticks.push(Number(t.toFixed(2)));
  const x = (i: number) => padL + (i * plotW) / (pts.length - 1);
  const y = (v: number) => padT + plotH * (1 - v / yMax);
  const path = (get: (t: CsoMonth) => number | null) =>
    pts.map((d, i) => (get(d) == null ? null : `${i === 0 || get(pts[i - 1]) == null ? "M" : "L"}${x(i)},${y(get(d)!)}`))
      .filter(Boolean).join(" ");
  const areaOf = (get: (t: CsoMonth) => number | null) => {
    const v = pts.map((d, i) => ({ i, val: get(d) })).filter((p) => p.val != null);
    if (v.length < 2) return "";
    return `M${x(v[0].i)},${y(v[0].val!)}` + v.slice(1).map((p) => `L${x(p.i)},${y(p.val!)}`).join("")
      + `L${x(v[v.length - 1].i)},${padT + plotH}L${x(v[0].i)},${padT + plotH}Z`;
  };

  return (
    <div className="mt-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>History</h3>
        <div className="flex items-center gap-4 text-xs" style={{ color: "var(--text-muted)" }}>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: SERIES_SALES }} />Sales</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: SERIES_COLL }} />Collections</span>
        </div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="mt-2 w-full" style={{ maxHeight: narrow ? 220 : 200, overflow: "visible" }} role="img"
        aria-label="This CSO's sales and collections productivity by month">
        <defs>
          <linearGradient id="csoIndSales" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_SALES} stopOpacity="0.16" />
            <stop offset="100%" stopColor={SERIES_SALES} stopOpacity="0" />
          </linearGradient>
          <linearGradient id="csoIndColl" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_COLL} stopOpacity="0.14" />
            <stop offset="100%" stopColor={SERIES_COLL} stopOpacity="0" />
          </linearGradient>
        </defs>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeWidth="1" opacity={t === 0 ? 0.9 : 0.45} />
            <text x={padL - 10} y={y(t) + 4} textAnchor="end" fontSize={fs} fill="var(--text-muted)">{Math.round(t * 100)}%</text>
          </g>
        ))}
        <line x1={padL} x2={W - padR} y1={y(1)} y2={y(1)} stroke="var(--text-secondary)" strokeWidth="1.25" strokeDasharray="4 5" opacity="0.75" />
        <text x={W - padR + 4} y={y(1) + 3.5} fontSize={fs} fill="var(--text-muted)">target</text>
        <path d={areaOf((t) => t.pctSold)} fill="url(#csoIndSales)" />
        <path d={areaOf((t) => t.pctCollected)} fill="url(#csoIndColl)" />
        <path d={path((t) => t.pctSold)} fill="none" stroke={SERIES_SALES} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />
        <path d={path((t) => t.pctCollected)} fill="none" stroke={SERIES_COLL} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />
        {pts.map((d, i) => (
          <g key={d.month}>
            {d.pctSold != null && (
              <circle cx={x(i)} cy={y(d.pctSold)} r={d.month === selected ? 5 : 3} fill={SERIES_SALES} stroke="var(--surface)" strokeWidth="2">
                <title>{`${d.monthLabel} · sales ${pctText(d.pctSold)}`}</title>
              </circle>
            )}
            {d.pctCollected != null && (
              <circle cx={x(i)} cy={y(d.pctCollected)} r={d.month === selected ? 5 : 3} fill={SERIES_COLL} stroke="var(--surface)" strokeWidth="2">
                <title>{`${d.monthLabel} · collections ${pctText(d.pctCollected)}`}</title>
              </circle>
            )}
            <text x={x(i)} y={H - 12} textAnchor="middle" fontSize={fs}
              fill={d.month === selected ? "var(--text-primary)" : "var(--text-muted)"}
              fontWeight={d.month === selected ? 600 : 400}>
              {d.monthLabel.slice(0, 3)}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

function Stat({ label, pct, tone, sub }: { label: string; pct: number | null; tone: string; sub: string }) {
  const b = band(pct);
  return (
    <div className="rounded-md border p-3" style={{ borderColor: "var(--border)", borderTop: `3px solid ${tone}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 text-2xl font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</div>
      <span className="mt-0.5 block text-xs font-medium" style={{ color: BAND_COLOR[b] }}>{BAND_LABEL[b]}</span>
      <span className="mt-1 block text-xs" style={{ color: "var(--text-muted)" }}>{sub}</span>
    </div>
  );
}

function Plain({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-md border p-3" style={{ borderColor: "var(--border)" }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 text-2xl font-semibold" style={{ color: "var(--text-primary)" }}>{value}</div>
      <span className="mt-1 block text-xs" style={{ color: "var(--text-muted)" }}>{sub}</span>
    </div>
  );
}

/** Clickable count that doubles as the status filter. */
function GradeChip({ label, count, on, color, onClick }: { label: string; count: number; on: boolean; color: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick}
      className="flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium"
      style={{
        borderColor: on ? color : "var(--border)",
        background: on ? `color-mix(in srgb, ${color} 12%, var(--surface))` : "var(--surface)",
        color: "var(--text-primary)",
      }}>
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
      <span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtInt(count)}</span>
    </button>
  );
}

function Th({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <th className={`px-3 py-2 font-medium ${right ? "text-right" : "text-left"}`}>{children}</th>;
}
function Td({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <td className={`px-3 py-2.5 align-top ${right ? "text-right tabular-nums" : "text-left"}`}>{children}</td>;
}

function Select({ label, value, options, onChange, optionLabel }: { label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string }) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}
