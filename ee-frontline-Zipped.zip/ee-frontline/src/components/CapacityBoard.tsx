"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { CapacityRow, CapacityTrendRow, CapacityWeek } from "@/lib/capacity";
import { band, BAND_COLOR, BAND_LABEL } from "@/lib/cso-bands";
import {
  dataAsAt, dayMonth, dayRange, fmtWhole, pctText, unitWord, CAPACITY_COUNTRIES, CAPACITY_CURRENCY, SERIES_BUILDS, SERIES_COLL, SERIES_SALES, UNIT_LEVEL,
  type CapacityCountry,
} from "@/lib/capacity-ui";
import { fmtInt } from "@/lib/format";
import ExportButtons from "@/components/ExportButtons";
import { stamp, type Cell } from "@/lib/export";
import CapacityCards from "@/components/CapacityCards";
import CapacityTable, { type SortKey, type SortState, type Status, type TableDim } from "@/components/CapacityTable";

const ALL = "All managers";
const ANY = "All";

/**
 * What "Branch" means per country. Rwanda's branch is the level the rest of the
 * company calls a district: `all_opportunities_master.branch` equals
 * `location_district` on every Rwandan job, 21 names to 21 names. Uganda and
 * Kenya have branches and nothing under them. So the hierarchy is
 * country > branch > territory in Rwanda and country > branch in Uganda and
 * Kenya, and every level comes from rows already in the payload.
 */
const BRANCH_LEVEL: Record<CapacityCountry, "district" | "branch"> = { Rwanda: "district", Uganda: "branch", Kenya: "branch" };

/** Which deep dive is open, and from where, so it expands in exactly one place. */
export type OpenKey = { level: TableDim; name: string; from: "cards" | "table" };

/**
 * The capacity planning board. A summary sentence, four scorecards, the focus
 * cards, then the table as evidence. One page for every country: Rwanda is
 * territories inside districts, grouped by manager; Uganda and Kenya are
 * branches only, so the district toggle and the manager chips do not appear
 * for them. There is one window and it is exactly the weeks selected: every
 * numerator, denominator and headcount on the scorecards and in the table
 * covers those weeks and nothing else, so adding a week never lowers a
 * figure. Masons working, Masons assigned and Masons to hire are one model: they add
 * up to the month's requirement, so Masons to hire is read from the same week set as
 * the two counts it completes. CSOs and their shortfall follow the same rule.
 * The organisation filters cascade down the hierarchy the data holds: manager,
 * branch, territory. Rwanda's branch is its district level, the same 21 names
 * the rest of the company calls branches. The
 * trailing four-week comparison appears only as the change beside a figure
 * and on the focus cards, which rank on it.
 * Every figure comes from the view at the level it is shown, so nothing here
 * adds units together.
 */
export default function CapacityBoard({
  country,
  calendar,
  month,
  rows,
  trend,
  builtAt,
  initialOpen = null,
}: {
  country: CapacityCountry;
  calendar: CapacityWeek[];
  month: string;
  rows: CapacityRow[];
  trend: CapacityTrendRow[];
  /** When the figures were computed, ISO. Shown as "Data as at". */
  builtAt: string;
  initialOpen?: OpenKey | null;
}) {
  const router = useRouter();
  const unit = UNIT_LEVEL[country];
  const hasManagers = unit === "territory";
  const currency = CAPACITY_CURRENCY[country];

  const months = useMemo(() => {
    const seen = new Map<string, string>();
    for (const w of calendar) seen.set(w.month, w.monthLabel);
    return Array.from(seen.entries()).map(([value, label]) => ({ value, label }));
  }, [calendar]);
  const monthLabel = months.find((m) => m.value === month)?.label ?? month;
  const monthName = monthLabel.split(" ")[0];

  const weeksInMonth = useMemo(() => calendar.filter((w) => w.month === month), [calendar, month]);

  // Land on the last complete week. The week in progress always reads low, so
  // it has to be chosen deliberately rather than landed on.
  const defaultWeeks = useMemo(() => {
    const complete = [...weeksInMonth].reverse().find((w) => w.isComplete);
    const pick = complete ?? weeksInMonth[weeksInMonth.length - 1];
    return pick ? [pick.weekNo] : [];
  }, [weeksInMonth]);

  const [manager, setManager] = useState(ALL);
  const [branch, setBranch] = useState(ANY);
  const [territory, setTerritory] = useState(ANY);
  const [weeks, setWeeks] = useState<number[]>(defaultWeeks);
  const [open, setOpen] = useState<OpenKey | null>(initialOpen);
  const [dim, setDim] = useState<TableDim>(initialOpen?.level ?? unit);
  const [sort, setSort] = useState<SortState>({ key: "built", dir: "asc" });
  const [status, setStatus] = useState<Status>("all");

  const weekKey = [...weeks].sort().join("");

  /**
   * The rows for the selected week set, every level. Working, Assigned and
   * To hire all come from this one set, so the three foot to the month's
   * requirement on every row: the view computes To hire as each unit's
   * shortfall after both counts.
   */
  const inMonth = useMemo(() => rows.filter((r) => r.weekKey === weekKey), [rows, weekKey]);

  // Managers come from the data, never a list in the code. Each chip carries
  // how many territories it covers. Uganda and Kenya have none.
  const managerCounts = useMemo(() => {
    const m = new Map<string, number>();
    if (hasManagers) for (const r of inMonth) if (r.level === unit && r.manager && r.manager !== "Unassigned") m.set(r.manager, (m.get(r.manager) ?? 0) + 1);
    return Array.from(m.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [inMonth, hasManagers, unit]);

  /**
   * The unit rows in scope, narrowed down the hierarchy: manager, then branch,
   * then territory. Rwanda's unit is the territory and its branch is the row's
   * parent; Uganda and Kenya have no level below the branch, so there the
   * branch filter picks the unit row itself.
   */
  const branchOf = (r: CapacityRow) => (unit === "territory" ? r.parent : r.name);
  const units = useMemo(
    () => inMonth.filter((r) =>
      r.level === unit
      && (manager === ALL || r.manager === manager)
      && (branch === ANY || branchOf(r) === branch)
      && (territory === ANY || r.name === territory)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [inMonth, unit, manager, branch, territory],
  );
  const districts = useMemo(() => {
    const names = new Set(units.map((r) => r.parent));
    return inMonth.filter((r) => r.level === "district" && names.has(r.name));
  }, [inMonth, units]);

  /** Branches a manager covers, then the territories inside the chosen branch. Never an impossible pair. */
  const branchOptions = useMemo(() => {
    const names = new Set(
      inMonth.filter((r) => r.level === unit && (manager === ALL || r.manager === manager))
        .map(branchOf).filter((n): n is string => Boolean(n)),
    );
    return Array.from(names).sort((a, b) => a.localeCompare(b));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inMonth, unit, manager]);
  const territoryOptions = useMemo(() => {
    if (unit !== "territory") return [];
    return inMonth
      .filter((r) => r.level === "territory" && (manager === ALL || r.manager === manager) && (branch === ANY || r.parent === branch))
      .map((r) => r.name).sort((a, b) => a.localeCompare(b));
  }, [inMonth, unit, manager, branch]);

  /**
   * The headline row is the deepest place chosen: the territory, else the
   * branch at its own level, else the manager, else the country. Each is read
   * from its own level row, never added up from the level below.
   */
  const head = territory !== ANY
    ? inMonth.find((r) => r.level === unit && r.name === territory)
    : branch !== ANY
      ? inMonth.find((r) => r.level === BRANCH_LEVEL[country] && r.name === branch)
      : manager === ALL
        ? inMonth.find((r) => r.level === "country")
        : inMonth.find((r) => r.level === "manager" && r.name === manager);

  /** A narrower choice above never leaves a stranded one below. */
  function pickManager(m: string) { setManager(m); setBranch(ANY); setTerritory(ANY); setOpen(null); }
  function pickBranch(b: string) { setBranch(b); setTerritory(ANY); setOpen(null); }
  function pickTerritory(t: string) { setTerritory(t); setOpen(null); }

  const chosen = weeksInMonth.filter((w) => weeks.includes(w.weekNo));
  const lastWeek = chosen[chosen.length - 1];
  const inProgress = chosen.find((w) => w.isCurrent);
  const allWeeks = weeksInMonth.map((w) => w.weekNo);
  const wholeMonth = allWeeks.length > 0 && allWeeks.every((n) => weeks.includes(n));

  /** "W1 and W2 of August, 1 to 14 Aug". Non-adjacent weeks list each range. */
  const weekPhrase = useMemo(() => {
    if (chosen.length === 0) return monthLabel;
    const names = chosen.map((w) => `W${w.weekNo}`);
    const list = names.length === 1 ? names[0] : `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
    const adjacent = chosen.every((w, i) => i === 0 || w.weekNo === chosen[i - 1].weekNo + 1);
    const dates = adjacent
      ? `${Number(chosen[0].weekStart.split("-")[2])} to ${dayMonth(chosen[chosen.length - 1].weekEnd)}`
      : chosen.map((w) => dayRange(w.weekStart, w.weekEnd)).join(" and ");
    return `${wholeMonth ? `the whole of ${monthName}` : `${list} of ${monthName}`}, ${dates}`;
  }, [chosen, monthLabel, monthName, wholeMonth]);

  function toggleWeek(n: number) {
    setWeeks((cur) => {
      if (cur.includes(n)) return cur.length === 1 ? cur : cur.filter((w) => w !== n);
      return [...cur, n];
    });
  }

  /** The table as displayed: one level, the status chip, the sort. Export reads the same list. */
  const base = dim === "district" ? districts : units;
  const counts = useMemo(() => ({
    all: base.length,
    focus: base.filter((r) => r.isFocus).length,
    behind: base.filter((r) => r.pctSqme != null && r.pctSqme < 1).length,
    at: base.filter((r) => r.pctSqme != null && r.pctSqme >= 1).length,
  }), [base]);
  const lines = useMemo(() => {
    const kept = base.filter((r) =>
      status === "all" ? true
      : status === "focus" ? r.isFocus
      : status === "behind" ? r.pctSqme != null && r.pctSqme < 1
      : r.pctSqme != null && r.pctSqme >= 1);
    const val: Record<SortKey, (r: CapacityRow) => number | string | null> = {
      name: (r) => r.name,
      built: (r) => r.pctSqme,
      sold: (r) => r.pctSales,
      collected: (r) => r.pctColl,
      csos: (r) => r.csosActive,
      working: (r) => r.working,
      assigned: (r) => r.assigned,
      toHire: (r) => r.toHire,
      productivity: (r) => r.pctBuildProductivity,
      ratio: (r) => r.buildCollRatio,
    };
    const get = val[sort.key];
    const dir = sort.dir === "asc" ? 1 : -1;
    return [...kept].sort((a, b) => {
      const x = get(a), y = get(b);
      // Missing values sink to the bottom whichever way the column is sorted.
      if (x == null && y == null) return a.name.localeCompare(b.name);
      if (x == null) return 1;
      if (y == null) return -1;
      const c = typeof x === "string" ? x.localeCompare(String(y)) : x - Number(y);
      return c !== 0 ? c * dir : a.name.localeCompare(b.name);
    });
  }, [base, status, sort]);

  const dimLabel = dim === "territory" ? "Territory" : dim === "district" ? "District" : "Branch";
  const exportHeaders = [dimLabel, dim === "territory" ? "District" : dim === "district" ? "Territories" : "Country",
    ...(hasManagers ? ["Manager"] : []), "In focus", "SQM-E built", "SQM-E target", "Built % of target", "Sold % of target", "Collected % of target",
    "CSOs", "CSOs short", "CSO requirement (month)",
    "Masons working", "Masons assigned", "Masons to hire", "Mason requirement (month)", "Builds per mason", "Target builds per mason", "Builds to collections"];
  const exportRows: Cell[][] = lines.map((r) => [
    r.name, dim === "territory" ? r.parent : dim === "district" ? r.nTerritories : r.country,
    ...(hasManagers ? [r.manager ?? ""] : []), r.isFocus ? "yes" : "",
    Math.round(r.sqmeBuilt), r.sqmeTargetWeek == null ? "" : Math.round(r.sqmeTargetWeek),
    r.pctSqme == null ? "" : Math.round(r.pctSqme * 100),
    r.pctSales == null ? "" : Math.round(r.pctSales * 100),
    r.pctColl == null ? "" : Math.round(r.pctColl * 100),
    r.csosActive, r.csosShort == null ? "" : Math.round(r.csosShort), r.minCsos == null ? "" : Math.round(r.minCsos),
    r.working, r.assigned, r.toHire == null ? "" : Math.round(r.toHire), r.minMasons == null ? "" : Math.round(r.minMasons),
    r.buildsPerMason == null ? "" : Math.round(r.buildsPerMason * 10) / 10,
    r.usualBuildsPerMason == null ? "" : Math.round(r.usualBuildsPerMason * 10) / 10,
    r.buildCollRatio == null ? "" : Math.round(r.buildCollRatio * 100) / 100,
  ]);
  const exportName = `capacity-${country}-${dim}_${monthLabel.replace(/\s+/g, "-")}_W${weekKey}_${stamp()}`;

  const who = territory !== ANY ? territory
    : branch !== ANY ? branch
    : manager === ALL ? country
    : `${manager}'s ${head?.nTerritories ?? units.length} territories`;
  const its = territory === ANY && branch === ANY && manager !== ALL ? "their" : "its";
  const headline = head?.pctSqme != null
    ? `${who} built ${pctText(head.pctSqme)} of ${its} build target in ${weekPhrase}.`
    : `${who}: no build target set for ${weekPhrase}.`;
  const unitsWord = unitWord(unit);

  const go = (c: string, m: string) => router.replace(`/toolkit/capacity?country=${encodeURIComponent(c)}&month=${m}`);

  return (
    <div className="mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6">
      <header className="no-print flex flex-col gap-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>Capacity planning</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              Which {unitsWord} are furthest behind, and what is holding each one back. Weekly{hasManagers ? ", by manager" : ""}.
            </p>
            <p className="mt-0.5 text-xs" style={{ color: "var(--text-muted)" }}>
              Data as at {dataAsAt(builtAt, country)}. Salesforce syncs to BigQuery every 15 minutes.
            </p>
          </div>
          <ExportButtons filename={exportName} headers={exportHeaders} rows={exportRows} />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select label="Country" value={country} options={CAPACITY_COUNTRIES} onChange={(c) => go(c, month)} />
          <Select
            label="Month"
            value={month}
            options={[...months].reverse().map((m) => m.value)}
            optionLabel={(v) => months.find((m) => m.value === v)?.label ?? v}
            onChange={(m) => go(country, m)}
          />
          <Select label="Branch" value={branch} options={[ANY, ...branchOptions]} onChange={pickBranch} />
          {unit === "territory" && (
            <Select label="Territory" value={territory} options={[ANY, ...territoryOptions]} onChange={pickTerritory} />
          )}
          {hasManagers && (
            // The managers read as one set, so they stay on one line and scroll
            // together on a narrow screen rather than breaking across two.
            <div className="flex w-full items-center gap-2 overflow-x-auto sm:w-auto">
              <Chip label={ALL} count={managerCounts.reduce((t, [, n]) => t + n, 0)} on={manager === ALL}
                color="var(--text-secondary)" onClick={() => pickManager(ALL)} />
              {managerCounts.map(([m, n]) => (
                <Chip key={m} label={m} count={n} on={manager === m} color="var(--accent-strong)"
                  onClick={() => pickManager(manager === m ? ALL : m)} />
              ))}
            </div>
          )}
        </div>
        <WeekPicker weeks={weeksInMonth} selected={weeks} onToggle={toggleWeek}
          wholeMonth={wholeMonth} onWholeMonth={() => setWeeks(allWeeks)} />
      </header>

      <div id="print-area" className="flex flex-col gap-4">
        <section className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
          <p className="text-base font-medium leading-snug sm:text-lg" style={{ color: "var(--text-primary)", textWrap: "balance" }}>
            {headline}
          </p>
          {head && (
            <p className="mt-1 text-sm" style={{ color: "var(--text-muted)" }}>
              {fmtInt(head.working)} masons working in {weekPhrase}, {fmtInt(head.assigned)} assigned to a job with no timesheet yet
              {head.toHire == null ? "" : `, and ${fmtWhole(head.toHire)} to hire across ${head.territoriesShort} ${unitWord(unit, head.territoriesShort)} against the month's requirement of ${fmtWhole(head.minMasons)}`}.
              {" "}{fmtInt(head.csosActive)} CSOs signed or collected a contract
              {head.minCsos == null ? "" : `, ${fmtWhole(head.csosShort)} short across ${head.csosUnitsShort} ${unitWord(unit, head.csosUnitsShort)} against a requirement of ${fmtWhole(head.minCsos)}`}.
              {inProgress ? ` ${inProgress.weekLabel} is still in progress, so its figures will rise until it closes.` : ""}
            </p>
          )}
        </section>

        {head && (
          <div className="flex flex-col gap-1.5">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Score label="1 · Sales" pct={head.pctSales} moved={delta(head.pctSales4w, head.pctSalesPrev4w)} tone={SERIES_SALES}
                note={`${fmtInt(head.sold)} sold against a target of ${fmtWhole(head.salesTargetWeek)} contracts in ${weekPhrase}`} />
              <Score label="2 · Collections" pct={head.pctColl} moved={delta(head.pctColl4w, head.pctCollPrev4w)} tone={SERIES_COLL}
                note={`${fmtInt(head.collected)} collected against a target of ${fmtWhole(head.buildTargetWeek)} contracts in ${weekPhrase}`} />
              <Score label="3 · Builds" pct={head.pctSqme} moved={delta(head.pctSqme4w, head.pctSqmePrev4w)} tone={SERIES_BUILDS}
                note={`${fmtWhole(head.sqmeBuilt)} of ${fmtWhole(head.sqmeTargetWeek)} SQM-E in ${weekPhrase} · ${fmtInt(head.built)} builds`} />
              <Masons head={head} weekPhrase={weekPhrase} unit={unit} />
            </div>
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>
              The change beside each figure is the last four complete weeks against the four before.
            </p>
          </div>
        )}

        {lastWeek && (
          <CapacityCards rows={units} unit={unit} currency={currency} trend={trend} lastWeekStart={lastWeek.weekStart} byManager={hasManagers && manager === ALL}
            open={open}
            onOpen={(name) => setOpen((cur) => (cur?.from === "cards" && cur.name === name ? null : { level: unit, name, from: "cards" }))}
            onClose={() => setOpen(null)} />
        )}

        {lastWeek && (
          <CapacityTable lines={lines} dim={dim} unit={unit} onDim={(d) => { setDim(d); setOpen(null); }}
            sort={sort} onSort={setSort} status={status} counts={counts} onStatus={setStatus}
            trend={trend} lastWeekStart={lastWeek.weekStart}
            open={open}
            onOpen={(level, name) => setOpen({ level, name, from: "table" })}
            onClose={() => setOpen(null)} />
        )}

        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          Masons working plus Masons assigned plus Masons to hire equals the month&apos;s requirement. Masons working is anyone on a timesheet in the selected weeks, Masons assigned is anyone with a live job and no timesheet in them,
          and Masons to hire is each {unit}&apos;s own shortfall after both, added up and never netted. CSOs are distinct people who signed or collected a contract in the selected weeks, and CSOs short is each {unit}&apos;s own shortfall against the country&apos;s requirement per {unit}, added up the same way.
          Build productivity is against the standard of 4 builds per mason a month, the same standard the requirement is derived from, scaled to the weeks selected like every other target.
          Each week&apos;s productive target scales to the Wednesdays it contains, matching the bonus calculation. Week 4 is longer than the others, so in some months its target is double.
          The focus cards rank on four complete weeks against the four before, never week against week, because builds bunch at month end.
          About 1,500 timesheet lines across all countries carry no country, district or job and are left out of every mason count.
        </p>
      </div>
    </div>
  );
}

/** Percentage points between two ratios, or null when either side is missing. */
function delta(now: number | null, before: number | null): number | null {
  return now != null && before != null ? Math.round((now - before) * 100) : null;
}

/**
 * Scorecard, the same shape as the CSO overview: big value for the selected
 * weeks, the trailing four-week change beside it, a thin bar, the counts
 * behind the percentage in a muted line, and the verdict in the status colour.
 */
function Score({ label, pct, moved, tone, note }: { label: string; pct: number | null; moved: number | null; tone: string; note: string }) {
  const b = band(pct);
  return (
    <div className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${tone}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 flex items-baseline gap-2">
        <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</span>
        {moved != null && (
          <span className="text-xs font-medium" style={{ color: moved >= 0 ? "var(--good)" : "var(--critical)" }}>
            {moved > 0 ? "+" : ""}{moved} pts
          </span>
        )}
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <div className="h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: BAND_COLOR[b] }} />
      </div>
      <span className="mt-2 block text-xs" style={{ color: "var(--text-muted)" }}>{note}</span>
      <span className="mt-0.5 block text-xs font-medium" style={{ color: BAND_COLOR[b] }}>{BAND_LABEL[b]}</span>
    </div>
  );
}

/**
 * Headcount for the selected weeks as one model: Working, then Assigned, then
 * To hire, adding up to the month's requirement. The big number is Working;
 * the bar is the masons in place (working plus assigned) against the
 * requirement, so To hire is the unfilled part of it.
 */
function Masons({ head, weekPhrase, unit }: { head: CapacityRow; weekPhrase: string; unit: string }) {
  const need = head.minMasons == null ? null : Math.round(head.minMasons);
  const pct = need != null && need > 0 ? (head.working + head.assigned) / need : null;
  const b = band(pct);
  const toHire = head.toHire == null ? null : Math.round(head.toHire);
  return (
    <div className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${SERIES_BUILDS}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>4 · Masons working</span>
      <div className="mt-1 flex items-baseline gap-1.5">
        <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{fmtInt(head.working)}</span>
        <span className="text-sm" style={{ color: "var(--text-muted)" }}>in {weekPhrase}</span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <div className="h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: BAND_COLOR[b] }} />
      </div>
      <span className="mt-2 block text-xs" style={{ color: toHire != null && toHire > 0 ? "var(--critical)" : "var(--good)" }}>
        {toHire == null ? "no requirement set for the month" : toHire > 0 ? `${fmtInt(toHire)} to hire across ${head.territoriesShort} ${unitWord(unit, head.territoriesShort)} against the month's requirement` : `no ${unit} is short against the month's requirement`}
      </span>
      <span className="mt-0.5 block text-xs" style={{ color: "var(--text-muted)" }}>
        {fmtInt(head.working)} working, {fmtInt(head.assigned)} assigned to a job with no timesheet yet
        {toHire == null || need == null ? "" : `, ${fmtInt(toHire)} to hire against the month's requirement of ${fmtInt(need)}`}. Distinct people at this level, not the sum of the {unitWord(unit)}.
      </span>
    </div>
  );
}

/** Clickable count that doubles as a filter, the chip idiom from the individual CSO page. */
function Chip({ label, count, on, color, onClick }: { label: string; count: number; on: boolean; color: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick}
      className="flex min-h-11 items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium sm:min-h-0"
      style={{
        borderColor: on ? color : "var(--border)",
        background: on ? `color-mix(in srgb, ${color} 12%, var(--surface))` : "var(--surface)",
        color: "var(--text-primary)",
      }}>
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
      <span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtInt(count)}</span>
    </button>
  );
}

/**
 * Four week windows as press-to-toggle buttons plus a whole-month shortcut.
 * Managers sometimes want one week and sometimes a run of them, and a dropdown
 * hides which weeks are on. The week in progress is labelled so nobody mistakes
 * a half week for a bad one.
 */
function WeekPicker({
  weeks,
  selected,
  onToggle,
  wholeMonth,
  onWholeMonth,
}: {
  weeks: CapacityWeek[];
  selected: number[];
  onToggle: (n: number) => void;
  wholeMonth: boolean;
  onWholeMonth: () => void;
}) {
  const btn = "min-h-11 flex-1 rounded-md border px-2 py-1.5 text-sm font-medium sm:min-h-0 sm:flex-none";
  const style = (on: boolean) => ({
    background: on ? "var(--accent-strong)" : "var(--surface)",
    borderColor: on ? "var(--accent-strong)" : "var(--border)",
    color: on ? "#fff" : "var(--text-secondary)",
  });
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>Weeks. Tap to add or remove. Every figure below covers exactly the weeks selected.</span>
      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Weeks">
        {weeks.map((w) => {
          const on = selected.includes(w.weekNo);
          return (
            <button key={w.weekNo} type="button" onClick={() => onToggle(w.weekNo)} aria-pressed={on} className={btn} style={style(on)}>
              <span className="block leading-tight">W{w.weekNo}</span>
              <span className="block text-[11px] font-normal leading-tight" style={{ opacity: 0.85 }}>
                {dayRange(w.weekStart, w.weekEnd)}{w.isCurrent ? ", in progress" : ""}
              </span>
            </button>
          );
        })}
        <button type="button" onClick={onWholeMonth} aria-pressed={wholeMonth} className={btn} style={style(wholeMonth)}>
          <span className="block leading-tight">Whole month</span>
          <span className="block text-[11px] font-normal leading-tight" style={{ opacity: 0.85 }}>
            {weeks.length === 4 ? "all four weeks" : `${weeks.length} week${weeks.length === 1 ? "" : "s"} so far`}
          </span>
        </button>
      </div>
    </div>
  );
}

function Select({
  label, value, options, onChange, optionLabel, disabled = false,
}: {
  label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string; disabled?: boolean;
}) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} disabled={disabled}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm disabled:opacity-50 sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}
