"use client";

import { AGE_BANDS, BUCKETS, PENDING_CARDS, bucketColor, fmtInt, fmtRWF, fmtSqme, type GroupStat } from "@/lib/format";

type Stats = Record<string, GroupStat>;
const EMPTY: GroupStat = { count: 0, sqme: 0, rwf: 0, zeroPaid: 0, notFullyPaid: 0, median: 0, over30: 0, oldest: 0, ageBands: [0, 0, 0, 0] };

export default function Scorecards({
  stats,
  visible,
  completedThisMonth,
  completedLastMonth,
  selected,
  onSelect,
  pending,
  onPending,
}: {
  stats: Stats;
  visible: string[]; // bucket keys to render, in order
  completedThisMonth: number;
  completedLastMonth: number;
  selected: string | null;
  onSelect: (bucket: string) => void;
  /** The four pending cards, keyed by PENDING_CARDS key, drawn between the collected and varnished cards. */
  pending?: Record<string, GroupStat>;
  onPending?: (key: string) => void;
}) {
  const delta = completedThisMonth - completedLastMonth;
  // Both collected columns and "started" are approximate for wall jobs (see the note below).
  const isFuzzy = (k: string) => k.startsWith("4") || k.startsWith("5") || k.startsWith("6");
  const showWallNote = visible.some(isFuzzy);

  const keys = [...visible.filter((k) => k[0] <= "5"), ...(pending ? PENDING_CARDS.map((c) => c.key) : []), ...visible.filter((k) => k[0] >= "7")];
  // The funnel's eight steps, numbered in order: signed, collected (two), the four
  // pending steps, varnished. The opt-in backlog and completed cards are not steps.
  const funnel = keys.filter((k) => /^[345P]/.test(k) || k.startsWith("7"));
  const stepOf = (k: string) => funnel.indexOf(k) + 1;
  // The eight steps always read as a snake on wide layouts: 1 to 4 across the top,
  // then 5 under 4 running back to 8 at bottom left, so the last step sits where the
  // eye ends. Phones keep the plain 1 to 8 order. The opt-in cards do not break it:
  // the pre-2026 backlog sits in its own row above step 1, Completed in its own row
  // under step 8, where the path finishes.
  const snake = pending != null && funnel.length === 8;
  const before = snake ? keys.filter((k) => k[0] === "1" || k[0] === "2") : [];
  const after = snake ? keys.filter((k) => k[0] === "8") : [];
  const rows: { keys: string[]; cls: string }[] = snake
    ? [
        { keys: before, cls: "grid grid-cols-2 gap-3 lg:grid-cols-4" },
        { keys: funnel, cls: "grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-4" },
        { keys: after, cls: "grid grid-cols-2 gap-3 lg:grid-cols-4" },
      ].filter((r) => r.keys.length > 0)
    : [{ keys, cls: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-[repeat(var(--cols),minmax(0,1fr))]" }];
  const SNAKE_ORDER = ["lg:order-1", "lg:order-2", "lg:order-3", "lg:order-4", "lg:order-8", "lg:order-7", "lg:order-6", "lg:order-5"];
  const orderOf = (k: string) => (snake ? SNAKE_ORDER[stepOf(k) - 1] : "");
  const num = (k: string) => (stepOf(k) > 0 ? `${stepOf(k)}. ` : "");

  return (
    <div className="flex flex-col gap-2">
      {/* The eight steps: two rows of four, snaking, with any backlog above and Completed below. */}
      {rows.map((row) => (
      <div key={row.keys[0]} className={row.cls} style={{ ["--cols" as string]: Math.max(row.keys.length, 1) }}>
        {row.keys.map((key) => {
          const pc = PENDING_CARDS.find((c) => c.key === key);
          if (pc && pending) {
            const s = pending[key] ?? EMPTY;
            return (
              <button key={key} onClick={() => onPending?.(key)} title="Open the houses and the QA tasks waiting for this step"
                className={`flex flex-col gap-1 rounded-lg border p-3 text-left transition ${orderOf(key)}`}
                style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${bucketColor(key)}` }}>
                <span className="text-xs font-medium" style={{ color: "var(--text-secondary)" }}>{num(key)}{pc.label}</span>
                <span className="text-2xl font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(s.count)}</span>
                <span className="text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtSqme(s.sqme)} SQM-E · {fmtInt(s.over30)} over 30d</span>
                <AgeBar bands={s.ageBands} />
                <span className="text-xs font-medium" style={{ color: "var(--accent-ink)" }}>Open →</span>
              </button>
            );
          }
          const b = BUCKETS.find((x) => x.key === key)!;
          const s = stats[key] ?? EMPTY;
          const fuzzy = isFuzzy(key);
          return (
            <button
              key={key}
              onClick={() => onSelect(key)}
              className={`flex flex-col gap-1 overflow-hidden rounded-lg border p-3 text-left ${orderOf(key)}`}
              style={{
                background: "var(--surface)",
                borderColor: selected === key ? "var(--accent-strong)" : "var(--border)",
                borderTop: `3px solid ${bucketColor(key)}`,
                boxShadow: selected === key ? "inset 0 0 0 1px var(--accent-strong)" : "none",
              }}
            >
              <span className="text-xs leading-tight" style={{ color: "var(--text-secondary)" }}>
                {num(key)}{b.label}
                {fuzzy && (
                  <span title="Approximate for wall and plaster jobs. See note below." style={{ cursor: "help", color: "var(--text-muted)" }}>
                    {" "}ⓘ
                  </span>
                )}
              </span>
              <span className="flex flex-wrap items-baseline gap-x-1.5">
                <span className="text-2xl font-semibold" style={{ color: "var(--text-primary)" }}>{fmtInt(s.count)}</span>
                <span className="text-xs" style={{ color: "var(--text-muted)" }} title="Equivalent square metres: a floor counts its full area, plaster, paint and repairs count a third.">
                  {fmtSqme(s.sqme)} SQM-E
                </span>
              </span>
              <SubStat bucketKey={key} s={s} thisMonth={completedThisMonth} delta={delta} />
              <AgeBar bands={s.ageBands} />
            </button>
          );
        })}
      </div>
      ))}

      {/* legend + caveat */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs" style={{ color: "var(--text-muted)" }}>
        <span className="flex items-center gap-2">
          <span>Time in stage:</span>
          {AGE_BANDS.map((band) => (
            <span key={band.label} className="flex items-center gap-1">
              <span className="h-2 w-2 rounded-sm" style={{ background: band.color }} />
              {band.label}
            </span>
          ))}
        </span>
        <span>
          <b>SQM-E</b>{" "}is size in equivalent square metres: a floor counts its full area, plaster, paint, ceiling plaster and repairs count a third of theirs.
        </span>
        {showWallNote && (
          <span>
            ⓘ A job counts as <b>Started</b>{" "}from the first of: the masons&apos; first timesheet, the first plaster evaluation, the construction start date or anti-termite delivery. Until one of those is recorded it stays in the Collected columns. Dates in the future, and start or payment dates from before the contract was signed, are ignored. Materials available comes from the Salesforce tick, which not every territory records.
          </span>
        )}
      </div>
    </div>
  );
}

function AgeBar({ bands }: { bands: number[] }) {
  const total = bands.reduce((a, b) => a + b, 0);
  if (!total) return null;
  return (
    <div
      className="mt-1.5 flex h-1.5 w-full overflow-hidden rounded-full"
      title={AGE_BANDS.map((b, i) => `${b.label}: ${bands[i]}`).join(" · ")}
    >
      {bands.map((n, i) =>
        n > 0 ? <span key={i} style={{ width: `${(n / total) * 100}%`, background: AGE_BANDS[i].color }} /> : null,
      )}
    </div>
  );
}

function SubStat({ bucketKey, s, thisMonth, delta }: { bucketKey: string; s: GroupStat; thisMonth: number; delta: number }) {
  const muted = { color: "var(--text-muted)" } as const;
  if (bucketKey.startsWith("1") || bucketKey.startsWith("3")) {
    return <span className="text-xs" style={muted}>RWF {fmtRWF(s.rwf)} out · {fmtInt(s.zeroPaid)} zero-paid</span>;
  }
  if (bucketKey.startsWith("6")) {
    return (
      <span className="text-xs" style={{ color: s.over30 > 0 ? "var(--critical)" : "var(--text-muted)" }}>
        {fmtInt(s.over30)} over 30d
      </span>
    );
  }
  if (bucketKey.startsWith("7")) {
    return <span className="text-xs" style={muted}>oldest {fmtInt(s.oldest)}d</span>;
  }
  if (bucketKey.startsWith("8")) {
    return (
      <span className="text-xs" style={{ color: delta >= 0 ? "var(--good)" : "var(--critical)" }}>
        {delta >= 0 ? "▲" : "▼"} {fmtInt(thisMonth)} this month
      </span>
    );
  }
  return <span className="text-xs" style={muted}>median {fmtInt(s.median)}d waiting</span>;
}
