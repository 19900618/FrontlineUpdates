/**
 * The three country flags as inline SVG, simplified to their bands and a
 * plain emblem: crisp at 24px, and soft as a watermark. Inline so they need
 * no image request and render the same on every platform (emoji flags do
 * not show on Windows). Colours are the flags' own, not the theme's.
 */
export type FlagCode = "RW" | "UG" | "KE";

export default function Flag({ code, className, style, title }: { code: FlagCode; className?: string; style?: React.CSSProperties; title?: string }) {
  const common = { viewBox: "0 0 600 400", className, style, preserveAspectRatio: "xMidYMid slice" as const, role: title ? "img" : undefined, "aria-hidden": title ? undefined : true };
  if (code === "RW") {
    // Blue over yellow over green, the sun top right.
    const rays = Array.from({ length: 24 }, (_, i) => (i * 360) / 24);
    return (
      <svg {...common}>
        {title && <title>{title}</title>}
        <rect width="600" height="200" fill="#00A1DE" />
        <rect y="200" width="600" height="100" fill="#FAD201" />
        <rect y="300" width="600" height="100" fill="#20603D" />
        <g transform="translate(480 100)" stroke="#E5BE01" strokeWidth="6" strokeLinecap="round">
          {rays.map((a) => <line key={a} x1="0" y1="0" x2="0" y2="-58" transform={`rotate(${a})`} />)}
        </g>
        <circle cx="480" cy="100" r="26" fill="#E5BE01" />
      </svg>
    );
  }
  if (code === "UG") {
    // Six bands, the white disc with the crested crane in the middle.
    const bands = ["#000000", "#FCDC04", "#D90000", "#000000", "#FCDC04", "#D90000"];
    return (
      <svg {...common}>
        {title && <title>{title}</title>}
        {bands.map((c, i) => <rect key={i} y={i * (400 / 6)} width="600" height={400 / 6 + 1} fill={c} />)}
        <circle cx="300" cy="200" r="66" fill="#FFFFFF" />
        {/* the crested crane in profile: body, a curved neck, head with beak, legs */}
        <g fill="none" stroke="#8E9A9B" strokeWidth="8" strokeLinecap="round">
          <path d="M310 214 C318 200 316 184 324 172" />
        </g>
        <ellipse cx="294" cy="224" rx="28" ry="15" fill="#8E9A9B" />
        <path d="M318 226 C330 222 338 214 342 204 C334 212 326 216 318 218 Z" fill="#8E9A9B" />
        <circle cx="326" cy="168" r="8" fill="#8E9A9B" />
        <path d="M319 170 L304 174 L319 178 Z" fill="#111111" />
        <path d="M330 160 L336 146 L340 160 Z" fill="#D90000" />
        <g stroke="#111111" strokeWidth="3" strokeLinecap="round"><line x1="290" y1="238" x2="286" y2="256" /><line x1="300" y1="238" x2="302" y2="256" /></g>
      </svg>
    );
  }
  // Kenya: black, red and green with white edges, the shield and spears.
  return (
    <svg {...common}>
      {title && <title>{title}</title>}
      <rect width="600" height="400" fill="#FFFFFF" />
      <rect width="600" height="100" fill="#000000" />
      <rect y="116" width="600" height="168" fill="#BB0000" />
      <rect y="300" width="600" height="100" fill="#006600" />
      <g stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round">
        <line x1="212" y1="60" x2="388" y2="340" />
        <line x1="388" y1="60" x2="212" y2="340" />
      </g>
      <path d="M300 70 C348 90 366 150 366 200 C366 250 348 310 300 330 C252 310 234 250 234 200 C234 150 252 90 300 70 Z" fill="#BB0000" />
      <path d="M300 70 C252 90 234 150 234 200 C234 250 252 310 300 330 C286 300 278 250 278 200 C278 150 286 100 300 70 Z" fill="#000000" />
      <path d="M300 70 C348 90 366 150 366 200 C366 250 348 310 300 330 C314 300 322 250 322 200 C322 150 314 100 300 70 Z" fill="#000000" />
      <rect x="296" y="100" width="8" height="200" rx="4" fill="#FFFFFF" />
      <circle cx="300" cy="150" r="10" fill="#FFFFFF" /><circle cx="300" cy="250" r="10" fill="#FFFFFF" />
    </svg>
  );
}
