"use client";

import { useEffect, useMemo, useState } from "react";
import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import type { QualityData, QualityDim, QualityExtra, QualityGroup, SentBackHouse } from "@/lib/quality";
import type { Bucket, Period as LeadsPeriod } from "@/lib/leads-period";
import type { Scorecards as ScorecardData, ScoreTrend, Unit } from "@/lib/quality-scorecards";
import { fmtInt } from "@/lib/format";
import { stamp, type Cell } from "@/lib/export";
import { SERIES_QA } from "@/lib/workspace-ui";
import Spinner from "@/components/Spinner";
import QualityScorecards from "@/components/QualityScorecards";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { Boxes, DataTable, Kpi, type Col } from "@/components/ws/primitives";

/** How many of the weakest units carry the Focus mark, the same idea as every other page. */
const WORST_N = 5;

type Cut = Exclude<QualityDim, "total" | "month">;

const pct = (a: number, b: number): number | null => (b > 0 ? a / b : null);
const pctText = (v: number | null): string => (v == null ? "-" : `${Math.round(v * 100)}%`);
/** At or above 95 reads well, 85 to 95 is watchable, below 85 needs someone to look. */
const band = (v: number | null): "good" | "watch" | "poor" | "none" =>
  v == null ? "none" : v >= 0.95 ? "good" : v >= 0.85 ? "watch" : "poor";
const BAND_INK: Record<string, string> = { good: "var(--good)", watch: "var(--warning)", poor: "var(--critical)", none: "var(--text-muted)" };
const pill = (v: number | null) => ({
  background: v == null ? "transparent" : `color-mix(in srgb, ${BAND_INK[band(v)]} 14%, transparent)`,
  color: BAND_INK[band(v)],
});

/**
 * Quality for one country: four scorecards, the last six periods, then the
 * country's units ranked worst first with the evaluations behind any of
 * them, and the two summary boxes. Every figure is read from the
 * country-filtered query; nothing here re-derives a rate.
 *
 * The scope in the filter bar narrows every query on the page (the server
 * re-runs them), and a scoped territory or branch also opens its sent-back
 * houses under the table.
 */
export default function QualityBoard(props: {
  country: CapacityCountry; slug: string; calendar: CapacityWeek[]; years: number[]; userEmail: string | null; freshness: string;
  /** The country's territories or branches, for the filter bar's dropdown. */
  units: string[];
  leads: LeadsPeriod; data: QualityData; scorecards: ScorecardData; scoreTrend: ScoreTrend[]; buckets: Bucket[];
}) {
  const { country, slug, calendar, years, userEmail, freshness } = props;
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} years={years} userEmail={userEmail} freshness={freshness} navigate="all" weekMode="single" units={props.units}>
      {(s) => <Body s={s} leads={props.leads} data={props.data} scorecards={props.scorecards} scoreTrend={props.scoreTrend} buckets={props.buckets} />}
    </WorkspaceShell>
  );
}

function Body({ s, leads, data, scorecards, scoreTrend, buckets }: {
  s: WsState; leads: LeadsPeriod; data: QualityData; scorecards: ScorecardData; scoreTrend: ScoreTrend[]; buckets: Bucket[];
}) {
  const { country, scope } = s;
  const rwanda = country === "Rwanda";
  /** The unit the queries were narrowed to: the scope in the bar. */
  const unit: Unit = scope ? { level: scope.level === "territory" ? "territory" : "branch", name: scope.name } : null;
  /**
   * Which level the table lists. Rwanda is run branch then territory, so both are
   * worth seeing; Uganda and Kenya have almost no territory on their evaluations,
   * so there the table is branches and nothing else.
   */
  const dim: Cut = rwanda && s.dim === "district" ? "branch" : "unit";
  const unitWord = rwanda && dim === "unit" ? "territory" : "branch";
  const total = data.groups.find((g) => g.dim === "total");

  const allTerritories = useMemo(
    () => data.groups.filter((g) => g.dim === "unit").map((g) => ({ name: g.name, parent: g.parent })),
    [data.groups],
  );
  /** A scoped territory keeps its branch in view, so the pair reads as a pair. */
  const branchOfUnit = unit?.level === "territory"
    ? (allTerritories.find((t) => t.name === unit.name)?.parent ?? s.scopeParent)
    : unit?.level === "branch" ? unit.name : null;
  const units = useMemo(
    () => data.groups
      .filter((g) => g.dim === dim)
      .filter((g) => !unit || (unit.level === "territory"
        ? (dim === "unit" ? g.name === unit.name : g.name === branchOfUnit)
        : (dim === "unit" ? g.parent === unit.name : g.name === unit.name)))
      .sort((a, b) => (pct(a.passed, a.evals) ?? 1) - (pct(b.passed, b.evals) ?? 1)),
    [data.groups, dim, unit, branchOfUnit],
  );
  const worst = useMemo(() => new Set(units.length > WORST_N ? units.slice(0, WORST_N).map((u) => u.name) : []), [units]);
  const extras = useMemo(() => new Map(data.extras.filter((e) => e.dim === dim).map((e) => [e.name, e])), [data.extras, dim]);
  const parentOf = useMemo(
    () => new Map(dim === "unit" ? units.flatMap((u) => (u.parent && u.parent !== u.name ? [[u.name, u.parent] as const] : [])) : []),
    [units, dim],
  );

  // The scoped unit's own row, for the panel under the table.
  const scopeDim: Cut | null = scope ? (scope.level === "territory" ? "unit" : "branch") : null;
  const scopeGroup = scope && scopeDim ? data.groups.find((g) => g.dim === scopeDim && g.name === scope.name) : undefined;

  const t = scopeGroup ?? total;
  // Every evaluation is a pass, a not ready, or a rework instruction, unless its decision is blank.
  const undecided = t ? t.evals - t.passed - t.failed - t.notReady : 0;

  const open = (u: QualityGroup) => {
    const level = dim === "unit" ? (rwanda ? "territory" : "branch") : "district";
    s.setScope({ level, name: u.name }, level === "territory" ? parentOf.get(u.name) ?? null : null);
  };

  const cols: Col<QualityGroup>[] = [
    { key: "name", header: unitWord === "territory" ? "Territory" : "Branch", mobile: "title", sort: (u) => u.name, copy: (u) => u.name, cell: (u) => (
      <span className="flex flex-col">
        <button type="button" onClick={() => open(u)} className="text-left font-semibold underline decoration-[var(--border)] underline-offset-4" style={{ color: "var(--text-primary)" }}>{u.name}</button>
        {parentOf.get(u.name) && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{parentOf.get(u.name)}</span>}
      </span>
    ) },
    { key: "pass", header: "Pass", right: true, sort: (u) => pct(u.passed, u.evals), copy: (u) => { const p = pct(u.passed, u.evals); return p == null ? "" : Math.round(p * 100); }, copyHeader: "Pass rate %", cell: (u) => {
      const p = pct(u.passed, u.evals);
      return (
        <span className="flex flex-col items-end">
          <span className="rounded px-2 py-0.5 text-sm font-semibold tabular-nums" style={pill(p)}>{pctText(p)}</span>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(u.evals)} checks</span>
        </span>
      );
    } },
    { key: "fail", header: "Fail", right: true, sort: (u) => pct(u.failed, u.evals), copy: (u) => u.failed, copyHeader: "Sent back", cell: (u) => (
      <span className="flex flex-col items-end tabular-nums" style={{ color: u.failed > 0 ? "var(--critical)" : "inherit" }}>
        <span>{pctText(pct(u.failed, u.evals))}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(u.failed)} {u.failed === 1 ? "check" : "checks"}</span>
      </span>
    ) },
    { key: "notready", header: "Not ready", right: true, sort: (u) => pct(u.notReady, u.evals), copy: (u) => u.notReady, cell: (u) => (
      <span className="flex flex-col items-end tabular-nums" style={{ color: u.notReady > 0 ? "var(--warning)" : "inherit" }}>
        <span>{pctText(pct(u.notReady, u.evals))}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(u.notReady)} {u.notReady === 1 ? "check" : "checks"}</span>
      </span>
    ) },
    { key: "final", header: "Ready for final", right: true, sort: (u) => extras.get(u.name)?.waitingFinal ?? null, cell: (u) => { const x = extras.get(u.name); return <span className="tabular-nums">{x ? fmtInt(x.waitingFinal) : "-"}</span>; } },
    { key: "match", header: "TL and QA matching", right: true, sort: (u) => { const x = extras.get(u.name); return x && x.tlPairs > 0 ? pct(x.tlMatched, x.tlPairs) : null; },
      copy: (u) => { const x = extras.get(u.name); const a = x && x.tlPairs > 0 ? pct(x.tlMatched, x.tlPairs) : null; return a == null ? "" : Math.round(a * 100); }, copyHeader: "TL and QA matching %",
      cell: (u) => {
        const x = extras.get(u.name);
        const agree = x && x.tlPairs > 0 ? pct(x.tlMatched, x.tlPairs) : null;
        return (
          <span className="flex flex-col items-end tabular-nums">
            {agree == null ? <span style={{ color: "var(--text-muted)" }}>none</span> : <span>{pctText(agree)}</span>}
            {x && x.tlPairs > 0 && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(x.tlPairs)} pairs</span>}
          </span>
        );
      } },
    { key: "cases", header: "Cases open", right: true, sort: (u) => extras.get(u.name)?.casesRaised ?? 0, cell: (u) => {
      const x = extras.get(u.name);
      return x && x.casesRaised > 0 ? <span style={{ color: "var(--warning)" }}>{fmtInt(x.casesRaised)}</span> : <span style={{ color: "var(--text-muted)" }}>none</span>;
    } },
  ];

  const exportRows: Cell[][] = units.map((u) => [
    u.name, u.evals, u.passed, u.failed, u.notReady,
    pct(u.passed, u.evals) == null ? "" : Math.round((pct(u.passed, u.evals) as number) * 100),
    u.jobs, u.masons, u.evaluators, u.spotChecked, u.agreed, u.avgDaysSignedToEval ?? "",
  ]);

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>Quality, {s.scopeLabel}</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>{leads.label} · {leads.range}</p>
      </div>
      <BarExports filename={`quality-${country}-${unitWord}_${leads.from}_to_${leads.to}_${stamp()}`}
        headers={[unitWord === "territory" ? "Territory" : "Branch", "Evaluations", "Passed", "Sent back", "Not ready",
          "Pass rate %", "Jobs", "Masons", "Evaluators", "Spot checked", "Manager agreed", "Avg days signed to eval"]}
        rows={exportRows} />

      <QualityScorecards country={country} period={leads} data={scorecards} trend={scoreTrend} buckets={buckets} unit={unit} />

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
            {scope ? (scope.level === "district" && dim === "unit" ? `Territories in ${scope.name}` : scope.name) : `${unitWord === "territory" ? "Territories" : "Branches"} to focus on`}
          </h2>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>Weakest pass rate first. Tap a name to open it.</span>
        </div>
        <DataTable rows={units} cols={cols} keyOf={(u) => u.name} mark={(u) => worst.has(u.name)} copyName="the table" empty="No QA check in this period."
          note={<>
            Ranked on pass rate, weakest first.{worst.size > 0 && ` Focus marks the ${WORST_N} with the lowest pass rate.`}
            {" "}Pass, fail and not ready are QA checks in this period, each shown as a share of them with its own count.
            Ready for final counts houses that have been varnished, have served the waiting period their product needs and have not
            yet passed a final evaluation, as things stand today rather than within this period.
            TL and QA matching counts territory lead decisions paired with the QA decision that followed, which is the same pairing
            the scorecard above uses. Cases open is every customer case nobody has closed yet, whenever it was raised, which is what
            the scorecard counts too; neither is filtered by the period.
          </>} />
      </section>

      {scope && scopeDim && (
        <Drill key={`${scope.level}|${scope.name}`} country={country} period={leads} dim={scopeDim} name={scope.name} unit={scopeGroup} />
      )}

      <QualityBoxes country={country} scorecards={scorecards} outstanding={data.sentBackOutstanding} />

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        A pass is the evaluator&apos;s decision of Pass. Not ready means the evaluator arrived and the job was unfinished, so the visit was wasted.
        Sent back is every other decision, which in practice is a rework instruction: repair minor issues, redo, repair masking, repair VX or
        intervention needed. Rates are counted from the evaluations themselves at each level, never added up from the level below.
        The scorecards at the top treat an evaluation as QA unless its department is District or Construction, counting a blank
        department as QA. Department only began to be filled in in April 2026, so in a window before then every evaluation counts
        as QA, whoever carried it out.
        {undecided > 0 && ` ${fmtInt(undecided)} ${undecided === 1 ? "evaluation has" : "evaluations have"} no decision recorded, so ${undecided === 1 ? "it counts" : "they count"} in the total but in none of the three.`}
        {rwanda
          ? " A territory comes from the job's own record in the customer journey; the few evaluations whose job has none are counted in the country total but listed under no territory."
          : " Branch comes from the evaluation row itself."}
      </p>
    </>
  );
}

/**
 * What the period came to, and what it leaves to do. Both are written from the
 * scorecards above rather than recounted, so a sentence here and the card it came
 * from can never disagree.
 */
function QualityBoxes({ country, scorecards, outstanding }: { country: string; scorecards: ScorecardData; outstanding: number }) {
  const jobs = scorecards.firstEval.reduce((n, p) => n + p.jobs, 0);
  const passed = scorecards.firstEval.reduce((n, p) => n + p.passed, 0);
  const failed = scorecards.firstEval.reduce((n, p) => n + p.failed, 0);
  const ready = scorecards.finalEval.reduce((n, p) => n + p.ready, 0);
  const { matched, pairs } = scorecards.matching;
  const open = scorecards.cases.stillOpen;
  const one = (n: number, a: string, b: string) => (n === 1 ? a : b);
  return (
    <Boxes
      happened={[
        jobs > 0
          ? `${pctText(pct(passed, jobs))} of houses in ${country} passed their first QA evaluation, ${pctText(pct(failed, jobs))} did not.`
          : `No house in ${country} finished its first QA evaluations in this period.`,
        pairs > 0
          ? `Territory leads and QA agreed on ${pctText(pct(matched, pairs))} of the ${fmtInt(pairs)} evaluations they both looked at.`
          : "No territory lead evaluation was paired with a QA evaluation in this period.",
        `${fmtInt(open)} customer ${one(open, "case is", "cases are")} still open.`,
      ]}
      next={[
        outstanding > 0
          ? `${fmtInt(outstanding)} ${one(outstanding, "house was", "houses were")} sent back and still ${one(outstanding, "needs", "need")} rework.`
          : "Nothing QA sent back in this period is still waiting on rework.",
        ready > 0
          ? `${fmtInt(ready)} finished ${one(ready, "build is", "builds are")} ready and waiting for a final evaluation.`
          : "No finished build is waiting for a final evaluation.",
        open > 0 ? `${fmtInt(open)} customer ${one(open, "case is", "cases are")} still open.` : "No customer case is open.",
      ]} />
  );
}

/**
 * One territory or branch opened under the table: a row of stat tiles and
 * the houses the unit still owes rework on. A house is on the list when QA
 * sent it back and, from that day onward, no District or Construction
 * evaluation has passed the same stage and no evaluation at all has happened
 * at the stage after it. Fetched when the unit is opened.
 */
function Drill({ country, period, dim, name, unit }: { country: string; period: LeadsPeriod; dim: Cut; name: string; unit: QualityGroup | undefined }) {
  const [rows, setRows] = useState<SentBackHouse[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    const qs = new URLSearchParams({ country, from: period.from, to: period.to, dim, name });
    fetch(`/api/quality/rows?${qs}`)
      .then(async (r) => {
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? r.statusText);
        if (live) setRows(j.rows as SentBackHouse[]);
      })
      .catch((e) => { if (live) setError(e instanceof Error ? e.message : String(e)); });
    return () => { live = false; };
  }, [country, period.from, period.to, dim, name]);

  const p = unit ? pct(unit.passed, unit.evals) : null;
  const oldest = rows && rows.length > 0 ? rows[0].daysSince : null;

  const cols: Col<SentBackHouse>[] = [
    { key: "job", header: "House", mobile: "title", sort: (r) => r.job, copy: (r) => r.job, cell: (r) => <span className="font-medium" style={{ color: "var(--text-primary)" }}>{r.job}</span> },
    { key: "stage", header: "Stage", sort: (r) => r.stage, cell: (r) => r.stage },
    { key: "decision", header: "QA said", sort: (r) => r.decision, cell: (r) => (
      <span className="rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: "color-mix(in srgb, var(--critical) 14%, transparent)", color: "var(--critical)" }}>{r.decision}</span>
    ) },
    { key: "date", header: "Sent back", sort: (r) => r.date, cell: (r) => <span className="whitespace-nowrap tabular-nums">{r.date}</span> },
    { key: "days", header: "Days waiting", right: true, sort: (r) => r.daysSince, cell: (r) => (
      <span className="tabular-nums" style={{ color: r.daysSince > 30 ? "var(--critical)" : r.daysSince > 14 ? "var(--warning)" : "inherit" }}>{fmtInt(r.daysSince)}</span>
    ) },
    { key: "mason", header: "Mason", sort: (r) => r.mason ?? null, cell: (r) => r.mason ?? "-" },
    { key: "evaluator", header: "Evaluator", sort: (r) => r.evaluator, cell: (r) => r.evaluator },
    { key: "comment", header: "Comment", copy: (r) => r.comment ?? "", cell: (r) => <span className="text-xs">{r.comment ? r.comment : <span style={{ color: "var(--text-muted)" }}>no comment</span>}</span> },
  ];

  return (
    <section className="flex flex-col gap-3 rounded-xl border-l-2 p-5" style={{ background: "var(--page)", borderColor: "var(--accent-strong)" }}>
      <div>
        <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{name}</h3>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>{[unit?.parent, unit ? `${fmtInt(unit.jobs)} houses` : null].filter(Boolean).join(" · ")}</p>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi label="QA checks" big={unit ? fmtInt(unit.evals) : "-"} tone={SERIES_QA} sub="Compaction, screed and prior paint, by QA, in this period." />
        <Kpi label="Passed" big={pctText(p)} tone={BAND_INK[band(p)]} lines={unit ? [`${fmtInt(unit.passed)} of ${fmtInt(unit.evals)} first time`] : undefined} sub={unit ? undefined : "No check in this period."} />
        <Kpi label="Sent back" big={unit ? fmtInt(unit.failed) : "-"} tone="var(--critical)" sub="QA instructed rework on these projects." />
        <Kpi label="Still owed" big={rows ? fmtInt(rows.length) : "…"} tone="var(--warning)"
          sub={oldest == null ? "Nothing sent back here is still outstanding." : `Nobody has cleared these since. The oldest has waited ${fmtInt(oldest)} days.`} />
      </div>
      <div>
        <h4 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
          Houses still sent back
          {rows ? <span className="ml-2 font-normal" style={{ color: "var(--text-muted)" }}>{rows.length === 300 ? "oldest 300" : `${fmtInt(rows.length)} of them`}</span> : null}
        </h4>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          QA sent these back and, since that day, no district evaluation has passed the same stage and no evaluation has happened at the stage after it. Longest-waiting first.
        </p>
      </div>
      {error && <p className="text-sm" style={{ color: "var(--critical)" }}>Could not load the houses: {error}</p>}
      {!rows && !error && <p className="text-sm" style={{ color: "var(--text-muted)" }}><Spinner label="Loading houses…" /></p>}
      {rows && (
        <DataTable rows={rows} cols={cols} keyOf={(r) => r.surveyId} pageSize={25} copyName="the houses"
          empty="Nothing outstanding: every house QA sent back in this period has since been passed again or moved on to the next stage." />
      )}
    </section>
  );
}

export type { QualityExtra };
