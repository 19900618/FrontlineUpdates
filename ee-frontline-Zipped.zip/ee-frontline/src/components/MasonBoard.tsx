"use client";

import { useEffect, useMemo, useState } from "react";
import type { Dataset, Config, Priority } from "@/lib/mason/types";
import { solve, eligibleJobs, band, BAND_LABEL } from "@/lib/mason/solver";
import { fmtInt } from "@/lib/format";

type Assign = Record<string, string | null>;
const BAND_COLOR: Record<string, string> = { starved: "var(--critical)", under: "var(--warning)", onTarget: "var(--good)", over: "var(--accent)" };
const POOL_CAP = 140; // max cards rendered in the "to assign" column

function fmtK(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (a >= 1e3) return Math.round(n / 1e3) + "K";
  return String(Math.round(n));
}
const PRIORITIES: { key: Priority; label: string }[] = [
  { key: "balanced", label: "Balanced" }, { key: "oldest", label: "Oldest first" },
  { key: "mostPaid", label: "Most paid" }, { key: "biggest", label: "Biggest first" },
];

export default function MasonBoard({ dataset }: { dataset: Dataset }) {
  const [ds, setDs] = useState<Dataset>(dataset);
  const [country, setCountry] = useState(dataset.meta.country);
  const [unit, setUnit] = useState(dataset.meta.unit);
  const [sub, setSub] = useState(dataset.meta.sub || "All");
  const [cap, setCap] = useState(dataset.meta.defaultCapacity || 90);
  const [priority, setPriority] = useState<Priority>("balanced");
  const [tab, setTab] = useState<"overview" | "board">("overview");
  const [loading, setLoading] = useState(false);
  const [assignment, setAssignment] = useState<Assign>(() =>
    solve(dataset.jobs, dataset.masons, {
      cap: dataset.meta.defaultCapacity || 90, minPaid: 0,
      products: ["Floor", "Plaster", "Paint"], priority: "balanced", maxAgeDays: 730, sectorFallback: false,
    }),
  );
  const [dragId, setDragId] = useState<string | null>(null);
  const [poolSearch, setPoolSearch] = useState("");

  const cfg: Config = useMemo(
    () => ({ cap, minPaid: 0, products: ["Floor", "Plaster", "Paint"], priority, maxAgeDays: 730, sectorFallback: false }),
    [cap, priority],
  );

  const primaryLabel = country === "Rwanda" ? "District" : "Branch";
  const subLabel = country === "Rwanda" ? "Territory" : "District";

  // country / unit / sub -> refetch (unit "" lets the server pick the largest unit)
  useEffect(() => {
    const wantSub = sub === "All" ? "" : sub;
    const same = country === ds.meta.country && (unit === "" || unit === ds.meta.unit) && wantSub === ds.meta.sub;
    if (same) {
      if (unit === "" && ds.meta.unit) setUnit(ds.meta.unit);
      return;
    }
    let cancelled = false;
    setLoading(true);
    fetch(`/api/mason?country=${encodeURIComponent(country)}&unit=${encodeURIComponent(unit)}&sub=${encodeURIComponent(wantSub)}`)
      .then((r) => r.json())
      .then((d) => { if (!cancelled && d.dataset) setDs(d.dataset); })
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [country, unit, sub, ds.meta.country, ds.meta.unit, ds.meta.sub]);

  // (re)solve into a proposed assignment whenever data or config changes
  useEffect(() => { setAssignment(solve(ds.jobs, ds.masons, cfg)); }, [ds, cfg]);

  const eligible = useMemo(() => eligibleJobs(ds.jobs, cfg), [ds, cfg]);
  const poolJobs = useMemo(() => {
    const q = poolSearch.trim().toLowerCase();
    return eligible.filter((j) => !assignment[j.id] && (!q || `${j.customer} ${j.village}`.toLowerCase().includes(q)));
  }, [eligible, assignment, poolSearch]);

  const loads = useMemo(() => {
    const l: Record<string, { sqm: number; count: number }> = {};
    ds.masons.forEach((m) => (l[m.key] = { sqm: 0, count: 0 }));
    for (const j of eligible) { const a = assignment[j.id]; if (a && l[a]) { l[a].sqm += j.sqm; l[a].count += 1; } }
    return l;
  }, [assignment, eligible, ds]);

  // Overview list: fewest-filled first (reacts to load). Board: stable order so columns never jump while dragging.
  const masonsSorted = useMemo(
    () => [...ds.masons].sort((a, b) => (loads[a.key]?.sqm ?? 0) / cap - (loads[b.key]?.sqm ?? 0) / cap),
    [ds, loads, cap],
  );
  const masonsStable = useMemo(() => [...ds.masons].sort((a, b) => b.completedSqm - a.completedSqm), [ds]);

  // headline numbers
  const assignedJobs = Object.values(loads).reduce((s, l) => s + l.count, 0);
  const assignedSqme = Math.round(Object.values(loads).reduce((s, l) => s + l.sqm, 0));
  const capacityTotal = ds.masons.length * cap;
  const waitingCovered = eligible.length - assignedJobs; // covered work that doesn't fit this month
  const bands = useMemo(() => {
    const b = { starved: 0, under: 0, onTarget: 0, over: 0 };
    ds.masons.forEach((m) => { b[band(loads[m.key]?.sqm ?? 0, cap)]++; });
    return b;
  }, [ds, loads, cap]);

  // coverage by sector
  const sectors = useMemo(() => {
    const m = new Map<string, { covered: number; uncovered: number }>();
    for (const j of ds.jobs) {
      if (!j.sector) continue;
      const k = j.sector;
      const e = m.get(k) ?? { covered: 0, uncovered: 0 };
      if (j.uncovered) e.uncovered += j.sqm; else e.covered += j.sqm;
      m.set(k, e);
    }
    return [...m.entries()].map(([sector, v]) => ({ sector, ...v, total: v.covered + v.uncovered }))
      .sort((a, b) => b.total - a.total).slice(0, 10);
  }, [ds]);

  function drop(target: string | null) {
    if (!dragId) return;
    setAssignment((prev) => ({ ...prev, [dragId]: target }));
    setDragId(null);
  }

  const ccy = "RWF";
  const m = ds.meta;

  return (
    <div className="mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6">
      <header className="flex flex-col gap-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>Mason scheduler</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>Suggested allocation of active work across masons, based on capacity and coverage. Review and adjust before finalising.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select label="Country" value={country} options={["Rwanda", "Uganda", "Kenya"]} onChange={(v) => { setCountry(v); setUnit(""); setSub("All"); }} />
            <Select label={primaryLabel} value={ds.meta.unit} options={ds.meta.units.length ? ds.meta.units : [ds.meta.unit]} onChange={(v) => { setUnit(v); setSub("All"); }} />
            <Select label={subLabel} value={sub} options={["All", ...ds.meta.subs]} onChange={setSub} />
            <Select label="Priority" value={priority} options={PRIORITIES.map((p) => p.key)} optionLabel={(k) => PRIORITIES.find((p) => p.key === k)?.label ?? k} onChange={(v) => setPriority(v as Priority)} />
            <label className="flex items-center gap-2 text-sm" style={{ color: "var(--text-secondary)" }}>
              <span style={{ color: "var(--text-muted)" }}>Target/mason</span>
              <input type="range" min={60} max={150} step={5} value={cap} onChange={(e) => setCap(Number(e.target.value))} />
              <span className="tabular-nums" style={{ color: "var(--text-primary)", fontWeight: 600 }}>{cap}</span>
            </label>
          </div>
        </div>
        <div className="inline-flex gap-1 self-start rounded-lg border p-1" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
          <TabBtn on={tab === "overview"} onClick={() => setTab("overview")}>Overview</TabBtn>
          <TabBtn on={tab === "board"} onClick={() => setTab("board")}>Plan board</TabBtn>
        </div>
      </header>

      {m.warning && (
        <div className="rounded-lg border p-3 text-sm" style={{ borderColor: "var(--critical)", background: "color-mix(in srgb, var(--critical) 7%, var(--surface))", color: "var(--text-secondary)" }}>
          Data warning: {m.warning}
        </div>
      )}
      {loading && <p className="text-sm" style={{ color: "var(--text-muted)" }}>Loading…</p>}

      {/* ===================== OVERVIEW ===================== */}
      {tab === "overview" && (
        <>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Work to build" big={fmtInt(m.totalSqm)} unit="SQM-E" sub={`${fmtInt(m.totalJobs)} active jobs · ${m.villagesTotal} villages`} />
            <Stat label="Monthly mason capacity" big={fmtInt(capacityTotal)} unit="SQM-E" sub={`${m.masonCount} masons × ${cap} target · backlog is ${(m.totalSqm / Math.max(1, capacityTotal)).toFixed(1)}× monthly capacity`} />
            <Stat label="Uncovered work" big={fmtInt(m.uncoveredSqm)} unit="SQM-E" sub={`${fmtInt(m.uncoveredJobs)} jobs in ${m.villagesTotal - m.villagesCovered} villages with no assigned mason`} tone="accent" />
            <Stat label="Beyond monthly capacity" big={fmtInt(Math.max(0, m.coveredSqm - assignedSqme))} unit="SQM-E" sub={`${fmtInt(Math.max(0, waitingCovered))} covered jobs exceed this month's capacity`} tone="warn" />
          </div>

          <div className="rounded-md border-l-2 px-3 py-2 text-sm" style={{ borderColor: "var(--accent)", background: "color-mix(in srgb, var(--accent) 5%, var(--surface))", color: "var(--text-secondary)" }}>
            This period's allocation covers <b style={{ color: "var(--text-primary)" }}>{fmtInt(assignedSqme)} SQM-E</b> across <b style={{ color: "var(--text-primary)" }}>{ds.masons.length}</b> masons ({fmtInt(assignedJobs)} jobs). {fmtInt(Math.max(0, waitingCovered))} covered jobs and {fmtInt(m.uncoveredJobs)} uncovered jobs remain unallocated.
          </div>

          {/* mason load */}
          <section className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Allocation vs each mason's target</h2>
              <span className="text-xs" style={{ color: "var(--text-muted)" }}>Ordered by utilisation · marker = {cap} SQM-E target</span>
            </div>
            <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs" style={{ color: "var(--text-muted)" }}>
              {(["starved", "under", "onTarget", "over"] as const).map((b) => (
                <span key={b} className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: BAND_COLOR[b] }} />{BAND_LABEL[b]} ({bands[b]})</span>
              ))}
            </div>
            <div className="mt-3 flex flex-col">
              {masonsSorted.map((mn) => {
                const load = loads[mn.key]?.sqm ?? 0;
                const cnt = loads[mn.key]?.count ?? 0;
                const bd = band(load, cap);
                const fill = Math.min(load / cap, 1.25) / 1.25 * 100;
                return (
                  <div key={mn.key} className="grid grid-cols-[minmax(140px,1fr)_2fr_150px] items-center gap-3 border-t py-2" style={{ borderColor: "var(--border)" }}>
                    <div><div className="truncate text-sm font-medium" style={{ color: "var(--text-primary)" }} title={mn.name}>{mn.name}</div><div className="truncate text-xs" style={{ color: "var(--text-muted)" }} title={mn.subs.join(", ")}>{mn.subs.length ? mn.subs.join(", ") : "unassigned"} · 4-wk output {fmtInt(mn.completedSqm)}</div></div>
                    <div className="relative h-5 rounded" style={{ background: "var(--surface-2, #faf8f3)", border: "1px solid var(--border)" }}>
                      <div className="absolute inset-y-0 left-0 rounded" style={{ width: `${fill}%`, background: `color-mix(in srgb, ${BAND_COLOR[bd]} 26%, transparent)`, borderRight: `2px solid ${BAND_COLOR[bd]}` }} />
                      <div className="absolute inset-y-[-3px] w-0.5" style={{ left: "80%", background: "var(--text-primary)", opacity: 0.45 }} />
                    </div>
                    <div className="flex items-baseline justify-end gap-1.5 text-right">
                      <span className="text-sm font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(load)}</span>
                      <span className="text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>/ {cap}</span>
                      <span className="w-full text-xs" style={{ color: BAND_COLOR[bd] }}>{cnt} jobs · {BAND_LABEL[bd]}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {/* demand gap */}
            <section className="rounded-lg border p-4" style={{ background: "color-mix(in srgb, var(--accent) 4%, var(--surface))", borderColor: "color-mix(in srgb, var(--accent) 22%, var(--border))" }}>
              <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Uncovered villages</h3>
              <p className="mb-2 text-xs" style={{ color: "var(--text-muted)" }}>Active work in villages with no assigned mason, largest first.</p>
              {ds.uncoveredVillages.slice(0, 8).map((v) => {
                const max = ds.uncoveredVillages[0]?.sqm || 1;
                return (
                  <div key={v.village + v.sector} className="flex items-center gap-3 border-t py-2 first:border-0" style={{ borderColor: "var(--border)" }}>
                    <div className="min-w-0 flex-1"><div className="truncate text-sm font-medium" style={{ color: "var(--text-primary)" }}>{v.village}</div><div className="text-xs" style={{ color: "var(--text-muted)" }}>{v.sector} · {v.jobs} jobs</div></div>
                    <div className="h-2 w-20 overflow-hidden rounded" style={{ background: "var(--border)" }}><div className="h-full" style={{ width: `${(v.sqm / max) * 100}%`, background: "var(--accent)" }} /></div>
                    <div className="w-20 text-right text-sm font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(v.sqm)}</div>
                  </div>
                );
              })}
              {ds.uncoveredVillages.length > 8 && (
                <p className="mt-2 text-xs" style={{ color: "var(--text-muted)" }}>+ {ds.uncoveredVillages.length - 8} more · {fmtInt(m.uncoveredJobs)} jobs · {fmtInt(m.uncoveredSqm)} SQM-E total</p>
              )}
            </section>

            {/* coverage by sector */}
            <section className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
              <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Coverage by sector</h3>
              <p className="mb-2 text-xs" style={{ color: "var(--text-muted)" }}>Active SQM-E per sector; green is covered by a mason.</p>
              {sectors.map((s) => (
                <div key={s.sector} className="grid grid-cols-[110px_1fr_78px] items-center gap-3 py-1.5">
                  <span className="truncate text-sm" style={{ color: "var(--text-secondary)" }}>{s.sector}</span>
                  <span className="flex h-5 overflow-hidden rounded" style={{ background: "var(--surface-2, #faf8f3)" }}>
                    <span style={{ width: `${(s.covered / s.total) * 100}%`, background: "color-mix(in srgb, var(--good) 28%, transparent)", borderRight: s.covered ? "2px solid var(--good)" : "none" }} />
                    <span style={{ width: `${(s.uncovered / s.total) * 100}%`, background: "color-mix(in srgb, var(--critical) 24%, transparent)", borderRight: s.uncovered ? "2px solid var(--critical)" : "none" }} />
                  </span>
                  <span className="text-right text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{Math.round((s.covered / s.total) * 100)}% covered</span>
                </div>
              ))}
            </section>
          </div>
        </>
      )}

      {/* ===================== PLAN BOARD ===================== */}
      {tab === "board" && (
        <>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm" style={{ color: "var(--text-secondary)" }}><b>Tap a job, then tap a mason to allocate it.</b> On a computer you can drag instead. Tap the job again or tap Unallocated to send it back. Utilisation updates as you go; changes are not yet saved.</p>
            <button onClick={() => setAssignment(solve(ds.jobs, ds.masons, cfg))} className="rounded-md border px-3 py-1.5 text-sm font-medium" style={{ borderColor: "var(--border)", background: "var(--surface)", color: "var(--text-secondary)" }}>Reset to suggested</button>
          </div>
          {dragId && (
            <div className="sticky top-2 z-20 flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-sm"
              style={{ background: "color-mix(in srgb, var(--accent) 14%, var(--surface))", borderColor: "var(--accent-strong)", color: "var(--text-primary)" }}>
              <span>Job selected. Tap a mason to allocate it.</span>
              <button type="button" onClick={() => setDragId(null)} className="rounded-md border px-2 py-1 text-xs"
                style={{ borderColor: "var(--border)", background: "var(--surface)", color: "var(--text-secondary)" }}>Cancel</button>
            </div>
          )}
          <div className="flex flex-col items-stretch gap-4 md:flex-row md:items-start">
            {/* pinned pool — stays put while you scroll to any mason */}
            <div className="flex max-h-[60vh] w-full shrink-0 flex-col rounded-xl border md:sticky md:top-4 md:max-h-[calc(100vh-6.5rem)] md:w-64 md:self-start"
              style={{ background: "color-mix(in srgb, var(--accent) 5%, var(--surface))", borderColor: "color-mix(in srgb, var(--accent) 26%, var(--border))" }}
              onDragOver={(e) => e.preventDefault()} onDrop={() => drop(null)}
              onClick={() => dragId && drop(null)}>
              <div className="border-b p-3" style={{ borderColor: "var(--border)" }}>
                <div className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Unallocated</div>
                <div className="text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(poolJobs.length)} eligible jobs, no mason assigned</div>
                <input value={poolSearch} onChange={(e) => setPoolSearch(e.target.value)} placeholder="Search job…"
                  className="mt-2 w-full rounded-md border px-2 py-1 text-sm" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
              </div>
              <div className="flex flex-1 flex-col gap-1.5 overflow-y-auto p-2">
                {poolJobs.slice(0, POOL_CAP).map((j) => <JobCard key={j.id} job={j} picked={dragId === j.id} onDrag={() => setDragId(j.id)} />)}
                {poolJobs.length > POOL_CAP && <p className="px-1 text-xs" style={{ color: "var(--text-muted)" }}>+ {fmtInt(poolJobs.length - POOL_CAP)} more (search to narrow)</p>}
                {poolJobs.length === 0 && <p className="px-1 py-4 text-center text-xs" style={{ color: "var(--text-muted)" }}>No unallocated jobs.</p>}
              </div>
            </div>

            {/* masons: wrapping grid, scroll vertically */}
            <div className="grid flex-1 gap-3" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(224px, 1fr))" }}>
              {masonsStable.map((mn) => {
                const load = loads[mn.key]?.sqm ?? 0;
                const bd = band(load, cap);
                const fill = Math.min(load / cap, 1.25) / 1.25 * 100;
                const mine = eligible.filter((j) => assignment[j.id] === mn.key);
                return (
                  <div key={mn.key} className="flex max-h-[380px] flex-col rounded-xl border" style={{ background: "var(--surface-2, #faf8f3)", borderColor: dragId ? "color-mix(in srgb, var(--accent) 45%, var(--border))" : "var(--border)" }}
                    onDragOver={(e) => e.preventDefault()} onDrop={() => drop(mn.key)}
                    onClick={() => dragId && drop(mn.key)}>
                    <div className="border-b p-3" style={{ borderColor: "var(--border)" }}>
                      <div className="truncate text-sm font-semibold" style={{ color: "var(--text-primary)" }} title={mn.name}>{mn.name}</div>
                      <div className="mb-2 truncate text-xs" style={{ color: "var(--text-muted)" }} title={mn.subs.join(", ")}>{mn.subs.length ? mn.subs.join(", ") : "unassigned"}</div>
                      <div className="relative h-4 rounded" style={{ background: "var(--surface)", border: "1px solid var(--border)" }}>
                        <div className="absolute inset-y-0 left-0 rounded" style={{ width: `${fill}%`, background: `color-mix(in srgb, ${BAND_COLOR[bd]} 30%, transparent)`, borderRight: `2px solid ${BAND_COLOR[bd]}` }} />
                        <div className="absolute inset-y-[-3px] w-0.5" style={{ left: "80%", background: "var(--text-primary)", opacity: 0.4 }} />
                      </div>
                      <div className="mt-1.5 flex items-center justify-between text-xs">
                        <span style={{ color: "var(--text-muted)" }}><b className="tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(load)}</b> / {cap} · {mine.length} jobs</span>
                        <span style={{ color: BAND_COLOR[bd], fontWeight: 600 }}>{BAND_LABEL[bd]}</span>
                      </div>
                    </div>
                    <div className="flex min-h-16 flex-1 flex-col gap-1.5 overflow-y-auto p-2">
                      {mine.map((j) => <JobCard key={j.id} job={j} picked={dragId === j.id} onDrag={() => setDragId(j.id)} />)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border p-3" style={{ background: "color-mix(in srgb, var(--accent) 5%, var(--surface))", borderColor: "color-mix(in srgb, var(--accent) 26%, var(--border))" }}>
            <span className="text-sm" style={{ color: "var(--text-secondary)" }}><b style={{ color: "var(--text-primary)" }}>Review before finalising.</b> {fmtInt(assignedJobs)} jobs allocated across {ds.masons.length} masons.</span>
            <button className="rounded-md px-3 py-1.5 text-sm font-medium text-white" style={{ background: "var(--accent-strong)" }}>Export mason sheets</button>
          </div>
        </>
      )}

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        Active masons and their territories come from timesheets filed in the last 4 weeks; jobs are the active build pipeline. SQM-E = m² × weight (Floor 1.0, Plaster/Paint 0.333). Data synced from Salesforce (~6h ceiling).
      </p>
    </div>
  );
}

function JobCard({ job, onDrag, picked }: { job: { customer: string; village: string; product: string; sqm: number; paid: number | null }; onDrag: () => void; picked?: boolean }) {
  const pc = job.product === "Floor" ? "var(--accent-ink)" : "var(--good)";
  return (
    // Draggable for mouse, tappable for touch: HTML5 drag-and-drop does not fire
    // on touch screens at all, so without the click path a phone cannot move a job.
    <div draggable onDragStart={onDrag}
      onClick={(e) => { e.stopPropagation(); onDrag(); }}
      className="cursor-grab rounded-lg border p-2 active:cursor-grabbing"
      style={{
        background: picked ? "color-mix(in srgb, var(--accent) 16%, var(--surface))" : "var(--surface)",
        borderColor: picked ? "var(--accent-strong)" : "var(--border)",
        boxShadow: picked ? "0 0 0 2px color-mix(in srgb, var(--accent) 40%, transparent)" : "none",
      }}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="truncate text-xs font-semibold" style={{ color: "var(--text-primary)" }} title={job.customer}>{job.customer}</span>
        <span className="shrink-0 text-xs font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(Math.round(job.sqm))}</span>
      </div>
      <div className="mt-0.5 flex items-center gap-1.5 text-[11px]" style={{ color: "var(--text-muted)" }}>
        <span style={{ color: pc, fontWeight: 700 }}>{job.product}</span> · {job.village}{job.paid != null ? ` · ${Math.round(job.paid * 100)}%` : ""}
      </div>
    </div>
  );
}

function Stat({ label, big, unit, sub, tone }: { label: string; big: string; unit: string; sub: string; tone?: "accent" | "warn" }) {
  const top = tone === "accent" ? "var(--accent)" : tone === "warn" ? "var(--warning)" : "var(--border)";
  return (
    <div className="flex flex-col gap-1 rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${top}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <span className="text-2xl font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{big} <span className="text-sm font-normal" style={{ color: "var(--text-muted)" }}>{unit}</span></span>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>{sub}</span>
    </div>
  );
}

function TabBtn({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick} className="rounded-md px-3 py-1.5 text-sm font-medium" style={{ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" }}>{children}</button>
  );
}

function Select({ label, value, options, onChange, optionLabel }: { label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string }) {
  return (
    <label className="flex items-center gap-1.5 text-sm" style={{ color: "var(--text-secondary)" }}>
      <span style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="rounded-md border px-2 py-1.5 text-sm" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}
