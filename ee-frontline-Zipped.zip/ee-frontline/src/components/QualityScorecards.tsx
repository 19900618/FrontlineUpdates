"use client";

import { useEffect, useState } from "react";
import type { Scorecards, ScorecardDim, ScorecardRow, ScoreTrend, Unit } from "@/lib/quality-scorecards";
import type { Bucket, Period } from "@/lib/leads-period";
import { fmtInt } from "@/lib/format";
import { SERIES_QA } from "@/lib/workspace-ui";
import Spinner from "@/components/Spinner";
import TrendChart from "@/components/ws/TrendChart";
import { DataTable, Kpi, type Col } from "@/components/ws/primitives";

/** The two headline rates keep their own colours across the page. */
const FIRST = SERIES_QA;
const MATCH = "#c2703d";
const pct = (a: number, b: number): number | null => (b > 0 ? a / b : null);
const pctText = (v: number | null): string => (v == null ? "-" : `${Math.round(v * 100)}%`);
const band = (v: number | null): string =>
  v == null ? "var(--text-muted)" : v >= 0.95 ? "var(--good)" : v >= 0.85 ? "var(--warning)" : "var(--critical)";

/** Which card's records are open. */
type Open = { dim: ScorecardDim; title: string } | null;

/**
 * The four Quality scorecards, in the order the business reads them. Every
 * figure is counted for this country and this window, and each of the last
 * three opens exactly the records it counts, so a number on screen can be
 * taken back to them.
 */
export default function QualityScorecards({ country, period, data, trend, buckets, unit }: {
  country: string; period: Period; data: Scorecards; trend: ScoreTrend[]; buckets: Bucket[]; unit: Unit;
}) {
  const [open, setOpen] = useState<Open>(null);
  const show = (dim: ScorecardDim, title: string) => setOpen((o) => (o && o.dim === dim ? null : { dim, title }));

  const first = data.firstEval;
  const firstJobs = first.reduce((n, p) => n + p.jobs, 0);
  const firstPassed = first.reduce((n, p) => n + p.passed, 0);
  const firstRate = pct(firstPassed, firstJobs);
  const ready = data.finalEval.reduce((n, p) => n + p.ready, 0);
  /** How often the territory lead and the QA evaluation that followed agreed. */
  const matchRate = pct(data.matching.matched, data.matching.pairs);
  const waits = data.finalEval.map((p) => `${p.product} after ${p.waitDays} ${p.waitDays === 1 ? "day" : "days"}`);

  const opener = (dim: ScorecardDim, title: string, enabled: boolean, label: string) => enabled ? (
    <button type="button" onClick={() => show(dim, title)} aria-pressed={open?.dim === dim}
      className="no-print text-sm font-medium underline underline-offset-4" style={{ color: open?.dim === dim ? "var(--text-primary)" : "var(--accent-ink)" }}>
      {open?.dim === dim ? "Hide" : label}
    </button>
  ) : undefined;

  return (
    <section className="flex flex-col gap-3">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Passed first QA evaluation" big={pctText(firstRate)} tone={band(firstRate)}
          lines={[firstJobs > 0 ? `${fmtInt(firstPassed)} of ${fmtInt(firstJobs)} houses` : "no house finished its first QA evaluations"]}
          sub="Floor needs its first QA compaction and its first QA screed to pass. Plaster needs its first QA prior paint." />
        <Kpi label="Ready for final evaluation" big={fmtInt(ready)} tone={ready > 0 ? "var(--warning)" : "var(--good)"}
          lines={["houses ready for final evaluation"]}
          sub={`Varnished, the waiting period served${waits.length > 0 ? ` (${waits.join(", ")})` : ""}, and the final evaluation not yet passed. As things stand today, not within this window.`}
          footer={opener("final-eval", "Houses ready for their final evaluation", ready > 0, "Show the houses")} />
        <Kpi label="TL and QA matching" big={pctText(matchRate)} tone={band(matchRate)}
          lines={[data.matching.pairs > 0 ? `${fmtInt(data.matching.tlPassQaFail)} TL passed, QA sent back` : "no territory lead evaluation was paired in this window"]}
          sub={<>
            {data.matching.pairs > 0 && `${fmtInt(data.matching.matched)} of ${fmtInt(data.matching.pairs)} paired evaluations agreed. `}
            The QA evaluation that followed the territory lead&apos;s on the same house and stage. Repair minor issues and Redo both count as sending it back. The list is the houses the lead passed and QA sent back.
          </>}
          footer={opener("matching", "Houses the territory lead passed and QA sent back", data.matching.tlPassQaFail > 0, "Show the houses")} />
        <Kpi label="Customer cases closure" big={fmtInt(data.cases.stillOpen)} tone={data.cases.stillOpen > 0 ? "var(--warning)" : "var(--good)"}
          lines={["still open"]}
          sub="Every case nobody has closed yet, whenever it was raised. Not filtered by the window."
          footer={opener("cases", "Customer cases still open", data.cases.stillOpen > 0, "See the cases")} />
      </div>

      {open && (
        <Drill key={`${open.dim}|${period.from}|${period.to}|${unit?.name ?? ""}`}
          country={country} period={period} dim={open.dim} title={open.title} unit={unit}
          total={open.dim === "final-eval" ? ready : open.dim === "matching" ? data.matching.tlPassQaFail : data.cases.stillOpen}
          onClose={() => setOpen(null)} />
      )}

      <ScoreTrendChart trend={trend} buckets={buckets} grain={period.mode} />
    </section>
  );
}

/** The records behind one card, fetched only when it is opened. */
function Drill({ country, period, dim, title, unit, total, onClose }: {
  country: string; period: Period; dim: ScorecardDim; title: string; unit: Unit; total: number; onClose: () => void;
}) {
  const [rows, setRows] = useState<ScorecardRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    // The list is narrowed the same way the page is, so it can never show a house the figure above it did not count.
    const qs = new URLSearchParams({ country, from: period.from, to: period.to, dim });
    if (unit) qs.set(unit.level, unit.name);
    fetch(`/api/quality/scorecard-rows?${qs}`)
      .then(async (r) => {
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? r.statusText);
        if (live) setRows(j.rows as ScorecardRow[]);
      })
      .catch((e) => { if (live) setError(e instanceof Error ? e.message : String(e)); });
    return () => { live = false; };
  }, [country, period.from, period.to, dim, unit]);

  const pillCell = (text: string, tone: string) => (
    <span className="inline-block rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: `color-mix(in srgb, ${tone} 14%, transparent)`, color: tone }}>{text}</span>
  );
  const cols: Col<ScorecardRow>[] = dim === "final-eval" ? [
    { key: "job", header: "House", mobile: "title", sort: (r) => r.job, copy: (r) => r.job, cell: (r) => <span className="font-medium" style={{ color: "var(--text-primary)" }}>{r.job}</span> },
    { key: "product", header: "Product", sort: (r) => r.product ?? null, cell: (r) => r.product ?? "-" },
    { key: "place", header: "Territory", sort: (r) => r.territory ?? r.branch ?? null, cell: (r) => r.territory ?? r.branch ?? "-" },
    { key: "moved", header: "Varnish moved", sort: (r) => r.date ?? null, cell: (r) => r.date ?? "-" },
    { key: "since", header: "Days since", right: true, sort: (r) => r.daysOpen, cell: (r) => (r.daysOpen == null ? "-" : fmtInt(r.daysOpen)) },
    { key: "overdue", header: "Days overdue", right: true, sort: (r) => r.daysOverdue, cell: (r) => <span style={{ color: (r.daysOverdue ?? 0) > 30 ? "var(--critical)" : "var(--warning)" }}>{r.daysOverdue == null ? "-" : fmtInt(r.daysOverdue)}</span> },
  ] : dim === "matching" ? [
    { key: "job", header: "House", mobile: "title", sort: (r) => r.job, copy: (r) => r.job, cell: (r) => <span className="font-medium" style={{ color: "var(--text-primary)" }}>{r.job}</span> },
    { key: "stage", header: "Stage", sort: (r) => r.product ?? null, cell: (r) => r.product ?? "-" },
    { key: "place", header: "Territory", sort: (r) => r.territory ?? r.branch ?? null, cell: (r) => r.territory ?? r.branch ?? "-" },
    { key: "tl", header: "TL said", sort: (r) => r.status ?? null, copy: (r) => `${r.status ?? ""} ${r.lead ?? ""} ${r.date ?? ""}`.trim(), cell: (r) => (
      <span className="flex flex-col items-start">{pillCell(r.status ?? "-", "var(--good)")}<span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.lead ?? "?"}{r.date ? ` · ${r.date}` : ""}</span></span>
    ) },
    { key: "qa", header: "QA said", sort: (r) => r.qaDecision ?? null, copy: (r) => `${r.qaDecision ?? ""} ${r.qaEvaluator ?? ""} ${r.qaDate ?? ""}`.trim(), cell: (r) => (
      <span className="flex flex-col items-start">{pillCell(r.qaDecision ?? "-", "var(--critical)")}<span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.qaEvaluator ?? "?"}{r.qaDate ? ` · ${r.qaDate}` : ""}</span></span>
    ) },
    { key: "between", header: "Days between", right: true, sort: (r) => r.daysOpen, cell: (r) => (r.daysOpen == null ? "-" : fmtInt(r.daysOpen)) },
    { key: "note", header: "Comment", copy: (r) => r.note ?? "", cell: (r) => <span className="text-xs">{r.note ?? "-"}</span> },
  ] : [
    { key: "case", header: "Case", mobile: "title", sort: (r) => r.qaDecision ?? r.id, copy: (r) => r.qaDecision ?? r.id, cell: (r) => <span className="font-medium" style={{ color: "var(--text-primary)" }}>{r.qaDecision ?? r.id}</span> },
    { key: "customer", header: "Customer", sort: (r) => r.job, cell: (r) => r.job },
    { key: "territory", header: "Territory", sort: (r) => r.territory ?? null, cell: (r) => r.territory ?? "-" },
    { key: "issue", header: "Issue", sort: (r) => r.qaEvaluator ?? null, copy: (r) => `${r.qaEvaluator ?? ""}${r.note ? ` (${r.note})` : ""}`, cell: (r) => (
      <span className="flex flex-col">{r.qaEvaluator ?? "-"}{r.note && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.note}</span>}</span>
    ) },
    { key: "branch", header: "Branch", sort: (r) => r.branch ?? null, cell: (r) => r.branch ?? "-" },
    { key: "raised", header: "Raised", sort: (r) => r.date ?? null, cell: (r) => r.date ?? "-" },
    { key: "open", header: "Days open", right: true, sort: (r) => r.daysOpen, cell: (r) => <span style={{ color: (r.daysOpen ?? 0) > 30 ? "var(--warning)" : "inherit" }}>{r.daysOpen == null ? "-" : fmtInt(r.daysOpen)}</span> },
    { key: "status", header: "Status", sort: (r) => r.status ?? null, cell: (r) => pillCell(r.status ?? "-", "var(--warning)") },
  ];

  return (
    <section className="flex flex-col gap-2 rounded-xl border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${FIRST}` }}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
          {title}
          {rows ? <span className="ml-2 text-sm font-normal" style={{ color: "var(--text-muted)" }}>{rows.length < total ? `newest ${fmtInt(rows.length)} of ${fmtInt(total)}` : `${fmtInt(rows.length)} in all`}</span> : null}
        </h3>
        <button type="button" onClick={onClose} className="no-print text-sm" style={{ color: "var(--text-muted)" }}>Close</button>
      </div>
      {error && <p className="text-sm" style={{ color: "var(--critical)" }}>Could not load the records: {error}</p>}
      {!rows && !error && <p className="text-sm" style={{ color: "var(--text-muted)" }}><Spinner label="Loading records…" /></p>}
      {rows && <DataTable rows={rows} cols={cols} keyOf={(r) => r.id} pageSize={10} copyName="the records" empty="Nothing here in this window." note="Newest first." />}
    </section>
  );
}

/**
 * The two headline rates over the six periods ending with the one on screen,
 * on the same axis. A period the country has no data for leaves a gap in the
 * line rather than a zero, because no territory lead pairing exists outside
 * Rwanda or before April 2026 and drawing that as 0% would read as a
 * collapse rather than as silence.
 */
function ScoreTrendChart({ trend, buckets, grain }: { trend: ScoreTrend[]; buckets: Bucket[]; grain: "month" | "quarter" }) {
  const by = new Map(trend.map((t) => [t.key, t]));
  const firstAt = (k: string) => { const t = by.get(k); return t && t.firstJobs > 0 ? t.firstPassed / t.firstJobs : null; };
  const matchAt = (k: string) => { const t = by.get(k); return t && t.pairs > 0 ? t.matched / t.pairs : null; };
  const series = [
    { key: "first", label: "Passed first QA evaluation", color: FIRST, values: buckets.map((b) => firstAt(b.key)),
      notes: buckets.map((b) => { const t = by.get(b.key); return t ? `${fmtInt(t.firstPassed)} of ${fmtInt(t.firstJobs)} houses` : null; }) },
    { key: "match", label: "TL and QA agreed", color: MATCH, values: buckets.map((b) => matchAt(b.key)),
      notes: buckets.map((b) => { const t = by.get(b.key); return t && t.pairs > 0 ? `${fmtInt(t.matched)} of ${fmtInt(t.pairs)} pairs` : null; }) },
  ].filter((s) => s.values.some((v) => v != null));
  if (series.length === 0) return null;
  return (
    <TrendChart title={`Last six ${grain === "quarter" ? "quarters" : "months"}`} months={buckets.map((b) => b.label)} series={series} target={null} yMax={1} />
  );
}
