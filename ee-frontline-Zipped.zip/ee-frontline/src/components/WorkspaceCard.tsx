import Link from "next/link";
import Flag, { type FlagCode } from "@/components/Flag";

/**
 * One box on the home page: a gradient tile. A country box carries its flag
 * twice: crisp and small beside the kicker, and soft and large behind the
 * text, faded into the gradient so it reads as a backdrop rather than a
 * poster. The toolkit box keeps its large code watermark. Colours come from
 * lib/workspaces.ts.
 */
export default function WorkspaceCard({
  href, title, code, kicker, blurb, from, to, glow, flag,
}: {
  href: string;
  title: string;
  code: string;
  kicker: string;
  blurb: string;
  from: string;
  to: string;
  glow: string;
  flag?: FlagCode;
}) {
  return (
    <Link
      href={href}
      className="group relative flex min-h-56 flex-col justify-between overflow-hidden rounded-2xl p-6 text-white shadow-lg transition duration-200 hover:-translate-y-1 hover:shadow-2xl focus-visible:outline-4 focus-visible:outline-offset-2 sm:min-h-64"
      style={{
        background: `radial-gradient(circle at 85% 15%, ${glow}55 0%, transparent 45%), linear-gradient(135deg, ${from} 0%, ${to} 100%)`,
        outlineColor: glow,
      }}
    >
      {flag && (
        <span
          aria-hidden
          className="pointer-events-none absolute inset-y-0 right-0 w-[78%] transition-transform duration-500 group-hover:scale-[1.04]"
          style={{
            opacity: 0.42,
            maskImage: "linear-gradient(to right, transparent 0%, rgba(0,0,0,0.55) 45%, black 100%)",
            WebkitMaskImage: "linear-gradient(to right, transparent 0%, rgba(0,0,0,0.55) 45%, black 100%)",
            transformOrigin: "80% 50%",
          }}
        >
          <Flag code={flag} className="h-full w-full" style={{ transform: "rotate(-7deg) scale(1.32)", transformOrigin: "60% 50%" }} />
        </span>
      )}
      {/* a dark veil over the flag so the text keeps its contrast */}
      {flag && <span aria-hidden className="pointer-events-none absolute inset-0" style={{ background: `linear-gradient(105deg, ${from} 0%, ${from}cc 38%, transparent 70%)` }} />}

      {/* soft light blob that drifts on hover */}
      <span
        aria-hidden
        className="pointer-events-none absolute -bottom-16 -left-16 h-48 w-48 rounded-full blur-3xl transition-transform duration-500 group-hover:translate-x-6 group-hover:-translate-y-4"
        style={{ background: glow, opacity: flag ? 0.22 : 0.35 }}
      />
      {!flag && (
        <span
          aria-hidden
          className="pointer-events-none absolute -right-2 -bottom-6 select-none text-[8rem] font-black leading-none tracking-tighter sm:text-[9rem]"
          style={{ color: "rgba(255,255,255,0.12)" }}
        >
          {code}
        </span>
      )}

      <div className="relative">
        <span className="inline-flex items-center gap-2 rounded-full py-1 pl-1.5 pr-2.5 text-[11px] font-semibold uppercase tracking-wider"
          style={{ background: "rgba(255,255,255,0.18)" }}>
          {flag ? (
            <Flag code={flag} className="h-3.5 w-[21px] rounded-[3px]" style={{ boxShadow: "0 0 0 1px rgba(255,255,255,0.35)" }} />
          ) : (
            <span className="ml-1 text-[11px]">{code}</span>
          )}
          {kicker}
        </span>
        <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl" style={{ textShadow: flag ? "0 1px 12px rgba(0,0,0,0.25)" : undefined }}>{title}</h2>
        <p className="mt-2 max-w-xs text-sm" style={{ color: "rgba(255,255,255,0.88)" }}>{blurb}</p>
      </div>

      <span className="relative mt-6 inline-flex items-center gap-1.5 text-sm font-semibold">
        Open
        <span aria-hidden className="transition-transform duration-200 group-hover:translate-x-1">→</span>
      </span>
    </Link>
  );
}
