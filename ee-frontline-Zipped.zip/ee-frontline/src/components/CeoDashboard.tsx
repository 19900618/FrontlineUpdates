"use client";

import { useState, useTransition, type ReactNode } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { CeoData } from "@/lib/ceo";
import { COUNTRIES, type CountryName } from "@/lib/workspaces";
import { CAPACITY_CURRENCY } from "@/lib/capacity-ui";
import { copyForSheets, type Cell } from "@/lib/export";
import { monthName } from "@/lib/period";
import { freshnessLine, whole } from "@/lib/workspace-ui";
import Logo from "@/components/Logo";
import Spinner from "@/components/Spinner";
import ExportButtons from "@/components/ExportButtons";
import TrendChart from "@/components/ws/TrendChart";
import { DataTable, type Col } from "@/components/ws/primitives";

/**
 * The CEO dashboard: nine line charts, three metrics by three countries,
 * January to the current month, actual against budget. Under the SQM-E row,
 * one table of paint SQM-E. Every figure comes from a settled view
 * (src/lib/ceo.ts); nothing is derived here beyond picking a row.
 *
 * The same two colours on all nine charts, actual solid and budget dashed,
 * with one legend at the top. Each row is a full-width heading with its
 * one-line caption, then three charts side by side (one column on a phone,
 * in country order). SQM-E and earnings are in each country's own unit or
 * currency; cost to serve is in USD, each country on its own axis so the
 * gap between actual and budget shows. The current month is a hollow point. The definitions and
 * the country notes sit behind one "How these are calculated" link.
 */
const ACTUAL = "#2f6f9f";
const BUDGET = "var(--text-secondary)";
const ORDER: CountryName[] = COUNTRIES.map((c) => c.name);

/** 20K, 1.2M, 295: the axis ticks, short enough for a narrow column. */
function compact(v: number): string {
  const a = Math.abs(v);
  if (a >= 1e6) return `${Number((v / 1e6).toFixed(1))}M`;
  if (a >= 1e3) return `${Number((v / 1e3).toFixed(1))}K`;
  return Math.round(v).toLocaleString("en-US");
}
/** 39.1K, 101K, 1.2M: the point labels; under ten thousand the whole number, so 1,165 and 1,210 stay distinct. */
function wholeNum(v: number): string {
  const a = Math.abs(v);
  if (a >= 1e6) return `${Number((v / 1e6).toFixed(1))}M`;
  if (a >= 1e5) return `${Math.round(v / 1e3)}K`;
  if (a >= 1e4) return `${Number((v / 1e3).toFixed(1))}K`;
  return Math.round(v).toLocaleString("en-US");
}
/** Dollars per SQM-E are small: 3.4, not 3.42; 94 above a hundred. */
const usd = (v: number): string => (Math.abs(v) >= 100 ? wholeNum(v) : Number(v.toFixed(1)).toLocaleString("en-US"));
const short = (m: string) => monthName(m).slice(0, 3);
const currencyOf = (c: CountryName) => CAPACITY_CURRENCY[c];

export default function CeoDashboard({ data, years, userEmail }: { data: CeoData; years: number[]; userEmail: string | null }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [pendingYear, setPendingYear] = useState<number | null>(null);
  const [showHow, setShowHow] = useState(false);
  const { months } = data;
  const labels = months.map(short);
  const partial = months.findIndex((m) => data.sqme.some((r) => r.month === m && r.current));
  const partialIdx = partial >= 0 ? partial : undefined;

  function setYear(y: number) {
    if (y === data.year || isPending) return;
    setPendingYear(y);
    startTransition(() => router.replace(y === 2026 ? "/ceo" : `/ceo?y=${y}`, { scroll: false }));
  }

  const at = <T extends { country: CountryName; month: string }>(rows: T[], c: CountryName, m: string) => rows.find((r) => r.country === c && r.month === m);
  const sqmeSeries = (c: CountryName) => ({
    actual: months.map((m) => at(data.sqme, c, m)?.built ?? null),
    budget: months.map((m) => at(data.sqme, c, m)?.target ?? null),
  });
  const masonSeries = (c: CountryName) => ({
    actual: months.map((m) => at(data.masons, c, m)?.actual ?? null),
    budget: months.map((m) => at(data.masons, c, m)?.target ?? null),
    notes: months.map((m) => { const r = at(data.masons, c, m); return r ? `${whole(r.masonsPaid)} masons paid` : null; }),
  });
  const ctsSeries = (c: CountryName) => ({
    actual: months.map((m) => at(data.cts, c, m)?.actual ?? null),
    budget: months.map((m) => at(data.cts, c, m)?.budget ?? null),
    open: months.filter((m) => { const r = at(data.cts, c, m); return !r || !r.closed; }),
  });

  // The page export: every chart's points and the paint table, one row per country and month.
  const exportHeaders = ["Metric", "Country", "Month", "Actual", "Budget", "Unit"];
  const exportRows: Cell[][] = [];
  for (const c of ORDER) {
    const s = sqmeSeries(c), e = masonSeries(c), k = ctsSeries(c);
    months.forEach((m, i) => exportRows.push(["SQM-E built", c, m, round(s.actual[i]), round(s.budget[i]), "SQM-E"]));
    months.forEach((m, i) => exportRows.push(["Average mason earnings, monthly", c, m, round(e.actual[i]), round(e.budget[i]), currencyOf(c)]));
    months.forEach((m, i) => exportRows.push(["Cost to serve, country level", c, m, round2(k.actual[i]), round2(k.budget[i]), "USD per SQM-E"]));
    months.forEach((m) => exportRows.push(["Paint SQM-E", c, m, round(at(data.sqme, c, m)?.paint ?? null), "", "SQM-E"]));
  }

  const chart = (c: CountryName, actual: (number | null)[], budget: (number | null)[],
    o: { notes?: (string | null)[]; yLabel?: string; note?: ReactNode; name: string; unit: string; format?: (v: number) => string; yMax?: number; decimals?: number }) => (
    <TrendChart key={c} title={c} compact legend={false} floor="zero" target={null} format={o.format ?? wholeNum} axisFormat={compact} partial={partialIdx} yLabel={o.yLabel} yMax={o.yMax}
      months={labels}
      series={[
        { key: "actual", label: "Actual", color: ACTUAL, values: actual, notes: o.notes },
        { key: "budget", label: "Budget", color: BUDGET, values: budget, dashed: true },
      ]}
      toolbar={<CopyChart name={`${o.name}, ${c}`} unit={o.unit} months={months} actual={actual} budget={budget} decimals={o.decimals ?? 0} />}
      note={o.note} />
  );

  const paintCols: Col<CountryName>[] = [
    { key: "country", header: "Country", mobile: "title", sort: (c) => c, cell: (c) => <span className="font-semibold">{c}</span> },
    ...months.map((m): Col<CountryName> => ({
      key: m, header: short(m), right: true, mobileLabel: monthName(m),
      sort: (c) => at(data.sqme, c, m)?.paint ?? null,
      cell: (c) => <span className="tabular-nums">{whole(at(data.sqme, c, m)?.paint ?? null)}</span>,
    })),
    {
      key: "ytd", header: "Year to date", right: true,
      sort: (c) => data.sqme.filter((r) => r.country === c).reduce((t, r) => t + (r.paint ?? 0), 0),
      cell: (c) => <span className="font-semibold tabular-nums">{whole(data.sqme.filter((r) => r.country === c).reduce((t, r) => t + (r.paint ?? 0), 0))}</span>,
    },
  ];

  const yearShown = isPending && pendingYear != null ? pendingYear : data.year;
  const ctsNote = (c: CountryName) => {
    const open = ctsSeries(c).open.map(short);
    return open.length ? `Books not yet closed: ${open.join(", ")}` : undefined;
  };

  return (
    <div className="flex min-h-[100dvh] flex-col">
      <header className="no-print flex items-center justify-between gap-4 border-b px-4 py-3 sm:px-8"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <div className="flex items-center gap-4">
          <Logo height={30} />
          <Link href="/" className="text-sm" style={{ color: "var(--accent-ink)" }}>← All workspaces</Link>
        </div>
        {userEmail && (
          <div className="flex min-w-0 items-center gap-3 text-xs">
            <span className="hidden truncate sm:inline" style={{ color: "var(--text-secondary)" }}>{userEmail}</span>
            {/* Auth.js route, not a page: a plain link is right, so the page-link rule is off here. */}
            {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
            <a href="/api/auth/signout" style={{ color: "var(--text-muted)" }}>Sign out</a>
          </div>
        )}
      </header>

      <main className="mx-auto w-full max-w-[80rem] flex-1 px-4 py-6 sm:px-6">
        <h1 className="text-2xl font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>CEO dashboard</h1>
        <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
          SQM-E built, mason earnings and cost to serve, actual against budget, January to {months.length ? monthName(months[months.length - 1]) : "date"} {data.year}.{" "}
          <button type="button" onClick={() => setShowHow((v) => !v)} aria-expanded={showHow} className="underline underline-offset-4" style={{ color: "var(--accent-ink)" }}>
            How these are calculated
          </button>
        </p>
        {showHow && <HowCalculated />}

        <div className="no-print mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl border px-3 py-2.5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}
          aria-busy={isPending}>
          <label className="flex items-center gap-2 text-sm" style={{ color: "var(--text-secondary)" }}>
            Year
            <select value={yearShown} onChange={(e) => setYear(Number(e.target.value))} disabled={isPending} aria-label="Year"
              className="min-h-11 rounded-md border px-2 py-1.5 text-sm sm:min-h-0" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
              {years.map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </label>
          {isPending && <span style={{ color: "var(--accent-strong)" }}><Spinner size={14} label="Loading" /></span>}
          <div className="flex items-center gap-4 text-sm" style={{ color: "var(--text-secondary)" }} aria-label="Legend">
            <span className="flex items-center gap-2"><span className="inline-block h-0.5 w-6 rounded" style={{ background: ACTUAL }} />Actual</span>
            <span className="flex items-center gap-2"><span className="inline-block w-6 border-t-2 border-dashed" style={{ borderColor: BUDGET }} />Budget</span>
            <span className="text-xs" style={{ color: "var(--text-muted)" }}>* month in progress</span>
          </div>
          <div className="ml-auto"><ExportButtons filename={`ceo-dashboard-${data.year}`} headers={exportHeaders} rows={exportRows} /></div>
        </div>

        <div className="flex flex-col gap-12 pt-8" style={{ opacity: isPending ? 0.45 : 1, transition: "opacity 200ms", pointerEvents: isPending ? "none" : undefined }}>
          <Row label="SQM-E built" blurb="SQM-E built against budget. Paint is excluded and shown in the table below.">
            {ORDER.map((c) => { const s = sqmeSeries(c); return chart(c, s.actual, s.budget, { name: "SQM-E built", unit: "SQM-E" }); })}
          </Row>

          <section>
            <Heading label="Paint SQM-E" blurb="Paint SQM-E built by month." />
            <DataTable rows={ORDER} cols={paintCols} keyOf={(c) => c} copyName="paint SQM-E" empty="No months yet this year." />
          </section>

          <Row label="Average mason earnings" blurb="Gross approved pay per mason, against the monthly productive threshold.">
            {ORDER.map((c) => { const s = masonSeries(c); return chart(c, s.actual, s.budget, { name: "Average mason earnings, monthly", unit: currencyOf(c), notes: s.notes }); })}
          </Row>

          <Row label="Cost to serve, country level" blurb="Revenue less COGS, district and country expenses, per SQM-E. Global overheads are not included.">
            {ORDER.map((c) => { const s = ctsSeries(c); return chart(c, s.actual, s.budget, { name: "Cost to serve, country level", unit: "USD per SQM-E", yLabel: "Cost per SQM-E, USD", note: ctsNote(c), format: usd, decimals: 2 }); })}
          </Row>

          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            {`${freshnessLine(data.syncedMs, data.builtAt)} · QuickBooks figures move only when a month's books are closed.`}
          </p>
        </div>
      </main>
    </div>
  );
}

const round = (v: number | null): Cell => (v == null ? "" : Math.round(v));
const round2 = (v: number | null): Cell => (v == null ? "" : Math.round(v * 100) / 100);

/** A row's full-width heading: the metric and its one-line caption. */
function Heading({ label, blurb }: { label: string; blurb: string }) {
  return (
    <div className="mb-4">
      <h2 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>{label}</h2>
      <p className="mt-0.5 text-sm" style={{ color: "var(--text-muted)" }}>{blurb}</p>
    </div>
  );
}

/** One metric: its heading across the top, the three countries' charts under it; one column on a phone, in country order. */
function Row({ label, blurb, children }: { label: string; blurb: string; children: ReactNode }) {
  return (
    <section>
      <Heading label={label} blurb={blurb} />
      <div className="grid gap-5 md:grid-cols-3">{children}</div>
    </section>
  );
}

/** The definitions and the country notes, opened from the line under the title. */
function HowCalculated() {
  const h = "text-sm font-semibold";
  const p = "mt-1 text-sm";
  const hs = { color: "var(--text-primary)" } as const;
  const ps = { color: "var(--text-secondary)" } as const;
  return (
    <section className="mt-3 grid gap-4 rounded-xl border p-4 md:grid-cols-3" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div>
        <h3 className={h} style={hs}>SQM-E built</h3>
        <p className={p} style={ps}>
          Floor and plaster completed in the month, by completion date, weighted: a floor counts its full area, plaster a third. It is not square metres.
          Paint is excluded by design and shown in the table under the row. Source: company_kpi_monthly, the company KPI view.
        </p>
      </div>
      <div>
        <h3 className={h} style={hs}>Average mason earnings</h3>
        <p className={p} style={ps}>
          Gross approved pay per mason paid in the month, bucketed by the timesheet end date, in local currency (RWF, UGX, KES).
          The bar is the monthly productive threshold: 100,000 RWF, 250,000 UGX and 10,000 KES. Source: productive_masons_monthly, the view the mason bonus uses.
        </p>
      </div>
      <div>
        <h3 className={h} style={hs}>Cost to serve, country level</h3>
        <p className={p} style={ps}>
          Revenue less cost of goods, district expenses and country overheads, per SQM-E built, from the closed books, converted to USD at the month&apos;s rate.
          The same figure as the country cost to serve in Looker. Shown as a cost, so lower is better, and a budget line above the actual line means we are spending less than planned.
          The budget is the same ratio over the country budget from the VG workbook, totals summed, never averaged. Global overheads are in neither line.
          A month whose books are not closed is left out rather than plotted as zero.
        </p>
      </div>
      <div className="md:col-span-3">
        <h3 className={h} style={hs}>Country notes</h3>
        <ul className="mt-1 list-disc space-y-1 pl-5 text-sm" style={ps}>
          <li><b>Rwanda.</b> RBF subsidy income sits in Other Income, outside the cost to serve chain. A month with no RBF booked is usually a booking delay, not a real change. The Full House section sits under Other Expenses and is excluded.</li>
          <li><b>Uganda.</b> Foreign exchange gain or loss sits under Other Expenses and is excluded. Spend classed to hub or Not specified sits at country level, so branch district totals do not foot to the country figure. Intended.</li>
          <li><b>Kenya.</b> Small numbers: one month moves the line. Read the labels, not the slope.</li>
          <li><b>The current month is partial</b> and drawn hollow with a star. QuickBooks figures move only when a month&apos;s books are closed; Salesforce syncs every 15 minutes and the page refreshes every 15 minutes.</li>
        </ul>
      </div>
    </section>
  );
}

/** Copy one chart as a table: month, actual, budget. */
function CopyChart({ name, unit, months, actual, budget, decimals }: { name: string; unit: string; months: string[]; actual: (number | null)[]; budget: (number | null)[]; decimals: number }) {
  const [state, setState] = useState<"ok" | "fail" | null>(null);
  async function copy() {
    const f = decimals > 0 ? round2 : round;
    const rows: Cell[][] = months.map((m, i) => [m, f(actual[i]), f(budget[i])]);
    const ok = await copyForSheets(["Month", `Actual (${unit})`, `Budget (${unit})`], rows);
    setState(ok ? "ok" : "fail");
    setTimeout(() => setState(null), 2500);
  }
  return (
    <span className="flex items-center gap-2">
      {state === "ok" && <span style={{ color: "var(--good)" }}>Copied</span>}
      {state === "fail" && <span style={{ color: "var(--critical)" }}>Copy failed</span>}
      <button type="button" onClick={copy} title={`Copy ${name} as a table`} className="min-h-11 rounded-md border px-2 py-1 text-xs font-medium sm:min-h-0"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-secondary)" }}>
        Copy table
      </button>
    </span>
  );
}
