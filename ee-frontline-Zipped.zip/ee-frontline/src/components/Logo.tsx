"use client";

import { useState } from "react";

/**
 * EarthEnable logo.
 *
 * Prefers the official asset at `public/EarthEnable+Logo.webp`. If that file
 * isn't present, it falls back to an SVG recreation of the house + sun-rays mark,
 * so the app always shows a brand mark. Swap the file in `public/` — no code change.
 */
export default function Logo({
  height = 34,
  showWordmark = true,
}: {
  height?: number;
  showWordmark?: boolean;
}) {
  const [imgOk, setImgOk] = useState(true);

  if (imgOk) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src="/EarthEnable+Logo.webp"
        alt="EarthEnable"
        onError={() => setImgOk(false)}
        style={{ height, width: "auto", display: "block" }}
      />
    );
  }

  // --- SVG fallback (recreation) ---
  return (
    <span
      className="inline-flex items-center gap-2 select-none"
      style={{ color: "var(--accent)" }}
      aria-label="EarthEnable"
    >
      <svg height={height} viewBox="0 0 128 104" fill="none" role="img" aria-hidden style={{ display: "block" }}>
        <g stroke="currentColor" strokeWidth="6" strokeLinecap="round">
          <line x1="64" y1="30" x2="64" y2="6" />
          <line x1="64" y1="30" x2="46" y2="12" />
          <line x1="64" y1="30" x2="82" y2="12" />
          <line x1="64" y1="30" x2="32" y2="22" />
          <line x1="64" y1="30" x2="96" y2="22" />
          <line x1="64" y1="32" x2="22" y2="34" />
          <line x1="64" y1="32" x2="106" y2="34" />
        </g>
        <path
          fill="currentColor"
          fillRule="evenodd"
          d="M64 40 L108 66 V100 H20 V66 Z M56 100 V78 H72 V100 Z"
        />
      </svg>
      {showWordmark && (
        <span className="flex flex-col leading-[0.82] font-extrabold tracking-tight">
          <span style={{ fontSize: height * 0.34 }}>EARTH</span>
          <span style={{ fontSize: height * 0.34 }}>ENABLE</span>
        </span>
      )}
    </span>
  );
}
