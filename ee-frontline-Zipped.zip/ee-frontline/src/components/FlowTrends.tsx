"use client";

import { fmtInt } from "@/lib/format";
import {
  STEPS, fmtPeriod, fmtPeriodLong, periodEnd, periodStart,
  type FlowPick, type Gran, type MoveTotal, type Step, type TrendRow,
} from "@/lib/journey-flow-shared";

const UNIT: Record<Gran, string> = { day: "day", week: "week", month: "month" };

/**
 * One small bar chart per step: how many customers reached it each day, week or month.
 * They answer "is this getting better?" and double as a period picker: tapping a bar
 * opens that period everywhere on the page.
 */
export default function FlowTrends({ trend, totals, periods, gran, today, start, end, pick, onPickPeriod, onSelect }: {
  trend: TrendRow[];
  totals: MoveTotal[];
  periods: string[];
  gran: Gran;
  today: string;
  start: string;
  end: string;
  pick: FlowPick;
  onPickPeriod: (periodStart: string) => void;
  onSelect: (to: number) => void;
}) {
  const showMat = trend.some((r) => r.to === 3 && r.n > 0);
  const steps = STEPS.filter((s) => s.key !== 3 || showMat);
  const unit = UNIT[gran];
  const current = periodStart(gran, today);

  return (
    <section className="flex flex-col gap-3 rounded-lg border p-4 sm:p-5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
          {gran === "day" ? "Day by day" : `${unit.charAt(0).toUpperCase()}${unit.slice(1)} by ${unit}`}
        </h2>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          Last {periods.length} {unit}s. Tap a bar to open that {unit}. The pale last bar is the {unit} so far. Each chart has its own scale.
        </p>
      </div>
      <div className={`grid grid-cols-2 gap-3 sm:grid-cols-3 ${showMat ? "xl:grid-cols-7" : "xl:grid-cols-6"}`}>
        {steps.map((s) => (
          <Mini key={s.key} step={s} trend={trend} periods={periods} gran={gran} current={current} start={start} end={end}
            total={totals.find((t) => t.to === s.key)?.n ?? 0} active={!pick || pick.to === s.key}
            onPickPeriod={onPickPeriod} onSelect={onSelect} />
        ))}
      </div>
    </section>
  );
}

function Mini({ step, trend, periods, gran, current, start, end, total, active, onPickPeriod, onSelect }: {
  step: Step;
  trend: TrendRow[];
  periods: string[];
  gran: Gran;
  current: string;
  start: string;
  end: string;
  total: number;
  active: boolean;
  onPickPeriod: (p: string) => void;
  onSelect: (to: number) => void;
}) {
  const vals = periods.map((p) => trend.find((r) => r.to === step.key && r.period === p)?.n ?? 0);
  const max = Math.max(1, ...vals);
  const VW = 240, VH = 70, G = 3;
  const N = Math.max(periods.length, 1);
  const bw = (VW - G * (N - 1)) / N;

  return (
    <div className="flex flex-col gap-1.5 rounded-md border p-2.5"
      style={{ borderColor: active ? "var(--border)" : "var(--border)", opacity: active ? 1 : 0.45, transition: "opacity .15s" }}>
      <button type="button" onClick={() => onSelect(step.key)} className="flex items-baseline justify-between gap-2 text-left">
        <span className="flex min-w-0 items-center gap-1.5 text-xs font-medium" style={{ color: "var(--text-secondary)" }}>
          <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: step.color }} />
          <span className="leading-tight">{step.name}</span>
        </span>
        <span className="text-lg font-semibold tabular-nums" style={{ color: "var(--text-primary)" }} title="In the selected period">{fmtInt(total)}</span>
      </button>
      <svg viewBox={`0 0 ${VW} ${VH}`} className="w-full" role="img" aria-label={`${step.name} per ${gran}`}>
        <line x1={0} x2={VW} y1={VH - 0.5} y2={VH - 0.5} style={{ stroke: "var(--grid)" }} />
        {periods.map((p, i) => {
          const v = vals[i];
          const h = v > 0 ? Math.max(2, (v / max) * (VH - 6)) : 0;
          const inWindow = p <= end && periodEnd(gran, p) >= start;
          const partial = p === current;
          return (
            <g key={p} onClick={() => onPickPeriod(p)} style={{ cursor: "pointer" }}>
              <title>{`${fmtPeriodLong(gran, p)}${partial ? " (so far)" : ""}: ${fmtInt(v)}`}</title>
              <rect x={i * (bw + G)} y={0} width={bw} height={VH} fill="transparent" />
              <rect x={i * (bw + G)} y={VH - h} width={bw} height={h} rx={1.5}
                style={{ fill: step.color, opacity: inWindow ? 1 : partial ? 0.22 : 0.38 }} />
            </g>
          );
        })}
      </svg>
      <div className="flex justify-between text-[10px]" style={{ color: "var(--text-muted)" }}>
        <span>{fmtPeriod(gran, periods[0] ?? current)}</span>
        <span>max {fmtInt(max)}</span>
        <span>{fmtPeriod(gran, periods[N - 1] ?? current)}</span>
      </div>
    </div>
  );
}
