"use client";

import { Fragment, useMemo, useState } from "react";
import Link from "next/link";
import {
  COUNTRIES, CURRENCY,
  type Country, type UgkeCsoMonth, type UgkePending,
} from "@/lib/cso-ugke-types";
import { band, BAND_COLOR, BAND_LABEL } from "@/lib/cso-bands";
import { fmtInt, telHref } from "@/lib/format";
import { useNarrow } from "@/lib/use-narrow";
import ExportButtons from "@/components/ExportButtons";
import { stamp, type Cell } from "@/lib/export";

const ALL = "All";
const SERIES_SALES = "#ee7203";
const SERIES_COLL = "#2f6f9f";
const SPARK_MONTHS = 6;
const FORM_MONTHS = 5;

type SortKey = "rank" | "sales" | "collections" | "pending" | "sold" | "collected" | "total" | "name";
const SORT_LABEL: Record<SortKey, string> = {
  rank: "Weakest overall first",
  sales: "Lowest sales productivity",
  collections: "Lowest collections productivity",
  pending: "Most awaiting payment",
  sold: "Most floor and plaster SQM-E sold",
  collected: "Most floor and plaster SQM-E collected",
  total: "Most SQM-E sold, all products",
  name: "Name",
};

/**
 * Same grading as Rwanda: the absolute target for "top", the peer distribution
 * for the rest. People whose role is not ranked (team leaders, managers) are
 * listed only when asked for, and never graded.
 */
type Grade = "top" | "above" | "below" | "support" | "none" | "unranked";
const GRADE_LABEL: Record<Grade, string> = {
  top: "Top performer",
  above: "Above average",
  below: "Below average",
  support: "Needs support",
  none: "No target",
  unranked: "Not ranked",
};
const GRADE_COLOR: Record<Grade, string> = {
  top: "var(--good)",
  above: "#2f6f9f",
  below: "var(--warning)",
  support: "var(--critical)",
  none: "var(--text-muted)",
  unranked: "var(--text-muted)",
};

const quantile = (sorted: number[], q: number): number =>
  sorted.length === 0 ? 0 : sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * q))];

/**
 * One number per CSO: the mean of the SQM-E sales and collections ratios. SQM-E is
 * the basis (2026-09-17) because nearly half of UG and KE contracts are follow-on
 * phases, each paid and collected on its own.
 */
function scoreOf(m: UgkeCsoMonth): number | null {
  const parts = [m.pctSoldSqme, m.pctCollectedSqme].filter((v): v is number => v != null);
  return parts.length ? parts.reduce((s, v) => s + v, 0) / parts.length : null;
}

const pctText = (v: number | null) => (v == null ? "-" : `${Math.round(v * 100)}%`);
const n0 = (v: number) => fmtInt(Math.round(v));
/** "1 contract", "2 contracts". */
const cnt = (v: number, word: string) => `${fmtInt(v)} ${word}${v === 1 ? "" : "s"}`;

function fmtK(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (a >= 1e3) return Math.round(n / 1e3) + "K";
  return String(Math.round(n));
}

const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function fmtDate(iso: string | null): string {
  if (!iso) return "";
  const [y, m, d] = iso.split("-").map(Number);
  return `${d} ${MON[m - 1]} ${y}`;
}

const positionLabel = (p: string | null) => p ?? "No position on record";

/** Everything sold / collected, paint included, every phase. Plain volume, never scored or coloured. */
const soldAll = (m: UgkeCsoMonth) => ({ contracts: m.soldContracts + m.paintSoldContracts, sqme: m.soldSqme + m.paintSqme, paint: m.paintSoldContracts });
const collectedAll = (m: UgkeCsoMonth) => ({ contracts: m.collectedContracts + m.paintCollectedContracts, sqme: m.collectedSqme + m.paintCollectedSqme, paint: m.paintCollectedContracts });

type FormResult = "hit" | "near" | "miss" | "none";
const FORM_COLOR: Record<FormResult, string> = {
  hit: "var(--good)",
  near: "var(--warning)",
  miss: "var(--critical)",
  none: "var(--border)",
};
function formOf(score: number | null): FormResult {
  if (score == null) return "none";
  if (score >= 1) return "hit";
  if (score >= 0.8) return "near";
  return "miss";
}

function direction(spark: (number | null)[]): "up" | "down" | "flat" {
  const v = spark.filter((x) => x != null) as number[];
  if (v.length < 3) return "flat";
  const first = v[0], last = v[v.length - 1];
  if (last > first * 1.1) return "up";
  if (last < first * 0.9) return "down";
  return "flat";
}

function buildTags(m: UgkeCsoMonth, pending: UgkePending | null, spark: (number | null)[], isNew: boolean): string[] {
  const tags: string[] = [];
  const s = m.pctSoldSqme, c = m.pctCollectedSqme;
  if (m.isPartMonth) tags.push(`Part month (${m.daysAvailable} of ${m.monthDays} days)`);
  if (m.isAwayFromHome) tags.push(`Worked in ${m.branch}`);
  if (m.soldSqme === 0) tags.push(m.paintSqme > 0 ? "Paint only this month" : "No sales this month");
  if (s != null && c != null) {
    if (s - c > 0.3) tags.push("Signing, not collecting");
    else if (c - s > 0.3) tags.push("Collecting, not signing");
  }
  if (m.donatedContracts >= 2) tags.push(`${m.donatedContracts} donated`);
  const dir = direction(spark);
  if (dir === "down") tags.push("Declining");
  if (dir === "up") tags.push("Improving");
  if (pending && pending.over1y >= 3) tags.push(`${pending.over1y} unpaid over a year`);
  if (isNew) tags.push("New CSO");
  return tags.slice(0, 3);
}

type Row = {
  m: UgkeCsoMonth;
  history: UgkeCsoMonth[];
  spark: (number | null)[];
  atTarget: number;
  scored: number;
  pending: UgkePending | null;
  score: number | null;
  grade: Grade;
  rankInBranch: number;
  branchSize: number;
  isNew: boolean;
  tags: string[];
  form: { month: string; label: string; result: FormResult; score: number | null }[];
};

export default function UgkeIndividual({ rows, pending, sample }: { rows: UgkeCsoMonth[]; pending: UgkePending[]; sample?: boolean }) {
  const months = useMemo(() => Array.from(new Set(rows.map((r) => r.month))).sort(), [rows]);
  const monthLabel = useMemo(() => {
    const m = new Map<string, string>();
    for (const r of rows) m.set(r.month, r.monthLabel);
    return m;
  }, [rows]);

  const defaultMonth = useMemo(() => {
    const complete = [...months].reverse().find((m) => rows.some((r) => r.month === m && r.hasTargets && !r.isCurrentMonth));
    return complete ?? months[months.length - 1] ?? "";
  }, [months, rows]);

  const [country, setCountry] = useState<Country>("Uganda");
  const [month, setMonth] = useState(defaultMonth);
  const [branch, setBranch] = useState(ALL);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortKey>("rank");
  const [grade, setGrade] = useState<Grade | "all">("all");
  const [includeLeavers, setIncludeLeavers] = useState(false);
  // Which roles are ranked is still under review, so the rest can be pulled in to look at.
  const [allRoles, setAllRoles] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const cur = CURRENCY[country];

  const pendingBy = useMemo(() => new Map(pending.map((p) => [p.csoId, p])), [pending]);
  const historyBy = useMemo(() => {
    const m = new Map<string, UgkeCsoMonth[]>();
    for (const r of rows) (m.get(r.csoId) ?? m.set(r.csoId, []).get(r.csoId)!).push(r);
    for (const list of m.values()) list.sort((a, b) => a.month.localeCompare(b.month));
    return m;
  }, [rows]);

  const monthRows = useMemo(
    () => rows.filter((r) =>
      r.country === country && r.month === month &&
      (includeLeavers || (r.isActiveStaff && !r.isUnverifiedStaff)) &&
      (allRoles || r.isRanked)),
    [rows, country, month, includeLeavers, allRoles],
  );
  const ranked = useMemo(() => monthRows.filter((r) => r.isRanked), [monthRows]);

  const branchOptions = useMemo(
    () => [ALL, ...Array.from(new Set(monthRows.map((r) => r.branch))).sort()],
    [monthRows],
  );

  /** Rank inside a branch is computed over the whole month, not the filtered view. */
  const branchRanks = useMemo(() => {
    const groups = new Map<string, { id: string; score: number }[]>();
    for (const r of ranked) {
      const sc = scoreOf(r);
      if (sc == null) continue;
      (groups.get(r.branch) ?? groups.set(r.branch, []).get(r.branch)!).push({ id: r.csoId, score: sc });
    }
    const rank = new Map<string, { rank: number; size: number }>();
    for (const list of groups.values()) {
      list.sort((a, b) => b.score - a.score);
      list.forEach((x, i) => rank.set(x.id, { rank: i + 1, size: list.length }));
    }
    return rank;
  }, [ranked]);

  const cuts = useMemo(() => {
    const scores = ranked.map(scoreOf).filter((s): s is number => s != null).sort((a, b) => a - b);
    return { q25: quantile(scores, 0.25), median: quantile(scores, 0.5) };
  }, [ranked]);

  const allRows: Row[] = useMemo(() => {
    return monthRows.map((m): Row => {
      const history = (historyBy.get(m.csoId) ?? []).filter((h) => h.month <= month);
      const window = history.slice(-SPARK_MONTHS);
      const scoredMonths = window.filter((h) => h.pctSoldSqme != null);
      const spark = window.map((h) => h.pctSoldSqme);
      const p = pendingBy.get(m.csoId) ?? null;
      const score = scoreOf(m);
      const r = branchRanks.get(m.csoId);

      let grade: Grade = "none";
      if (!m.isRanked) grade = "unranked";
      else if (score != null) {
        if (score >= 1) grade = "top";
        else if (score <= cuts.q25) grade = "support";
        else if (score >= cuts.median) grade = "above";
        else grade = "below";
      }

      return {
        m, history, spark,
        atTarget: scoredMonths.filter((h) => (h.pctSoldSqme ?? 0) >= 1).length,
        scored: scoredMonths.length,
        pending: p,
        form: history.slice(-FORM_MONTHS).map((h) => {
          const sc = scoreOf(h);
          return { month: h.month, label: h.monthLabel, result: formOf(sc), score: sc };
        }),
        score, grade,
        rankInBranch: r?.rank ?? 0,
        branchSize: r?.size ?? 0,
        isNew: m.isNewCso,
        tags: buildTags(m, p, spark, m.isNewCso),
      };
    });
  }, [monthRows, historyBy, pendingBy, month, branchRanks, cuts]);

  const gradeCounts = useMemo(() => {
    const c: Record<Grade, number> = { top: 0, above: 0, below: 0, support: 0, none: 0, unranked: 0 };
    for (const r of allRows) c[r.grade]++;
    return c;
  }, [allRows]);

  const listed: Row[] = useMemo(() => {
    const q = search.trim().toLowerCase();
    const out = allRows.filter((r) => {
      if (branch !== ALL && r.m.branch !== branch) return false;
      if (grade !== "all" && r.grade !== grade) return false;
      if (q && !`${r.m.cso} ${r.m.branch}`.toLowerCase().includes(q)) return false;
      return true;
    });
    const by: Record<SortKey, (a: Row, b: Row) => number> = {
      rank: (a, b) => (a.score ?? 99) - (b.score ?? 99),
      sales: (a, b) => (a.m.pctSoldSqme ?? 99) - (b.m.pctSoldSqme ?? 99),
      collections: (a, b) => (a.m.pctCollectedSqme ?? 99) - (b.m.pctCollectedSqme ?? 99),
      pending: (a, b) => (b.pending?.sqme ?? 0) - (a.pending?.sqme ?? 0),
      sold: (a, b) => b.m.soldSqme - a.m.soldSqme,
      collected: (a, b) => b.m.collectedSqme - a.m.collectedSqme,
      total: (a, b) => soldAll(b.m).sqme - soldAll(a.m).sqme,
      name: (a, b) => a.m.cso.localeCompare(b.m.cso),
    };
    return [...out].sort(by[sort]);
  }, [allRows, branch, grade, search, sort]);

  /** Branch medians among ranked CSOs, in SQM-E, for the expanded row. */
  const medians = useMemo(() => {
    const med = (xs: number[]) => {
      const a = [...xs].sort((x, y) => x - y);
      return a.length ? a[Math.floor(a.length / 2)] : 0;
    };
    const by = new Map<string, UgkeCsoMonth[]>();
    for (const r of ranked) (by.get(r.branch) ?? by.set(r.branch, []).get(r.branch)!).push(r);
    const out = new Map<string, { n: number; medSold: number; medColl: number }>();
    for (const [b, p] of by) out.set(b, { n: p.length, medSold: med(p.map((x) => x.soldSqme)), medColl: med(p.map((x) => x.collectedSqme)) });
    return out;
  }, [ranked]);
  const medianFor = (b: string) => medians.get(b) ?? { n: 0, medSold: 0, medColl: 0 };

  const exportHeaders = ["CSO", "Country", "Branch", "Position", "Standing", "Rank in branch",
    "Floor & plaster SQM-E sold", "Sales SQM-E target", "Sales % of target",
    "Floor & plaster SQM-E collected", "Collections SQM-E target", "Collections % of target",
    "Floor & plaster contracts sold (every phase)", "Floor & plaster jobs sold (phase 1)", "Floor jobs", "Plaster jobs",
    "Floor & plaster contracts collected (every phase)",
    "Paint SQM-E sold", "Paint contracts sold", "Paint contracts collected",
    "Floor, plaster & paint SQM-E sold", "Floor, plaster & paint contracts sold", "Floor, plaster & paint SQM-E collected", "Floor, plaster & paint contracts collected",
    "Donated contracts", "Awaiting payment (SQM-E)", "Awaiting payment (contracts)", `Cash to reach the gate (${cur})`, "Awaiting payment over a year",
    "Months at target", "Months scored", "Flags"];
  const exportRows: Cell[][] = listed.map((r) => {
    const s = soldAll(r.m), c = collectedAll(r.m);
    return [
      r.m.cso, r.m.country, r.m.homeBranch, positionLabel(r.m.position), GRADE_LABEL[r.grade],
      r.branchSize > 0 ? `${r.rankInBranch} of ${r.branchSize}` : "",
      Math.round(r.m.soldSqme), r.m.minSoldSqme == null ? "" : Math.round(r.m.minSoldSqme),
      r.m.pctSoldSqme == null ? "" : Math.round(r.m.pctSoldSqme * 100),
      Math.round(r.m.collectedSqme), r.m.minCollectedSqme == null ? "" : Math.round(r.m.minCollectedSqme),
      r.m.pctCollectedSqme == null ? "" : Math.round(r.m.pctCollectedSqme * 100),
      r.m.soldContracts, r.m.sold, r.m.soldFloor, r.m.soldPlaster,
      r.m.collectedContracts,
      Math.round(r.m.paintSqme), r.m.paintSoldContracts, r.m.paintCollectedContracts,
      Math.round(s.sqme), s.contracts, Math.round(c.sqme), c.contracts,
      r.m.donatedContracts,
      Math.round(r.pending?.sqme ?? 0), r.pending?.contracts ?? 0, r.pending?.cash ?? 0, r.pending?.over1y ?? 0,
      r.atTarget, r.scored, r.tags.join("; "),
    ];
  });
  const exportName = `cso-${country.toLowerCase()}-individual_${(monthLabel.get(month) ?? month).replace(/\s+/g, "-")}_${stamp()}`;

  return (
    <div className="mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6">
      {sample && (
        <div className="rounded-md border px-4 py-2.5 text-sm"
          style={{ borderColor: "var(--warning)", background: "color-mix(in srgb, var(--warning) 12%, var(--surface))", color: "var(--text-primary)" }}>
          <strong>Sample data.</strong> Names and numbers are made up, for reviewing the layout. Real Salesforce data comes once the page is agreed.
        </div>
      )}

      <header className="flex flex-col gap-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>UG &amp; KE individual CSO performance</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              Every CSO against the same per-person SQM-E standard, scored on floor and plaster across every phase, with everything they sold alongside. Select anyone to see their history.
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Link href="/toolkit/cso-ugke" className="text-sm hover:underline" style={{ color: "var(--accent-ink)" }}>← UG &amp; KE overview</Link>
            <ExportButtons filename={exportName} headers={exportHeaders} rows={exportRows} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Toggle options={COUNTRIES.map((c) => ({ key: c, label: c }))} value={country}
            onChange={(k) => { setCountry(k as Country); setBranch(ALL); setSelected(null); }} />
          <Select label="Month" value={month} options={[...months].reverse()} optionLabel={(m) => monthLabel.get(m) ?? m} onChange={setMonth} />
          <Select label="Branch" value={branch} options={branchOptions} onChange={setBranch} />
          <Select label="Sort by" value={sort} options={Object.keys(SORT_LABEL)} optionLabel={(s) => SORT_LABEL[s as SortKey]} onChange={(v) => setSort(v as SortKey)} />
          <ToggleButton on={includeLeavers} onClick={() => setIncludeLeavers((v) => !v)} onLabel="Including leavers" offLabel="Current staff only" />
          <ToggleButton on={allRoles} onClick={() => setAllRoles((v) => !v)} onLabel="Everyone who sold" offLabel="Ranked roles only" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search CSO, branch…"
            className="min-h-11 w-full flex-1 rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-auto sm:min-w-48"
            style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
        </div>
      </header>

      <section className="rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b p-4" style={{ borderColor: "var(--border)" }}>
          <div className="flex flex-wrap items-center gap-2">
            <GradeChip label="Everyone" count={allRows.length} on={grade === "all"} color="var(--text-secondary)" onClick={() => setGrade("all")} />
            {(["top", "above", "below", "support"] as Grade[]).map((g) => (
              <GradeChip key={g} label={GRADE_LABEL[g]} count={gradeCounts[g]} on={grade === g}
                color={GRADE_COLOR[g]} onClick={() => setGrade(grade === g ? "all" : g)} />
            ))}
            {allRoles && gradeCounts.unranked > 0 && (
              <GradeChip label={GRADE_LABEL.unranked} count={gradeCounts.unranked} on={grade === "unranked"}
                color={GRADE_COLOR.unranked} onClick={() => setGrade(grade === "unranked" ? "all" : "unranked")} />
            )}
          </div>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>
            Graded in SQM-E against target and against peers this month. Select a row for full history.
          </span>
        </div>

        <div className="hidden overflow-x-auto md:block print:block">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ color: "var(--text-muted)", borderBottom: "1px solid var(--border)" }}>
                <Th>CSO</Th>
                <Th>Standing</Th>
                <Th>Sales this month (SQM-E)</Th>
                <Th>Collections this month (SQM-E)</Th>
                <Th right>Awaiting payment</Th>
                <Th right>At target</Th>
                <Th>% of target (last {FORM_MONTHS} months)</Th>
              </tr>
            </thead>
            <tbody>
              {listed.map((r) => (
                <Fragment key={r.m.csoId}>
                  <tr onClick={() => setSelected((c) => (c === r.m.csoId ? null : r.m.csoId))}
                    style={{
                      borderTop: "1px solid var(--border)", cursor: "pointer",
                      background: r.m.csoId === selected
                        ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)"
                        : r.grade === "top" ? "color-mix(in srgb, var(--good) 5%, transparent)"
                        : r.grade === "support" ? "color-mix(in srgb, var(--critical) 5%, transparent)"
                        : "transparent",
                    }}>
                    <Td>
                      <span className="flex items-stretch gap-2.5">
                        <span className="w-0.5 shrink-0 rounded-full" style={{ background: GRADE_COLOR[r.grade] }} />
                        <span className="min-w-0">
                          <span className="block truncate font-medium leading-tight" style={{ color: "var(--text-primary)" }}>{r.m.cso}</span>
                          <span className="block text-xs" style={{ color: "var(--text-muted)" }}>
                            {r.m.homeBranch}
                            {r.branchSize > 0 && ` · #${r.rankInBranch} of ${r.branchSize}`}
                            {r.m.position !== "Customer Sales Officer" && ` · ${positionLabel(r.m.position)}`}
                          </span>
                        </span>
                      </span>
                    </Td>
                    <Td>
                      <span className="inline-block rounded px-1.5 py-0.5 text-xs font-semibold"
                        style={{ background: `color-mix(in srgb, ${GRADE_COLOR[r.grade]} 16%, transparent)`, color: "var(--text-primary)" }}>
                        {GRADE_LABEL[r.grade]}
                      </span>
                      {r.tags.length > 0 && (
                        <span className="mt-1 flex flex-wrap gap-1">
                          {r.tags.map((t) => (
                            <span key={t} className="rounded px-1.5 py-0.5 text-[11px]"
                              style={{ border: "1px solid var(--border)", color: "var(--text-secondary)" }}>{t}</span>
                          ))}
                        </span>
                      )}
                    </Td>
                    <Td><Progress actual={r.m.soldSqme} target={r.m.minSoldSqme} pct={r.m.pctSoldSqme} tone={SERIES_SALES}
                      extra={`floor and plaster · ${cnt(r.m.soldContracts, "contract")}, ${cnt(r.m.sold, "job")}`} total={soldAll(r.m)} /></Td>
                    <Td><Progress actual={r.m.collectedSqme} target={r.m.minCollectedSqme} pct={r.m.pctCollectedSqme} tone={SERIES_COLL}
                      extra={`floor and plaster · ${cnt(r.m.collectedContracts, "contract")}`} total={collectedAll(r.m)} /></Td>
                    <Td right>
                      {r.pending && r.pending.contracts > 0 ? (
                        <>
                          <span className="block font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{n0(r.pending.sqme)} SQM-E</span>
                          <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{cnt(r.pending.contracts, "contract")} · {fmtK(r.pending.cash)} {cur} to go</span>
                          {r.pending.over1y > 0 && (
                            <span className="block text-xs" style={{ color: "var(--warning)" }}>{fmtInt(r.pending.over1y)} over a year</span>
                          )}
                        </>
                      ) : <span style={{ color: "var(--text-muted)" }}>-</span>}
                    </Td>
                    <Td right>
                      {r.scored > 0 ? (
                        <>
                          <span className="block font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{r.atTarget} of {r.scored}</span>
                          <span className="block text-xs" style={{ color: "var(--text-muted)" }}>months</span>
                        </>
                      ) : <span style={{ color: "var(--text-muted)" }}>-</span>}
                    </Td>
                    <Td><Form form={r.form} /></Td>
                  </tr>
                  {r.m.csoId === selected && (
                    <tr>
                      <td colSpan={7} className="p-0">
                        <Detail row={r} month={month} cur={cur} peers={medianFor(r.m.branch)}
                          history={historyBy.get(r.m.csoId) ?? []} onClose={() => setSelected(null)} />
                      </td>
                    </tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>

        {/* Phones get stacked cards; the same tap expands the same detail. */}
        <div className="flex flex-col md:hidden">
          {listed.map((r) => (
            <div key={r.m.csoId} className="border-t" style={{ borderColor: "var(--border)" }}>
              <button type="button" onClick={() => setSelected((c) => (c === r.m.csoId ? null : r.m.csoId))}
                className="w-full border-l-4 p-4 text-left"
                style={{
                  borderLeftColor: GRADE_COLOR[r.grade],
                  background: r.m.csoId === selected ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)" : "transparent",
                }}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <span className="block truncate font-medium" style={{ color: "var(--text-primary)" }}>{r.m.cso}</span>
                    <span className="block text-xs" style={{ color: "var(--text-muted)" }}>
                      {r.m.homeBranch}
                      {r.branchSize > 0 && ` · #${r.rankInBranch} of ${r.branchSize}`}
                      {r.m.position !== "Customer Sales Officer" && ` · ${positionLabel(r.m.position)}`}
                    </span>
                  </div>
                  <span className="shrink-0 rounded px-1.5 py-0.5 text-[11px] font-semibold"
                    style={{ background: `color-mix(in srgb, ${GRADE_COLOR[r.grade]} 16%, transparent)`, color: "var(--text-primary)" }}>
                    {GRADE_LABEL[r.grade]}
                  </span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-3">
                  <Progress actual={r.m.soldSqme} target={r.m.minSoldSqme} pct={r.m.pctSoldSqme} tone={SERIES_SALES}
                    extra={`SQM-E sold · ${cnt(r.m.soldContracts, "contract")}`} total={soldAll(r.m)} />
                  <Progress actual={r.m.collectedSqme} target={r.m.minCollectedSqme} pct={r.m.pctCollectedSqme} tone={SERIES_COLL}
                    extra={`SQM-E collected · ${cnt(r.m.collectedContracts, "contract")}`} total={collectedAll(r.m)} />
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                  <Form form={r.form} />
                  <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                    {r.pending && r.pending.contracts > 0
                      ? `${n0(r.pending.sqme)} SQM-E awaiting payment · ${fmtK(r.pending.cash)} ${cur} to go`
                      : "Nothing awaiting payment"}
                  </span>
                </div>
                {r.tags.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {r.tags.map((t) => (
                      <span key={t} className="rounded px-1.5 py-0.5 text-[11px]"
                        style={{ border: "1px solid var(--border)", color: "var(--text-secondary)" }}>{t}</span>
                    ))}
                  </div>
                )}
              </button>
              {r.m.csoId === selected && (
                <Detail row={r} month={month} cur={cur} peers={medianFor(r.m.branch)}
                  history={historyBy.get(r.m.csoId) ?? []} onClose={() => setSelected(null)} />
              )}
            </div>
          ))}
        </div>

        {listed.length === 0 && (
          <p className="p-8 text-center text-sm" style={{ color: "var(--text-muted)" }}>No CSOs match these filters.</p>
        )}
      </section>

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        Productivity is measured in SQM-E across every phase: in Uganda and Kenya nearly half of all contracts are follow-on phases, each priced, paid and collected on its own. A contract is any phase, as Salesforce lists it; a job is phase 1, one per house. The coloured score counts floor and plaster only, because that is what the targets are set on. The plain &quot;Floor, plaster &amp; paint&quot; line underneath adds paint (SQM-E at the plaster weight, m² × 0.333) and is volume, not a score. A phase counts as collected when it reaches its own payment gate (50% floor, 75% plaster, 100% paint). Awaiting payment means contracts the CSO signed where the customer has not yet paid to that gate and construction has not started: the same test as the Collections module, counted as of today rather than for the selected month. Ranked: Customer Sales Officers, Sales Agents, Sales Reps and sellers with no position on record; team leaders and managers are not ranked, and this rule is under review. Only CSOs with activity in the month appear.
      </p>
    </div>
  );
}

/**
 * The coloured part is the score (floor and plaster SQM-E against target). The line
 * under the rule is everything sold, paint included, in plain ink: volume, not
 * performance, so it deliberately carries no colour.
 */
function Progress({ actual, target, pct, tone, extra, total }: {
  actual: number; target: number | null; pct: number | null; tone: string; extra: string;
  total?: { contracts: number; sqme: number; paint: number };
}) {
  return (
    <div className="flex min-w-44 flex-col gap-1">
      <span className="flex items-baseline gap-1.5">
        <span className="font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{n0(actual)}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>of {target == null ? "-" : n0(target)}</span>
        <span className="ml-auto text-xs font-medium tabular-nums" style={{ color: "var(--text-secondary)" }}>{pctText(pct)}</span>
      </span>
      <span className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: tone }} />
      </span>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>{extra}</span>
      {total && (
        <span className="mt-0.5 border-t pt-1 text-xs tabular-nums" style={{ borderColor: "var(--border)", color: "var(--text-secondary)" }}>
          Floor, plaster &amp; paint: <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{n0(total.sqme)} SQM-E</span> · {cnt(total.contracts, "contract")}
          {total.paint > 0 && <span style={{ color: "var(--text-muted)" }}> · incl. {total.paint} paint</span>}
        </span>
      )}
    </div>
  );
}

function Detail({ row, month, cur, peers, history, onClose }: {
  row: Row;
  month: string;
  cur: string;
  peers: { n: number; medSold: number; medColl: number };
  history: UgkeCsoMonth[];
  onClose: () => void;
}) {
  const m = row.m;
  const s = soldAll(m), c = collectedAll(m);
  return (
    <div className="border-l-2 p-5" style={{ background: "var(--page)", borderColor: "var(--accent-strong)" }}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{m.cso}</h3>
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>
            {m.homeBranch} branch
            {row.branchSize > 0 && ` · #${row.rankInBranch} of ${row.branchSize} in branch`}
            {` · ${positionLabel(m.position)}`}
            {m.supervisor ? ` · reports to ${m.supervisor}` : ""}
            {m.hireDate ? ` · hired ${fmtDate(m.hireDate)}` : ""}
            {m.phone ? " · " : ""}
            {m.phone && <a href={telHref(m.phone) ?? undefined} className="hover:underline" style={{ color: "var(--accent-ink)" }}>{m.phone}</a>}
          </p>
          {m.isAwayFromHome && (
            <p className="mt-0.5 text-xs" style={{ color: "var(--warning)" }}>This month&apos;s work was in {m.branch}, outside their usual branch.</p>
          )}
        </div>
        <button type="button" onClick={onClose} className="rounded-md border px-2.5 py-1 text-sm"
          style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>
          Collapse
        </button>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Sales productivity" pct={m.pctSoldSqme} tone={SERIES_SALES}
          sub={`${n0(m.soldSqme)} SQM-E sold of ${m.minSoldSqme == null ? "-" : n0(m.minSoldSqme)} target · ${cnt(m.soldContracts, "contract")}, ${cnt(m.sold, "job")}`} />
        <Stat label="Collections productivity" pct={m.pctCollectedSqme} tone={SERIES_COLL}
          sub={`${n0(m.collectedSqme)} SQM-E collected of ${m.minCollectedSqme == null ? "-" : n0(m.minCollectedSqme)} target · ${cnt(m.collectedContracts, "contract")}`} />
        <Plain label="Awaiting payment" value={row.pending ? `${n0(row.pending.sqme)} SQM-E` : "0"}
          sub={row.pending
            ? `${cnt(row.pending.contracts, "contract")} · ${fmtK(row.pending.cash)} ${cur} still to reach the gate · ${row.pending.over1y} over a year`
            : "Every contract they signed is paid to the gate"} />
        <Plain label="Branch median" value={`${n0(peers.medSold)} SQM-E sold`} sub={`${n0(peers.medColl)} SQM-E collected · ${peers.n} CSOs`} />
      </div>

      <h4 className="mt-5 text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Everything they sold this month</h4>
      <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <Plain label="Floor" value={`${n0(m.soldFloorSqme)} SQM-E`} sub={`${cnt(m.soldFloor, "job")} · scored`} />
        <Plain label="Plaster" value={`${n0(m.soldSqme - m.soldFloorSqme)} SQM-E`} sub={`${cnt(m.soldPlaster, "job")} · scored`} />
        <Plain label="Paint" value={`${n0(m.paintSqme)} SQM-E`} sub={`${cnt(m.paintSoldContracts, "contract")} (${n0(m.paintM2)} m²) · not scored`} />
        <Plain label="Donated or zero value" value={fmtInt(m.donatedContracts)} sub="contracts, nothing to collect · not scored" />
        <Plain label="Floor, plaster &amp; paint" value={`${n0(s.sqme)} SQM-E`} sub={`${cnt(s.contracts, "contract")} sold · ${n0(c.sqme)} SQM-E collected`} />
      </div>

      <Trend trend={history} selected={month} />
    </div>
  );
}

function Form({ form }: { form: { month: string; label: string; result: FormResult; score: number | null }[] }) {
  if (form.length === 0) return <span className="text-xs" style={{ color: "var(--text-muted)" }}>no history</span>;
  const pad: FormResult[] = Array(Math.max(0, FORM_MONTHS - form.length)).fill("none");
  return (
    <span className="flex items-center gap-1">
      {pad.map((_, i) => (
        <span key={`pad${i}`} className="grid h-5 min-w-9 place-items-center rounded px-1 text-[11px] font-semibold"
          style={{ background: "var(--border)", color: "var(--text-muted)" }}>·</span>
      ))}
      {form.map((f, i) => (
        <span key={f.month} title={`${f.label}: ${pctText(f.score)} of target`}
          className="grid h-5 min-w-9 place-items-center rounded px-1 text-[11px] font-semibold tabular-nums"
          style={{
            background: FORM_COLOR[f.result], color: "#fff",
            outline: i === form.length - 1 ? "2px solid var(--text-primary)" : "none", outlineOffset: "1px",
          }}>
          {pctText(f.score)}
        </span>
      ))}
    </span>
  );
}

function Trend({ trend, selected }: { trend: UgkeCsoMonth[]; selected: string }) {
  const narrow = useNarrow();
  const all = trend.filter((t) => t.pctSoldSqme != null || t.pctCollectedSqme != null);
  const pts = narrow ? all.slice(-5) : all;
  if (pts.length < 2) return null;

  const W = narrow ? 380 : 800;
  const H = narrow ? 210 : 180;
  const padL = narrow ? 40 : 46, padR = narrow ? 16 : 22, padT = 16, padB = narrow ? 32 : 30;
  const fs = narrow ? 13 : 10.5;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const rawMax = Math.max(...pts.flatMap((d) => [d.pctSoldSqme ?? 0, d.pctCollectedSqme ?? 0]));
  const yMax = Math.max(1.25, Math.ceil((rawMax * 1.08) / 0.25) * 0.25);
  const step = yMax > 3 ? 1 : 0.5;
  const ticks: number[] = [];
  for (let t = 0; t <= yMax + 1e-9; t += step) ticks.push(Number(t.toFixed(2)));
  const x = (i: number) => padL + (i * plotW) / (pts.length - 1);
  const y = (v: number) => padT + plotH * (1 - v / yMax);
  const path = (get: (t: UgkeCsoMonth) => number | null) =>
    pts.map((d, i) => (get(d) == null ? null : `${i === 0 || get(pts[i - 1]) == null ? "M" : "L"}${x(i)},${y(get(d)!)}`))
      .filter(Boolean).join(" ");
  const areaOf = (get: (t: UgkeCsoMonth) => number | null) => {
    const v = pts.map((d, i) => ({ i, val: get(d) })).filter((p) => p.val != null);
    if (v.length < 2) return "";
    return `M${x(v[0].i)},${y(v[0].val!)}` + v.slice(1).map((p) => `L${x(p.i)},${y(p.val!)}`).join("")
      + `L${x(v[v.length - 1].i)},${padT + plotH}L${x(v[0].i)},${padT + plotH}Z`;
  };

  return (
    <div className="mt-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>History (SQM-E against target)</h3>
        <div className="flex items-center gap-4 text-xs" style={{ color: "var(--text-muted)" }}>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: SERIES_SALES }} />Sales</span>
          <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: SERIES_COLL }} />Collections</span>
        </div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="mt-2 w-full" style={{ maxHeight: narrow ? 220 : 200, overflow: "visible" }} role="img"
        aria-label="This CSO's sales and collections productivity by month">
        <defs>
          <linearGradient id="ugkeIndSales" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_SALES} stopOpacity="0.16" />
            <stop offset="100%" stopColor={SERIES_SALES} stopOpacity="0" />
          </linearGradient>
          <linearGradient id="ugkeIndColl" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_COLL} stopOpacity="0.14" />
            <stop offset="100%" stopColor={SERIES_COLL} stopOpacity="0" />
          </linearGradient>
        </defs>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeWidth="1" opacity={t === 0 ? 0.9 : 0.45} />
            <text x={padL - 10} y={y(t) + 4} textAnchor="end" fontSize={fs} fill="var(--text-muted)">{Math.round(t * 100)}%</text>
          </g>
        ))}
        <line x1={padL} x2={W - padR} y1={y(1)} y2={y(1)} stroke="var(--text-secondary)" strokeWidth="1.25" strokeDasharray="4 5" opacity="0.75" />
        <text x={W - padR + 4} y={y(1) + 3.5} fontSize={fs} fill="var(--text-muted)">target</text>
        <path d={areaOf((t) => t.pctSoldSqme)} fill="url(#ugkeIndSales)" />
        <path d={areaOf((t) => t.pctCollectedSqme)} fill="url(#ugkeIndColl)" />
        <path d={path((t) => t.pctSoldSqme)} fill="none" stroke={SERIES_SALES} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />
        <path d={path((t) => t.pctCollectedSqme)} fill="none" stroke={SERIES_COLL} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />
        {pts.map((d, i) => (
          <g key={d.month}>
            {d.pctSoldSqme != null && (
              <circle cx={x(i)} cy={y(d.pctSoldSqme)} r={d.month === selected ? 5 : 3} fill={SERIES_SALES} stroke="var(--surface)" strokeWidth="2">
                <title>{`${d.monthLabel} · sales ${pctText(d.pctSoldSqme)}`}</title>
              </circle>
            )}
            {d.pctCollectedSqme != null && (
              <circle cx={x(i)} cy={y(d.pctCollectedSqme)} r={d.month === selected ? 5 : 3} fill={SERIES_COLL} stroke="var(--surface)" strokeWidth="2">
                <title>{`${d.monthLabel} · collections ${pctText(d.pctCollectedSqme)}`}</title>
              </circle>
            )}
            <text x={x(i)} y={H - 12} textAnchor="middle" fontSize={fs}
              fill={d.month === selected ? "var(--text-primary)" : "var(--text-muted)"} fontWeight={d.month === selected ? 600 : 400}>
              {d.monthLabel.slice(0, 3)}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

function Stat({ label, pct, tone, sub }: { label: string; pct: number | null; tone: string; sub: string }) {
  const b = band(pct);
  return (
    <div className="rounded-md border p-3" style={{ borderColor: "var(--border)", borderTop: `3px solid ${tone}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 text-2xl font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</div>
      <span className="mt-0.5 block text-xs font-medium" style={{ color: BAND_COLOR[b] }}>{BAND_LABEL[b]}</span>
      <span className="mt-1 block text-xs" style={{ color: "var(--text-muted)" }}>{sub}</span>
    </div>
  );
}

function Plain({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-md border p-3" style={{ borderColor: "var(--border)" }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 text-2xl font-semibold" style={{ color: "var(--text-primary)" }}>{value}</div>
      <span className="mt-1 block text-xs" style={{ color: "var(--text-muted)" }}>{sub}</span>
    </div>
  );
}

function GradeChip({ label, count, on, color, onClick }: { label: string; count: number; on: boolean; color: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick}
      className="flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium"
      style={{
        borderColor: on ? color : "var(--border)",
        background: on ? `color-mix(in srgb, ${color} 12%, var(--surface))` : "var(--surface)",
        color: "var(--text-primary)",
      }}>
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
      <span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtInt(count)}</span>
    </button>
  );
}

function ToggleButton({ on, onClick, onLabel, offLabel }: { on: boolean; onClick: () => void; onLabel: string; offLabel: string }) {
  return (
    <button type="button" onClick={onClick} className="rounded-md border px-2.5 py-1.5 text-sm"
      style={{
        background: "var(--surface)",
        borderColor: on ? "var(--accent-strong)" : "var(--border)",
        color: on ? "var(--text-primary)" : "var(--text-secondary)",
      }}>
      {on ? onLabel : offLabel}
    </button>
  );
}

function Toggle({ options, value, onChange }: { options: { key: string; label: string }[]; value: string; onChange: (k: string) => void }) {
  return (
    <div className="inline-flex rounded-md border p-0.5" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      {options.map((o) => {
        const on = o.key === value;
        return (
          <button key={o.key} type="button" onClick={() => onChange(o.key)} className="rounded px-2.5 py-1 text-sm font-medium"
            style={{ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" }}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function Th({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <th className={`px-3 py-2 font-medium ${right ? "text-right" : "text-left"}`}>{children}</th>;
}
function Td({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <td className={`px-3 py-2.5 align-top ${right ? "text-right tabular-nums" : "text-left"}`}>{children}</td>;
}

function Select({ label, value, options, onChange, optionLabel }: { label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string }) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}
