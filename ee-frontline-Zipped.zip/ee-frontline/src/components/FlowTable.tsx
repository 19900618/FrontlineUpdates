"use client";

import { useMemo, useState } from "react";
import ExportButtons from "./ExportButtons";
import Spinner from "./Spinner";
import { type Cell } from "@/lib/export";
import { bucketLabel, fmtInt, stageName, telHref } from "@/lib/format";
import { PRODUCT_LABEL, STEPS, fmtDay, stepOf, type FlowPick, type FlowRow, type LocDim, type MoveTotal } from "@/lib/journey-flow-shared";

const productOf = (r: FlowRow) => PRODUCT_LABEL[r.product_family] ?? r.product_family;

const PAGE = 50;
const WIDTHS = [12, 22, 26, 26, 20, 16, 22, 10, 14, 14, 18, 14, 12, 14, 12, 8, 26];

const nowAt = (r: FlowRow) => (r.now_bucket ? bucketLabel(r.now_bucket) : r.now_stage ? stageName(r.now_stage) : "");
const took = (r: FlowRow) =>
  r.days_from_prev == null ? "" : r.days_from_prev === 0 ? "same day" : `${fmtInt(r.days_from_prev)} day${r.days_from_prev === 1 ? "" : "s"}`;
const fromText = (r: FlowRow) => (r.from_key == null ? "New contract" : `from ${stepOf(r.from_key)?.name ?? ""}`);

/**
 * The customers behind the numbers: everyone who moved in the period, or just the
 * movement tapped above. Chips switch movement without scrolling back up. Exports
 * exactly what is listed (the search included).
 */
export default function FlowTable({ rows, truncated, loading, error, totals, pick, onPick, onClear, windowTitle, dim, filenameBase }: {
  rows: FlowRow[];
  truncated: boolean;
  loading: boolean;
  error: string | null;
  totals: MoveTotal[];
  pick: FlowPick;
  onPick: (to: number) => void;
  onClear: () => void;
  windowTitle: string;
  dim: LocDim;
  filenameBase: string;
}) {
  const [search, setSearch] = useState("");
  // "Show more" resets whenever a new list arrives, without an effect.
  const [more, setMore] = useState<{ rows: FlowRow[]; n: number }>({ rows, n: PAGE });
  const limit = more.rows === rows ? more.n : PAGE;

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter((r) =>
      `${r.customer_name ?? ""} ${r.opportunity_label ?? ""} ${r.phone ?? ""} ${r.cso_name ?? ""} ${r.territory} ${r.branch}`.toLowerCase().includes(s),
    );
  }, [rows, search]);
  const shown = filtered.slice(0, limit);

  const count = (k: number) => totals.find((t) => t.to === k)?.n ?? 0;
  const allMoves = totals.reduce((s, t) => s + t.n, 0);
  const chips = STEPS.filter((s) => s.key !== 3 || count(3) > 0);
  const locOf = (r: FlowRow) => (dim === "branch" ? r.branch : r.territory);
  const title = pick
    ? pick.from != null
      ? `${stepOf(pick.from)?.name} to ${stepOf(pick.to)?.name}`
      : stepOf(pick.to)?.name ?? ""
    : "Every move";

  const headers = [
    "Moved on", "Step reached", "Came from", "Customer", "Opportunity", "Phone", "CSO", "Country", "Branch", "District",
    "Territory", "Product", "Signed date", "Previous step on", "Days since previous step", "Steps jumped", "Now at",
  ];
  const rowFor = (r: FlowRow): Cell[] => [
    r.event_date, stepOf(r.to_key)?.name ?? "", r.from_key == null ? "New contract" : stepOf(r.from_key)?.name ?? "",
    r.customer_name ?? "", r.opportunity_label ?? "", r.phone ?? "", r.cso_name ?? "", r.country, r.branch, r.district ?? "",
    r.territory, productOf(r), r.signed_date ?? "", r.from_date ?? "", r.days_from_prev ?? "",
    r.skipped_steps || "", nowAt(r),
  ];

  // Excel: every move on one tab, then a tab per step reached. The library loads only on click.
  const [busy, setBusy] = useState(false);
  async function downloadExcel() {
    setBusy(true);
    try {
      const { default: writeExcelFile } = await import("write-excel-file/universal");
      const header = headers.map((h) => ({ value: h, fontWeight: "bold" as const }));
      const columns = WIDTHS.map((width) => ({ width }));
      const tab = (sheet: string, list: FlowRow[]) => ({
        data: [header, ...list.map((r) => rowFor(r).map((v) => (v === "" || v == null ? null : v)))],
        sheet,
        columns,
        stickyRowsCount: 1,
      });
      const sheets = [
        tab("All moves", filtered),
        ...STEPS.filter((s) => filtered.some((r) => r.to_key === s.key)).map((s) => tab(s.name.slice(0, 31), filtered.filter((r) => r.to_key === s.key))),
      ];
      const blob = await writeExcelFile(sheets).toBlob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${filenameBase}.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="flex flex-col gap-3 rounded-lg border p-4 sm:p-5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
          Customers who moved: {title}
        </h2>
        <span className="text-sm" style={{ color: "var(--text-muted)" }}>{windowTitle}</span>
      </div>

      <div className="flex flex-wrap gap-2">
        <Chip active={!pick} onClick={onClear} label="Every move" n={allMoves} />
        {chips.map((s) => (
          <Chip key={s.key} active={pick?.to === s.key && pick.from == null} onClick={() => onPick(s.key)} label={s.name} n={count(s.key)} color={s.color} />
        ))}
        {pick?.from != null && (
          <Chip active onClick={onClear} label={`${stepOf(pick.from)?.short} to ${stepOf(pick.to)?.short}`} suffix="×" />
        )}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, phone, CSO, place…"
          className="min-h-11 w-full rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-72"
          style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
        <div className="flex flex-wrap items-center gap-2">
          <ExportButtons filename={filenameBase} headers={headers} rows={filtered.map(rowFor)} />
          <button type="button" onClick={downloadExcel} disabled={busy || filtered.length === 0}
            className="min-h-11 rounded-md border px-3 py-1.5 text-sm font-medium sm:min-h-0"
            style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)", opacity: busy ? 0.6 : 1 }}>
            {busy ? "Preparing Excel…" : "Download Excel (tab per step)"}
          </button>
        </div>
      </div>

      <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
        {loading ? <Spinner label="Loading customers…" /> : `${fmtInt(filtered.length)} ${filtered.length === 1 ? "move" : "moves"}${search ? " match the search" : ""}`}
        {truncated && !loading && " (the first 3,000; pick a step or a territory to see the rest)"}
      </p>
      {error && <p className="text-sm" style={{ color: "var(--critical)" }}>Couldn&apos;t load the list: {error}</p>}

      <div style={{ opacity: loading ? 0.5 : 1, transition: "opacity .15s" }}>
        {/* wide screens: table */}
        <div className="hidden overflow-hidden rounded-md border lg:block print:block" style={{ borderColor: "var(--border)" }}>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs" style={{ background: "var(--page)", color: "var(--text-muted)" }}>
                <th className="px-3 py-2 font-medium">Moved on</th>
                <th className="px-3 py-2 font-medium">Step reached</th>
                <th className="px-3 py-2 font-medium">Customer</th>
                <th className="px-3 py-2 font-medium">Phone</th>
                <th className="px-3 py-2 font-medium">CSO</th>
                <th className="px-3 py-2 font-medium">{dim === "branch" ? "Branch" : "Territory"}</th>
                <th className="px-3 py-2 font-medium">Product</th>
                <th className="px-3 py-2 text-right font-medium">Took</th>
                <th className="px-3 py-2 font-medium">Now at</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((r) => {
                const s = stepOf(r.to_key);
                const tel = telHref(r.phone);
                return (
                  <tr key={`${r.opportunity_id}-${r.to_key}`} className="border-t align-top" style={{ borderColor: "var(--grid)" }}>
                    <td className="whitespace-nowrap px-3 py-2 tabular-nums" style={{ color: "var(--text-secondary)" }}>{fmtDay(r.event_date)}</td>
                    <td className="px-3 py-2">
                      <span className="flex items-center gap-1.5 font-medium" style={{ color: "var(--text-primary)" }}>
                        <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: s?.color }} />{s?.name}
                      </span>
                      {r.from_key != null && (
                        <span className="text-xs" style={{ color: r.skipped_steps > 0 ? "var(--accent-ink)" : "var(--text-muted)" }}>
                          {fromText(r)}{r.skipped_steps > 0 ? ", jumped a step" : ""}
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2">
                      <span style={{ color: "var(--text-primary)" }}>{r.customer_name ?? "Unnamed"}</span>
                      <span className="block max-w-64 truncate text-xs" style={{ color: "var(--text-muted)" }} title={r.opportunity_label ?? ""}>
                        {r.opportunity_label}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-3 py-2">
                      {tel ? <a href={tel} style={{ color: "var(--accent-ink)" }}>{r.phone}</a> : <span style={{ color: "var(--text-muted)" }}>{r.phone ?? ""}</span>}
                    </td>
                    <td className="px-3 py-2" style={{ color: "var(--text-secondary)" }}>{r.cso_name ?? ""}</td>
                    <td className="px-3 py-2" style={{ color: "var(--text-secondary)" }}>{locOf(r)}</td>
                    <td className="px-3 py-2" style={{ color: "var(--text-secondary)" }}>{productOf(r)}</td>
                    <td className="whitespace-nowrap px-3 py-2 text-right tabular-nums" style={{ color: "var(--text-secondary)" }}>{took(r)}</td>
                    <td className="whitespace-nowrap px-3 py-2" style={{ color: "var(--text-secondary)" }}>{nowAt(r)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {!loading && filtered.length === 0 && (
            <p className="p-6 text-center text-sm" style={{ color: "var(--text-muted)" }}>Nobody made this move in the period.</p>
          )}
        </div>

        {/* phones and tablets: cards */}
        <div className="flex flex-col gap-2 lg:hidden print:hidden">
          {shown.map((r) => {
            const s = stepOf(r.to_key);
            const tel = telHref(r.phone);
            return (
              <div key={`${r.opportunity_id}-${r.to_key}`} className="flex flex-col gap-1 rounded-md border p-3"
                style={{ borderColor: "var(--border)", borderLeft: `4px solid ${s?.color}` }}>
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{s?.name}</span>
                  <span className="text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtDay(r.event_date)}</span>
                </div>
                <span className="text-sm" style={{ color: "var(--text-primary)" }}>
                  {r.customer_name ?? "Unnamed"} <span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.opportunity_label}</span>
                </span>
                {r.from_key != null && (
                  <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
                    {fromText(r)}{took(r) ? `, took ${took(r)}` : ""}{r.skipped_steps > 0 ? ", jumped a step" : ""}
                  </span>
                )}
                <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                  {[locOf(r), productOf(r), r.cso_name].filter(Boolean).join(" · ")}
                </span>
                <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs" style={{ color: "var(--text-secondary)" }}>Now: {nowAt(r)}</span>
                  {tel && (
                    <a href={tel} className="min-h-11 rounded-md px-3 py-2 text-sm font-medium text-white" style={{ background: "var(--accent-strong)" }}>
                      Call {r.phone}
                    </a>
                  )}
                </div>
              </div>
            );
          })}
          {!loading && filtered.length === 0 && (
            <p className="p-4 text-center text-sm" style={{ color: "var(--text-muted)" }}>Nobody made this move in the period.</p>
          )}
        </div>

        {filtered.length > limit && (
          <button type="button" onClick={() => setMore({ rows, n: limit + 200 })}
            className="mt-3 min-h-11 w-full rounded-md border px-3 py-2 text-sm font-medium sm:min-h-0"
            style={{ borderColor: "var(--border)", color: "var(--accent-ink)", background: "var(--surface)" }}>
            Show more ({fmtInt(filtered.length - limit)} not shown yet)
          </button>
        )}
      </div>
    </section>
  );
}

function Chip({ active, onClick, label, n, color, suffix }: {
  active: boolean;
  onClick: () => void;
  label: string;
  n?: number;
  color?: string;
  suffix?: string;
}) {
  return (
    <button type="button" onClick={onClick} aria-pressed={active}
      className="flex min-h-11 items-center gap-1.5 rounded-full border px-3 py-1 text-sm sm:min-h-0"
      style={{
        borderColor: active ? "var(--accent-strong)" : "var(--border)",
        background: active ? "rgba(238,114,3,.1)" : "var(--surface)",
        color: active ? "var(--text-primary)" : "var(--text-secondary)",
        fontWeight: active ? 600 : 400,
      }}>
      {color && <span className="h-2 w-2 rounded-full" style={{ background: color }} />}
      {label}
      {n != null && <span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtInt(n)}</span>}
      {suffix && <span aria-hidden>{suffix}</span>}
    </button>
  );
}
