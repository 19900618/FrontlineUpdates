"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  COUNTRIES, CURRENCY, ESTABLISHMENT, FLOOR_SHARE_TARGET,
  type Country, type UgkeBranchMonth, type UgkeCsoMonth, type UgkePending,
} from "@/lib/cso-ugke-types";
import { band, BAND_COLOR, BAND_LABEL } from "@/lib/cso-bands";
import { fmtInt } from "@/lib/format";
import { useNarrow } from "@/lib/use-narrow";
import ExportButtons from "@/components/ExportButtons";
import { stamp, type Cell } from "@/lib/export";

const ALL = "All";
/**
 * One identity per link in the chain (sell, collect, build), fixed across every
 * tile, bar and line on the page. Validated as a set on the light surface:
 * worst adjacent CVD dE 20.3. Orange and aqua sit under 3:1 contrast, so every
 * mark carries a text label or legend beside it.
 */
const SERIES_SALES = "#ee7203";
const SERIES_COLL = "#2f6f9f";
const SERIES_BUILD = "#1baf7a";
/** Product mix. Floor and plaster validated as a pair (CVD dE 24.9); paint is neutral because it is not scored. */
const MIX_FLOOR = "#4a3aa7";
const MIX_PLASTER = "#e87ba4";
const MIX_PAINT = "#a8a69f";
const TREND_MONTHS = 9;
const WORST_N = 8;

/**
 * Two layers per group. Productivity is judged on ranked CSOs only (they carry
 * the standard); the "all" figures are what the branch actually sold, including
 * team leaders and managers, and are what an MD reads as volume.
 *
 * SQM-E is the unit of productivity (decided 2026-09-17). Nearly half of UG and KE
 * contracts are follow-on phases, each priced, paid and collected on its own, so a
 * count of jobs hid the work. Contracts (every phase) and jobs (phase 1) stay
 * beside it as volume, so anyone checking against Salesforce can reconcile.
 */
type Agg = {
  csos: number;
  newCsos: number;
  soldSqme: number; collectedSqme: number;
  minSoldSqme: number; minCollectedSqme: number;
  allSoldSqme: number; allSoldFloorSqme: number; allCollectedSqme: number;
  allSoldContracts: number; allCollectedContracts: number;
  allSoldJobs: number; allCollectedJobs: number;
  valueSold: number;
  paintSqme: number; paintM2: number; paintCollectedSqme: number; paintValue: number;
  paintSoldContracts: number; paintCollectedContracts: number;
  donatedContracts: number;
  /** Floor and plaster signed by team leaders and managers. */
  otherSoldSqme: number;
  otherSoldContracts: number;
};

function aggregate(rows: UgkeCsoMonth[]): Agg {
  const a: Agg = {
    csos: 0, newCsos: 0, soldSqme: 0, collectedSqme: 0, minSoldSqme: 0, minCollectedSqme: 0,
    allSoldSqme: 0, allSoldFloorSqme: 0, allCollectedSqme: 0,
    allSoldContracts: 0, allCollectedContracts: 0, allSoldJobs: 0, allCollectedJobs: 0, valueSold: 0,
    paintSqme: 0, paintM2: 0, paintCollectedSqme: 0, paintValue: 0, paintSoldContracts: 0, paintCollectedContracts: 0,
    donatedContracts: 0, otherSoldSqme: 0, otherSoldContracts: 0,
  };
  for (const r of rows) {
    a.allSoldSqme += r.soldSqme; a.allSoldFloorSqme += r.soldFloorSqme; a.allCollectedSqme += r.collectedSqme;
    a.allSoldContracts += r.soldContracts; a.allCollectedContracts += r.collectedContracts;
    a.allSoldJobs += r.sold; a.allCollectedJobs += r.collected; a.valueSold += r.valueSold;
    a.paintSqme += r.paintSqme; a.paintM2 += r.paintM2; a.paintCollectedSqme += r.paintCollectedSqme; a.paintValue += r.paintValue;
    a.paintSoldContracts += r.paintSoldContracts; a.paintCollectedContracts += r.paintCollectedContracts;
    a.donatedContracts += r.donatedContracts;
    if (!r.isRanked) { a.otherSoldSqme += r.soldSqme; a.otherSoldContracts += r.soldContracts; continue; }
    a.csos += 1;
    if (r.isNewCso) a.newCsos += 1;
    a.soldSqme += r.soldSqme; a.collectedSqme += r.collectedSqme;
    a.minSoldSqme += r.minSoldSqme ?? 0; a.minCollectedSqme += r.minCollectedSqme ?? 0;
  }
  return a;
}

type BuildAgg = {
  buildsSqme: number; sqmeTarget: number; buildsContracts: number; builds: number;
  paintBuildsSqme: number; paintBuildsContracts: number; paintBuilds: number;
};
function buildAgg(list: UgkeBranchMonth[]): BuildAgg {
  const b: BuildAgg = { buildsSqme: 0, sqmeTarget: 0, buildsContracts: 0, builds: 0, paintBuildsSqme: 0, paintBuildsContracts: 0, paintBuilds: 0 };
  for (const x of list) {
    b.buildsSqme += x.buildsSqme; b.sqmeTarget += x.sqmeTarget ?? 0;
    b.buildsContracts += x.buildsContracts; b.builds += x.builds;
    b.paintBuildsSqme += x.paintBuildsSqme; b.paintBuildsContracts += x.paintBuildsContracts; b.paintBuilds += x.paintBuilds;
  }
  return b;
}

const ratio = (actual: number, standard: number): number | null => (standard > 0 ? actual / standard : null);
const share = (part: number, whole: number): number | null => (whole > 0 ? part / whole : null);
const salesOf = (a: Agg) => ratio(a.soldSqme, a.minSoldSqme);
const collOf = (a: Agg) => ratio(a.collectedSqme, a.minCollectedSqme);
const buildOf = (b: BuildAgg) => ratio(b.buildsSqme, b.sqmeTarget);
const pctText = (v: number | null) => (v == null ? "-" : `${Math.round(v * 100)}%`);
const n0 = (v: number) => fmtInt(Math.round(v));
/** "1 contract", "2 contracts". */
const cnt = (v: number, word: string) => `${fmtInt(v)} ${word}${v === 1 ? "" : "s"}`;

function fmtK(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e9) return (n / 1e9).toFixed(1) + "B";
  if (a >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (a >= 1e3) return Math.round(n / 1e3) + "K";
  return String(Math.round(n));
}

export default function UgkeOverview({ rows, branches, pending, sample }: {
  rows: UgkeCsoMonth[]; branches: UgkeBranchMonth[]; pending: UgkePending[]; sample?: boolean;
}) {
  const months = useMemo(() => Array.from(new Set(rows.map((r) => r.month))).sort(), [rows]);
  const monthLabel = useMemo(() => {
    const m = new Map<string, string>();
    for (const r of rows) m.set(r.month, r.monthLabel);
    return m;
  }, [rows]);

  // Open on the last COMPLETE month: the month in progress always reads low.
  const defaultMonth = useMemo(() => {
    const complete = [...months].reverse().find((m) => rows.some((r) => r.month === m && r.hasTargets && !r.isCurrentMonth));
    return complete ?? months[months.length - 1] ?? "";
  }, [months, rows]);

  const [country, setCountry] = useState<Country>("Uganda");
  const [month, setMonth] = useState(defaultMonth);
  const [branch, setBranch] = useState(ALL);
  const [includeLeavers, setIncludeLeavers] = useState(false);

  const est = ESTABLISHMENT[country];
  const floorTarget = FLOOR_SHARE_TARGET[country];
  const cur = CURRENCY[country];

  const branchNames = useMemo(
    // "Unassigned" holds work with no location; it is not a branch and has no establishment.
    () => Array.from(new Set(branches.filter((b) => b.country === country && b.branch !== "Unassigned").map((b) => b.branch))).sort(),
    [branches, country],
  );

  const scopeFor = useMemo(
    () => (m: string) =>
      rows.filter((r) =>
        r.country === country && r.month === m &&
        (branch === ALL || r.branch === branch) &&
        (includeLeavers || (r.isActiveStaff && !r.isUnverifiedStaff))),
    [rows, country, branch, includeLeavers],
  );
  const capFor = useMemo(
    () => (m: string) => branches.filter((b) => b.country === country && b.month === m && (branch === ALL || b.branch === branch)),
    [branches, country, branch],
  );

  const scoped = useMemo(() => scopeFor(month), [scopeFor, month]);
  const total = useMemo(() => aggregate(scoped), [scoped]);
  const build = useMemo(() => buildAgg(capFor(month)), [capFor, month]);
  const prevMonth = months[months.indexOf(month) - 1];
  const prev = useMemo(() => (prevMonth ? aggregate(scopeFor(prevMonth)) : null), [prevMonth, scopeFor]);
  const buildPrev = useMemo(() => (prevMonth ? buildAgg(capFor(prevMonth)) : null), [prevMonth, capFor]);

  const salesPct = salesOf(total);
  const collPct = collOf(total);
  const buildPct = buildOf(build);

  const branchesInScope = branch === ALL ? branchNames.length : 1;
  const expectedCsos = branchesInScope * est;
  const isCurrent = scoped.some((r) => r.isCurrentMonth);
  const leftSince = useMemo(
    () => rows.filter((r) => r.country === country && r.month === month && r.isRanked && !r.isActiveStaff &&
      (branch === ALL || r.branch === branch)).length,
    [rows, country, month, branch],
  );

  /** Signed but not yet at the payment gate, right now, for the CSOs in view. */
  const awaiting = useMemo(() => {
    const ids = new Set(rows
      .filter((r) => r.country === country && r.isRanked && (branch === ALL || r.homeBranch === branch) &&
        (includeLeavers || (r.isActiveStaff && !r.isUnverifiedStaff)))
      .map((r) => r.csoId));
    const a = { csos: 0, contracts: 0, sqme: 0, cash: 0, under90d: 0, over1y: 0 };
    for (const p of pending) {
      if (!ids.has(p.csoId)) continue;
      a.csos += 1; a.contracts += p.contracts; a.sqme += p.sqme; a.cash += p.cash;
      a.under90d += p.under90d; a.over1y += p.over1y;
    }
    return a;
  }, [rows, pending, country, branch, includeLeavers]);

  /** One row per branch, scored across the whole chain: sell, collect, build. */
  const groups = useMemo(() => {
    const byBranch = new Map<string, UgkeCsoMonth[]>();
    for (const r of scoped) (byBranch.get(r.branch) ?? byBranch.set(r.branch, []).get(r.branch)!).push(r);
    const cap = new Map<string, UgkeBranchMonth[]>();
    for (const c of capFor(month)) (cap.get(c.branch) ?? cap.set(c.branch, []).get(c.branch)!).push(c);
    const names = new Set([...byBranch.keys(), ...cap.keys()].filter((n) => n !== "Unassigned"));

    return Array.from(names)
      .map((name) => {
        const a = aggregate(byBranch.get(name) ?? []);
        const bd = buildAgg(cap.get(name) ?? []);
        const s = salesOf(a);
        const c = collOf(a);
        const bp = buildOf(bd);
        return {
          name, a, bd,
          pctSales: s, pctColl: c, pctBuild: bp,
          floorShare: share(a.allSoldFloorSqme, a.allSoldSqme),
          paintShare: share(a.paintSqme, a.allSoldSqme + a.paintSqme),
          // Rank on the weakest link, so a branch that sells but cannot build still surfaces.
          worst: [s, c, bp]
            .filter((v): v is number => v != null)
            .reduce<number | null>((lo, v) => (lo == null ? v : Math.min(lo, v)), null),
        };
      })
      .sort((x, y) => (x.worst ?? 99) - (y.worst ?? 99));
  }, [scoped, capFor, month]);

  const belowStandard = groups.filter((g) => g.worst != null && g.worst < 1);
  const weakest = belowStandard.slice(0, WORST_N);

  const trend = useMemo(() => {
    return months.slice(-TREND_MONTHS).map((m) => {
      const a = aggregate(scopeFor(m));
      return {
        month: m, label: monthLabel.get(m) ?? m,
        sales: salesOf(a), coll: collOf(a), build: buildOf(buildAgg(capFor(m))),
      };
    });
  }, [months, scopeFor, capFor, monthLabel]);

  const paintShareSold = share(total.paintSqme, total.allSoldSqme + total.paintSqme);
  const headline = [
    `${isCurrent ? "Month in progress. " : ""}${country}, ${monthLabel.get(month) ?? month}: floor and plaster sales at ${pctText(salesPct)} of the SQM-E standard, collections at ${pctText(collPct)} and builds at ${pctText(buildPct)} of target, with ${total.csos} of ${expectedCsos} CSOs working.`,
    readOut(salesPct, collPct, buildPct),
    total.paintSqme > 0 ? `Paint added ${n0(total.paintSqme)} SQM-E on top, ${pctText(paintShareSold)} of everything sold.` : "",
  ].filter(Boolean).join(" ");

  const exportHeaders = ["Country", "Branch", "CSOs", "CSOs required",
    "Floor & plaster SQM-E sold", "Sales % of target", "Floor & plaster contracts sold (every phase)", "Floor & plaster jobs sold (phase 1)",
    "Floor & plaster SQM-E collected", "Collections % of target", "Floor & plaster contracts collected (every phase)", "Floor & plaster jobs collected (phase 1)",
    "SQM-E built", "SQM-E build target", "Builds % of target", "Contracts built (every phase)", "Jobs built (phase 1)",
    "Floor share of SQM-E", "Floor share plan",
    "Paint SQM-E sold", "Paint share of SQM-E sold", "Paint contracts sold", "Paint SQM-E collected", "Paint SQM-E built", "Paint contracts built",
    "Donated contracts", "SQM-E sold by team leaders and managers", `Contract value sold (${cur})`];
  const exportRows: Cell[][] = groups.map((g) => [
    country, g.name, g.a.csos, est,
    Math.round(g.a.allSoldSqme), g.pctSales == null ? "" : Math.round(g.pctSales * 100), g.a.allSoldContracts, g.a.allSoldJobs,
    Math.round(g.a.allCollectedSqme), g.pctColl == null ? "" : Math.round(g.pctColl * 100), g.a.allCollectedContracts, g.a.allCollectedJobs,
    Math.round(g.bd.buildsSqme), Math.round(g.bd.sqmeTarget), g.pctBuild == null ? "" : Math.round(g.pctBuild * 100), g.bd.buildsContracts, g.bd.builds,
    g.floorShare == null ? "" : Math.round(g.floorShare * 100), Math.round(floorTarget * 100),
    Math.round(g.a.paintSqme), g.paintShare == null ? "" : Math.round(g.paintShare * 100), g.a.paintSoldContracts,
    Math.round(g.a.paintCollectedSqme), Math.round(g.bd.paintBuildsSqme), g.bd.paintBuildsContracts,
    g.a.donatedContracts, Math.round(g.a.otherSoldSqme), Math.round(g.a.valueSold + g.a.paintValue),
  ]);
  const exportName = `cso-${country.toLowerCase()}_${(monthLabel.get(month) ?? month).replace(/\s+/g, "-")}_${stamp()}`;

  return (
    <div className="mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6">
      {sample && <SampleBanner />}

      <header className="flex flex-col gap-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>UG &amp; KE CSO performance</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              The sales team&apos;s month in SQM-E, from signing to building. {country}.
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Link href="/toolkit/cso-ugke/individual" className="rounded-md px-3 py-1.5 text-sm font-medium text-white" style={{ background: "var(--accent-strong)" }}>
              Individual CSOs
            </Link>
            <ExportButtons filename={exportName} headers={exportHeaders} rows={exportRows} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Toggle options={COUNTRIES.map((c) => ({ key: c, label: c }))} value={country}
            onChange={(k) => { setCountry(k as Country); setBranch(ALL); }} />
          <Select label="Month" value={month} options={[...months].reverse()} optionLabel={(m) => monthLabel.get(m) ?? m} onChange={setMonth} />
          <Select label="Branch" value={branch} options={[ALL, ...branchNames]} onChange={setBranch} />
          <button type="button" onClick={() => setIncludeLeavers((v) => !v)}
            className="rounded-md border px-2.5 py-1.5 text-sm"
            style={{
              background: "var(--surface)",
              borderColor: includeLeavers ? "var(--accent-strong)" : "var(--border)",
              color: includeLeavers ? "var(--text-primary)" : "var(--text-secondary)",
            }}>
            {includeLeavers ? "Including leavers" : "Current staff only"}
          </button>
        </div>
      </header>

      {/* 0. The month in one paragraph: what an MD would say out loud. */}
      <p className="rounded-lg border px-4 py-3 text-sm leading-relaxed"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {headline}
      </p>

      {/* 1-4. The chain, then the people who run it. */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <ChainTile step="1" label="Sales" tone={SERIES_SALES} pct={salesPct} prev={prev ? salesOf(prev) : null}
          actual={total.soldSqme} standard={total.minSoldSqme}
          lines={[
            { label: "Floor & plaster", sqme: total.allSoldSqme, contracts: total.allSoldContracts, jobs: total.allSoldJobs },
            { label: "Paint", sqme: total.paintSqme, contracts: total.paintSoldContracts, jobs: null },
            { label: "Total", sqme: total.allSoldSqme + total.paintSqme, contracts: total.allSoldContracts + total.paintSoldContracts, jobs: null, total: true },
          ]}
          foot={`Contract value ${fmtK(total.valueSold + total.paintValue)} ${cur}${total.paintValue > 0 ? `, paint ${fmtK(total.paintValue)}` : ""}`} />
        <ChainTile step="2" label="Collections" tone={SERIES_COLL} pct={collPct} prev={prev ? collOf(prev) : null}
          actual={total.collectedSqme} standard={total.minCollectedSqme}
          lines={[
            { label: "Floor & plaster", sqme: total.allCollectedSqme, contracts: total.allCollectedContracts, jobs: total.allCollectedJobs },
            { label: "Paint", sqme: total.paintCollectedSqme, contracts: total.paintCollectedContracts, jobs: null },
            { label: "Total", sqme: total.allCollectedSqme + total.paintCollectedSqme, contracts: total.allCollectedContracts + total.paintCollectedContracts, jobs: null, total: true },
          ]}
          foot="Each phase counts when it reaches its own gate: floor 50% paid, plaster 75%, paint 100%" />
        <ChainTile step="3" label="Builds" tone={SERIES_BUILD} pct={buildPct} prev={buildPrev ? buildOf(buildPrev) : null}
          actual={build.buildsSqme} standard={build.sqmeTarget}
          lines={[
            { label: "Floor & plaster", sqme: build.buildsSqme, contracts: build.buildsContracts, jobs: build.builds },
            { label: "Paint", sqme: build.paintBuildsSqme, contracts: build.paintBuildsContracts, jobs: null },
            { label: "Total", sqme: build.buildsSqme + build.paintBuildsSqme, contracts: build.buildsContracts + build.paintBuildsContracts, jobs: null, total: true },
          ]}
          foot="The build target covers floor and plaster only" />
        <TeamTile csos={total.csos} expected={expectedCsos} est={est} branches={branchesInScope}
          perCso={total.csos > 0 ? total.soldSqme / total.csos : null}
          perStd={total.csos > 0 ? total.minSoldSqme / total.csos : null}
          newCsos={total.newCsos} leftSince={leftSince} otherSoldSqme={total.otherSoldSqme} />
      </div>

      {/* 5-7. What sits behind the headline numbers. */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <MixCard floor={total.allSoldFloorSqme} plaster={total.allSoldSqme - total.allSoldFloorSqme} paint={total.paintSqme} plan={floorTarget} />
        <OutsideCard
          paint={{
            sold: total.paintSqme, collected: total.paintCollectedSqme, built: build.paintBuildsSqme,
            soldShare: paintShareSold,
            collShare: share(total.paintCollectedSqme, total.allCollectedSqme + total.paintCollectedSqme),
            builtShare: share(build.paintBuildsSqme, build.buildsSqme + build.paintBuildsSqme),
            soldContracts: total.paintSoldContracts, collectedContracts: total.paintCollectedContracts, builtContracts: build.paintBuildsContracts,
          }}
          donated={total.donatedContracts}
          donatedShare={share(total.donatedContracts, total.allSoldContracts + total.paintSoldContracts + total.donatedContracts)}
          otherSqme={total.otherSoldSqme} otherShare={share(total.otherSoldSqme, total.allSoldSqme)} />
        <AwaitingCard a={awaiting} cur={cur} />
      </div>

      <Trend data={trend} selected={month} />

      {weakest.length > 0 && (
        <section className="rounded-lg border p-5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
          <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
            <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
              Weakest {weakest.length === 1 ? "branch" : "branches"}
            </h2>
            <span className="text-xs" style={{ color: "var(--text-muted)" }}>
              {weakest.length} of {groups.length} below target · {country} {pctText(salesPct)} sales, {pctText(collPct)} collections, {pctText(buildPct)} builds
            </span>
          </div>
          <p className="mt-0.5 text-xs" style={{ color: "var(--text-muted)" }}>
            Ranked on whichever part of the chain is lagging, in SQM-E. The bar behind each figure is the target.
          </p>
          <div className="mt-4 grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2 xl:grid-cols-4">
            {weakest.map((g) => (
              <div key={g.name} className="flex flex-col gap-2 border-l-2 pl-3" style={{ borderColor: BAND_COLOR[band(g.worst)] }}>
                <div className="flex items-baseline justify-between gap-2">
                  <span className="truncate text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{g.name}</span>
                  <span className="shrink-0 text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{g.a.csos} of {est} CSOs</span>
                </div>
                <div className="flex flex-col gap-1.5">
                  <MiniBar label="Sales" pct={g.pctSales} tone={SERIES_SALES} />
                  <MiniBar label="Collections" pct={g.pctColl} tone={SERIES_COLL} />
                  <MiniBar label="Builds" pct={g.pctBuild} tone={SERIES_BUILD} />
                </div>
                <p className="text-xs leading-snug" style={{ color: "var(--text-secondary)" }}>
                  {readOut(g.pctSales, g.pctColl, g.pctBuild)}
                </p>
                {(est - g.a.csos > 0 || (g.floorShare != null && g.floorShare < floorTarget - 0.05)) && (
                  <p className="text-xs leading-snug" style={{ color: "var(--warning)" }}>
                    {[
                      est - g.a.csos > 0 ? `Short ${est - g.a.csos} CSOs` : null,
                      g.floorShare != null && g.floorShare < floorTarget - 0.05
                        ? `floor only ${pctText(g.floorShare)} of sales, plan ${pctText(floorTarget)}` : null,
                    ].filter(Boolean).join(" · ")}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <div className="border-b p-4" style={{ borderColor: "var(--border)" }}>
          <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Branch breakdown</h2>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            Floor and plaster in SQM-E, every phase, with contracts (every phase) and jobs (phase 1) underneath. Paint alongside, not scored. The standard is the branch SQM-E target shared across {est} CSOs, with sales set 30% higher to keep the pipeline fed.
          </p>
        </div>
        <div className="hidden overflow-x-auto md:block print:block">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ color: "var(--text-muted)" }}>
                <Th>Branch</Th>
                <Th right>CSOs</Th>
                <Th right>Sold</Th><Th right>Sales</Th>
                <Th right>Collected</Th><Th right>Coll.</Th>
                <Th right>Built</Th><Th right>Builds</Th>
                <Th right>Floor share</Th>
                <Th right>Paint</Th>
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => (
                <tr key={g.name} style={{ borderTop: "1px solid var(--border)" }}>
                  <Td><span className="font-medium" style={{ color: "var(--text-primary)" }}>{g.name}</span></Td>
                  <Td right><Headcount have={g.a.csos} need={est} /></Td>
                  <Td right>
                    <Two main={`${n0(g.a.allSoldSqme)} SQM-E`} sub={`${cnt(g.a.allSoldContracts, "contract")} · ${cnt(g.a.allSoldJobs, "job")}`} />
                    {(g.a.donatedContracts > 0 || g.a.otherSoldSqme > 0) && (
                      <span className="block text-[11px]" style={{ color: "var(--text-muted)" }}>
                        {[g.a.donatedContracts > 0 ? `${g.a.donatedContracts} donated` : null, g.a.otherSoldSqme > 0 ? `incl. ${n0(g.a.otherSoldSqme)} by managers` : null].filter(Boolean).join(" · ")}
                      </span>
                    )}
                  </Td>
                  <Td right><Pct v={g.pctSales} /></Td>
                  <Td right><Two main={`${n0(g.a.allCollectedSqme)} SQM-E`} sub={`${cnt(g.a.allCollectedContracts, "contract")} · ${cnt(g.a.allCollectedJobs, "job")}`} /></Td>
                  <Td right><Pct v={g.pctColl} /></Td>
                  <Td right>
                    <Two main={`${n0(g.bd.buildsSqme)} of ${n0(g.bd.sqmeTarget)}`} sub={`${cnt(g.bd.buildsContracts, "contract")} · ${cnt(g.bd.builds, "job")}`} />
                  </Td>
                  <Td right><Pct v={g.pctBuild} /></Td>
                  <Td right><Share v={g.floorShare} target={floorTarget} /></Td>
                  <Td right>
                    {g.a.paintSoldContracts > 0 || g.bd.paintBuildsContracts > 0 ? (
                      <>
                        <span className="block" style={{ color: "var(--text-primary)" }}>{n0(g.a.paintSqme)} SQM-E</span>
                        <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{cnt(g.a.paintSoldContracts, "contract")} · {pctText(g.paintShare)} of sales</span>
                        <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{n0(g.bd.paintBuildsSqme)} SQM-E built</span>
                      </>
                    ) : <span style={{ color: "var(--text-muted)" }}>-</span>}
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Phones get stacked cards: a ten-column table is unreadable at 390px. */}
        <div className="flex flex-col md:hidden">
          {groups.map((g) => (
            <div key={g.name} className="border-t p-4" style={{ borderColor: "var(--border)" }}>
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate font-medium" style={{ color: "var(--text-primary)" }}>{g.name}</span>
                <span className="shrink-0 text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>
                  SQM-E: {n0(g.a.allSoldSqme)} sold · {n0(g.a.allCollectedSqme)} collected · {n0(g.bd.buildsSqme)} built
                </span>
              </div>
              <div className="mt-3 flex flex-col gap-2">
                <MiniBar label="Sales" pct={g.pctSales} tone={SERIES_SALES} />
                <MiniBar label="Collections" pct={g.pctColl} tone={SERIES_COLL} />
                <MiniBar label="Builds" pct={g.pctBuild} tone={SERIES_BUILD} />
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <Fact label="CSOs" value={`${fmtInt(g.a.csos)} of ${est}`}
                  note={est - g.a.csos > 0 ? `${est - g.a.csos} short` : "full"} bad={est - g.a.csos > 0} />
                <Fact label="Contracts sold" value={fmtInt(g.a.allSoldContracts)} note={`${cnt(g.a.allSoldJobs, "job")} (phase 1)`} />
                <Fact label="Floor share" value={pctText(g.floorShare)} note={`plan ${pctText(floorTarget)}`}
                  bad={g.floorShare != null && g.floorShare < floorTarget - 0.05} />
                <Fact label="Paint" value={`${n0(g.a.paintSqme)} SQM-E`} note={`${pctText(g.paintShare)} of sales, not scored`} />
                <Fact label="Donated" value={fmtInt(g.a.donatedContracts)} note="contracts, not scored" />
              </dl>
            </div>
          ))}
        </div>

        {groups.length === 0 && (
          <p className="p-8 text-center text-sm" style={{ color: "var(--text-muted)" }}>No CSO activity for this month.</p>
        )}
      </section>

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        Productivity is measured in SQM-E, counting every phase: in Uganda and Kenya nearly half of all contracts are follow-on phases that add rooms or products to a house, each priced, paid and collected on its own. A contract is any phase, as Salesforce lists it; a job is phase 1, one per house. Scores cover floor and plaster only, because that is what the branch targets are set on. Paint has no target, so it is shown alongside; paint SQM-E uses the plaster weight (m² × 0.333). Collected means that phase crossed its own payment gate: 50% for floor, 75% for plaster, 100% for paint. Targets come from the branch SQM-E targets, compared one month ahead, as in Rwanda. Productivity counts ranked CSOs only, while totals include team leaders and managers; which roles are ranked is still under review. Donated contracts are shown but not scored. The current month is in progress and will read low until it closes.
      </p>
    </div>
  );
}

function SampleBanner() {
  return (
    <div className="rounded-md border px-4 py-2.5 text-sm"
      style={{ borderColor: "var(--warning)", background: "color-mix(in srgb, var(--warning) 12%, var(--surface))", color: "var(--text-primary)" }}>
      <strong>Sample data.</strong> Names and numbers are made up, for reviewing the layout. Real Salesforce data comes once the page is agreed.
    </div>
  );
}

/** Names the weakest link in the sell, collect, build chain. */
function readOut(sales: number | null, coll: number | null, build: number | null): string {
  const parts: [string, number][] = [];
  if (sales != null) parts.push(["selling", sales]);
  if (coll != null) parts.push(["collecting", coll]);
  if (build != null) parts.push(["building", build]);
  if (parts.length === 0) return "No target set for this month.";
  parts.sort((a, b) => a[1] - b[1]);
  const [name, low] = parts[0];
  const highest = parts[parts.length - 1][1];
  if (low >= 1) return "Every part of the chain is at target.";
  if (highest - low < 0.15) return "The whole chain is moving at the same pace.";
  return {
    selling: "Selling is the constraint.",
    collecting: "Signing is ahead of collecting: payments are the constraint.",
    building: "Customers are paying faster than masons can build.",
  }[name] ?? "";
}

/**
 * One link of the chain. The score (and its colour) is floor and plaster SQM-E
 * against target; the table underneath is plain ink because paint and the counts
 * are volume, not performance.
 */
function ChainTile({ step, label, tone, pct, prev, actual, standard, lines, foot }: {
  step: string; label: string; tone: string; pct: number | null; prev: number | null;
  actual: number; standard: number;
  lines: { label: string; sqme: number; contracts: number; jobs: number | null; total?: boolean }[];
  foot: string;
}) {
  const b = band(pct);
  const moved = pct != null && prev != null ? Math.round((pct - prev) * 100) : null;
  return (
    <div className="flex flex-col rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${tone}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{step} · {label}</span>
      <div className="mt-1 flex items-baseline gap-2">
        <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</span>
        {moved != null && (
          <span className="text-xs font-medium" style={{ color: moved >= 0 ? "var(--good)" : "var(--critical)" }}>
            {moved > 0 ? `▲ ${moved} pts` : moved < 0 ? `▼ ${-moved} pts` : "no change"} vs last month
          </span>
        )}
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <div className="h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: BAND_COLOR[b] }} />
      </div>
      <span className="mt-2 block text-xs" style={{ color: "var(--text-muted)" }}>
        {n0(actual)} of {n0(standard)} SQM-E, floor and plaster · <span style={{ color: BAND_COLOR[b] }}>{BAND_LABEL[b]}</span>
      </span>
      <table className="mt-3 w-full text-xs">
        <thead>
          <tr style={{ color: "var(--text-muted)" }}>
            <th className="pb-1 text-left font-normal"></th>
            <th className="pb-1 text-right font-normal">SQM-E</th>
            <th className="pb-1 text-right font-normal">Contracts</th>
            <th className="pb-1 text-right font-normal">Jobs</th>
          </tr>
        </thead>
        <tbody className="tabular-nums">
          {lines.map((l) => (
            <tr key={l.label} style={{ borderTop: l.total ? "1px solid var(--border)" : undefined }}>
              <td className="py-0.5" style={{ color: l.total ? "var(--text-primary)" : "var(--text-secondary)", fontWeight: l.total ? 600 : 400 }}>{l.label}</td>
              <td className="py-0.5 text-right" style={{ color: "var(--text-primary)", fontWeight: l.total ? 600 : 400 }}>{n0(l.sqme)}</td>
              <td className="py-0.5 text-right" style={{ color: "var(--text-primary)", fontWeight: l.total ? 600 : 400 }}>{fmtInt(l.contracts)}</td>
              <td className="py-0.5 text-right" style={{ color: "var(--text-muted)" }}>{l.jobs == null ? "" : fmtInt(l.jobs)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <span className="mt-auto pt-2 text-xs" style={{ color: "var(--text-muted)" }}>{foot}</span>
    </div>
  );
}

/** The people behind the chain: do we have them, and are they producing. */
function TeamTile({ csos, expected, est, branches, perCso, perStd, newCsos, leftSince, otherSoldSqme }: {
  csos: number; expected: number; est: number; branches: number;
  perCso: number | null; perStd: number | null;
  newCsos: number; leftSince: number; otherSoldSqme: number;
}) {
  const pct = expected > 0 ? csos / expected : null;
  const gap = csos - expected;
  return (
    <div className="flex flex-col rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>4 · Sales team</span>
      <div className="mt-1 flex items-baseline gap-1.5">
        <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{fmtInt(csos)}</span>
        <span className="text-sm" style={{ color: "var(--text-muted)" }}>of {fmtInt(expected)} CSOs</span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <div className="h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: BAND_COLOR[band(pct)] }} />
      </div>
      <span className="mt-2 block text-xs" style={{ color: gap < 0 ? "var(--critical)" : "var(--good)" }}>
        {gap < 0 ? `${fmtInt(-gap)} short` : gap > 0 ? `${fmtInt(gap)} above establishment` : "At establishment"} · {branches} {branches === 1 ? "branch" : "branches"} at {est} each
      </span>
      <dl className="mt-3 flex flex-col gap-1 text-xs">
        <Line label="Per CSO this month" value={perCso == null ? "-" : `${n0(perCso)} SQM-E`}
          note={perStd == null ? "" : `standard ${n0(perStd)}`} />
        <Line label="New CSOs" value={fmtInt(newCsos)} note="joined in the last two months" />
        <Line label="Since left" value={fmtInt(leftSince)} note="worked this month, no longer staff" />
        <Line label="Sold by team leaders and managers" value={`${n0(otherSoldSqme)} SQM-E`} note="in totals, not in productivity" />
      </dl>
    </div>
  );
}

function Line({ label, value, note }: { label: string; value: string; note: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2">
      <dt style={{ color: "var(--text-secondary)" }}>{label}</dt>
      <dd className="text-right tabular-nums">
        <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{value}</span>
        {note && <span className="block text-[11px]" style={{ color: "var(--text-muted)" }}>{note}</span>}
      </dd>
    </div>
  );
}

/** Floor, plaster and paint as shares of all SQM-E sold, with the floor plan called out. */
function MixCard({ floor, plaster, paint, plan }: { floor: number; plaster: number; paint: number; plan: number }) {
  const all = floor + plaster + paint;
  const fp = floor + plaster;
  const floorOfFp = fp > 0 ? floor / fp : null;
  const off = floorOfFp != null ? Math.round((floorOfFp - plan) * 100) : null;
  const segs = [
    { key: "Floor", v: floor, color: MIX_FLOOR },
    { key: "Plaster", v: plaster, color: MIX_PLASTER },
    { key: "Paint", v: paint, color: MIX_PAINT },
  ].filter((s) => s.v > 0);
  return (
    <section className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>5 · Product mix</h2>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>Share of SQM-E sold</span>
      </div>
      <div className="mt-3 flex h-3 w-full gap-[2px]" role="img" aria-label="Floor, plaster and paint share of SQM-E sold">
        {segs.map((s, i) => (
          <span key={s.key} title={`${s.key}: ${pctText(all > 0 ? s.v / all : null)}`} className="block h-full"
            style={{
              width: `${all > 0 ? (s.v / all) * 100 : 0}%`, background: s.color,
              borderTopLeftRadius: i === 0 ? 4 : 0, borderBottomLeftRadius: i === 0 ? 4 : 0,
              borderTopRightRadius: i === segs.length - 1 ? 4 : 0, borderBottomRightRadius: i === segs.length - 1 ? 4 : 0,
            }} />
        ))}
      </div>
      <dl className="mt-3 flex flex-col gap-1 text-xs">
        {[
          { key: "Floor", v: floor, color: MIX_FLOOR },
          { key: "Plaster", v: plaster, color: MIX_PLASTER },
          { key: "Paint (not scored)", v: paint, color: MIX_PAINT },
        ].map((s) => (
          <div key={s.key} className="flex items-baseline justify-between gap-2">
            <dt className="flex items-center gap-1.5" style={{ color: "var(--text-secondary)" }}>
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: s.color }} />{s.key}
            </dt>
            <dd className="tabular-nums" style={{ color: "var(--text-primary)" }}>
              <span className="font-semibold">{pctText(all > 0 ? s.v / all : null)}</span>
              <span style={{ color: "var(--text-muted)" }}> · {n0(s.v)} SQM-E</span>
            </dd>
          </div>
        ))}
      </dl>
      {off != null && (
        <p className="mt-2 text-xs" style={{ color: Math.abs(off) <= 5 ? "var(--text-secondary)" : "var(--warning)" }}>
          Floor is {pctText(floorOfFp)} of floor and plaster sold; the plan is {pctText(plan)}.
          {Math.abs(off) > 5 ? ` ${Math.abs(off)} points ${off < 0 ? "below" : "above"} plan.` : " In line with plan."}
        </p>
      )}
    </section>
  );
}

/** Everything sold that the scores leave out, sized against the total so it is never invisible. */
function OutsideCard({ paint, donated, donatedShare, otherSqme, otherShare }: {
  paint: {
    sold: number; collected: number; built: number;
    soldShare: number | null; collShare: number | null; builtShare: number | null;
    soldContracts: number; collectedContracts: number; builtContracts: number;
  };
  donated: number; donatedShare: number | null; otherSqme: number; otherShare: number | null;
}) {
  return (
    <section className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>6 · Outside the scores</h2>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>Sized against the total</span>
      </div>
      <table className="mt-3 w-full text-xs">
        <thead>
          <tr style={{ color: "var(--text-muted)" }}>
            <th className="pb-1 text-left font-normal">Paint</th>
            <th className="pb-1 text-right font-normal">Sold</th>
            <th className="pb-1 text-right font-normal">Collected</th>
            <th className="pb-1 text-right font-normal">Built</th>
          </tr>
        </thead>
        <tbody className="tabular-nums">
          <tr>
            <td className="py-0.5" style={{ color: "var(--text-secondary)" }}>SQM-E</td>
            <td className="py-0.5 text-right" style={{ color: "var(--text-primary)" }}>{n0(paint.sold)}</td>
            <td className="py-0.5 text-right" style={{ color: "var(--text-primary)" }}>{n0(paint.collected)}</td>
            <td className="py-0.5 text-right" style={{ color: "var(--text-primary)" }}>{n0(paint.built)}</td>
          </tr>
          <tr>
            <td className="py-0.5" style={{ color: "var(--text-secondary)" }}>Share of all SQM-E</td>
            <td className="py-0.5 text-right font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(paint.soldShare)}</td>
            <td className="py-0.5 text-right font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(paint.collShare)}</td>
            <td className="py-0.5 text-right font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(paint.builtShare)}</td>
          </tr>
          <tr>
            <td className="py-0.5" style={{ color: "var(--text-secondary)" }}>Contracts</td>
            <td className="py-0.5 text-right" style={{ color: "var(--text-primary)" }}>{fmtInt(paint.soldContracts)}</td>
            <td className="py-0.5 text-right" style={{ color: "var(--text-primary)" }}>{fmtInt(paint.collectedContracts)}</td>
            <td className="py-0.5 text-right" style={{ color: "var(--text-primary)" }}>{fmtInt(paint.builtContracts)}</td>
          </tr>
        </tbody>
      </table>
      <dl className="mt-3 flex flex-col gap-1 border-t pt-2 text-xs" style={{ borderColor: "var(--border)" }}>
        <Line label="Donated or zero-value contracts" value={fmtInt(donated)} note={`${pctText(donatedShare)} of contracts signed, nothing to collect`} />
        <Line label="Sold by team leaders and managers" value={`${n0(otherSqme)} SQM-E`} note={`${pctText(otherShare)} of floor and plaster SQM-E`} />
      </dl>
    </section>
  );
}

/** The pipeline: signed but not yet paid to the gate. Tomorrow's collections live here. */
function AwaitingCard({ a, cur }: { a: { csos: number; contracts: number; sqme: number; cash: number; under90d: number; over1y: number }; cur: string }) {
  return (
    <section className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>7 · Signed, awaiting payment</h2>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>Right now, not by month</span>
      </div>
      <div className="mt-2 flex items-baseline gap-1.5">
        <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{n0(a.sqme)}</span>
        <span className="text-sm" style={{ color: "var(--text-muted)" }}>SQM-E</span>
      </div>
      <dl className="mt-3 flex flex-col gap-1 text-xs">
        <Line label="Contracts waiting" value={fmtInt(a.contracts)} note="every phase" />
        <Line label="Cash still needed to reach the gate" value={`${fmtK(a.cash)} ${cur}`} note="" />
        <Line label="Signed in the last 90 days" value={fmtInt(a.under90d)} note="warm, chase now" />
        <Line label="Over a year old" value={fmtInt(a.over1y)} note="likely dead, review" />
        <Line label="CSOs holding them" value={fmtInt(a.csos)} note="" />
      </dl>
      <p className="mt-2 text-[11px] leading-snug" style={{ color: "var(--text-muted)" }}>
        Contracts not yet paid to 50% (floor), 75% (plaster) or 100% (paint), with no construction started. Same test as the Collections module.
      </p>
    </section>
  );
}

function axisFor(max: number): { yMax: number; ticks: number[] } {
  const yMax = Math.max(1.25, Math.ceil((max * 1.08) / 0.25) * 0.25);
  const step = yMax > 3 ? 1 : 0.5;
  const ticks: number[] = [];
  for (let t = 0; t <= yMax + 1e-9; t += step) ticks.push(Number(t.toFixed(2)));
  return { yMax, ticks };
}

type TrendPoint = { month: string; label: string; sales: number | null; coll: number | null; build: number | null };
const TREND_SERIES: { key: "sales" | "coll" | "build"; label: string; color: string }[] = [
  { key: "sales", label: "Sales", color: SERIES_SALES },
  { key: "coll", label: "Collections", color: SERIES_COLL },
  { key: "build", label: "Builds", color: SERIES_BUILD },
];

function Trend({ data, selected }: { data: TrendPoint[]; selected: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const narrow = useNarrow();
  const all = data.filter((d) => d.sales != null || d.coll != null || d.build != null);
  const pts = narrow ? all.slice(-5) : all;
  if (pts.length < 2) return null;

  const W = narrow ? 380 : 800;
  const H = narrow ? 250 : 224;
  const padL = narrow ? 40 : 46, padR = narrow ? 16 : 22, padT = 18, padB = narrow ? 34 : 36;
  const fs = narrow ? 13 : 10.5;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const { yMax, ticks } = axisFor(Math.max(...pts.flatMap((d) => [d.sales ?? 0, d.coll ?? 0, d.build ?? 0])));
  const x = (i: number) => padL + (i * plotW) / (pts.length - 1);
  const y = (v: number) => padT + plotH * (1 - v / yMax);
  const line = (key: "sales" | "coll" | "build") =>
    pts.map((d, i) => (d[key] == null ? null : `${i === 0 || pts[i - 1][key] == null ? "M" : "L"}${x(i)},${y(d[key]!)}`))
      .filter(Boolean).join(" ");
  const hv = hover != null ? pts[hover] : null;

  return (
    <section className="rounded-lg border p-5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Longitudinal data</h2>
          <p className="mt-0.5 text-xs" style={{ color: "var(--text-muted)" }}>Each link of the chain against its SQM-E target, month by month. Floor and plaster, every phase.</p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          {TREND_SERIES.map((s) => <Key key={s.key} color={s.color} label={s.label} />)}
        </div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="mt-3 w-full" style={{ maxHeight: narrow ? 260 : 250, overflow: "visible" }} role="img"
        aria-label="Sales, collections and builds against target by month">
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeWidth="1" opacity={t === 0 ? 0.9 : 0.45} />
            <text x={padL - 10} y={y(t) + 4} textAnchor="end" fontSize={fs} fill="var(--text-muted)">{Math.round(t * 100)}%</text>
          </g>
        ))}
        <line x1={padL} x2={W - padR} y1={y(1)} y2={y(1)} stroke="var(--text-secondary)" strokeWidth="1.25" strokeDasharray="4 5" opacity="0.75" />
        <text x={W - padR + 4} y={y(1) + 3.5} fontSize={fs} fill="var(--text-muted)">target</text>
        {TREND_SERIES.map((s) => (
          <path key={s.key} d={line(s.key)} fill="none" stroke={s.color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        ))}
        {hover != null && <line x1={x(hover)} x2={x(hover)} y1={padT} y2={padT + plotH} stroke="var(--text-muted)" strokeWidth="1" opacity="0.35" />}
        {pts.map((d, i) => {
          const on = hover === i || (hover == null && d.month === selected);
          return (
            <g key={d.month}>
              {TREND_SERIES.map((s) => d[s.key] != null && (
                <circle key={s.key} cx={x(i)} cy={y(d[s.key]!)} r={on ? 5 : 3.5} fill={s.color} stroke="var(--surface)" strokeWidth="2" />
              ))}
              <text x={x(i)} y={H - 14} textAnchor="middle" fontSize={fs}
                fill={d.month === selected ? "var(--text-primary)" : "var(--text-muted)"} fontWeight={d.month === selected ? 600 : 400}>
                {d.label.slice(0, 3)}
              </text>
            </g>
          );
        })}
        {hv && (
          <g transform={`translate(${Math.min(Math.max(x(hover!) - 70, padL), W - padR - 140)}, ${padT + 2})`}>
            <rect width="140" height="66" rx="6" fill="var(--surface)" stroke="var(--border)" />
            <text x="10" y="17" fontSize="11" fontWeight="600" fill="var(--text-primary)">{hv.label}</text>
            {TREND_SERIES.map((s, k) => (
              <g key={s.key}>
                <circle cx="14" cy={30 + k * 14} r="3.5" fill={s.color} />
                <text x="24" y={34 + k * 14} fontSize="10.5" fill="var(--text-secondary)">{s.label} {pctText(hv[s.key])}</text>
              </g>
            ))}
          </g>
        )}
        {pts.map((_, i) => (
          <rect key={i} x={x(i) - plotW / (pts.length * 2)} y={padT} width={plotW / pts.length} height={plotH}
            fill="transparent" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
        ))}
      </svg>
    </section>
  );
}

function Key({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5" style={{ color: "var(--text-muted)" }}>
      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />
      {label}
    </span>
  );
}

function MiniBar({ label, pct, tone }: { label: string; pct: number | null; tone: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-20 shrink-0 text-xs" style={{ color: "var(--text-muted)" }}>{label}</span>
      <span className="h-2 flex-1 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: tone }} />
      </span>
      <span className="w-10 shrink-0 text-right text-xs font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</span>
    </div>
  );
}

function Two({ main, sub }: { main: string; sub: string }) {
  return (
    <>
      <span className="block" style={{ color: "var(--text-primary)" }}>{main}</span>
      <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{sub}</span>
    </>
  );
}

function Headcount({ have, need }: { have: number; need: number }) {
  const short = need - have;
  return (
    <>
      <span className="block tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(have)}</span>
      <span className="block text-xs tabular-nums" style={{ color: short > 0 ? "var(--warning)" : "var(--good)" }}>
        {short > 0 ? `${fmtInt(short)} short` : "full"}
      </span>
    </>
  );
}

function Share({ v, target }: { v: number | null; target: number }) {
  const low = v != null && v < target - 0.05;
  return (
    <>
      <span className="block tabular-nums" style={{ color: low ? "var(--warning)" : "var(--text-primary)" }}>{pctText(v)}</span>
      <span className="block text-xs" style={{ color: "var(--text-muted)" }}>plan {pctText(target)}</span>
    </>
  );
}

function Fact({ label, value, note, bad }: { label: string; value: string; note?: string; bad?: boolean }) {
  return (
    <div>
      <dt style={{ color: "var(--text-muted)" }}>{label}</dt>
      <dd className="font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{value}</dd>
      {note && <dd className="tabular-nums" style={{ color: bad ? "var(--warning)" : "var(--text-muted)" }}>{note}</dd>}
    </div>
  );
}

function Pct({ v }: { v: number | null }) {
  const b = band(v);
  return (
    <span className="rounded px-1.5 py-0.5 text-xs font-semibold tabular-nums"
      style={{ background: `color-mix(in srgb, ${BAND_COLOR[b]} 18%, transparent)`, color: "var(--text-primary)" }}>
      {pctText(v)}
    </span>
  );
}

function Th({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <th className={`px-3 py-2 font-medium ${right ? "text-right" : "text-left"}`}>{children}</th>;
}
function Td({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <td className={`px-3 py-2 align-top ${right ? "text-right tabular-nums" : "text-left"}`}>{children}</td>;
}

function Toggle({ options, value, onChange }: { options: { key: string; label: string }[]; value: string; onChange: (k: string) => void }) {
  return (
    <div className="inline-flex rounded-md border p-0.5" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      {options.map((o) => {
        const on = o.key === value;
        return (
          <button key={o.key} type="button" onClick={() => onChange(o.key)} className="rounded px-2.5 py-1 text-sm font-medium"
            style={{ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" }}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function Select({ label, value, options, onChange, optionLabel }: { label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string }) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}
