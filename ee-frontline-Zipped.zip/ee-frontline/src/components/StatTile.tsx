import { fmtInt } from "@/lib/format";

type Props = {
  label: string;
  value: number;
  accent?: string; // a status color var, drawn as a thin left rule
  hint?: string;
};

/** Stat tile: sentence-case label, semibold value, optional severity accent. */
export default function StatTile({ label, value, accent, hint }: Props) {
  return (
    <div
      className="flex flex-col gap-1 rounded-lg border p-4"
      style={{ background: "var(--surface)", borderColor: "var(--border)" }}
    >
      <div className="flex items-center gap-2">
        {accent && (
          <span
            className="inline-block h-3 w-1 rounded-full"
            style={{ background: accent }}
            aria-hidden
          />
        )}
        <span className="text-sm" style={{ color: "var(--text-secondary)" }}>
          {label}
        </span>
      </div>
      <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>
        {fmtInt(value)}
      </span>
      {hint && (
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
          {hint}
        </span>
      )}
    </div>
  );
}
