import { bucketColor, fmtInt, heatColor, heatTextColor } from "@/lib/format";

export type StageCol = { bucket: string; label: string };

type Props = {
  territories: string[];
  stages: StageCol[];
  /** key `${territory}|${bucket}` -> value, in whichever unit is showing */
  counts: Map<string, number>;
  rowTotals: Map<string, number>;
  colTotals: Map<string, number>;
  /** What the numbers are: jobs on the board, or their size in SQM-E. */
  unit: "jobs" | "sqme";
  onSelect: (territory: string) => void;
};

const val = (n: number) => fmtInt(Math.round(n));

export default function Heatmap({ territories, stages, counts, rowTotals, colTotals, unit, onSelect }: Props) {
  const max = Math.max(1, ...Array.from(counts.values()));
  const suffix = unit === "sqme" ? " SQM-E" : "";

  return (
    <div className="rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <p className="px-3 pt-2 text-xs md:hidden" style={{ color: "var(--text-muted)" }}>
        Swipe sideways to see every stage. The territory column stays put.
      </p>
      <div className="overflow-x-auto">
        <table className="w-full border-separate" style={{ borderSpacing: "2px" }}>
          <thead>
            <tr>
              <th className="sticky left-0 z-10 px-3 py-2 text-left text-xs font-medium" style={{ background: "var(--surface)", color: "var(--text-muted)", borderRight: "1px solid var(--border)" }}>
                Territory
              </th>
              {stages.map((s) => (
                <th
                  key={s.bucket}
                  className="px-2 py-2 text-center align-bottom text-xs font-medium leading-tight"
                  style={{ color: "var(--text-secondary)", minWidth: "6.5rem", borderTop: `3px solid ${bucketColor(s.bucket)}` }}
                >
                  {s.label}
                </th>
              ))}
              <th className="px-2 py-2 text-right text-xs font-medium" style={{ color: "var(--text-muted)" }}>Total</th>
            </tr>
          </thead>
          <tbody>
            {territories.map((t) => (
              <tr key={t}>
                <td onClick={() => onSelect(t)} className="sticky left-0 z-10 cursor-pointer whitespace-nowrap px-3 py-1.5 text-sm hover:underline" style={{ background: "var(--surface)", color: "var(--text-primary)", borderRight: "1px solid var(--border)" }} title={`Open ${t}`}>
                  {t}
                </td>
                {stages.map((s) => {
                  const v = counts.get(`${t}|${s.bucket}`) ?? 0;
                  return (
                    <td
                      key={s.bucket}
                      onClick={() => v > 0 && onSelect(t)}
                      title={`${t} · ${s.label}: ${val(v)}${suffix}`}
                      className="px-2 py-1.5 text-center text-xs tabular-nums"
                      style={{ background: heatColor(v, max), color: heatTextColor(v, max), cursor: v > 0 ? "pointer" : "default", borderRadius: "4px" }}
                    >
                      {v > 0 ? val(v) : ""}
                    </td>
                  );
                })}
                <td className="px-2 py-1.5 text-right text-xs font-medium tabular-nums" style={{ color: "var(--text-secondary)" }}>
                  {val(rowTotals.get(t) ?? 0)}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td className="sticky left-0 z-10 px-3 py-2 text-xs font-medium" style={{ background: "var(--surface)", color: "var(--text-muted)" }}>Total</td>
              {stages.map((s) => (
                <td key={s.bucket} className="px-2 py-2 text-center text-xs font-medium tabular-nums" style={{ color: "var(--text-secondary)" }}>
                  {val(colTotals.get(s.bucket) ?? 0)}
                </td>
              ))}
              <td />
            </tr>
          </tfoot>
        </table>
      </div>
      <div className="flex items-center gap-2 px-3 py-2 text-xs" style={{ color: "var(--text-muted)" }}>
        <span>fewer</span>
        <span className="h-2 w-24 rounded" style={{ background: "linear-gradient(90deg, #ffe3cc, #ee7203, #8f3f0c)" }} />
        <span>{unit === "sqme" ? "more SQM-E" : "more clients"}</span>
        <span className="ml-auto">Click a territory row to open its board.</span>
      </div>
    </div>
  );
}
