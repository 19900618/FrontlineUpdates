"use client";

import { Fragment } from "react";
import type { CapacityRow, CapacityTrendRow } from "@/lib/capacity";
import { fmt1, fmtWhole, pctText, perfColor, trendWindow, unitWord, type UnitLevel } from "@/lib/capacity-ui";
import { fmtInt } from "@/lib/format";
import CapacityDeepDive, { DEEP_DIVE_WEEKS } from "@/components/CapacityDeepDive";
import type { OpenKey } from "@/components/CapacityBoard";

export type TableDim = "territory" | "district" | "branch";
export type Status = "all" | "focus" | "behind" | "at";
export type SortKey = "name" | "built" | "sold" | "collected" | "csos" | "working" | "assigned" | "toHire" | "productivity" | "ratio";
export type SortState = { key: SortKey; dir: "asc" | "desc" };

const SORT_LABEL: Record<SortKey, string> = {
  name: "Name",
  built: "Built % of target",
  sold: "Sold % of target",
  collected: "Collected % of target",
  csos: "CSOs",
  working: "Masons working",
  assigned: "Masons assigned",
  toHire: "Masons to hire",
  productivity: "Build productivity",
  ratio: "Builds to collections",
};

const STATUS: { key: Status; label: string; color: string }[] = [
  { key: "all", label: "Everyone", color: "var(--text-secondary)" },
  { key: "focus", label: "In focus", color: "var(--accent-strong)" },
  { key: "behind", label: "Behind target", color: "var(--warning)" },
  { key: "at", label: "At target", color: "var(--good)" },
];

/**
 * The evidence layer: every unit (territory or branch), or every district in
 * Rwanda, in the order the board sorted them, weakest first by default. Rows
 * come straight from the view at their own level, so a district's masons and
 * CSOs are distinct people across the district and its shortfalls are its
 * territories' own gaps added up. Nothing is summed here. Only Built %
 * carries colour. Tapping a row opens the deep dive directly beneath it;
 * tapping again closes it.
 */
export default function CapacityTable({
  lines,
  dim,
  unit,
  onDim,
  sort,
  onSort,
  status,
  counts,
  onStatus,
  trend,
  lastWeekStart,
  open,
  onOpen,
  onClose,
}: {
  lines: CapacityRow[];
  dim: TableDim;
  /** The country's unit of management. Rwanda territories also toggle to districts. */
  unit: UnitLevel;
  onDim: (d: TableDim) => void;
  sort: SortState;
  onSort: (s: SortState) => void;
  status: Status;
  counts: Record<Status, number>;
  onStatus: (s: Status) => void;
  trend: CapacityTrendRow[];
  lastWeekStart: string;
  open: OpenKey | null;
  onOpen: (level: TableDim, name: string) => void;
  onClose: () => void;
}) {
  const isOpen = (l: CapacityRow) => open?.from === "table" && open.level === l.level && open.name === l.name;
  const detail = (l: CapacityRow) => (
    <CapacityDeepDive row={l} window={trendWindow(trend, l.level, l.name, lastWeekStart, DEEP_DIVE_WEEKS)} onClose={onClose} />
  );
  const toggle = (l: CapacityRow) => (isOpen(l) ? onClose() : onOpen(l.level as TableDim, l.name));

  // Percentages sort ascending by default so the weakest is first; counts descending so the biggest is first.
  const clickSort = (key: SortKey) =>
    onSort(sort.key === key
      ? { key, dir: sort.dir === "asc" ? "desc" : "asc" }
      : { key, dir: key === "csos" || key === "working" || key === "assigned" || key === "toHire" ? "desc" : "asc" });

  const nameHeader = dim === "territory" ? "Territory" : dim === "district" ? "District" : "Branch";
  const cols: { key: SortKey; h: string; right?: boolean; f: (l: CapacityRow) => React.ReactNode }[] = [
    { key: "name", h: nameHeader, f: (l) => <NameCell l={l} /> },
    { key: "built", h: "Built", right: true, f: (l) => (
      <span className="flex flex-col items-end">
        <PctCell v={l.pctSqme} />
        <span className="text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>
          {l.sqmeTargetWeek == null ? `${fmtWhole(l.sqmeBuilt)} SQM-E, no target` : `${fmtWhole(l.sqmeBuilt)} of ${fmtWhole(l.sqmeTargetWeek)} SQM-E`}
        </span>
      </span>
    ) },
    { key: "sold", h: "Sold", right: true, f: (l) => pctText(l.pctSales) },
    { key: "collected", h: "Collected", right: true, f: (l) => pctText(l.pctColl) },
    { key: "csos", h: "CSOs", right: true, f: (l) => <CsoCell l={l} /> },
    { key: "working", h: "Masons working", right: true, f: (l) => fmtInt(l.working) },
    { key: "assigned", h: "Masons assigned", right: true, f: (l) => fmtInt(l.assigned) },
    { key: "toHire", h: "Masons to hire", right: true, f: (l) => <HireCell l={l} /> },
    { key: "productivity", h: "Build productivity", right: true, f: (l) => <ProdCell l={l} /> },
    { key: "ratio", h: "Builds to collections", right: true, f: (l) => (l.buildCollRatio == null ? "-" : l.buildCollRatio.toFixed(2)) },
  ];

  const level = dim === "district" ? "district" : unit;
  const rollup = dim === "district" ? "District" : "Country";

  return (
    <section className="rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-col gap-3 border-b p-4" style={{ borderColor: "var(--border)" }}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            {STATUS.map((s) => (
              <Chip key={s.key} label={s.label} count={counts[s.key]} on={status === s.key} color={s.color}
                onClick={() => onStatus(status === s.key && s.key !== "all" ? "all" : s.key)} />
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-1.5 text-sm md:hidden" style={{ color: "var(--text-secondary)" }}>
              <span style={{ color: "var(--text-muted)" }}>Sort</span>
              <select value={`${sort.key}|${sort.dir}`}
                onChange={(e) => { const [key, dir] = e.target.value.split("|") as [SortKey, "asc" | "desc"]; onSort({ key, dir }); }}
                className="min-h-11 rounded-md border px-2 py-1.5 text-sm"
                style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
                {(Object.keys(SORT_LABEL) as SortKey[]).flatMap((k) => [
                  <option key={`${k}|asc`} value={`${k}|asc`}>{SORT_LABEL[k]}, low to high</option>,
                  <option key={`${k}|desc`} value={`${k}|desc`}>{SORT_LABEL[k]}, high to low</option>,
                ])}
              </select>
            </label>
            {unit === "territory" && (
              <Toggle options={[{ key: "territory", label: "Territories" }, { key: "district", label: "Districts" }]}
                value={dim} onChange={(k) => onDim(k as TableDim)} />
            )}
          </div>
        </div>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          {lines.length} {unitWord(level, lines.length)} for the selected weeks, {SORT_LABEL[sort.key].toLowerCase()} {sort.dir === "asc" ? "low to high" : "high to low"}.
          Sold and collected are against their own targets. A row opens its deep dive.
        </p>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          Working plus Assigned plus To hire equals the month&apos;s requirement. Working is anyone on a timesheet in the selected weeks.
          Assigned is anyone with a live job and no timesheet in those weeks. To hire is each {unit}&apos;s own shortfall after both, added up,
          never netted against {unitWord(unit)} that are over. Where a {unit} is above its requirement, To hire is zero, so the three columns can
          add to more than the requirement. CSOs are the people who signed or collected a contract in the selected weeks, and the shortfall beneath
          is each {unit}&apos;s own gap against the country&apos;s requirement per {unit}, added up the same way.
          {" "}{rollup} counts are distinct people, not the sum of the {unitWord(unit)}.
        </p>
      </div>

      <div className="hidden overflow-x-auto md:block print:block">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ color: "var(--text-muted)", borderBottom: "1px solid var(--border)" }}>
              {cols.map((c) => (
                <th key={c.key} className={`px-3 py-2 text-xs font-medium ${c.right ? "text-right" : "text-left"}`}
                  aria-sort={sort.key === c.key ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}>
                  <button type="button" onClick={() => clickSort(c.key)} className="inline-flex items-center gap-1"
                    style={{ color: sort.key === c.key ? "var(--text-primary)" : "var(--text-muted)" }}>
                    {c.h}
                    <span aria-hidden style={{ opacity: sort.key === c.key ? 1 : 0.35 }}>{sort.key === c.key && sort.dir === "desc" ? "↓" : "↑"}</span>
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lines.map((l) => {
              const on = isOpen(l);
              return (
                <Fragment key={l.name}>
                  <tr onClick={() => toggle(l)} aria-expanded={on}
                    style={{
                      borderTop: "1px solid var(--border)", cursor: "pointer",
                      background: on ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)" : "transparent",
                      color: "var(--text-secondary)",
                    }}>
                    {cols.map((c) => <td key={c.key} className={`px-3 py-2.5 align-top ${c.right ? "text-right tabular-nums" : "text-left"}`}>{c.f(l)}</td>)}
                  </tr>
                  {on && (
                    <tr>
                      <td colSpan={cols.length} className="p-0">{detail(l)}</td>
                    </tr>
                  )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Phones get stacked cards; the same tap expands the same detail beneath the card. */}
      <div className="flex flex-col md:hidden">
        {lines.map((l) => {
          const on = isOpen(l);
          return (
            <div key={l.name} className="border-t" style={{ borderColor: "var(--border)" }}>
              <button type="button" onClick={() => toggle(l)} aria-expanded={on}
                className="flex w-full flex-col gap-2 p-4 text-left"
                style={{ background: on ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)" : "transparent" }}>
                <div className="flex items-start justify-between gap-2">
                  <NameCell l={l} />
                  <div className="flex flex-col items-end gap-0.5">
                    <PctCell v={l.pctSqme} />
                    <span className="text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>
                      {fmtWhole(l.sqmeBuilt)}{l.sqmeTargetWeek == null ? "" : ` of ${fmtWhole(l.sqmeTargetWeek)}`} SQM-E
                    </span>
                  </div>
                </div>
                <dl className="grid grid-cols-3 gap-x-3 gap-y-1 text-xs">
                  <Kv k="Sold" v={pctText(l.pctSales)} />
                  <Kv k="Collected" v={pctText(l.pctColl)} />
                  <Kv k="Builds to coll." v={l.buildCollRatio == null ? "-" : l.buildCollRatio.toFixed(2)} />
                  <Kv k="CSOs" v={csoText(l)} />
                  <Kv k="Masons working" v={fmtInt(l.working)} />
                  <Kv k="Masons assigned" v={fmtInt(l.assigned)} />
                  <Kv k="Masons to hire" v={fmtWhole(l.toHire)} />
                </dl>
                <p className="text-xs" style={{ color: "var(--text-muted)" }}><ProdSentence l={l} /></p>
              </button>
              {on && detail(l)}
            </div>
          );
        })}
      </div>

      {lines.length === 0 && (
        <p className="p-8 text-center text-sm" style={{ color: "var(--text-muted)" }}>Nothing matches this filter.</p>
      )}
    </section>
  );
}

function NameCell({ l }: { l: CapacityRow }) {
  return (
    <span className="flex min-w-0 flex-col">
      <span className="truncate font-medium leading-tight" style={{ color: "var(--text-primary)" }} title={l.name}>{l.name}</span>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>
        {l.level === "territory" ? l.parent : l.level === "district" ? `${l.nTerritories} territories` : l.country}
        {l.isFocus && <span className="ml-1.5 rounded px-1 py-px text-[10px] font-semibold"
          style={{ background: "color-mix(in srgb, var(--accent-strong) 16%, transparent)", color: "var(--text-primary)" }}>in focus</span>}
      </span>
    </span>
  );
}

/** The count, with the shortfall beneath it at every level, the same shape as To hire. */
function CsoCell({ l }: { l: CapacityRow }) {
  const short = l.csosShort == null ? null : Math.round(l.csosShort);
  return (
    <span className="flex flex-col items-end">
      <span>{fmtInt(l.csosActive)}</span>
      {short != null && short > 0 && (
        <span className="text-xs" style={{ color: "var(--warning)" }}>{fmtInt(short)} short</span>
      )}
    </span>
  );
}

function csoText(l: CapacityRow): string {
  const short = l.csosShort == null ? null : Math.round(l.csosShort);
  return `${fmtInt(l.csosActive)}${short != null && short > 0 ? `, ${fmtInt(short)} short` : ""}`;
}

function HireCell({ l }: { l: CapacityRow }) {
  if (l.toHire == null) return <span style={{ color: "var(--text-muted)" }}>-</span>;
  const n = Math.round(l.toHire);
  return <span style={{ color: n > 0 ? "var(--warning)" : "var(--text-primary)" }}>{fmtInt(n)}</span>;
}

/**
 * "1.1 per mason" over "target 4". The target is the monthly standard scaled
 * to the weeks selected, the same scaling as Built, Sold and Collected, so the
 * figure and its target always cover the same period. A full month reads
 * "target 4"; fewer weeks name the period.
 */
function targetPhrase(l: CapacityRow): string {
  if (l.usualBuildsPerMason == null) return "no standard set";
  return `target ${fmt1(l.usualBuildsPerMason)}${l.nWeeks === 4 ? "" : ` for ${l.nWeeks} week${l.nWeeks === 1 ? "" : "s"}`}`;
}

function ProdCell({ l }: { l: CapacityRow }) {
  if (l.buildsPerMason == null) return <span style={{ color: "var(--text-muted)" }}>-</span>;
  return (
    <span className="flex flex-col items-end">
      <span>{fmt1(l.buildsPerMason)} per mason</span>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>{targetPhrase(l)}</span>
    </span>
  );
}

function ProdSentence({ l }: { l: CapacityRow }) {
  if (l.buildsPerMason == null) return <>No masons worked, so there is no build productivity to show.</>;
  return <>Each mason completed {fmt1(l.buildsPerMason)} builds, {targetPhrase(l)}.</>;
}

function PctCell({ v }: { v: number | null }) {
  return (
    <span className="inline-block rounded px-1.5 py-0.5 text-xs font-semibold tabular-nums"
      style={{ background: v == null ? "transparent" : `color-mix(in srgb, ${perfColor(v)} 18%, transparent)`, color: "var(--text-primary)" }}>
      {pctText(v)}
    </span>
  );
}

function Kv({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex flex-col">
      <dt style={{ color: "var(--text-muted)" }}>{k}</dt>
      <dd className="font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{v}</dd>
    </div>
  );
}

/** Clickable count that doubles as the status filter, the chip idiom from the individual CSO page. */
function Chip({ label, count, on, color, onClick }: { label: string; count: number; on: boolean; color: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick}
      className="flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium"
      style={{
        borderColor: on ? color : "var(--border)",
        background: on ? `color-mix(in srgb, ${color} 12%, var(--surface))` : "var(--surface)",
        color: "var(--text-primary)",
      }}>
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
      <span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtInt(count)}</span>
    </button>
  );
}

function Toggle({ options, value, onChange }: { options: { key: string; label: string }[]; value: string; onChange: (k: string) => void }) {
  return (
    <div className="no-print inline-flex rounded-md border p-0.5" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      {options.map((o) => {
        const on = o.key === value;
        return (
          <button key={o.key} type="button" onClick={() => onChange(o.key)} className="min-h-11 rounded px-2.5 py-1 text-sm font-medium sm:min-h-0"
            style={{ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" }}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
