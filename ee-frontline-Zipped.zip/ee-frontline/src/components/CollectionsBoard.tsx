"use client";

import Spinner from "./Spinner";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import type { CollSummaryRow, CollRow } from "@/lib/collections";
import { fmtInt } from "@/lib/format";

const CURRENCY: Record<string, string> = { Rwanda: "RWF", Uganda: "UGX", Kenya: "KES" };
const SIZER_BANDS = [2000, 5000, 10000, 20000, 50000];
const ALL = "All";
const COUNTRY_ORDER = ["Rwanda", "Uganda", "Kenya"];
// Placeholder for a record with no territory/branch. Never offered as a filter or a bar.
const UNASSIGNED = "Unassigned";

function fmtK(n: number): string {
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (a >= 1e3) return Math.round(n / 1e3) + "K";
  return String(Math.round(n));
}

// which of the 3 piles a backlog row belongs to
type Seg = "active" | "stalled" | "never";
function segOf(r: CollRow): Seg {
  if (r.cash <= 0) return "never";
  return r.days != null && r.days <= 90 ? "active" : "stalled";
}

type SegSum = { active: number; stalled: number; never: number; total: number };
function segSums(rows: CollRow[]): SegSum {
  let active = 0, stalled = 0, never = 0;
  for (const r of rows) {
    const g = segOf(r);
    if (g === "active") active += r.sqme;
    else if (g === "stalled") stalled += r.sqme;
    else never += r.sqme;
  }
  return { active, stalled, never, total: active + stalled + never };
}

export default function CollectionsBoard({ summary }: { summary: CollSummaryRow[] }) {
  // Rwanda → Uganda → Kenya; any other country falls in after, sorted.
  const countries = useMemo(() => {
    const present = new Set(summary.map((r) => r.country).filter(Boolean));
    const known = COUNTRY_ORDER.filter((c) => present.has(c));
    const extra = [...present].filter((c) => !COUNTRY_ORDER.includes(c)).sort();
    return [...known, ...extra];
  }, [summary]);
  const [country, setCountry] = useState(countries.includes("Rwanda") ? "Rwanda" : countries[0] ?? "Rwanda");
  const [location, setLocation] = useState(ALL);
  const [product, setProduct] = useState<"All" | "Floor" | "Plaster">("All");
  const [from, setFrom] = useState("2026-01-01"); // signed-date lower bound (blank = no bound)
  const [to, setTo] = useState(""); // signed-date upper bound (blank = no bound)
  const [threshold, setThreshold] = useState(5000);
  const [groupBy, setGroupBy] = useState<"big" | "small">("big");

  const [rows, setRows] = useState<CollRow[]>([]);
  const [loading, setLoading] = useState(false);

  const ccy = CURRENCY[country] ?? "";
  const dim: "territory" | "branch" = country === "Rwanda" ? "territory" : "branch";
  const locOf = (r: CollRow) =>
    dim === "territory" ? (r.territory && r.territory.trim() ? r.territory : "Unassigned") : r.branch || "Unassigned";
  const bigLabel = country === "Rwanda" ? "District" : "Branch";
  const smallLabel = country === "Rwanda" ? "Territory" : "District";
  const bigOf = (r: CollRow) => (r.branch && r.branch.trim() ? r.branch : "Unassigned");
  const smallOf = (r: CollRow) =>
    country === "Rwanda"
      ? (r.territory && r.territory.trim() ? r.territory : "Unassigned")
      : (r.district && r.district.trim() ? r.district : "Unassigned");

  // backlog rows for the country (source for the overview, sizer and ranking)
  useEffect(() => {
    setLocation(ALL);
    let cancelled = false;
    setLoading(true);
    fetch(`/api/collections?country=${encodeURIComponent(country)}`)
      .then((r) => r.json())
      .then((d) => { if (!cancelled) setRows(d.rows ?? []); })
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, [country]);

  // location options: every location with backlog in this country (stable regardless of date)
  // Records with no location are dropped from the picker (branch and territory alike).
  const locations = useMemo(
    () => [ALL, ...Array.from(new Set(rows.map(locOf))).filter((l) => l !== UNASSIGNED).sort()],
    [rows, dim],
  );

  const filteredRows = useMemo(
    () =>
      rows.filter((r) => {
        if (product !== "All" && r.product !== product) return false;
        if (location !== ALL && locOf(r) !== location) return false;
        if (from && r.signed && r.signed < from) return false;
        if (to && r.signed && r.signed > to) return false;
        return true;
      }),
    [rows, product, location, from, to, dim],
  );

  // overview aggregates, computed from the filtered rows so every filter (incl. date) applies
  const ov = useMemo(() => {
    let backlog = 0, sqme = 0, owed = 0, active = 0, activeSqme = 0, stalled = 0, stalledSqme = 0, never = 0, neverSqme = 0;
    for (const r of filteredRows) {
      backlog++; sqme += r.sqme; owed += r.outstanding;
      const s = segOf(r);
      if (s === "active") { active++; activeSqme += r.sqme; }
      else if (s === "stalled") { stalled++; stalledSqme += r.sqme; }
      else { never++; neverSqme += r.sqme; }
    }
    return { backlog, sqme, owed, active, activeSqme, stalled, stalledSqme, never, neverSqme };
  }, [filteredRows]);

  // segment share of the SQM-E backlog (matches the SQM-E figure shown on each panel)
  const share = (segSqme: number) => (ov.sqme ? Math.round((segSqme / ov.sqme) * 100) : 0);

  // stacked-bar data: group by big unit (district/branch); the finer view nests small units under each
  const byBig = useMemo(() => {
    const m = new Map<string, CollRow[]>();
    for (const r of filteredRows) { const k = bigOf(r); (m.get(k) ?? m.set(k, []).get(k)!).push(r); }
    return Array.from(m.entries())
      .filter(([name]) => name !== UNASSIGNED)
      .map(([name, rs]) => ({ name, ...segSums(rs) }))
      .sort((a, b) => b.total - a.total);
  }, [filteredRows, country]);
  const bySmall = useMemo(() => {
    const big = new Map<string, Map<string, CollRow[]>>();
    for (const r of filteredRows) {
      const bk = bigOf(r), sk = smallOf(r);
      if (!big.has(bk)) big.set(bk, new Map());
      const inner = big.get(bk)!; (inner.get(sk) ?? inner.set(sk, []).get(sk)!).push(r);
    }
    return Array.from(big.entries())
      .filter(([name]) => name !== UNASSIGNED)
      .map(([name, inner]) => {
        const smalls = Array.from(inner.entries())
          .filter(([sname]) => sname !== UNASSIGNED)
          .map(([sname, rs]) => ({ name: sname, ...segSums(rs) }))
          .sort((a, b) => b.total - a.total);
        return { name, total: smalls.reduce((t, x) => t + x.total, 0), smalls };
      })
      .sort((a, b) => b.total - a.total);
  }, [filteredRows, country]);
  const bigMax = byBig[0]?.total ?? 1;
  const smallMax = useMemo(() => Math.max(1, ...bySmall.flatMap((g) => g.smalls.map((s) => s.total))), [bySmall]);

  const bands = useMemo(
    () =>
      SIZER_BANDS.map((max) => {
        const inB = filteredRows.filter((r) => r.distance <= max);
        return { max, builds: inB.length, sqme: inB.reduce((s, r) => s + r.sqme, 0), cash: inB.reduce((s, r) => s + r.distance, 0) };
      }),
    [filteredRows],
  );
  const slam = filteredRows.filter((r) => r.distance <= threshold);
  const slamSqme = slam.reduce((s, r) => s + r.sqme, 0);
  const slamCash = slam.reduce((s, r) => s + r.distance, 0);

  const base =
    `country=${encodeURIComponent(country)}&product=${product}` +
    (from ? `&from=${from}` : "") + (to ? `&to=${to}` : "") +
    (location !== ALL ? `&loc=${encodeURIComponent(location)}` : "");
  const listHref = (seg?: string, within?: number) =>
    `/toolkit/collections/list?${base}${within != null ? `&within=${within}` : ""}${seg ? `&seg=${seg}` : ""}`;

  return (
    <div className="mx-auto flex max-w-[85rem] flex-col gap-4 p-4 sm:p-6">
      <header className="flex flex-col gap-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>Collections backlog</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>Signed and deposited, not yet at the build payment milestone.</p>
          </div>
          <Link href={listHref()} className="rounded-md px-3 py-1.5 text-sm font-medium text-white" style={{ background: "var(--accent-strong)" }}>Follow-up list</Link>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select label="Country" value={country} options={countries} onChange={setCountry} />
          <Select label={dim === "territory" ? "Territory" : "Branch"} value={location} options={locations} onChange={setLocation} />
          <Select label="Product" value={product} options={["All", "Floor", "Plaster"]} onChange={(v) => setProduct(v as typeof product)} />
          <label className="flex items-center gap-1.5 text-sm" style={{ color: "var(--text-secondary)" }}>
            <span style={{ color: "var(--text-muted)" }}>Signed</span>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)}
              className="rounded-md border px-2 py-1.5 text-sm" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
            <span style={{ color: "var(--text-muted)" }}>to</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)}
              className="rounded-md border px-2 py-1.5 text-sm" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
          </label>
        </div>
      </header>

      {/* one card: the total is the overarching figure; the 3 segments are subsumed beneath it on the same surface */}
      <div className="overflow-hidden rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--accent-strong)", borderTop: "3px solid var(--accent-strong)" }}>
        <div className="p-4">
          <span className="text-xs" style={{ color: "var(--text-secondary)" }}>Total collections backlog{location !== ALL ? ` · ${location}` : ""}</span>
          {loading ? (
            <div className="mt-2 text-sm" style={{ color: "var(--text-muted)" }}><Spinner label="Loading…" /></div>
          ) : (
            <div className="mt-1 flex flex-wrap items-baseline gap-x-5 gap-y-1">
              <span className="text-4xl font-semibold" style={{ color: "var(--text-primary)" }}>
                {fmtInt(ov.sqme)} <span className="text-base font-normal" style={{ color: "var(--text-muted)" }}>SQM-E</span>
              </span>
              <span className="text-sm" style={{ color: "var(--text-secondary)" }}>{fmtInt(ov.backlog)} builds</span>
              <span className="text-sm" style={{ color: "var(--text-secondary)" }}>{fmtK(ov.owed)} {ccy} owed</span>
            </div>
          )}
        </div>
        {!loading && (
          <div className="grid grid-cols-1 border-t sm:grid-cols-3" style={{ borderColor: "var(--border)" }}>
            <SegPanel first href={listHref("active")} tone="var(--good)" label="Active"
              builds={ov.active} sqme={ov.activeSqme} pct={share(ov.activeSqme)} desc="Deposited, paid within the last 90 days." />
            <SegPanel href={listHref("stalled")} tone="var(--warning)" label="Stalled"
              builds={ov.stalled} sqme={ov.stalledSqme} pct={share(ov.stalledSqme)} desc="Deposited, no payment in over 90 days." />
            <SegPanel href={listHref("never")} tone="var(--text-muted)" label="Never paid"
              builds={ov.never} sqme={ov.neverSqme} pct={share(ov.neverSqme)} desc="Signed, no payment received." />
          </div>
        )}
      </div>

      {/* quick wins: cumulative threshold table */}
      <section className="rounded-lg border p-4" style={{ background: "color-mix(in srgb, var(--accent-strong) 9%, var(--surface))", borderColor: "color-mix(in srgb, var(--accent-strong) 22%, var(--border))" }}>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Quick wins</h2>
          <label className="flex items-center gap-2 text-sm" style={{ color: "var(--text-secondary)" }}>
            <span style={{ color: "var(--text-muted)" }}>Within</span>
            <input type="number" value={threshold} min={0} step={1000} onChange={(e) => setThreshold(Math.max(0, Number(e.target.value) || 0))}
              className="w-24 rounded-md border px-2 py-1 text-right text-sm tabular-nums"
              style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
            <span style={{ color: "var(--text-muted)" }}>{ccy}</span>
          </label>
        </div>
        <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>How far to chase the payment gap. Each row is cumulative.</p>
        <p className="mt-3 text-sm" style={{ color: "var(--text-secondary)" }}>
          Collecting <b style={{ color: "var(--accent-ink)" }}>{fmtK(slamCash)} {ccy}</b> would bring{" "}
          <b style={{ color: "var(--accent-ink)" }}>{fmtInt(slam.length)}</b> accounts{" "}
          (<b style={{ color: "var(--accent-ink)" }}>{fmtInt(slamSqme)}</b> SQM-E) to their milestone.
        </p>

        <div className="mt-2 overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ color: "var(--text-muted)" }}>
                <th className="px-2.5 py-2 text-left font-medium">Payment gap</th>
                <th className="px-2.5 py-2 text-right font-medium">Accounts</th>
                <th className="hidden px-2.5 py-2 text-right font-medium sm:table-cell">SQM-E</th>
                <th className="hidden px-2.5 py-2 text-right font-medium sm:table-cell">% of backlog</th>
                <th className="px-2.5 py-2 text-right font-medium">Cash to collect</th>
                <th className="px-2.5 py-2" />
              </tr>
            </thead>
            <tbody>
              {bands.map((b) => {
                const sel = threshold === b.max;
                return (
                  <tr key={b.max} onClick={() => setThreshold(b.max)}
                    style={{ cursor: "pointer", borderTop: "1px solid var(--border)", background: sel ? "color-mix(in srgb, var(--accent-strong) 8%, var(--surface))" : "transparent" }}>
                    <td className="px-2.5 py-2 text-left font-semibold" style={{ color: "var(--text-primary)", boxShadow: sel ? "inset 3px 0 0 var(--accent-strong)" : "none" }}>≤ {fmtK(b.max)} {ccy}</td>
                    <td className="px-2.5 py-2 text-right tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(b.builds)}</td>
                    <td className="hidden px-2.5 py-2 text-right tabular-nums sm:table-cell" style={{ color: "var(--text-primary)" }}>{fmtInt(b.sqme)}</td>
                    <td className="hidden px-2.5 py-2 sm:table-cell">
                      <div className="flex items-center justify-end gap-2">
                        <span className="hidden h-1.5 w-20 overflow-hidden rounded-full sm:block" style={{ background: "var(--border)" }}>
                          <span className="block h-full rounded-full" style={{ width: `${share(b.sqme)}%`, background: "var(--accent-strong)" }} />
                        </span>
                        <span className="w-9 text-right tabular-nums" style={{ color: "var(--text-secondary)" }}>{share(b.sqme)}%</span>
                      </div>
                    </td>
                    <td className="px-2.5 py-2 text-right tabular-nums" style={{ color: "var(--text-secondary)" }}>{fmtK(b.cash)} {ccy}</td>
                    <td className="px-2.5 py-2 text-right">
                      <Link href={listHref(undefined, b.max)} onClick={(e) => e.stopPropagation()} className="font-medium hover:underline" style={{ color: "var(--accent-ink)" }}>View</Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

      </section>

      {/* where the collections backlog sits: stacked bars by segment */}
      {location === ALL && !loading && byBig.length > 0 && (
        <section className="rounded-lg border p-4" style={{ background: "color-mix(in srgb, #5b7a99 11%, var(--surface))", borderColor: "color-mix(in srgb, #5b7a99 24%, var(--border))" }}>
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Where the collections backlog sits</h2>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>Backlog SQM-E by {(groupBy === "big" ? bigLabel : smallLabel).toLowerCase()}, split by segment.</p>
            </div>
            <Toggle options={[{ key: "big", label: bigLabel }, { key: "small", label: smallLabel }]} value={groupBy} onChange={(k) => setGroupBy(k as "big" | "small")} />
          </div>
          <Legend />
          <div className="mt-3 flex flex-col gap-2">
            {groupBy === "big"
              ? byBig.map((u) => <Bar key={u.name} name={u.name} seg={u} max={bigMax} />)
              : bySmall.map((g) => (
                  <div key={g.name} className="flex flex-col gap-1.5 border-t pt-2.5 first:border-0 first:pt-0" style={{ borderColor: "var(--border)" }}>
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span style={{ color: "var(--text-secondary)" }}>{g.name}</span>
                      <span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{fmtInt(g.total)} SQM-E</span>
                    </div>
                    {g.smalls.map((s) => <Bar key={s.name} name={s.name} seg={s} max={smallMax} indent />)}
                  </div>
                ))}
          </div>
        </section>
      )}
    </div>
  );
}

function SegPanel({ href, tone, label, builds, sqme, pct, desc, first }: { href: string; tone: string; label: string; builds: number; sqme: number; pct: number; desc: string; first?: boolean }) {
  return (
    <Link href={href} className={`group flex flex-col gap-1 p-4 ${first ? "" : "border-t sm:border-t-0 sm:border-l"}`} style={{ borderColor: "var(--border)" }}>
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
          <span className="h-2 w-2 rounded-full" style={{ background: tone }} />
          {label}
        </span>
        <span className="rounded-md px-2 py-0.5 text-xl font-bold tabular-nums" style={{ background: `color-mix(in srgb, ${tone} 22%, transparent)`, color: "var(--text-primary)" }}>{pct}%</span>
      </div>
      <span className="text-2xl font-semibold" style={{ color: "var(--text-primary)" }}>
        {fmtInt(sqme)} <span className="text-sm font-normal" style={{ color: "var(--text-muted)" }}>SQM-E</span>
      </span>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(builds)} builds</span>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>{desc}</span>
      <span className="mt-1 text-xs font-medium group-hover:underline" style={{ color: "var(--accent-ink)" }}>View accounts</span>
    </Link>
  );
}

function Toggle({ options, value, onChange }: { options: { key: string; label: string }[]; value: string; onChange: (k: string) => void }) {
  return (
    <div className="inline-flex rounded-md border p-0.5" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      {options.map((o) => {
        const on = o.key === value;
        return (
          <button key={o.key} type="button" onClick={() => onChange(o.key)} className="rounded px-2.5 py-1 text-sm font-medium"
            style={{ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" }}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function Legend() {
  const items: [string, string][] = [["Active", "var(--good)"], ["Stalled", "var(--warning)"], ["Never paid", "var(--text-muted)"]];
  return (
    <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs" style={{ color: "var(--text-muted)" }}>
      {items.map(([label, color]) => (
        <span key={label} className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />
          {label}
        </span>
      ))}
    </div>
  );
}

function Bar({ name, seg, max, indent }: { name: string; seg: SegSum; max: number; indent?: boolean }) {
  const w = max > 0 ? (seg.total / max) * 100 : 0;
  const pctOf = (v: number) => (seg.total > 0 ? (v / seg.total) * 100 : 0);
  return (
    <div className="flex items-center gap-2">
      <span className={`shrink-0 truncate text-sm ${indent ? "w-24 pl-3" : "w-28"}`} style={{ color: "var(--text-secondary)" }} title={name}>{name}</span>
      <span className="relative h-5 flex-1 overflow-hidden rounded" style={{ background: "var(--border)" }}>
        <span className="absolute inset-y-0 left-0 flex overflow-hidden rounded" style={{ width: `${w}%` }}>
          {seg.active > 0 && <span title={`Active ${fmtInt(seg.active)}`} style={{ width: `${pctOf(seg.active)}%`, background: "var(--good)" }} />}
          {seg.stalled > 0 && <span title={`Stalled ${fmtInt(seg.stalled)}`} style={{ width: `${pctOf(seg.stalled)}%`, background: "var(--warning)" }} />}
          {seg.never > 0 && <span title={`Never paid ${fmtInt(seg.never)}`} style={{ width: `${pctOf(seg.never)}%`, background: "var(--text-muted)" }} />}
        </span>
      </span>
      <span className="w-16 shrink-0 text-right text-sm tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(seg.total)}</span>
    </div>
  );
}

function Select({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (v: string) => void }) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}
