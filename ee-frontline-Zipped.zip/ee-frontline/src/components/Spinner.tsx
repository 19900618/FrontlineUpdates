/**
 * The app's one loading signal: a small spinning ring. Every page reads BigQuery,
 * which takes seconds, so anywhere the app is waiting it says so with this rather
 * than sitting still and looking stuck.
 */
export default function Spinner({ size = 16, label }: { size?: number; label?: string }) {
  return (
    <span className="inline-flex items-center gap-2" role="status" aria-live="polite">
      <span
        className="inline-block shrink-0 animate-spin rounded-full border-2 border-current border-t-transparent"
        style={{ width: size, height: size, opacity: 0.5 }}
        aria-hidden
      />
      {label ? <span>{label}</span> : <span className="sr-only">Loading</span>}
    </span>
  );
}
