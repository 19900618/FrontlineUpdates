"use client";

import { useState } from "react";
import { copyForSheets, downloadCsv, type Cell } from "@/lib/export";

/**
 * The two export routes, side by side. "Copy for Google Sheets" is listed first
 * because it is the one that actually works for most people: paste into a sheet
 * and the columns land correctly, with no import dialog to get wrong.
 */
export default function ExportButtons({
  filename,
  headers,
  rows,
  onPrint,
}: {
  filename: string;
  headers: string[];
  rows: Cell[][];
  onPrint?: () => void;
}) {
  const [copied, setCopied] = useState<null | "ok" | "fail">(null);

  async function copy() {
    const ok = await copyForSheets(headers, rows);
    setCopied(ok ? "ok" : "fail");
    setTimeout(() => setCopied(null), 2500);
  }

  const btn = "min-h-11 rounded-md px-3 py-1.5 text-sm font-medium sm:min-h-0";

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button type="button" onClick={copy} className={`${btn} text-white`} style={{ background: "var(--accent-strong)" }}>
        {copied === "ok" ? "Copied, now paste into Sheets" : copied === "fail" ? "Copy failed, use CSV" : "Copy for Google Sheets"}
      </button>
      <button type="button" onClick={() => downloadCsv(filename, headers, rows)} className={`${btn} border`}
        style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>
        Download CSV
      </button>
      {onPrint && (
        <button type="button" onClick={onPrint} className={`${btn} border`}
          style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>
          Print
        </button>
      )}
      {copied === "ok" && (
        <span className="text-xs" style={{ color: "var(--good)" }}>
          Open a Google Sheet and press Ctrl+V
        </span>
      )}
    </div>
  );
}
