"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { NAV, isGroup, type NavItem } from "@/lib/nav";
import Logo from "@/components/Logo";
import Spinner from "@/components/Spinner";

/**
 * The menu. Sections are headings; a module with several views (the CSO pages) sits
 * in a group that expands, so the list stays short and the group you are working in
 * is the one open. Items marked hidden in lib/nav.ts are left out here.
 *
 * A clicked link keeps a spinner until the URL becomes that page. Every page waits
 * on BigQuery for a few seconds, and without the spinner a click looks like nothing
 * happened.
 */
export default function Sidebar({ userEmail }: { userEmail?: string | null }) {
  const [open, setOpen] = useState(false); // mobile drawer
  const [clicked, setClicked] = useState<string | null>(null);
  const [toggled, setToggled] = useState<Record<string, boolean>>({});
  const pathname = usePathname();

  // Still waiting whenever the URL is not yet the page that was clicked.
  const pending = clicked && clicked !== pathname ? clicked : null;

  function go(href: string) {
    setOpen(false);
    if (href !== pathname) setClicked(href);
  }

  const shown = (items: NavItem[]) => items.filter((i) => !i.hidden);

  function renderItem(item: NavItem, inGroup: boolean) {
    const pad = inGroup ? "px-2 py-1.5" : "px-2 py-1.5";
    if (!item.enabled) {
      return (
        <span key={item.href} className={`flex items-center justify-between rounded-md text-sm ${pad}`}
          style={{ color: "var(--text-muted)", opacity: 0.6 }}>
          {item.label}
          {item.soon && (
            <span className="rounded px-1.5 py-0.5 text-[10px]" style={{ border: "1px solid var(--border)" }}>soon</span>
          )}
        </span>
      );
    }
    const active = pathname === item.href;
    return (
      <Link key={item.href} href={item.href} onClick={() => go(item.href)}
        className={`flex items-center justify-between gap-2 rounded-md text-sm ${pad}`}
        style={{
          color: active ? "var(--text-primary)" : "var(--text-secondary)",
          background: active ? "color-mix(in srgb, var(--seq-500) 14%, transparent)" : "transparent",
          boxShadow: active ? "inset 2px 0 0 var(--seq-500)" : "none",
          fontWeight: active ? 600 : 400,
        }}>
        <span className="truncate">{item.label}</span>
        {pending === item.href && <span style={{ color: "var(--accent-strong)" }}><Spinner size={13} /></span>}
      </Link>
    );
  }

  const nav = (
    <nav className="flex flex-col gap-5 p-4">
      <Link href="/" onClick={() => go("/")} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm"
        style={{ color: "var(--accent-ink)" }}>
        ← All workspaces
        {pending === "/" && <Spinner size={13} />}
      </Link>
      {NAV.map((section) => {
        const entries = section.entries.filter((e) => (isGroup(e) ? shown(e.items).length > 0 : !e.hidden));
        if (entries.length === 0) return null;
        return (
          <div key={section.title} className="flex flex-col gap-1">
            <span className="px-2 text-[11px] font-semibold uppercase tracking-wide" style={{ color: "var(--text-muted)" }}>
              {section.title}
            </span>
            {entries.map((entry) => {
              if (!isGroup(entry)) return renderItem(entry, false);
              const items = shown(entry.items);
              const holdsActive = items.some((i) => i.href === pathname);
              const holdsPending = items.some((i) => i.href === pending);
              // Open the group you are in; a click can override that either way.
              const expanded = toggled[entry.label] ?? (holdsActive || holdsPending);
              return (
                <div key={entry.label} className="flex flex-col gap-0.5">
                  <button type="button" aria-expanded={expanded}
                    onClick={() => setToggled((t) => ({ ...t, [entry.label]: !expanded }))}
                    className="flex items-center justify-between gap-2 rounded-md px-2 py-1.5 text-left text-sm"
                    style={{ color: holdsActive ? "var(--text-primary)" : "var(--text-secondary)", fontWeight: holdsActive ? 600 : 400 }}>
                    <span className="truncate">{entry.label}</span>
                    <span aria-hidden className="text-xs"
                      style={{ color: "var(--text-muted)", transform: expanded ? "rotate(90deg)" : "none", transition: "transform .15s" }}>
                      ›
                    </span>
                  </button>
                  {expanded && (
                    <div className="ml-3 flex flex-col gap-0.5 border-l pl-2" style={{ borderColor: "var(--border)" }}>
                      {items.map((i) => renderItem(i, true))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        );
      })}
    </nav>
  );

  return (
    <>
      {/* mobile top bar */}
      <div className="flex items-center justify-between border-b p-3 md:hidden"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <Brand />
        <button onClick={() => setOpen((v) => !v)} className="min-h-11 rounded-md border px-3 py-1.5 text-sm"
          style={{ borderColor: "var(--border)", color: "var(--text-secondary)" }}>
          Menu
        </button>
      </div>
      {open && (
        <div className="border-b md:hidden" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
          {nav}
          <UserFooter userEmail={userEmail} />
        </div>
      )}

      {/* desktop sidebar */}
      <aside className="hidden w-60 shrink-0 flex-col border-r md:flex"
        style={{ background: "var(--surface)", borderColor: "var(--border)", height: "100dvh", position: "sticky", top: 0 }}>
        <div className="border-b p-4" style={{ borderColor: "var(--border)" }}>
          <Brand />
        </div>
        <div className="flex-1 overflow-y-auto">{nav}</div>
        <UserFooter userEmail={userEmail} />
      </aside>
    </>
  );
}

function Brand() {
  return (
    <div className="flex flex-col items-start gap-1.5">
      <Logo height={30} />
      <span className="text-base font-bold" style={{ color: "var(--text-primary)" }}>
        Frontline toolkit
      </span>
    </div>
  );
}

function UserFooter({ userEmail }: { userEmail?: string | null }) {
  if (!userEmail) return null;
  return (
    <div className="border-t p-3 text-xs" style={{ borderColor: "var(--border)" }}>
      <div className="truncate" style={{ color: "var(--text-secondary)" }} title={userEmail}>
        {userEmail}
      </div>
      {/* Auth.js route, not a page: a plain link is right, so the page-link rule is off here. */}
      {/* eslint-disable-next-line @next/next/no-html-link-for-pages */}
      <a href="/api/auth/signout" className="mt-1 inline-block" style={{ color: "var(--text-muted)" }}>
        Sign out
      </a>
    </div>
  );
}
