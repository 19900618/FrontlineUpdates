"use client";

/**
 * A five-point line for a table cell or a trend card: the last complete
 * weeks, oldest on the left, the value printed at every point in the series
 * colour, an optional dashed target line, and the week dates under the first
 * and last point. The same two chart rules as TrendChart: every point is
 * labelled, and the floor is zero unless zero would flatten the line, in
 * which case it may rise to the lowest value minus a fifth of the range.
 */
export type SparkPoint = { label: string; value: number | null; note?: string };

export default function Sparkline({ points, target, color = "var(--text-secondary)", format, targetLabel, width = 220, height = 64 }: {
  points: SparkPoint[];
  target?: number | null;
  color?: string;
  format?: (v: number) => string;
  targetLabel?: string;
  width?: number;
  height?: number;
}) {
  const fmt = format ?? ((v: number) => Math.round(v).toLocaleString("en-US"));
  const n = points.length;
  if (n === 0) return <span className="text-xs" style={{ color: "var(--text-muted)" }}>no weeks</span>;
  const vals = points.map((p) => p.value).filter((v): v is number => v != null);
  const rawMax = Math.max(target ?? 0, ...vals, 0.01);
  const rawMin = Math.min(target ?? Infinity, ...vals);
  const range = rawMax - rawMin;
  const yMin = vals.length > 0 && rawMin > 0 && range < 0.4 * rawMax ? Math.max(0, rawMin - range / 5) : 0;
  const yMax = rawMax * 1.12 || 1;
  const padL = 10, padR = 10, padT = 14, padB = 14;
  const W = width, H = height;
  const x = (i: number) => (n === 1 ? W / 2 : padL + (i * (W - padL - padR)) / (n - 1));
  const y = (v: number) => padT + (H - padT - padB) * (1 - (Math.min(Math.max(v, yMin), yMax) - yMin) / (yMax - yMin));
  const d = points.map((p, i) => (p.value == null ? null : `${i === 0 || points[i - 1].value == null ? "M" : "L"}${x(i).toFixed(1)},${y(p.value).toFixed(1)}`)).filter(Boolean).join(" ");
  const fs = 9.5;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="block w-full" style={{ maxWidth: width, overflow: "visible" }} role="img"
      aria-label={points.map((p) => `${p.label}: ${p.value == null ? "no data" : fmt(p.value)}`).join(", ")}>
      <line x1={padL} x2={W - padR} y1={y(yMin)} y2={y(yMin)} stroke="var(--grid)" strokeWidth="1" />
      {target != null && target >= yMin && target <= yMax && (
        <>
          <line x1={padL} x2={W - padR} y1={y(target)} y2={y(target)} stroke="var(--text-primary)" strokeWidth="1" strokeDasharray="3 3" opacity="0.55" />
          {targetLabel && <text x={W - padR} y={y(target) - 3} textAnchor="end" fontSize={fs - 1} fill="var(--text-muted)">{targetLabel}</text>}
        </>
      )}
      <path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {points.map((p, i) => p.value == null ? null : (
        <g key={i}>
          <circle cx={x(i)} cy={y(p.value)} r={i === n - 1 ? 3.5 : 2.5} fill={color} stroke="var(--surface)" strokeWidth="1.5">
            <title>{`${p.label}: ${fmt(p.value)}${p.note ? ` (${p.note})` : ""}`}</title>
          </circle>
          <text x={x(i)} y={y(p.value) - 6} textAnchor="middle" fontSize={fs} fontWeight={600} fill={color}
            stroke="var(--surface)" strokeWidth="2.5" paintOrder="stroke">{fmt(p.value)}</text>
        </g>
      ))}
      <text x={padL} y={H - 2} textAnchor="start" fontSize={fs - 1} fill="var(--text-muted)">{points[0].label}</text>
      {n > 1 && <text x={W - padR} y={H - 2} textAnchor="end" fontSize={fs - 1} fill="var(--text-muted)">{points[n - 1].label}</text>}
    </svg>
  );
}
