"use client";

import { Fragment, useEffect, useMemo, useState } from "react";
import { fmtInt, telHref } from "@/lib/format";
import { addMonthsIso, weekOfDay } from "@/lib/period";
import type { WsCsoCash, WsCsoMonth, WsCsoPending } from "@/lib/workspace-types";
import { dayMonth, levelTitle, money, pctText, whole, SERIES_COLL, SERIES_SALES } from "@/lib/workspace-ui";
import Spinner from "@/components/Spinner";
import { stamp, type Cell } from "@/lib/export";
import { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { Chip, DataTable, FormPills, Muted, Progress, Select, Stack, Tag, type Col } from "@/components/ws/primitives";
import TrendChart from "@/components/ws/TrendChart";

/**
 * Individual CSOs, modelled on the existing RW individual CSO page: the same
 * controls, standing chips and five-month pill guide, reading the same views,
 * for whichever country the workspace is. Three columns are new: Money
 * collected (a day, its week against the weekly target, and the period, from
 * the daily cash view), Commission (Rwanda, provisional) and Cash received
 * against revenue. Opens filtered to the workspace scope and can widen back
 * out to the whole country.
 */
const ALL = "All";
const FORM_MONTHS = 5;
type Grade = "top" | "above" | "below" | "support" | "none" | "unranked";
const GRADE_LABEL: Record<Grade, string> = { top: "Top performer", above: "Above average", below: "Below average", support: "Needs support", none: "No target", unranked: "Not ranked" };
const GRADE_COLOR: Record<Grade, string> = { top: "var(--good)", above: "#2f6f9f", below: "var(--warning)", support: "var(--critical)", none: "var(--text-muted)", unranked: "var(--text-muted)" };

const quantile = (sorted: number[], q: number) => (sorted.length === 0 ? 0 : sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * q))]);
const ratio = (a: number, b: number | null) => (b == null || b <= 0 ? null : a / b);

/** A CSO's months in the period folded into one row: flows summed, the score as actual over target. */
type Agg = {
  m: WsCsoMonth; months: WsCsoMonth[];
  sold: number; soldSqme: number; collected: number; collectedSqme: number;
  minSold: number | null; minSoldSqme: number | null; minCollected: number | null; minCollectedSqme: number | null;
  pctSold: number | null; pctCollected: number | null;
};
function fold(ms: WsCsoMonth[]): Agg {
  const last = ms[ms.length - 1];
  const sum = (f: (x: WsCsoMonth) => number) => ms.reduce((t, x) => t + f(x), 0);
  const sumT = (f: (x: WsCsoMonth) => number | null) => (ms.some((x) => f(x) != null) ? ms.reduce((t, x) => t + (f(x) ?? 0), 0) : null);
  const a: Agg = {
    m: last, months: ms,
    sold: sum((x) => x.sold), soldSqme: sum((x) => x.soldSqme), collected: sum((x) => x.collected), collectedSqme: sum((x) => x.collectedSqme),
    minSold: sumT((x) => x.minSold), minSoldSqme: sumT((x) => x.minSoldSqme), minCollected: sumT((x) => x.minCollected), minCollectedSqme: sumT((x) => x.minCollectedSqme),
    pctSold: null, pctCollected: null,
  };
  if (ms.length === 1) { a.pctSold = last.pctSold; a.pctCollected = last.pctCollected; }
  else if (last.scoreBasis === "contracts") { a.pctSold = ratio(a.sold, a.minSold); a.pctCollected = ratio(a.collected, a.minCollected); }
  else { a.pctSold = ratio(a.soldSqme, a.minSoldSqme); a.pctCollected = ratio(a.collectedSqme, a.minCollectedSqme); }
  return a;
}
const scoreOf = (p: { pctSold: number | null; pctCollected: number | null }) => {
  const parts = [p.pctSold, p.pctCollected].filter((v): v is number => v != null);
  return parts.length ? parts.reduce((s, v) => s + v, 0) / parts.length : null;
};
function direction(spark: (number | null)[]): "up" | "down" | "flat" {
  const v = spark.filter((x): x is number => x != null);
  if (v.length < 3) return "flat";
  const first = v[0], last = v[v.length - 1];
  return last > first * 1.1 ? "up" : last < first * 0.9 ? "down" : "flat";
}

type Row = Agg & {
  id: string; grade: Grade; score: number | null; rank: number; size: number; tags: string[];
  form: { key: string; label: string; pct: number | null }[]; atTarget: number; scored: number;
  pending: WsCsoPending | null; cash: WsCsoCash | null;
};

export default function CsoList({ s, months, pending, currency }: { s: WsState; months: WsCsoMonth[]; pending: WsCsoPending[]; currency: string }) {
  const { period, scope, country } = s;
  const rw = country === "Rwanda";
  const inPeriod = useMemo(() => {
    const set = new Set(period.mode === "quarter" ? [0, 1, 2].map((i) => addMonthsIso(period.month, i)) : [period.month]);
    return months.filter((m) => set.has(m.month));
  }, [months, period]);

  const [district, setDistrict] = useState(scope?.level === "district" ? scope.name : ALL);
  const [unit, setUnit] = useState(scope && scope.level !== "district" ? scope.name : ALL);
  const [staffOnly, setStaffOnly] = useState(true);
  const [search, setSearch] = useState("");
  const [grade, setGrade] = useState<Grade | "all">("all");
  const [selected, setSelected] = useState<string | null>(null);
  const today = new Date().toISOString().slice(0, 10);
  const [day, setDay] = useState(today);
  // The money columns, keyed by the request they answer: a new day or period
  // reads as loading until its own answer lands. The parent keys this
  // component on the scope, so a new scope mounts it fresh.
  const cashKey = `${country}|${day}|${period.start}|${period.end}`;
  const [cashState, setCashState] = useState<{ key: string; rows?: Map<string, WsCsoCash>; error?: string } | null>(null);
  const cash = cashState?.key === cashKey ? cashState.rows ?? null : null;
  const cashError = cashState?.key === cashKey ? cashState.error ?? null : null;

  useEffect(() => {
    let live = true;
    const wk = weekOfDay(day);
    const q = new URLSearchParams({ country, day, weekStart: wk.start, weekEnd: wk.end, start: period.start, end: period.end });
    fetch(`/api/workspace/cso-cash?${q}`)
      .then(async (r) => { const j = await r.json(); if (!r.ok) throw new Error(j.error ?? r.statusText); if (live) setCashState({ key: cashKey, rows: new Map((j.rows as WsCsoCash[]).map((c) => [c.csoId, c])) }); })
      .catch((e) => { if (live) setCashState({ key: cashKey, error: e instanceof Error ? e.message : String(e) }); });
    return () => { live = false; };
  }, [country, day, period.start, period.end, cashKey]);

  const pendingBy = useMemo(() => new Map(pending.map((p) => [p.csoId, p])), [pending]);
  const historyBy = useMemo(() => {
    const m = new Map<string, WsCsoMonth[]>();
    for (const r of months) (m.get(r.csoId) ?? m.set(r.csoId, []).get(r.csoId)!).push(r);
    for (const l of m.values()) l.sort((a, b) => a.month.localeCompare(b.month));
    return m;
  }, [months]);

  /** One folded row per CSO active in the period, before the table filters. */
  const folded = useMemo(() => {
    const by = new Map<string, WsCsoMonth[]>();
    for (const r of inPeriod) {
      if (staffOnly && !(r.isActiveStaff && !r.isUnverifiedStaff)) continue;
      (by.get(r.csoId) ?? by.set(r.csoId, []).get(r.csoId)!).push(r);
    }
    return Array.from(by.values()).map((ms) => fold(ms.sort((a, b) => a.month.localeCompare(b.month))));
  }, [inPeriod, staffOnly]);

  const districts = useMemo(() => [ALL, ...Array.from(new Set(folded.map((f) => f.m.district))).filter((d) => d !== "Unassigned").sort()], [folded]);
  const units = useMemo(() => [ALL, ...Array.from(new Set(folded.filter((f) => district === ALL || f.m.district === district).map((f) => f.m.unit))).filter((u) => u !== "Unassigned").sort()], [folded, district]);

  const allRows: Row[] = useMemo(() => {
    const ranked = folded.filter((f) => f.m.isRanked);
    const scores = ranked.map(scoreOf).filter((v): v is number => v != null).sort((a, b) => a - b);
    const cuts = { q25: quantile(scores, 0.25), median: quantile(scores, 0.5) };
    const groups = new Map<string, { id: string; score: number }[]>();
    for (const f of ranked) { const sc = scoreOf(f); if (sc != null) (groups.get(f.m.unit) ?? groups.set(f.m.unit, []).get(f.m.unit)!).push({ id: f.m.csoId, score: sc }); }
    const rank = new Map<string, { rank: number; size: number }>();
    for (const l of groups.values()) { l.sort((a, b) => b.score - a.score); l.forEach((x, i) => rank.set(x.id, { rank: i + 1, size: l.length })); }
    const lastMonth = period.mode === "quarter" ? period.fetchMonth : period.month;
    return folded.map((f): Row => {
      const hist = (historyBy.get(f.m.csoId) ?? []).filter((h) => h.month <= lastMonth);
      const spark = hist.slice(-6).map((h) => h.pctSold);
      const scored = hist.slice(-6).filter((h) => h.pctSold != null);
      const score = scoreOf(f);
      let g: Grade = "none";
      if (!f.m.isRanked) g = "unranked";
      else if (score != null) g = score >= 1 ? "top" : score <= cuts.q25 ? "support" : score >= cuts.median ? "above" : "below";
      const p = pendingBy.get(f.m.csoId) ?? null;
      const tags: string[] = [];
      if (f.months.some((x) => x.isPartMonth) && f.months.length === 1) tags.push(`Part month (${f.m.daysAvailable} of ${f.m.monthDays} days)`);
      if (f.m.isAwayFromHome) tags.push(`Worked in ${f.m.unit}`);
      if (f.sold === 0 && f.soldSqme === 0) tags.push(period.mode === "quarter" ? "No sales this quarter" : "No sales this month");
      if (f.pctSold != null && f.pctCollected != null) {
        if (f.pctSold - f.pctCollected > 0.3) tags.push("Signing, not collecting");
        else if (f.pctCollected - f.pctSold > 0.3) tags.push("Collecting, not signing");
      }
      const dir = direction(spark);
      if (dir === "down") tags.push("Declining");
      if (dir === "up") tags.push("Improving");
      if (p && p.over1y >= 5) tags.push(`${p.over1y} stale follow-ups`);
      if (f.m.isNewCso) tags.push("New CSO");
      const r = rank.get(f.m.csoId);
      return {
        ...f, id: f.m.csoId, grade: g, score, rank: r?.rank ?? 0, size: r?.size ?? 0, tags: tags.slice(0, 3),
        form: hist.slice(-FORM_MONTHS).map((h) => ({ key: h.month, label: h.monthLabel, pct: scoreOf(h) })),
        atTarget: scored.filter((h) => (h.pctSold ?? 0) >= 1).length, scored: scored.length,
        pending: p, cash: cash?.get(f.m.csoId) ?? null,
      };
    });
  }, [folded, historyBy, pendingBy, cash, period]);

  const gradeCounts = useMemo(() => {
    const c: Record<Grade, number> = { top: 0, above: 0, below: 0, support: 0, none: 0, unranked: 0 };
    for (const r of allRows) c[r.grade]++;
    return c;
  }, [allRows]);

  const listed = useMemo(() => {
    const q = search.trim().toLowerCase();
    const out = allRows.filter((r) =>
      (district === ALL || r.m.district === district) && (unit === ALL || r.m.unit === unit) && (grade === "all" || r.grade === grade)
      && (!q || `${r.m.cso} ${r.m.unit} ${r.m.district}`.toLowerCase().includes(q)));
    // Weakest overall first; the table's headers sort on anything else.
    return [...out].sort((a, b) => (a.score ?? 99) - (b.score ?? 99));
  }, [allRows, district, unit, grade, search]);

  const unitWordTitle = rw ? "Territory" : "Branch";
  const basis = rw ? "contracts" : "SQM-E";
  const wk = weekOfDay(day);

  const cols: Col<Row>[] = [
    { key: "cso", header: "CSO", mobile: "title", sort: (r) => r.m.cso, copy: (r) => r.m.cso, cell: (r) => (
      <span className="flex items-stretch gap-2.5">
        <span className="w-0.5 shrink-0 rounded-full" style={{ background: GRADE_COLOR[r.grade] }} />
        <span className="min-w-0">
          <span className="block font-medium leading-tight" style={{ color: "var(--text-primary)" }}>{r.m.cso}</span>
          <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{r.m.homeUnit ?? r.m.unit}{r.size > 0 ? ` · #${r.rank} of ${r.size}` : ""}</span>
        </span>
      </span>
    ) },
    { key: "standing", header: "Standing", sort: (r) => r.score, copy: (r) => GRADE_LABEL[r.grade], cell: (r) => (
      <span className="flex flex-col items-start gap-1">
        <span className="inline-block rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: `color-mix(in srgb, ${GRADE_COLOR[r.grade]} 16%, transparent)`, color: "var(--text-primary)" }}>{GRADE_LABEL[r.grade]}</span>
        {r.tags.length > 0 && <span className="flex flex-wrap gap-1">{r.tags.map((t) => <Tag key={t}>{t}</Tag>)}</span>}
      </span>
    ) },
    { key: "sales", header: `Sales, ${period.short}`, sort: (r) => r.pctSold, copy: (r) => (r.pctSold == null ? "" : Math.round(r.pctSold * 100)), copyHeader: "Sales % of target", cell: (r) => rw
      ? <Progress actual={r.sold} target={r.minSold} pct={r.pctSold} tone={SERIES_SALES} under={`${whole(r.soldSqme)} of ${whole(r.minSoldSqme)} SQM-E`} />
      : <Progress actual={Math.round(r.soldSqme)} target={r.minSoldSqme} pct={r.pctSold} tone={SERIES_SALES} under={`SQM-E · ${whole(r.sold)} contracts`} /> },
    { key: "coll", header: `Collections, ${period.short}`, sort: (r) => r.pctCollected, copy: (r) => (r.pctCollected == null ? "" : Math.round(r.pctCollected * 100)), copyHeader: "Collections % of target", cell: (r) => rw
      ? <Progress actual={r.collected} target={r.minCollected} pct={r.pctCollected} tone={SERIES_COLL} under={`${whole(r.collectedSqme)} of ${whole(r.minCollectedSqme)} SQM-E`} />
      : <Progress actual={Math.round(r.collectedSqme)} target={r.minCollectedSqme} pct={r.pctCollected} tone={SERIES_COLL} under={`SQM-E · ${whole(r.collected)} contracts`} /> },
    { key: "money", header: <>Money collected<span className="block font-normal">{dayMonth(day)} · week · {period.short}</span></>, mobileLabel: "Money collected", right: true, sort: (r) => r.cash?.periodCash ?? null, copy: (r) => r.cash?.periodCash ?? "", copyHeader: `Money collected, period (${currency})`, cell: (r) => r.cash ? (
      <span className="flex flex-col items-end tabular-nums">
        <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{money(r.cash.dayCash, currency)}</span>
        <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{money(r.cash.weekCash, currency)}{r.cash.weeklyCashTarget != null ? ` of ${money(r.cash.weeklyCashTarget, currency)} this week` : " this week"}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{money(r.cash.periodCash, currency)} {period.short}</span>
      </span>
    ) : <span className="text-xs" style={{ color: "var(--text-muted)" }}>{cash ? "none" : "…"}</span> },
    { key: "commission", header: <>Commission<span className="block font-normal">{dayMonth(day)} · {period.short}</span></>, mobileLabel: "Commission", right: true, sort: (r) => (rw ? r.cash?.periodCommission ?? null : null), copy: (r) => (rw ? r.cash?.periodCommission ?? "" : ""), copyHeader: `Commission, period (${currency})`, cell: (r) => rw ? (r.cash ? (
      <span className="flex flex-col items-end tabular-nums">
        <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{money(r.cash.dayCommission, currency)}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{money(r.cash.periodCommission, currency)} {period.short}</span>
      </span>
    ) : <span className="text-xs" style={{ color: "var(--text-muted)" }}>{cash ? "none" : "…"}</span>) : <span className="text-xs" style={{ color: "var(--text-muted)" }}>not in Salesforce</span> },
    { key: "cvr", header: "Cash received vs revenue", right: true, sort: (r) => (r.cash ? ratio(r.cash.periodCash, r.cash.periodRevenue) : null), copy: (r) => { const v = r.cash ? ratio(r.cash.periodCash, r.cash.periodRevenue) : null; return v == null ? "" : Math.round(v * 100); }, copyHeader: "Cash received vs revenue %", cell: (r) => r.cash ? (
      <Stack top={pctText(ratio(r.cash.periodCash, r.cash.periodRevenue))} under={`${money(r.cash.periodCash, currency)} in · ${money(r.cash.periodRevenue, currency)} completed`} />
    ) : <span className="text-xs" style={{ color: "var(--text-muted)" }}>{cash ? "none" : "…"}</span> },
    { key: "pending", header: "Open follow-ups", right: true, sort: (r) => r.pending?.contracts ?? 0, cell: (r) => r.pending && r.pending.contracts > 0 ? (
      <span className="flex flex-col items-end tabular-nums">
        <span className="font-medium" style={{ color: "var(--text-primary)" }}>{fmtInt(r.pending.contracts)}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{money(r.pending.cash, currency)} owed</span>
        {r.pending.over1y > 0 && <span className="text-xs" style={{ color: "var(--warning)" }}>{fmtInt(r.pending.over1y)} over a year</span>}
      </span>
    ) : <span style={{ color: "var(--text-muted)" }}>-</span> },
    { key: "attarget", header: "At target", right: true, sort: (r) => (r.scored > 0 ? r.atTarget / r.scored : null), copy: (r) => (r.scored > 0 ? `${r.atTarget} of ${r.scored}` : ""), cell: (r) => r.scored > 0 ? <Stack top={`${r.atTarget} of ${r.scored}`} under="months" /> : <span style={{ color: "var(--text-muted)" }}>-</span> },
    { key: "form", header: `% of target, last ${FORM_MONTHS} months`, cell: (r) => <FormPills pills={r.form} /> },
  ];

  const exportHeaders = ["CSO", unitWordTitle, rw ? "District" : "Branch", "Standing", `Rank in ${unitWordTitle.toLowerCase()}`,
    "Contracts sold", "SQM-E sold", "Sales % of target", "Contracts collected", "SQM-E collected", "Collections % of target",
    `Money collected ${day} (${currency})`, `Money collected, week (${currency})`, `Money collected, period (${currency})`,
    `Commission ${day} (${currency})`, `Commission, period (${currency})`, `Cash received, period (${currency})`, `Revenue completed, period (${currency})`,
    "Open follow-ups", `Owed (${currency})`, "Follow-ups over a year", "Months at target", "Months scored", "Flags"];
  const exportRows: Cell[][] = listed.map((r) => [
    r.m.cso, r.m.homeUnit ?? r.m.unit, r.m.district, GRADE_LABEL[r.grade], r.size > 0 ? `${r.rank} of ${r.size}` : "",
    r.sold, Math.round(r.soldSqme), r.pctSold == null ? "" : Math.round(r.pctSold * 100), r.collected, Math.round(r.collectedSqme), r.pctCollected == null ? "" : Math.round(r.pctCollected * 100),
    r.cash?.dayCash ?? "", r.cash?.weekCash ?? "", r.cash?.periodCash ?? "", r.cash?.dayCommission ?? "", r.cash?.periodCommission ?? "", r.cash?.periodCash ?? "", r.cash?.periodRevenue ?? "",
    r.pending?.contracts ?? 0, r.pending?.cash ?? 0, r.pending?.over1y ?? 0, r.atTarget, r.scored, r.tags.join("; "),
  ]);

  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        {rw && <Select label="District" value={district} options={districts} onChange={(v) => { setDistrict(v); setUnit(ALL); }} />}
        <Select label={unitWordTitle} value={unit} options={units} onChange={setUnit} />
        <button type="button" onClick={() => setStaffOnly((v) => !v)} className="min-h-11 rounded-md border px-2.5 py-1.5 text-sm sm:min-h-0"
          style={{ background: "var(--surface)", borderColor: staffOnly ? "var(--border)" : "var(--accent-strong)", color: "var(--text-secondary)" }}>
          {staffOnly ? "Current staff only" : "Including leavers"}
        </button>
        <label className="flex items-center gap-1.5 text-sm" style={{ color: "var(--text-secondary)" }}>
          <span style={{ color: "var(--text-muted)" }}>Money on</span>
          <input type="date" value={day} max={today} onChange={(e) => e.target.value && setDay(e.target.value)}
            className="min-h-11 rounded-md border px-2 py-1.5 text-sm sm:min-h-0" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
        </label>
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={`Search CSO, ${unitWordTitle.toLowerCase()}…`}
          className="min-h-11 w-full flex-1 rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-auto sm:min-w-48" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
      </div>
      <BarExports filename={`csos-${country.toLowerCase()}_${period.label.replace(/\s+/g, "-")}_${stamp()}`} headers={exportHeaders} rows={exportRows} />

      <div className="flex flex-wrap items-center gap-2">
        <Chip label="Everyone" count={allRows.length} on={grade === "all"} color="var(--text-secondary)" onClick={() => setGrade("all")} />
        {(["top", "above", "below", "support"] as Grade[]).map((g) => (
          <Chip key={g} label={GRADE_LABEL[g]} count={gradeCounts[g]} on={grade === g} color={GRADE_COLOR[g]} onClick={() => setGrade(grade === g ? "all" : g)} />
        ))}
        {gradeCounts.unranked > 0 && <Chip label="Not ranked" count={gradeCounts.unranked} on={grade === "unranked"} color={GRADE_COLOR.unranked} onClick={() => setGrade(grade === "unranked" ? "all" : "unranked")} />}
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
          Graded against target and against peers for {period.short}, in {basis}. Select a row for full history.
          {cashError && <span style={{ color: "var(--critical)" }}> Money columns could not load: {cashError}</span>}
          {!cash && !cashError && <span className="ml-2 inline-flex"><Spinner size={12} label="loading money" /></span>}
        </span>
      </div>

      <div className="flex flex-col gap-3">
        <DataTable rows={listed} cols={cols} keyOf={(r) => r.id} onRow={(r) => setSelected((cur) => (cur === r.id ? null : r.id))} selectedKey={selected} copyName="the CSO list"
          empty="No CSOs match these filters."
          note={`Money collected is cash received on the contracts each CSO signed: the day chosen, the calendar week holding it (${dayMonth(wk.start)} to ${dayMonth(wk.end)})${rw ? "" : " against the branch's weekly cash target per CSO where one exists"}, and ${period.short}. ${rw ? "Commission is Salesforce's 50% and 100% commission per contract, booked on the day each milestone was reached; it is provisional until payroll confirms the rule. " : "Commission is not recorded in Salesforce for this country. "}Cash received vs revenue compares money in with the contract value of builds completed in the same period. Open follow-ups are contracts signed that have not crossed the payment gate, counted as the Collections module does.`} />
        {selected && (() => {
          const r = listed.find((x) => x.id === selected) ?? allRows.find((x) => x.id === selected);
          if (!r) return null;
          const hist = historyBy.get(r.id) ?? [];
          return (
            <Fragment>
              <div className="rounded-xl border-l-2 p-5" style={{ background: "var(--page)", borderColor: "var(--accent-strong)" }}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{r.m.cso}</h3>
                    <p className="text-sm" style={{ color: "var(--text-muted)" }}>
                      {r.m.homeUnit ?? r.m.unit} · {r.m.district}{r.size > 0 ? ` · #${r.rank} of ${r.size} in ${levelTitle(s.unit).toLowerCase()}` : ""}{r.m.manager ? ` · manager ${r.m.manager}` : ""}
                      {r.m.phone && <> · <a href={telHref(r.m.phone) ?? undefined} className="hover:underline" style={{ color: "var(--accent-ink)" }}>{r.m.phone}</a></>}
                    </p>
                  </div>
                  <button type="button" onClick={() => setSelected(null)} className="rounded-md border px-2.5 py-1 text-sm" style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>Collapse</button>
                </div>
                {hist.length > 1 ? (
                  <div className="mt-4">
                    <TrendChart title="History, against the standard" months={hist.map((h) => h.monthLabel.slice(0, 3))}
                      selected={hist.findIndex((h) => h.month === (period.mode === "quarter" ? period.fetchMonth : period.month))}
                      series={[
                        { key: "s", label: "Sales", color: SERIES_SALES, values: hist.map((h) => h.pctSold) },
                        { key: "c", label: "Collections", color: SERIES_COLL, values: hist.map((h) => h.pctCollected) },
                      ]} />
                  </div>
                ) : <Muted>Only one month of history.</Muted>}
              </div>
            </Fragment>
          );
        })()}
      </div>
    </>
  );
}
