"use client";

import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import { monthName } from "@/lib/period";
import type { JourneyStock, WsData, WsRow } from "@/lib/workspace-types";
import {
  bottomN, count, currencyOf, freshnessLine, headRow, levelTitle, money, one, pctText, tableLevel, tableRows, trendRows, unitWord, whole,
  SERIES_BUILDS, unitsOf,
} from "@/lib/workspace-ui";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { stamp, type Cell } from "@/lib/export";
import { Boxes, DataTable, Fact, Kpi, PctCell, Remaining, Stack, type Col, Paint, paintNote } from "@/components/ws/primitives";
import TrendChart from "@/components/ws/TrendChart";
import MasonList from "@/components/ws/MasonList";

/**
 * Page 3, Masons: Overview (Built, masons against requirement, to hire,
 * builds per mason) and Individual masons, as tabs.
 */
export default function MasonsPage(props: { country: CapacityCountry; slug: string; calendar: CapacityWeek[]; data: WsData; journey: JourneyStock; userEmail: string | null }) {
  const { country, slug, calendar, data, journey, userEmail } = props;
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} userEmail={userEmail} freshness={freshnessLine(data.syncedMs, data.builtAt)} units={unitsOf(data)}>
      {(s) => <Body s={s} data={data} journey={journey} />}
    </WorkspaceShell>
  );
}

/** The two sub-pages live in the sidebar and reach here as `tab`. */
function Body({ s, data, journey }: { s: WsState; data: WsData; journey: JourneyStock }) {
  const tab = s.tab === "masons" ? "masons" : "overview";
  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>{tab === "masons" ? "Individual masons" : "Masons"}, {s.scopeLabel}</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>{s.period.label}</p>
      </div>
      {tab === "overview" ? <Overview s={s} data={data} journey={journey} /> : <MasonList key={`${s.scope?.level ?? ""}|${s.scope?.name ?? ""}`} s={s} data={data} currency={currencyOf(s.country)} />}
    </>
  );
}

function Overview({ s, data, journey }: { s: WsState; data: WsData; journey: JourneyStock }) {
  const { period, scope, country } = s;
  const currency = currencyOf(country);
  const head = headRow(data.rows, period, country, scope);
  const rows = tableRows(data.rows, period, country, scope, s.dim);
  const level = tableLevel(country, scope, s.dim);
  const headLevel = scope?.level ?? "country";
  const headName = scope?.name ?? country;
  const waiting = journey.stock.find((r) => r.level === headLevel && r.name === headName && r.bucket === "paid_not_started");
  const trend = trendRows(data.rows, period, headLevel, headName);
  const selectedIdx = trend.findIndex((r) => r.month === period.fetchMonth);

  const sorted = [...rows].sort((a, b) => (a.buildsPerMason ?? 99) - (b.buildsPerMason ?? 99) || a.name.localeCompare(b.name));
  const worst = bottomN(rows, (r) => r.buildsPerMason);
  const needWord = (r: WsRow) => (r.usualBuildsPerMason == null ? "no standard set" : `target ${one(r.usualBuildsPerMason)}${r.nWeeks === 4 && !r.isQuarter ? "" : ` for ${period.short}`}`);

  const pick = (r: WsRow) => s.setScope(r.level === "country" ? null : { level: r.level as "territory" | "district" | "branch", name: r.name }, r.level === "territory" ? r.parent : null);
  const pct100 = (v: number | null) => (v == null ? "" : Math.round(v * 100));
  const cols: Col<WsRow>[] = [
    { key: "name", header: levelTitle(level), mobile: "title", sort: (r) => r.name, copy: (r) => r.name, cell: (r) => (
      <span className="flex flex-col">
        <button type="button" onClick={() => pick(r)}
          className="text-left font-semibold underline decoration-[var(--border)] underline-offset-4" style={{ color: "var(--text-primary)" }}>{r.name}</button>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.level === "territory" ? r.parent : r.level === "district" ? count(r.nTerritories, "territory", "territories") : r.country}</span>
      </span>
    ) },
    { key: "built", header: "Built SQM-E", right: true, sort: (r) => r.pctSqme, copy: (r) => pct100(r.pctSqme), copyHeader: "Built SQM-E % of target", cell: (r) => <PctCell pct={r.pctSqme} under={`${whole(r.sqmeBuilt)} / ${whole(r.sqmeTarget)}`} /> },
    { key: "revenue", header: "Revenue", right: true, sort: (r) => r.revenue, copy: (r) => Math.round(r.revenue), copyHeader: `Revenue (${currency})`, cell: (r) => <Stack top={money(r.revenue, currency)} under="completed" /> },
    { key: "working", header: "Working", right: true, sort: (r) => r.working, cell: (r) => <Stack top={whole(r.working)} /> },
    { key: "assigned", header: "Assigned", right: true, sort: (r) => r.assigned, cell: (r) => <Stack top={whole(r.assigned)} /> },
    { key: "hire", header: "To hire", right: true, sort: (r) => r.toHire, copy: (r) => r.toHire == null ? "" : Math.round(r.toHire), cell: (r) => <Stack top={r.toHire == null ? "-" : whole(r.toHire)} under={`need ${whole(r.minMasons)}`} color={r.toHire != null && r.toHire > 0 ? "var(--critical)" : undefined} /> },
    { key: "bpm", header: "Builds per mason", right: true, sort: (r) => r.buildsPerMason, copy: (r) => r.buildsPerMason == null ? "" : Math.round(r.buildsPerMason * 10) / 10, cell: (r) => <PctCell pct={r.pctBuildProductivity} under={`${one(r.buildsPerMason)} per mason · ${whole(r.built)} builds · ${needWord(r)}`} /> },
    { key: "ontime", header: "On time", right: true, sort: (r) => r.pctOnTime, copy: (r) => pct100(r.pctOnTime), copyHeader: "On time %", cell: (r) => <Stack top={pctText(r.pctOnTime)} under={`${whole(r.buildsOnTime)} of ${whole(r.buildsOnTime + r.buildsLate)}`} /> },
    { key: "waiting", header: "Waiting per mason", right: true, sort: (r) => r.waitingPerMason, copy: (r) => r.waitingPerMason == null ? "" : Math.round(r.waitingPerMason * 10) / 10, cell: (r) => <Stack top={r.waitingPerMason == null ? "-" : one(r.waitingPerMason)} under={`${whole(r.collectedNotBuilt)} waiting`} /> },
    { key: "earning", header: "Earning enough", right: true, sort: (r) => r.pctMasonsProductive, copy: (r) => pct100(r.pctMasonsProductive), copyHeader: "Earning enough %", cell: (r) => <Stack top={pctText(r.pctMasonsProductive)} under={`${whole(r.masonsProductive)} of ${whole(r.working)}`} /> },
    { key: "paint", header: "Paint", right: true, sort: (r) => r.paintSqmeBuilt, copy: (r) => Math.round(r.paintSqmeBuilt), copyHeader: "Paint SQM-E built", cell: (r) => <Paint sqme={r.paintSqmeBuilt} contracts={r.paintBuilt} /> },
  ];
  const exportRows: Cell[][] = sorted.map((r) => [
    r.name, r.level === "territory" ? r.parent ?? "" : "", Math.round(r.sqmeBuilt), Math.round(r.sqmeTarget ?? 0), pct100(r.pctSqme), Math.round(r.revenue), r.working, r.assigned,
    r.minMasons == null ? "" : Math.round(r.minMasons), r.toHire == null ? "" : Math.round(r.toHire), r.buildsPerMason == null ? "" : Math.round(r.buildsPerMason * 10) / 10,
    r.usualBuildsPerMason == null ? "" : Math.round(r.usualBuildsPerMason * 10) / 10, pct100(r.pctOnTime), r.collectedNotBuilt, pct100(r.pctMasonsProductive),
    Math.round(r.paintSqmeBuilt), r.paintBuilt,
  ]);

  return (
    <>
      {head ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Kpi label="Built" pct={head.pctSqme} tone={SERIES_BUILDS}
            lines={[<Fact key="sqme" n={head.sqmeBuilt} of={head.sqmeTarget} word="SQM-E" />, <Fact key="builds" n={head.built} of={head.buildTarget} word="builds" />]}
            remaining={head.sqmeTarget == null ? "no target set" : <Remaining parts={[{ n: head.sqmeTarget - head.sqmeBuilt, word: "SQM-E" }]} />}
            note={<>{paintNote(head.paintSqmeBuilt) ? <span className="block">{paintNote(head.paintSqmeBuilt)}</span> : null}<span className="block">Revenue {money(head.revenue, currency)}, contract value of builds completed, live from Salesforce</span></>}
            sub={`${whole(head.floorsBuilt)} floors, ${whole(head.plastersBuilt)} plasters`} />
          <Kpi label="Masons" big={whole(head.totalMasons)} tone={SERIES_BUILDS}
            lines={[<Fact key="w" n={head.working} word="working" />, <Fact key="a" n={head.assigned} word="assigned, not started" />]}
            remaining={head.minMasons == null ? "no requirement set" : `${whole(head.minMasons)} needed`}
            sub="Distinct people at this level, not the sum of the units" />
          <Kpi label="To hire" big={head.toHire == null ? "-" : whole(head.toHire)} tone={head.toHire != null && head.toHire > 0 ? "var(--critical)" : "var(--good)"}
            lines={[head.toHire != null && head.toHire > 0 ? <Fact key="s" n={head.territoriesShort} word={`${unitWord(s.unit, head.territoriesShort)} short of masons`} /> : <span key="ok">Every {unitWord(s.unit, 1)} has enough masons</span>]}
            sub="Each unit's own shortfall after working and assigned, added up, never netted" />
          <Kpi label="Builds per mason" big={one(head.buildsPerMason)} tone={SERIES_BUILDS}
            lines={[
              <span key="t">{head.usualBuildsPerMason == null ? "no standard set" : <Fact n={one(head.usualBuildsPerMason)} word={`is the standard for ${period.short}`} />}</span>,
              <Fact key="l" n={head.buildsLate} word="builds late" />,
            ]}
            remaining={`${pctText(head.pctOnTime)} finished on time`} />
        </div>
      ) : (
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>No figures for {s.scopeLabel} in {period.label}.</p>
      )}

      {trend.length > 0 && (
        <TrendChart title={`Builds per mason, January to ${monthName(period.fetchMonth)}`} months={trend.map((r) => r.monthLabel.slice(0, 3))} selected={selectedIdx}
          target={4} targetLabel="Target 4 a month" format={(v) => one(v)} yMax={Math.max(5, ...trend.map((r) => Math.ceil((r.buildsPerMason ?? 0) * 1.1)))}
          series={[{ key: "bpm", label: "Builds per mason", color: SERIES_BUILDS, values: trend.map((r) => r.buildsPerMason) }]} />
      )}

      <BarExports filename={`masons-${country.toLowerCase()}_${period.label.replace(/\s+/g, "-")}_${stamp()}`}
        headers={[levelTitle(level), "Branch", "SQM-E built", "SQM-E target", "Built %", `Revenue (${currency})`, "Working", "Assigned", "Masons needed", "To hire", "Builds per mason", "Standard per mason", "On time %", "Paid customers waiting", "Earning enough %", "Paint SQM-E built", "Paint contracts built"]}
        rows={exportRows} />

      <section className="flex flex-col gap-3">
        <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
          {scope ? (scope.level === "district" ? `Territories in ${scope.name}` : scope.name) : `By ${unitWord(level, 1)}`}
        </h2>
        <DataTable rows={sorted} cols={cols} keyOf={(r) => `${r.level}|${r.name}`} mark={(r) => worst.has(r.name)} copyName="the table"
          note={`Focus marks the five lowest on builds per mason. Waiting per mason is paid customers not yet built, divided by working masons. Working plus assigned plus to hire equals what each ${unitWord(s.unit, 1)} needs for the month. Earning enough is masons whose approved pay met the productive bar for these weeks.`} />
      </section>

      {head && (
        <Boxes
          happened={[
            `Built ${whole(head.sqmeBuilt)} of ${whole(head.sqmeTarget)} SQM-E, ${whole(head.built)} builds.`,
            `${whole(head.working)} masons worked, each built ${one(head.buildsPerMason)}${head.usualBuildsPerMason != null ? ` against a target of ${one(head.usualBuildsPerMason)}` : ""}.`,
            `${pctText(head.pctOnTime)} of builds finished on time. ${pctText(head.pctMasonsProductive)} of masons earned above the productive bar.`,
          ]}
          next={[
            head.toHire != null && head.toHire > 0 ? `Hire ${whole(head.toHire)} masons. Working plus assigned is below the requirement.` : "Enough masons. The gap is output per mason.",
            waiting ? `${whole(waiting.n)} paid customers are waiting. Give them to masons with space this week.` : "Nobody is waiting for a build to start.",
            `${whole(head.buildsLate)} builds finished late. ${whole(head.assigned)} ${head.assigned === 1 ? "mason is" : "masons are"} assigned but not started.`,
          ]} />
      )}
    </>
  );
}
