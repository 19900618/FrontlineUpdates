"use client";

import { useEffect, useMemo, useState } from "react";
import { fmtInt } from "@/lib/format";
import type { WsData, WsMason, UnitLevel } from "@/lib/workspace-types";
import { dayMonth, levelTitle, money, one, pctText, unitLevelOf, unitWord, whole, SERIES_BUILDS } from "@/lib/workspace-ui";
import Spinner from "@/components/Spinner";
import { stamp, type Cell } from "@/lib/export";
import { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { Chip, DataTable, FormPills, PctCell, Select, Stack, type Col } from "@/components/ws/primitives";

/**
 * Individual masons: one row per mason for the place chosen (the workspace
 * scope by default, widenable to the whole country) over the period. The
 * rows come from capacity_mason_week_v2; the skills column is the QA pass
 * rate behind that function's `skills` CTE until a training source exists.
 */
const ALL = "All";
type Status = "all" | "Working" | "Assigned, not started";

export default function MasonList({ s, data, currency }: { s: WsState; data: WsData; currency: string }) {
  const { period, scope, country } = s;
  const unit = unitLevelOf(country);
  const [level, setLevel] = useState<UnitLevel | "country">(scope?.level ?? "country");
  const [name, setName] = useState(scope?.name ?? country);
  const [status, setStatus] = useState<Status>("all");
  const [search, setSearch] = useState("");
  // The roster, keyed by the request it answers, so a new place or period
  // reads as loading until its own answer lands. The parent keys this
  // component on the scope, so a new scope mounts it fresh.
  const reqKey = `${country}|${level}|${name}|${period.start}|${period.end}|${period.weekKey}`;
  const [answer, setAnswer] = useState<{ key: string; rows?: WsMason[]; error?: string } | null>(null);
  const rows = answer?.key === reqKey ? answer.rows ?? null : null;
  const error = answer?.key === reqKey ? answer.error ?? null : null;

  useEffect(() => {
    let live = true;
    const q = new URLSearchParams({ country, level, name, start: period.start, end: period.end, weeks: period.weekKey });
    fetch(`/api/workspace/masons?${q}`)
      .then(async (r) => { const j = await r.json(); if (!r.ok) throw new Error(j.error ?? r.statusText); if (live) setAnswer({ key: reqKey, rows: j.rows as WsMason[] }); })
      .catch((e) => { if (live) setAnswer({ key: reqKey, error: e instanceof Error ? e.message : String(e) }); });
    return () => { live = false; };
  }, [country, level, name, period.start, period.end, period.weekKey, reqKey]);

  /** The places to choose from: every unit (and Rwanda's districts) in the period payload. */
  const places = useMemo(() => {
    const units = data.rows.filter((r) => r.level === unit && r.month === period.month && r.weekKey === period.weekKey).map((r) => r.name).sort();
    const districts = country === "Rwanda" ? data.rows.filter((r) => r.level === "district" && r.month === period.month && r.weekKey === period.weekKey).map((r) => r.name).sort() : [];
    return { units, districts };
  }, [data, unit, country, period]);

  const listed = useMemo(() => {
    const q = search.trim().toLowerCase();
    const out = (rows ?? []).filter((m) => (status === "all" || m.status === status) && (!q || `${m.masonName} ${m.unit ?? ""}`.toLowerCase().includes(q)));
    // Most SQM-E completed first; the table's headers sort on anything else.
    return [...out].sort((a, b) => b.sqmeCompleted - a.sqmeCompleted);
  }, [rows, status, search]);

  const counts = useMemo(() => ({
    all: rows?.length ?? 0, working: rows?.filter((m) => m.status === "Working").length ?? 0, assigned: rows?.filter((m) => m.status !== "Working").length ?? 0,
  }), [rows]);

  const rates = useMemo(() => {
    const v = Array.from(new Set((rows ?? []).map((m) => m.weeklyRate).filter((x): x is number => x != null && x > 0).map((x) => Math.round(x))));
    return v.sort((a, b) => a - b);
  }, [rows]);
  const rateNote = rates.length === 0 ? "No standard is set for this place yet"
    : rates.length === 1 ? `Standard is ${rates[0]} SQM-E a week for one mason`
    : `Standard is ${rates[0]} to ${rates[rates.length - 1]} SQM-E a week for one mason, by ${unitWord(unit, 1)}`;

  const cols: Col<WsMason>[] = [
    { key: "mason", header: "Mason", mobile: "title", sort: (m) => m.masonName, copy: (m) => m.masonName, cell: (m) => (
      <span className="flex flex-col">
        <span className="font-medium" style={{ color: "var(--text-primary)" }}>{m.masonName}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{m.unit ?? "no unit"}{m.unitParent ? ` · ${m.unitParent}` : ""}</span>
      </span>
    ) },
    { key: "status", header: "Status", sort: (m) => m.status, cell: (m) => (
      <span className="inline-block rounded px-1.5 py-0.5 text-xs font-semibold"
        style={{ background: `color-mix(in srgb, ${m.status === "Working" ? "var(--good)" : "var(--warning)"} 16%, transparent)`, color: "var(--text-primary)" }}>{m.status}</span>
    ) },
    { key: "builds", header: "Builds", right: true, sort: (m) => m.builds, cell: (m) => <Stack top={whole(m.builds)} under={m.timesheets ? `${whole(m.timesheets)} timesheets` : undefined} /> },
    { key: "sqme", header: "SQM-E completed", right: true, sort: (m) => m.sqmeCompleted, copy: (m) => Math.round(m.sqmeCompleted), cell: (m) => <Stack top={whole(m.sqmeCompleted)} /> },
    { key: "revenue", header: "Revenue", right: true, sort: (m) => m.revenue, copy: (m) => Math.round(m.revenue), copyHeader: `Revenue (${currency})`, cell: (m) => <Stack top={money(m.revenue, currency)} under="completed" /> },
    { key: "inhand", header: "SQM-E in hand", right: true, sort: (m) => m.sqmeInHand, copy: (m) => Math.round(m.sqmeInHand), cell: (m) => <Stack top={whole(m.sqmeInHand)} under={`${whole(m.jobsInHand)} ${m.jobsInHand === 1 ? "job" : "jobs"}`} /> },
    { key: "time", header: "Time needed", right: true, sort: (m) => m.timeNeededWeeks, copy: (m) => (m.timeNeededWeeks == null ? "" : Math.round(m.timeNeededWeeks * 10) / 10), copyHeader: "Time needed (weeks)", cell: (m) => <Stack top={m.timeNeededWeeks == null ? "-" : `${one(m.timeNeededWeeks)} wk`} under={m.weeklyRate == null ? "no standard" : `at ${whole(m.weeklyRate)} a week`} /> },
    { key: "ontime", header: "On time", right: true, sort: (m) => m.pctOnTime, copy: (m) => (m.pctOnTime == null ? "" : Math.round(m.pctOnTime * 100)), copyHeader: "On time %", cell: (m) => <Stack top={m.builds ? `${whole(m.buildsOnTime)} of ${whole(m.buildsOnTime + m.buildsLate)}` : "-"} under={m.builds ? pctText(m.pctOnTime) : undefined} /> },
    { key: "earned", header: "Earned", right: true, sort: (m) => m.earnings, copy: (m) => Math.round(m.earnings), copyHeader: `Earned (${currency})`, cell: (m) => <Stack top={money(m.earnings, currency)} under={m.threshold ? `${pctText(m.pctOfThreshold)} of the bar` : undefined} color={m.isProductive ? "var(--good)" : undefined} /> },
    { key: "form", header: "Productive, last 5 weeks", copy: (m) => m.weeks.map((w) => (w.earnings > 0 && w.pctOfThreshold != null ? `${Math.round(w.pctOfThreshold * 100)}%` : "-")).join(" "), cell: (m) => <FormPills pills={m.weeks.map((w) => ({ key: w.weekStart, label: `${w.weekLabel} (${dayMonth(w.weekStart)} to ${dayMonth(w.weekEnd)})`, pct: w.earnings > 0 ? w.pctOfThreshold : null }))} /> },
    { key: "qa", header: "QA pass rate", right: true, sort: (m) => m.pctQaPass, copy: (m) => (m.pctQaPass == null ? "" : Math.round(m.pctQaPass * 100)), copyHeader: "QA pass rate %", cell: (m) => <PctCell pct={m.pctQaPass} under={m.qaMeasured ? `${whole(m.qaPassed)} of ${whole(m.qaMeasured)} first checks` : "no checks"} /> },
  ];

  const headers = ["Mason", levelTitle(unit), "Status", "Builds", "SQM-E completed", "SQM-E in hand", "Time needed (weeks)", `Weekly rate (SQM-E)`, "Builds on time", "Builds late", `Earned (${currency})`, "Productive", "QA first checks", "QA passed"];
  const exportRows: Cell[][] = listed.map((m) => [m.masonName, m.unit ?? "", m.status, m.builds, Math.round(m.sqmeCompleted), Math.round(m.sqmeInHand), m.timeNeededWeeks == null ? "" : Math.round(m.timeNeededWeeks * 10) / 10, m.weeklyRate == null ? "" : Math.round(m.weeklyRate), m.buildsOnTime, m.buildsLate, Math.round(m.earnings), m.isProductive ? "Yes" : "No", m.qaMeasured, m.qaPassed]);

  const placeOptions = [ALL, ...places.districts.map((d) => `Branch: ${d}`), ...places.units];
  const placeValue = level === "country" ? ALL : level === "district" ? `Branch: ${name}` : name;
  function pickPlace(v: string) {
    if (v === ALL) { setLevel("country"); setName(country); return; }
    if (v.startsWith("Branch: ")) { setLevel("district"); setName(v.slice(8)); return; }
    setLevel(unit); setName(v);
  }

  return (
    <>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${SERIES_BUILDS}` }}>
          <span className="block text-sm" style={{ color: "var(--text-secondary)" }}>Masons in {s.unit === level || level === "district" ? name : country}</span>
          <span className="mt-1 block text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{rows ? fmtInt(rows.length) : "…"}</span>
          <span className="mt-1 block text-xs" style={{ color: "var(--text-muted)" }}>{rows ? `${fmtInt(counts.working)} working, ${fmtInt(counts.assigned)} assigned and not started, in ${period.short}` : "loading"}</span>
        </div>
        <div className="rounded-xl border border-dashed p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", opacity: 0.7 }}>
          <span className="block text-sm" style={{ color: "var(--text-muted)" }}>Masons trained, coming later</span>
          <span className="mt-1 block text-3xl font-semibold" style={{ color: "var(--text-muted)" }}>–</span>
          <span className="mt-1 block text-xs" style={{ color: "var(--text-muted)" }}>Waiting on a training record source. Salesforce holds none, so the QA pass rate column stands in as the skills measure.</span>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Select label={levelTitle(unit)} value={placeValue} options={placeOptions} optionLabel={(v) => (v === ALL ? `All ${unitWord(unit)}` : v)} onChange={pickPlace} />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search mason…"
          className="min-h-11 w-full flex-1 rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-auto sm:min-w-48" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
      </div>
      <BarExports filename={`masons-${country.toLowerCase()}-${name.replace(/\s+/g, "-")}_${period.label.replace(/\s+/g, "-")}_${stamp()}`} headers={headers} rows={exportRows} />

      <div className="flex flex-wrap items-center gap-2">
        <Chip label="Everyone" count={counts.all} on={status === "all"} color="var(--text-secondary)" onClick={() => setStatus("all")} />
        <Chip label="Working" count={counts.working} on={status === "Working"} color="var(--good)" onClick={() => setStatus(status === "Working" ? "all" : "Working")} />
        <Chip label="Assigned, not started" count={counts.assigned} on={status === "Assigned, not started"} color="var(--warning)" onClick={() => setStatus(status === "Assigned, not started" ? "all" : "Assigned, not started")} />
        {!rows && !error && <span className="text-xs" style={{ color: "var(--text-muted)" }}><Spinner size={12} label="Loading masons, up to ten seconds" /></span>}
        {error && <span className="text-xs" style={{ color: "var(--critical)" }}>Could not load the masons: {error}</span>}
      </div>

      <DataTable rows={listed} cols={cols} keyOf={(m) => m.masonId} copyName="the mason list" empty={rows ? "No masons match these filters." : "Loading…"}
        note={`${rateNote}: the ${unitWord(unit, 1)}'s monthly SQM-E target per mason, over 4.33 weeks. Time needed is SQM-E in hand at that rate. SQM-E in hand is the jobs assigned to the mason that became buildable in the 90 days to ${dayMonth(period.end)} and were not finished by then. Each pill is that week's approved pay against the productive bar, ${whole(rows?.[0]?.weeklyThreshold ?? 0)} ${currency} for each Wednesday in the week, oldest on the left, the last selected week outlined. QA pass rate is the mason's first QA checks in the 90 days to ${dayMonth(period.end)}, the skills proxy until training records exist.`} />
    </>
  );
}
