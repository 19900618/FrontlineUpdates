"use client";

import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import type { QualityData, QualityGroup } from "@/lib/quality";
import type { WsData, WsRow } from "@/lib/workspace-types";
import {
  currencyOf, dayMonth, freshnessLine, lastCompleteWeeks, money, monthRow, one, pctText, weekRow, whole, SERIES_BUILDS, SERIES_COLL, unitsOf,
} from "@/lib/workspace-ui";
import { quarterOf } from "@/lib/period";
import { fmtInt } from "@/lib/format";
import WorkspaceShell, { type WsState } from "@/components/ws/WorkspaceShell";
import { DataTable, Paint, PctCell, Stack, type Col } from "@/components/ws/primitives";
import Sparkline from "@/components/ws/Sparkline";

/**
 * The MARGA meeting, Rwanda only: the four blocks of the workbook the team
 * rebuilds by hand every Monday. Each block is a heading, a table in the
 * workbook's column order and a Copy table button, so a paste lands in the
 * shape the team already reads. Root causes and Action needed are filled in
 * by hand in the meeting and are not columns here (removed 2026-09-29 on
 * request); the paste takes the figures only. Default period: month to date.
 */
export default function MargaPage(props: {
  country: CapacityCountry; slug: string; calendar: CapacityWeek[]; years: number[]; data: WsData; nowData: WsData; nowMonth: string;
  quality: QualityData; userEmail: string | null;
}) {
  const { country, slug, calendar, years, data, nowData, nowMonth, quality, userEmail } = props;
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} years={years} userEmail={userEmail} freshness={freshnessLine(data.syncedMs, data.builtAt)} units={unitsOf(data)}>
      {(s) => <Body s={s} data={data} nowData={nowData} nowMonth={nowMonth} quality={quality} currency={currencyOf(country)} />}
    </WorkspaceShell>
  );
}

const FOCUS_N = 5;
const pct = (a: number, b: number): number | null => (b > 0 ? a / b : null);
const pct100 = (v: number | null | undefined) => (v == null ? "" : Math.round(v * 100));
/** The N weakest on a score, lowest first. Places without a score are left out. */
function focus<T>(rows: T[], score: (r: T) => number | null, n = FOCUS_N): T[] {
  return rows.filter((r) => score(r) != null).sort((a, b) => (score(a) as number) - (score(b) as number)).slice(0, n);
}
/** The territory or branch name on one line, its district small underneath. */
const Name = ({ name, under }: { name: string; under?: string | null }) => (
  <span className="flex flex-col">
    <span className="whitespace-nowrap font-semibold" style={{ color: "var(--text-primary)" }}>{name}</span>
    {under && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{under}</span>}
  </span>
);

function Body({ s, data, nowData, nowMonth, quality, currency }: { s: WsState; data: WsData; nowData: WsData; nowMonth: string; quality: QualityData; currency: string }) {
  const { period } = s;
  const territories = data.rows.filter((r) => r.level === "territory" && r.month === period.month && r.weekKey === period.weekKey);
  const quarter = quarterOf(period.fetchMonth);
  const qaTarget = quarter >= 4 ? 0.95 : 0.9;

  // C1. Sales and collections: worst five on the average of sales % and collections %.
  const salesScore = (r: WsRow) => (r.pctSales == null && r.pctColl == null ? null : ((r.pctSales ?? 0) + (r.pctColl ?? 0)) / 2);
  const salesFocus = focus(territories, salesScore);
  const salesCols: Col<WsRow>[] = [
    { key: "territory", header: "Territory", mobile: "title", sort: (r) => r.name, copy: (r) => r.name, cell: (r) => <Name name={r.name} under={r.parent} /> },
    { key: "manager", header: "Manager", sort: (r) => r.manager, copy: (r) => r.manager ?? "", cell: (r) => r.manager ?? "-" },
    { key: "sold", header: "Sold", right: true, sort: (r) => r.sold, cell: (r) => whole(r.sold) },
    { key: "salesTarget", header: "Sales target", right: true, sort: (r) => r.salesTarget, copy: (r) => (r.salesTarget == null ? "" : Math.round(r.salesTarget)), cell: (r) => whole(r.salesTarget) },
    { key: "salesPct", header: "Sales %", right: true, sort: (r) => r.pctSales, copy: (r) => pct100(r.pctSales), cell: (r) => <PctCell pct={r.pctSales} /> },
    { key: "collected", header: "Collected", right: true, sort: (r) => r.collected, cell: (r) => whole(r.collected) },
    { key: "collTarget", header: "Collections target", right: true, sort: (r) => r.buildTarget, copy: (r) => (r.buildTarget == null ? "" : Math.round(r.buildTarget)), cell: (r) => whole(r.buildTarget) },
    { key: "collPct", header: "Collections %", right: true, sort: (r) => r.pctColl, copy: (r) => pct100(r.pctColl), cell: (r) => <PctCell pct={r.pctColl} /> },
    { key: "csos", header: "CSOs", right: true, sort: (r) => r.csosActive, cell: (r) => whole(r.csosActive) },
    { key: "csosReq", header: "CSOs required", right: true, sort: (r) => r.minCsos, copy: (r) => (r.minCsos == null ? "" : Math.round(r.minCsos)), cell: (r) => whole(r.minCsos) },
    { key: "perCso", header: "Per-CSO output", right: true, sort: (r) => r.contractsPerCso, copy: (r) => (r.contractsPerCso == null ? "" : Math.round(r.contractsPerCso * 10) / 10), cell: (r) => <Stack top={one(r.contractsPerCso)} under={r.usualContractsPerCso == null ? undefined : `standard ${one(r.usualContractsPerCso)}`} /> },
  ];

  // C2 and C3. Builds by region: worst five on SQM-E built against target.
  const buildCols: Col<WsRow>[] = [
    { key: "territory", header: "Territory", mobile: "title", sort: (r) => r.name, copy: (r) => r.name, cell: (r) => <Name name={r.name} under={r.parent} /> },
    { key: "sqme", header: "SQM-E built", right: true, sort: (r) => r.sqmeBuilt, copy: (r) => Math.round(r.sqmeBuilt), cell: (r) => whole(r.sqmeBuilt) },
    { key: "sqmeTarget", header: "SQM-E target", right: true, sort: (r) => r.sqmeTarget, copy: (r) => (r.sqmeTarget == null ? "" : Math.round(r.sqmeTarget)), cell: (r) => whole(r.sqmeTarget) },
    { key: "sqmePct", header: "SQM-E %", right: true, sort: (r) => r.pctSqme, copy: (r) => pct100(r.pctSqme), cell: (r) => <PctCell pct={r.pctSqme} /> },
    { key: "builds", header: "Builds", right: true, sort: (r) => r.built, cell: (r) => whole(r.built) },
    { key: "working", header: "Masons working", right: true, sort: (r) => r.working, cell: (r) => whole(r.working) },
    { key: "assigned", header: "Masons assigned", right: true, sort: (r) => r.assigned, cell: (r) => whole(r.assigned) },
    { key: "required", header: "Masons required", right: true, sort: (r) => monthRow(data.rows, period.fetchMonth, r.level, r.name)?.minMasons ?? null, copy: (r) => { const m = monthRow(data.rows, period.fetchMonth, r.level, r.name); return m?.minMasons == null ? "" : Math.round(m.minMasons); }, cell: (r) => whole(monthRow(data.rows, period.fetchMonth, r.level, r.name)?.minMasons) },
    { key: "hire", header: "To hire", right: true, sort: (r) => monthRow(data.rows, period.fetchMonth, r.level, r.name)?.toHire ?? null, copy: (r) => { const m = monthRow(data.rows, period.fetchMonth, r.level, r.name); return m?.toHire == null ? "" : Math.round(m.toHire); }, cell: (r) => { const m = monthRow(data.rows, period.fetchMonth, r.level, r.name); return <span style={{ color: m?.toHire ? "var(--critical)" : "inherit" }}>{whole(m?.toHire)}</span>; } },
    { key: "bpm", header: "Builds per mason", right: true, sort: (r) => r.buildsPerMason, copy: (r) => (r.buildsPerMason == null ? "" : Math.round(r.buildsPerMason * 10) / 10), cell: (r) => one(r.buildsPerMason) },
    { key: "bpmTarget", header: "Target per mason", right: true, sort: (r) => r.usualBuildsPerMason, copy: (r) => (r.usualBuildsPerMason == null ? "" : Math.round(r.usualBuildsPerMason * 10) / 10), cell: (r) => one(r.usualBuildsPerMason) },
    { key: "paint", header: "Paint", right: true, sort: (r) => r.paintSqmeBuilt, copy: (r) => Math.round(r.paintSqmeBuilt), copyHeader: "Paint SQM-E built", cell: (r) => <Paint sqme={r.paintSqmeBuilt} contracts={r.paintBuilt} /> },
  ];
  const regions = ["East and North", "South and West"];
  const inRegion = (region: string) => territories.filter((r) => r.region === region);
  const regionFocus = (region: string) => focus(inRegion(region), (r) => r.pctSqme);
  const branchesOf = (region: string) => [...new Set(inRegion(region).map((r) => r.parent).filter((p): p is string => !!p))].sort();

  // C4. Quality per branch (Rwanda's branch is its district).
  const branches = quality.groups.filter((g) => g.dim === "branch");
  const passFocus = focus(branches, (g) => pct(g.passed, g.evals));
  const passCols: Col<QualityGroup>[] = [
    { key: "branch", header: "Branch", mobile: "title", sort: (g) => g.name, copy: (g) => g.name, cell: (g) => <Name name={g.name} /> },
    { key: "visits", header: "QA visits", right: true, sort: (g) => g.evals, cell: (g) => fmtInt(g.evals) },
    { key: "passed", header: "Passed", right: true, sort: (g) => g.passed, cell: (g) => fmtInt(g.passed) },
    { key: "failed", header: "Failed", right: true, sort: (g) => g.failed, cell: (g) => fmtInt(g.failed) },
    { key: "notready", header: "Not ready", right: true, sort: (g) => g.notReady, cell: (g) => fmtInt(g.notReady) },
    { key: "passRate", header: "Pass rate", right: true, sort: (g) => pct(g.passed, g.evals), copy: (g) => pct100(pct(g.passed, g.evals)), cell: (g) => <PctCell pct={pct(g.passed, g.evals)} /> },
    { key: "failRate", header: "Fail rate", right: true, sort: (g) => pct(g.failed, g.evals), copy: (g) => pct100(pct(g.failed, g.evals)), cell: (g) => pctText(pct(g.failed, g.evals)) },
    { key: "nrRate", header: "Not ready rate", right: true, sort: (g) => pct(g.notReady, g.evals), copy: (g) => pct100(pct(g.notReady, g.evals)), cell: (g) => pctText(pct(g.notReady, g.evals)) },
  ];
  const matchFocus = focus(branches.filter((g) => g.spotChecked > 0), (g) => pct(g.agreed, g.spotChecked));
  const matchCols: Col<QualityGroup>[] = [
    { key: "branch", header: "Branch", mobile: "title", sort: (g) => g.name, copy: (g) => g.name, cell: (g) => <Name name={g.name} /> },
    { key: "spot", header: "Spot checks", right: true, sort: (g) => g.spotChecked, cell: (g) => fmtInt(g.spotChecked) },
    { key: "matched", header: "Matched", right: true, sort: (g) => g.agreed, cell: (g) => fmtInt(g.agreed) },
    { key: "matchRate", header: "Match rate", right: true, sort: (g) => pct(g.agreed, g.spotChecked), copy: (g) => pct100(pct(g.agreed, g.spotChecked)), cell: (g) => <PctCell pct={pct(g.agreed, g.spotChecked)} /> },
  ];

  // C6. Five-week trend cards for the focus territories of the two build blocks.
  const weeks = lastCompleteWeeks(nowCalendar(nowData), 5);
  const points = (r: WsRow, pick: (w: WsRow) => number | null) =>
    weeks.map((w) => { const x = weekRow(nowData.rows, r.level, r.name, w); return { label: `${dayMonth(w.weekStart)} to ${dayMonth(w.weekEnd)}`, value: x ? pick(x) : null }; });

  const block = (title: string, aside: string | undefined, table: React.ReactNode) => (
    <section className="flex flex-col gap-3">
      <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
        <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{title}</h2>
        {aside && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{aside}</span>}
      </div>
      {table}
    </section>
  );

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>MARGA meeting</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>{period.label}. Four blocks, each with a Copy table button; the paste lands in the workbook&apos;s column order.</p>
      </div>

      {block("Territories to focus on, sales and collections", `Worst ${FOCUS_N} on the average of sales and collections against target.`,
        <DataTable rows={salesFocus} cols={salesCols} keyOf={(r) => r.name} copyName="sales and collections" empty="No territory has a sales or collections score for this period." />)}

      {regions.map((region) => {
        const rows = regionFocus(region);
        return (
          <div key={region} className="flex flex-col gap-3">
            {block(`Territories to focus on, building, ${region}`, `Branches: ${branchesOf(region).join(", ") || "none"}. Worst ${FOCUS_N} on SQM-E built against target. No construction manager is recorded in the data.`,
              <DataTable rows={rows} cols={buildCols} keyOf={(r) => r.name} copyName={`building, ${region}`} empty="No territory in this region has a build target for this period."
                note={`Masons required and To hire are against ${period.mode === "quarter" ? "the quarter's last month's" : "the month's"} requirement.`} />)}
            {rows.length > 0 && (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {rows.map((r) => {
                  const need = monthRow(nowData.rows, nowMonth, r.level, r.name)?.minMasons ?? null;
                  const masons = points(r, (w) => w.working);
                  const earn = points(r, (w) => w.earningsPerMason);
                  const lastM = masons.at(-1)?.value ?? null;
                  const lastE = earn.at(-1)?.value ?? null;
                  return (
                    <div key={r.name} className="flex flex-col gap-2 rounded-xl border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${SERIES_BUILDS}` }}>
                      <span className="flex items-baseline justify-between gap-2">
                        <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{r.name}</span>
                        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.parent}</span>
                      </span>
                      <span className="flex items-center gap-3">
                        <span className="flex w-20 shrink-0 flex-col">
                          <span className="text-xl font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{lastM == null ? "-" : whole(lastM)}</span>
                          <span className="text-xs" style={{ color: "var(--text-muted)" }}>masons working{need != null ? `, target ${whole(need)}` : ""}</span>
                        </span>
                        <span className="min-w-0 flex-1"><Sparkline points={masons} target={need} color={SERIES_BUILDS} targetLabel="requirement" /></span>
                      </span>
                      <span className="flex items-center gap-3">
                        <span className="flex w-20 shrink-0 flex-col">
                          <span className="text-xl font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{lastE == null ? "-" : money(lastE, currency)}</span>
                          <span className="text-xs" style={{ color: "var(--text-muted)" }}>earnings per mason</span>
                        </span>
                        <span className="min-w-0 flex-1"><Sparkline points={earn} target={null} color={SERIES_COLL} format={(v) => money(v, currency).replace(`${currency} `, "")} /></span>
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}

      {block("Branches to focus on, pass rate", `Worst ${FOCUS_N} on the QA pass rate.`,
        <DataTable rows={passFocus} cols={passCols} keyOf={(g) => g.name} copyName="the pass rates" empty="No QA check in this period."
          note={`Pass rate target: 90% in Q3, 95% in Q4. This period sits in Q${quarter}, target ${pctText(qaTarget)}.`} />)}

      {block("Branches to focus on, agreement with territory leads", `Worst ${FOCUS_N} on the share of spot checks where the manager agreed.`,
        <DataTable rows={matchFocus} cols={matchCols} keyOf={(g) => g.name} copyName="the agreement rates" empty="No spot check in this period."
          note={`Pass rate target: 90% in Q3, 95% in Q4. This period sits in Q${quarter}, target ${pctText(qaTarget)}.`} />)}

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        Sales, collections, SQM-E and headcounts are the capacity view&apos;s rows for {period.label}; the region is the sales managers&apos; split named by compass region.
        Quality figures are the QA checks (compaction, screed, prior paint) dated in the period, per branch, and spot checks are manager re-checks of those evaluations.
        Weeks in the trend cards are the last five complete calendar weeks (days 1 to 7, 8 to 14, 15 to 21, 22 to month end).
      </p>
    </>
  );
}

/** The calendar weeks the current month's payload can answer for. */
function nowCalendar(nowData: WsData): CapacityWeek[] {
  const seen = new Map<string, CapacityWeek>();
  for (const r of nowData.rows) {
    if (r.level !== "country" || r.isQuarter || r.nWeeks !== 1) continue;
    const key = `${r.month}|${r.weekKey}`;
    if (seen.has(key)) continue;
    seen.set(key, { month: r.month, monthLabel: r.monthLabel, weekNo: Number(r.weekKey), weekLabel: r.periodLabel, weekStart: r.periodStart, weekEnd: r.periodEnd, isComplete: r.isComplete, isCurrent: !r.isComplete });
  }
  return [...seen.values()].sort((a, b) => a.weekStart.localeCompare(b.weekStart));
}
