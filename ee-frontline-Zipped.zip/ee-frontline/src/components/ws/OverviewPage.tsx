"use client";

import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import { monthName } from "@/lib/period";
import type { JourneyStock, WsData, WsRow } from "@/lib/workspace-types";
import {
  bottomN, collectedToday, count, currencyOf, freshnessLine, headRow, levelTitle, money, movementText, pctText, tableLevel, tableRows,
  toGo, trendRows, unitWord, whole, SERIES_BUILDS, SERIES_COLL, SERIES_SALES, unitsOf,
} from "@/lib/workspace-ui";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { stamp, type Cell } from "@/lib/export";
import { Boxes, DataTable, Fact, Kpi, PctCell, Remaining, Stack, type Col, Paint, paintNote } from "@/components/ws/primitives";
import TrendChart from "@/components/ws/TrendChart";
import RankBars from "@/components/ws/RankBars";

/**
 * Page 1, Overview: four scorecards (Built, Sold, Collected, Revenue), the
 * January-to-date trend, the ranked table with movement, the ranking chart
 * and the two boxes. Every figure is the view's row for the selected period
 * at the level shown; the page picks rows and words them.
 */
export default function OverviewPage(props: { country: CapacityCountry; slug: string; calendar: CapacityWeek[]; data: WsData; journey: JourneyStock; userEmail: string | null }) {
  const { country, slug, calendar, data, journey, userEmail } = props;
  const currency = currencyOf(country);
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} userEmail={userEmail} freshness={freshnessLine(data.syncedMs, data.builtAt)} units={unitsOf(data)}>
      {(s) => <Body s={s} data={data} journey={journey} currency={currency} />}
    </WorkspaceShell>
  );
}

function Body({ s, data, journey, currency }: { s: WsState; data: WsData; journey: JourneyStock; currency: string }) {
  const { period, scope, country } = s;
  const head = headRow(data.rows, period, country, scope);
  const rows = tableRows(data.rows, period, country, scope, s.dim);
  const level = tableLevel(country, scope, s.dim);
  const headLevel = scope?.level ?? "country";
  const headName = scope?.name ?? country;
  const today = collectedToday(data.rows, headLevel, headName);

  const stockOf = (bucket: string) => journey.stock.find((r) => r.level === headLevel && r.name === headName && r.bucket === bucket);
  const notPaid = stockOf("sold_not_paid");
  const waiting = stockOf("paid_not_started");
  const building = stockOf("building");

  const trend = trendRows(data.rows, period, headLevel, headName);
  const selectedIdx = trend.findIndex((r) => r.month === period.fetchMonth);

  // Worst first: the ranking's reverse. Rows without a rank sink to the bottom.
  const sorted = [...rows].sort((a, b) => (b.rank ?? -1) - (a.rank ?? -1) || a.name.localeCompare(b.name));
  const worst = bottomN(rows, (r) => r.pctSqme);

  const pick = (r: WsRow) => s.setScope(rowScope(r), r.level === "territory" ? r.parent : null);
  const pct100 = (v: number | null) => (v == null ? "" : Math.round(v * 100));
  const cols: Col<WsRow>[] = [
    { key: "rank", header: "Ranking", cell: (r) => <span className="font-semibold tabular-nums" style={{ color: "var(--text-muted)" }}>{r.rank ?? "–"}</span>, mobile: "hide", sort: (r) => r.rank == null ? null : -r.rank, copy: (r) => r.rank ?? "" },
    { key: "name", header: levelTitle(level), mobile: "title", sort: (r) => r.name, copy: (r) => r.name, cell: (r) => (
      <span className="flex flex-col">
        <button type="button" onClick={() => pick(r)}
          className="text-left font-semibold underline decoration-[var(--border)] underline-offset-4 hover:decoration-[var(--text-primary)]" style={{ color: "var(--text-primary)" }}>
          {r.rank != null && <span className="mr-1.5 text-xs font-semibold md:hidden" style={{ color: "var(--text-muted)" }}>#{r.rank}</span>}{r.name}
        </button>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
          {r.level === "territory" ? r.parent : r.level === "district" ? count(r.nTerritories, "territory", "territories") : r.country}
        </span>
      </span>
    ) },
    { key: "built", header: "Built SQM-E", right: true, sort: (r) => r.pctSqme, copy: (r) => pct100(r.pctSqme), copyHeader: "Built SQM-E % of target", cell: (r) => <PctCell pct={r.pctSqme} under={`${whole(r.sqmeBuilt)} / ${whole(r.sqmeTarget)}`} href={s.href(`/${s.slug}/masons`, { scope: rowScope(r) })} /> },
    { key: "builds", header: "Builds", right: true, sort: (r) => r.pctBuild, copy: (r) => pct100(r.pctBuild), copyHeader: "Builds % of target", cell: (r) => <PctCell pct={r.pctBuild} under={`${whole(r.built)} / ${whole(r.buildTarget)}`} href={s.href(`/${s.slug}/masons`, { scope: rowScope(r) })} /> },
    { key: "sold", header: "Sold", right: true, sort: (r) => r.pctSales, copy: (r) => pct100(r.pctSales), copyHeader: "Sold % of target", cell: (r) => <PctCell pct={r.pctSales} under={`${whole(r.sold)} / ${whole(r.salesTarget)}`} href={s.href(`/${s.slug}/sales`, { scope: rowScope(r) })} /> },
    { key: "collected", header: "Collected", right: true, sort: (r) => r.pctColl, copy: (r) => pct100(r.pctColl), copyHeader: "Collected % of target", cell: (r) => <PctCell pct={r.pctColl} under={`${whole(r.collected)} / ${whole(r.buildTarget)}`} href={s.href(`/${s.slug}/sales`, { scope: rowScope(r) })} /> },
    { key: "revenue", header: "Revenue", right: true, sort: (r) => r.revenue, copy: (r) => Math.round(r.revenue), copyHeader: `Revenue (${currency})`, cell: (r) => <Stack top={money(r.revenue, currency)} under={r.revenueTarget != null ? `of ${money(r.revenueTarget, currency)}` : undefined} href={s.href(`/${s.slug}/sales`, { scope: rowScope(r) })} /> },
    { key: "masons", header: "Masons", right: true, sort: (r) => r.totalMasons, copy: (r) => r.totalMasons, cell: (r) => <Stack top={`${whole(r.totalMasons)} of ${whole(r.minMasons)}`} under={r.toHire != null && r.toHire > 0 ? `${whole(r.toHire)} to hire` : undefined} color={r.toHire != null && r.toHire > 0 ? "var(--critical)" : undefined} href={s.href(`/${s.slug}/masons`, { scope: rowScope(r) })} /> },
    { key: "qa", header: "Passed QA", right: true, sort: (r) => r.pctQaPass, copy: (r) => pct100(r.pctQaPass), copyHeader: "Passed QA %", cell: (r) => <PctCell pct={r.pctQaPass} under={r.qaMeasured ? `${whole(r.qaPassed)} / ${whole(r.qaMeasured)} checks` : "no checks"} /> },
    { key: "move", header: "Movement", right: true, sort: (r) => r.rankMove, copy: (r) => r.rankMove ?? "", cell: (r) => { const m = movementText(r.rankMove); return <span className="font-semibold tabular-nums" style={{ color: m.color }}>{m.text}</span>; } },
    { key: "paint", header: "Paint", right: true, sort: (r) => r.paintSqmeBuilt, copy: (r) => Math.round(r.paintSqmeBuilt), copyHeader: "Paint SQM-E built", cell: (r) => <Paint sqme={r.paintSqmeBuilt} contracts={r.paintBuilt} /> },
  ];
  const exportRows: Cell[][] = sorted.map((r) => [
    r.rank ?? "", r.name, r.level === "territory" ? r.parent ?? "" : "", Math.round(r.sqmeBuilt), Math.round(r.sqmeTarget ?? 0), pct100(r.pctSqme),
    r.built, Math.round(r.buildTarget ?? 0), r.sold, Math.round(r.salesTarget ?? 0), r.collected, Math.round(r.revenue), r.revenueTarget == null ? "" : Math.round(r.revenueTarget),
    r.totalMasons, r.minMasons == null ? "" : Math.round(r.minMasons), r.toHire == null ? "" : Math.round(r.toHire), pct100(r.pctQaPass), r.rankMove ?? "",
    Math.round(r.paintSqmeBuilt), r.paintBuilt,
  ]);

  const scopeWord = scope ? scope.name : country;
  const behind = sorted.filter((r) => worst.has(r.name)).map((r) => r.name);

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>{scopeWord}, {period.label}</h1>
        {period.inProgress && <p className="mt-0.5 text-xs" style={{ color: "var(--text-muted)" }}>A week in this period is still in progress, so its figures will rise until it closes.</p>}
      </div>

      {head ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Kpi label="Built" pct={head.pctSqme} tone={SERIES_BUILDS} href={s.href(`/${s.slug}/masons`)}
            lines={[<Fact key="sqme" n={head.sqmeBuilt} of={head.sqmeTarget} word="SQM-E" />, <Fact key="builds" n={head.built} of={head.buildTarget} word="builds" />]}
            remaining={head.sqmeTarget == null ? "no target set" : <Remaining parts={[{ n: head.sqmeTarget - head.sqmeBuilt, word: "SQM-E" }]} />}
            note={paintNote(head.paintSqmeBuilt)}
            sub={`${whole(head.floorsBuilt)} floors, ${whole(head.plastersBuilt)} plasters${head.otherBuilt ? `, ${whole(head.otherBuilt)} other` : ""}`} />
          <Kpi label="Sold" pct={head.pctSales} tone={SERIES_SALES} href={s.href(`/${s.slug}/sales`)}
            lines={[<Fact key="c" n={head.sold} of={head.salesTarget} word="contracts" />, <Fact key="s" n={head.sqmeSold} of={head.sqmeSalesTarget} word="SQM-E" />]}
            remaining={head.salesTarget == null ? "no target set" : <Remaining parts={[{ n: head.salesTarget - head.sold, word: "contracts" }, { n: (head.sqmeSalesTarget ?? 0) - head.sqmeSold, word: "SQM-E" }]} />}
            note={paintNote(head.paintSqmeSold)}
            sub="Sales targets are the build targets times 1.3" />
          <Kpi label="Collected" pct={head.pctColl} tone={SERIES_COLL} href={s.href(`/${s.slug}/sales`)}
            lines={[<Fact key="c" n={head.collected} of={head.buildTarget} word="contracts" />, <Fact key="s" n={head.sqmeCollected} of={head.sqmeTarget} word="SQM-E" />]}
            remaining={head.buildTarget == null ? "no target set" : <Remaining parts={[{ n: head.buildTarget - head.collected, word: "contracts" }, { n: (head.sqmeTarget ?? 0) - head.sqmeCollected, word: "SQM-E" }]} />}
            note={paintNote(head.paintSqmeCollected)}
            sub={`${whole(today)} collected today`} />
          {head.revenueTarget != null ? (
            <Kpi label="Revenue" pct={head.pctRevenue} tone="var(--accent-strong)" href={s.href(`/${s.slug}/sales`)}
              lines={[<Fact key="r" n={money(head.revenue, currency)} of={money(head.revenueTarget, currency)} />]}
              remaining={head.revenueTarget > head.revenue ? <><b style={{ color: "var(--critical)" }}>{money(head.revenueTarget - head.revenue, currency)}</b> to go</> : "Target reached"}
              note="Contract value of builds completed, live from Salesforce"
              sub={`${money(head.cashReceived, currency)} of cash received in the same period.`} />
          ) : (
            <Kpi label="Revenue" big={money(head.revenue, currency)} tone="var(--accent-strong)" href={s.href(`/${s.slug}/sales`)}
              lines={[<Fact key="r" n={money(head.cashReceived, currency)} word="cash received" />]}
              note="Contract value of builds completed, live from Salesforce"
              sub="No revenue target set for this country" />
          )}
        </div>
      ) : (
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>No figures for {scopeWord} in {period.label}.</p>
      )}

      {trend.length > 0 && (
        <TrendChart title={`January to ${monthName(period.fetchMonth)}, against target`} months={trend.map((r) => r.monthLabel.slice(0, 3))} selected={selectedIdx}
          series={[
            { key: "built", label: "Built", color: SERIES_BUILDS, values: trend.map((r) => r.pctSqme) },
            { key: "sold", label: "Sold", color: SERIES_SALES, values: trend.map((r) => r.pctSales) },
            { key: "collected", label: "Collected", color: SERIES_COLL, values: trend.map((r) => r.pctColl) },
          ]} />
      )}

      <BarExports filename={`overview-${country.toLowerCase()}_${period.label.replace(/\s+/g, "-")}_${stamp()}`}
        headers={["Ranking", levelTitle(level), "Branch", "SQM-E built", "SQM-E target", "Built %", "Builds", "Build target", "Sold", "Sales target", "Collected", `Revenue (${currency})`, `Revenue target (${currency})`, "Masons", "Masons needed", "To hire", "Passed QA %", "Movement", "Paint SQM-E built", "Paint contracts built"]}
        rows={exportRows} />

      <section className="flex flex-col gap-3">
        <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
          {scope ? (scope.level === "district" ? `Territories in ${scope.name}` : scope.name) : `All ${unitWord(level)}`}
        </h2>
        <DataTable rows={sorted} cols={cols} keyOf={(r) => `${r.level}|${r.name}`} mark={(r) => worst.has(r.name)} copyName="the ranking"
          note={`Ranking is on SQM-E built against target, 1 is best. Focus marks the five furthest behind. Movement is the change in ranking against the previous ${period.mode === "quarter" ? "quarter" : "month, same weeks"}. Tap a name to look inside it. Tap a number to open that page for it.`} />
      </section>

      {rows.length > 1 && (
        <RankBars title={`Every ${unitWord(level, 1)} on SQM-E built`} onPick={(name) => { const r = rows.find((x) => x.name === name); if (r) pick(r); }}
          items={rows.map((r) => ({ name: r.name, pct: r.pctSqme, built: r.sqmeBuilt, target: r.sqmeTarget }))} />
      )}

      {head && (
        <Boxes
          happened={[
            `Built ${whole(head.sqmeBuilt)} of ${whole(head.sqmeTarget)} SQM-E, ${whole(head.built)} builds.`,
            `Signed ${whole(head.sold)} of ${whole(head.salesTarget)} contracts and collected ${whole(head.collected)} of ${whole(head.buildTarget)}.`,
            `Revenue ${money(head.revenue, currency)}${head.revenueTarget != null ? ` of ${money(head.revenueTarget, currency)}` : ""}. Cash received ${money(head.cashReceived, currency)}.`,
          ]}
          next={[
            notPaid ? `${whole(notPaid.n)} customers signed but have not paid, ${money(notPaid.owed, currency)} owed. They are next month's collections.` : "No customers are waiting to pay.",
            waiting ? `${whole(waiting.n)} customers paid and are waiting for a build to start${building ? `, ${whole(building.over30)} builds are over 30 days in progress` : ""}.` : "Nobody is waiting for a build to start.",
            behind.length ? `${level === "district" ? "Branches" : levelTitle(level) === "Branch" ? "Branches" : "Territories"} to focus on: ${behind.join(", ")}.` : `${toGo(head.sqmeBuilt, head.sqmeTarget, "SQM-E")} for ${scopeWord}. ${pctText(head.pctSqme)} of the build target so far.`,
          ]} />
      )}
    </>
  );
}

function rowScope(r: WsRow): { level: "territory" | "district" | "branch"; name: string } | null {
  return r.level === "territory" || r.level === "district" || r.level === "branch" ? { level: r.level, name: r.name } : null;
}
