"use client";

import { useMemo, useState, type ReactNode } from "react";
import { useSearchParams } from "next/navigation";
import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import type { CtsBranch, CtsCountry, CtsRow } from "@/lib/cts";
import { stamp, type Cell } from "@/lib/export";
import { monthName } from "@/lib/period";
import { SERIES_COLL } from "@/lib/workspace-ui";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { DataTable, Kpi, type Col } from "@/components/ws/primitives";
import TrendChart from "@/components/ws/TrendChart";

/**
 * Cost to serve for one country workspace (docs/cts-page-and-revenue.md,
 * item 1): three scorecards, the country line against its budget, and the
 * branches as a shaded table, worst first, with a branch's own line opened
 * under it on a click. Every figure is the one Looker shows: the country
 * layer from country_financials (the CEO dashboard's row), the branch layer
 * from branch_financials, both read as they are in src/lib/cts.ts. The
 * currency toggle in the filter bar picks the USD or the local column of the
 * same rows, so nothing is recomputed here. USD by default, because that is
 * what Looker shows.
 */
type Currency = "USD" | "local";
const ACTUAL = SERIES_COLL;
const BUDGET = "var(--text-secondary)";

/** 20K, 1.2M, 295: the axis ticks. */
function compact(v: number): string {
  const a = Math.abs(v);
  if (a >= 1e6) return `${Number((v / 1e6).toFixed(1))}M`;
  if (a >= 1e3) return `${Number((v / 1e3).toFixed(1))}K`;
  return Math.round(v).toLocaleString("en-US");
}
/** Local currency per SQM-E: 7,284 and 10,207 whole, 115K and 1.2M above that, so one chart keeps one style. */
function local(v: number): string {
  const a = Math.abs(v);
  if (a >= 1e6) return `${Number((v / 1e6).toFixed(1))}M`;
  if (a >= 1e5) return `${Math.round(v / 1e3)}K`;
  return Math.round(v).toLocaleString("en-US");
}
/** Dollars per SQM-E are small: 5.0, not 4.98; 94 above a hundred. */
const usd = (v: number): string => (Math.abs(v) >= 100 ? local(v) : v.toFixed(1));
const short = (m: string) => monthName(m).slice(0, 3);

export default function CtsPage(props: {
  country: CapacityCountry; slug: string; calendar: CapacityWeek[]; years: number[]; userEmail: string | null; freshness: string;
  data: CtsCountry; months: string[]; year: number;
}) {
  const { country, slug, calendar, years, userEmail, freshness, data } = props;
  const params = useSearchParams();
  const [cur, setCurState] = useState<Currency>(params.get("cur") === data.currency ? "local" : "USD");
  function setCur(c: Currency) {
    setCurState(c);
    const q = new URLSearchParams(window.location.search);
    if (c === "local") q.set("cur", data.currency); else q.delete("cur");
    const qs = q.toString();
    window.history.replaceState(null, "", `${window.location.pathname}${qs ? `?${qs}` : ""}`);
  }
  const seg = (on: boolean) => ({ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" });
  const toggle = (
    <div className="inline-flex rounded-md border p-0.5" style={{ borderColor: "var(--border)", background: "var(--surface)" }} role="group" aria-label="Currency">
      {(["USD", "local"] as Currency[]).map((c) => (
        <button key={c} type="button" onClick={() => setCur(c)} aria-pressed={cur === c} className="min-h-11 rounded px-2.5 py-1 text-sm font-medium sm:min-h-0" style={seg(cur === c)}>
          {c === "USD" ? "USD" : data.currency}
        </button>
      ))}
    </div>
  );
  const units = data.branches.map((b) => b.branch);
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} years={years} userEmail={userEmail} freshness={freshness}
      periodControls={false} units={units} unitLevel={country === "Rwanda" ? "district" : "branch"} barControls={toggle}>
      {(s) => <Body s={s} data={data} months={props.months} year={props.year} cur={cur} />}
    </WorkspaceShell>
  );
}

function Body({ s, data, months, year, cur }: { s: WsState; data: CtsCountry; months: string[]; year: number; cur: Currency }) {
  const { country, scope } = s;
  const unit = cur === "USD" ? "USD" : data.currency;
  const actualOf = (r: CtsRow | null | undefined) => (r == null ? null : cur === "USD" ? r.actualUsd : r.actualLocal);
  const budgetOf = (r: CtsRow | null | undefined) => (r == null ? null : cur === "USD" ? r.budgetUsd : r.budgetLocal);
  const fmt = cur === "USD" ? usd : local;
  const withUnit = (v: number | null) => (v == null ? "-" : `${unit} ${fmt(v)}`);
  const [showHow, setShowHow] = useState(false);
  const [picked, setPicked] = useState<string | null>(null);

  // The latest closed month is "this month" on this page: the books, not the calendar.
  const closed = data.rows.filter((r) => r.closed && r.actualUsd != null);
  const latest = closed[closed.length - 1] ?? null;
  const ytd = data.ytd;
  const open = data.rows.filter((r) => !r.closed).map((r) => short(r.month));
  const noRate = data.rows.filter((r) => r.closed && r.rate == null).map((r) => short(r.month));
  const diff = latest && budgetOf(latest) != null && actualOf(latest) != null ? (actualOf(latest) as number) - (budgetOf(latest) as number) : null;

  const labels = months.map(short);
  const actual = data.rows.map(actualOf);
  const budget = data.rows.map(budgetOf);
  const noteLines: ReactNode[] = [];
  if (open.length) noteLines.push(`Books not yet closed: ${open.join(", ")}.`);
  if (noRate.length) noteLines.push(`No exchange rate loaded for ${noRate.join(", ")}, so no point is drawn.`);
  noteLines.push("Lower is better. A budget line above the actual line means we are spending less than planned.");

  // The branches, worst first on the year to date; the dropdown narrows the list to one and opens its line.
  const branches = useMemo(() => {
    const list = scope ? data.branches.filter((b) => b.branch === scope.name) : data.branches;
    return list.slice().sort((a, b) => (actualOf(b.ytd) ?? -1) - (actualOf(a.ytd) ?? -1) || a.branch.localeCompare(b.branch));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.branches, scope, cur]);
  const selectedName = scope ? scope.name : picked;
  const selected = selectedName ? data.branches.find((b) => b.branch === selectedName) ?? null : null;
  const maxCell = Math.max(0, ...data.branches.flatMap((b) => b.rows.map((r) => actualOf(r) ?? 0)));
  const shade = (v: number | null) => (v == null || maxCell <= 0 ? undefined : `color-mix(in srgb, var(--critical) ${Math.round(6 + 44 * Math.min(1, v / maxCell))}%, transparent)`);
  const closedMonths = months.filter((m) => data.rows.find((r) => r.month === m)?.closed);

  const branchCols: Col<CtsBranch>[] = [
    { key: "branch", header: "Branch", mobile: "title", sort: (b) => b.branch, copy: (b) => b.branch, cell: (b) => <span className="font-semibold">{b.branch}</span> },
    ...closedMonths.map((m, i): Col<CtsBranch> => ({
      key: m, header: short(m), right: true, mobileLabel: monthName(m),
      sort: (b) => actualOf(b.rows[months.indexOf(m)]) ?? null,
      copy: (b) => round2(actualOf(b.rows[months.indexOf(m)])),
      copyHeader: `${monthName(m)} (${unit} per SQM-E)`,
      cell: (b) => { const v = actualOf(b.rows[months.indexOf(m)]); return <span className="block rounded px-1.5 py-0.5 tabular-nums" style={{ background: shade(v) }}>{v == null ? "-" : fmt(v)}</span>; },
      ...(i === 0 ? {} : {}),
    })),
    { key: "target", header: "Target", right: true, sort: (b) => budgetOf(b.ytd) ?? null, copy: (b) => round2(budgetOf(b.ytd)), copyHeader: `Target, year to date (${unit} per SQM-E)`,
      cell: (b) => <span className="tabular-nums" style={{ color: "var(--text-secondary)" }}>{budgetOf(b.ytd) == null ? "-" : fmt(budgetOf(b.ytd) as number)}</span> },
    { key: "ytd", header: "Year to date", right: true, sort: (b) => actualOf(b.ytd) ?? null, copy: (b) => round2(actualOf(b.ytd)), copyHeader: `Year to date (${unit} per SQM-E)`,
      cell: (b) => { const v = actualOf(b.ytd), t = budgetOf(b.ytd); return <span className="font-semibold tabular-nums" style={{ color: v != null && t != null ? (v > t ? "var(--critical)" : "var(--good)") : undefined }}>{v == null ? "-" : fmt(v)}</span>; } },
  ];

  const exportRows: Cell[][] = [];
  const push = (layer: string, name: string, r: CtsRow) => exportRows.push([layer, name, r.month === "YTD" ? "Year to date" : r.month, round2(actualOf(r)), round2(budgetOf(r)), r.closed ? "yes" : "no", r.rate ?? ""]);
  for (const r of data.rows) push("Country", country, r);
  if (ytd) push("Country", country, ytd);
  for (const b of data.branches) { for (const r of b.rows) push("Branch", b.branch, r); if (b.ytd) push("Branch", b.branch, b.ytd); }

  const yLabel = `Cost per SQM-E, ${unit}`;
  const lastMonth = months[months.length - 1];

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>Cost to serve, {country}</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>
          Revenue less cost of goods and expenses, per SQM-E built, from the closed books, January to {monthName(lastMonth)} {year}.{" "}
          <button type="button" onClick={() => setShowHow((v) => !v)} aria-expanded={showHow} className="underline underline-offset-4" style={{ color: "var(--accent-ink)" }}>
            How these are calculated
          </button>
        </p>
        {showHow && <HowCalculated currency={data.currency} />}
      </div>
      <BarExports filename={`cost-to-serve-${country.toLowerCase()}-${unit}_${stamp()}`}
        headers={["Layer", "Name", "Month", `Cost to serve (${unit} per SQM-E)`, `Budget (${unit} per SQM-E)`, "Books closed", `${data.currency} per USD`]}
        rows={exportRows} />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Kpi label="Cost to serve, this month" big={withUnit(actualOf(latest))} tone={ACTUAL}
          lines={[<span key="m">per SQM-E, {latest ? monthName(latest.month) : "no month closed yet"}</span>]}
          sub="Country level: revenue less cost of goods, district and country expenses, over SQM-E built. The figure Looker and the CEO dashboard show." />
        <Kpi label="Year to date" big={withUnit(actualOf(ytd))} tone={ACTUAL}
          lines={[<span key="m">{closed.length ? `January to ${monthName(closed[closed.length - 1].month)}` : "no month closed yet"}</span>]}
          sub="The closed months' spend over their SQM-E, each month at its own rate. Not an average of the months." />
        <Kpi label="Against budget" big={diff == null ? "-" : `${fmt(Math.abs(diff))} ${diff > 0 ? "above" : "below"}`}
          tone={diff == null ? "var(--text-muted)" : diff > 0 ? "var(--critical)" : "var(--good)"}
          lines={[<span key="b">budget {withUnit(budgetOf(latest))}{latest ? `, ${monthName(latest.month)}` : ""}</span>]}
          sub="Lower is better. Above budget means each SQM-E cost more to serve than planned." />
      </div>

      <TrendChart title={`Cost to serve, country level, January to ${monthName(lastMonth)}`} months={labels} legend floor="zero" target={null}
        format={fmt} axisFormat={compact} yLabel={yLabel}
        series={[
          { key: "actual", label: "Actual", color: ACTUAL, values: actual },
          { key: "budget", label: "Budget", color: BUDGET, values: budget, dashed: true },
        ]}
        note={<span>{noteLines.map((l, i) => <span key={i} className="block">{l}</span>)}</span>} />

      <section className="flex flex-col gap-3">
        <div>
          <h2 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>Branches, worst first</h2>
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>
            Branch cost to serve is a different, lower figure: district costs only, before country overheads, so it does not add up to the country line.
            Shaded by cost; Target is the branch&apos;s year-to-date target. Click a branch for its own line.
          </p>
        </div>
        <DataTable rows={branches} cols={branchCols} keyOf={(b) => b.branch} copyName="branches"
          onRow={(b) => setPicked((p) => (p === b.branch ? null : b.branch))} selectedKey={selected?.branch ?? null}
          empty="No branch figures for this year." />
        {selected && (
          <TrendChart key={`${selected.branch}|${cur}`} title={`${selected.branch}, branch cost to serve, January to ${monthName(lastMonth)}`} months={labels} legend floor="zero" target={null}
            format={fmt} axisFormat={compact} yLabel={yLabel}
            series={[
              { key: "actual", label: "Actual", color: ACTUAL, values: selected.rows.map(actualOf) },
              { key: "target", label: "Target", color: BUDGET, values: selected.rows.map(budgetOf), dashed: true },
            ]}
            note={`Branch level: revenue less cost of goods and district expenses, over the branch's SQM-E built, against its own target from branch_financials. ${open.length ? `Books not yet closed: ${open.join(", ")}.` : ""}`} />
        )}
      </section>
    </>
  );
}

const round2 = (v: number | null | undefined): Cell => (v == null ? "" : Math.round(v * 100) / 100);

function HowCalculated({ currency }: { currency: string }) {
  const h = "text-sm font-semibold";
  const p = "mt-1 text-sm";
  const hs = { color: "var(--text-primary)" } as const;
  const ps = { color: "var(--text-secondary)" } as const;
  return (
    <section className="mt-3 grid gap-4 rounded-xl border p-4 md:grid-cols-3" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div>
        <h3 className={h} style={hs}>Country level</h3>
        <p className={p} style={ps}>
          Revenue less cost of goods sold, district expenses and country overheads, divided by the SQM-E built in the month, from the closed QuickBooks books
          (qb_reporting.country_financials, the view Looker reads). The budget is the same ratio over the country budget loaded from the VG workbook, revenue,
          costs and SQM-E each summed for the month, never averaged. Global overheads are in neither line. The same figure as the CEO dashboard&apos;s cost to serve row.
        </p>
      </div>
      <div>
        <h3 className={h} style={hs}>Branch level</h3>
        <p className={p} style={ps}>
          Revenue less cost of goods sold and district expenses, over the branch&apos;s SQM-E built, against the branch target from the same view
          (qb_reporting.branch_financials). Country overheads are not allocated to branches, so a branch reads lower than the country and the branches do not sum to it.
          Year to date, for the country and for each branch, is the closed months&apos; spend over their SQM-E; the Target column is the year-to-date target over the same months.
        </p>
      </div>
      <div>
        <h3 className={h} style={hs}>Currency, sign and months</h3>
        <p className={p} style={ps}>
          USD figures divide the {currency} figure by the month&apos;s budget rate from the VG workbook (qb_reporting.fx_rates_monthly), not a daily rate:
          dividing actual and budget by the same rate keeps currency movement out of an operational cost chart. The rates cover 2026 only; a month with no rate shows no point.
          Cost to serve is negative in the books; it is shown as a cost, so lower is better. Only months whose books are closed are shown, and the open months are named under the chart.
          QuickBooks figures move only when a month&apos;s books are closed; the page refreshes every 15 minutes.
        </p>
      </div>
    </section>
  );
}
