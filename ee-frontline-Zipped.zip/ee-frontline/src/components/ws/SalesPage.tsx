"use client";

import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import { monthName } from "@/lib/period";
import type { JourneyStock, WsCsoMonth, WsCsoPending, WsData, WsRow } from "@/lib/workspace-types";
import {
  bottomN, collectedToday, count, currencyOf, freshnessLine, headRow, levelTitle, money, pctText, tableLevel, tableRows, trendRows, unitsOf, unitWord, whole,
  SERIES_COLL, SERIES_SALES,
} from "@/lib/workspace-ui";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { stamp, type Cell } from "@/lib/export";
import { BUCKETS } from "@/lib/format";
const BUCKET_KEYS = BUCKETS.map((b) => b.key);
import { Boxes, DataTable, Fact, Kpi, Paint, paintNote, PctCell, Remaining, Stack, type Col } from "@/components/ws/primitives";
import TrendChart from "@/components/ws/TrendChart";
import CsoList from "@/components/ws/CsoList";
import Dashboard from "@/components/Dashboard";
import type { WaitingRow } from "@/lib/territory";
import type { MatrixRow, Summary } from "@/lib/data";
import { useSearchParams } from "next/navigation";

/**
 * Page 2, Sales and collections: three sub-pages as tabs. Overview (the
 * mockup with SQM-E everywhere), Individual CSOs (the existing individual CSO
 * page, built inside this workspace) and Customer journey (the Classic
 * toolkit's Journey board itself, with the country fixed and the territory
 * taken from the filter bar). The period and the scope carry across all three.
 */
export default function SalesPage(props: {
  country: CapacityCountry; slug: string; calendar: CapacityWeek[]; data: WsData; journey: JourneyStock;
  csos: { months: WsCsoMonth[]; pending: WsCsoPending[] }; userEmail: string | null;
  /** The Journey board's data, loaded only for the journey tab. */
  board: { matrix: MatrixRow[]; summary: Summary; waiting: WaitingRow[] } | null;
}) {
  const { country, slug, calendar, data, journey, csos, userEmail, board } = props;
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} userEmail={userEmail} freshness={freshnessLine(data.syncedMs, data.builtAt)} units={unitsOf(data)}>
      {(s) => <Body s={s} data={data} journey={journey} csos={csos} board={board} />}
    </WorkspaceShell>
  );
}

/**
 * The three sub-pages live in the sidebar (Overview, Individual CSOs,
 * Customer journey) and reach here as `tab`; the routes did not change.
 */
function Body({ s, data, journey, csos, board }: { s: WsState; data: WsData; journey: JourneyStock; csos: { months: WsCsoMonth[]; pending: WsCsoPending[] }; board: { matrix: MatrixRow[]; summary: Summary; waiting: WaitingRow[] } | null }) {
  const tab = s.tab === "csos" || s.tab === "journey" ? s.tab : "overview";
  // A link from the capacity backlog names one of our buckets; the board opens the matching column.
  const wanted = useSearchParams().get("bucket");
  const boardBucket = wanted === "sold_not_paid" ? "3" : wanted === "paid_not_started" ? "4" : wanted === "building" ? "6" : wanted === "finished" ? "8" : null;
  const currency = currencyOf(s.country);
  const title = tab === "csos" ? "Individual CSOs" : tab === "journey" ? "Customer journey" : "Sales and collections";
  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>{title}, {s.scopeLabel}</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>{s.period.label}</p>
      </div>
      {tab === "overview" && <Overview s={s} data={data} journey={journey} currency={currency} />}
      {tab === "csos" && <CsoList key={`${s.scope?.level ?? ""}|${s.scope?.name ?? ""}`} s={s} months={csos.months} pending={csos.pending} currency={currency} />}
      {tab === "journey" && board && (
        <Dashboard matrix={board.matrix} summary={board.summary} waiting={board.waiting} generatedAt="" embedded fixedCountry={s.country}
          location={s.scope?.level === s.unit ? s.scope.name : ""} onLocation={(name) => s.setScope(name ? { level: s.unit, name } : null)}
          initialBucket={boardBucket ? BUCKET_KEYS.find((k) => k.startsWith(boardBucket)) ?? null : null} />
      )}
    </>
  );
}

function Overview({ s, data, journey, currency }: { s: WsState; data: WsData; journey: JourneyStock; currency: string }) {
  const { period, scope, country } = s;
  const head = headRow(data.rows, period, country, scope);
  const rows = tableRows(data.rows, period, country, scope, s.dim);
  const level = tableLevel(country, scope, s.dim);
  const headLevel = scope?.level ?? "country";
  const headName = scope?.name ?? country;
  const today = collectedToday(data.rows, headLevel, headName);
  const owedOf = (lvl: string, name: string) => journey.stock.find((r) => r.level === lvl && r.name === name && r.bucket === "sold_not_paid");
  const notPaid = owedOf(headLevel, headName);
  const waiting = journey.stock.find((r) => r.level === headLevel && r.name === headName && r.bucket === "paid_not_started");
  const trend = trendRows(data.rows, period, headLevel, headName);
  const selectedIdx = trend.findIndex((r) => r.month === period.fetchMonth);

  const score = (r: WsRow) => (r.pctSales == null && r.pctColl == null ? null : ((r.pctSales ?? 0) + (r.pctColl ?? 0)) / 2);
  const sorted = [...rows].sort((a, b) => (score(a) ?? 99) - (score(b) ?? 99) || a.name.localeCompare(b.name));
  const worst = bottomN(rows, score);

  const pick = (r: WsRow) => s.setScope(r.level === "country" ? null : { level: r.level as "territory" | "district" | "branch", name: r.name }, r.level === "territory" ? r.parent : null);
  const pct100 = (v: number | null) => (v == null ? "" : Math.round(v * 100));
  const cols: Col<WsRow>[] = [
    { key: "name", header: levelTitle(level), mobile: "title", sort: (r) => r.name, copy: (r) => r.name, cell: (r) => (
      <span className="flex flex-col">
        <button type="button" onClick={() => pick(r)}
          className="text-left font-semibold underline decoration-[var(--border)] underline-offset-4" style={{ color: "var(--text-primary)" }}>{r.name}</button>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.level === "territory" ? r.parent : r.level === "district" ? count(r.nTerritories, "territory", "territories") : r.country}</span>
      </span>
    ) },
    { key: "sold", header: "Sold", right: true, sort: (r) => r.pctSales, copy: (r) => pct100(r.pctSales), copyHeader: "Sold % of target", cell: (r) => <PctCell pct={r.pctSales} under={`${whole(r.sold)} / ${whole(r.salesTarget)}`} /> },
    { key: "sqmeSold", header: "SQM-E sold", right: true, sort: (r) => r.pctSqmeSales, copy: (r) => pct100(r.pctSqmeSales), copyHeader: "SQM-E sold % of target", cell: (r) => <PctCell pct={r.pctSqmeSales} under={`${whole(r.sqmeSold)} / ${whole(r.sqmeSalesTarget)}`} /> },
    { key: "collected", header: "Collected", right: true, sort: (r) => r.pctColl, copy: (r) => pct100(r.pctColl), copyHeader: "Collected % of target", cell: (r) => <PctCell pct={r.pctColl} under={`${whole(r.collected)} / ${whole(r.buildTarget)}`} /> },
    { key: "sqmeColl", header: "SQM-E collected", right: true, sort: (r) => r.pctSqmeColl, copy: (r) => pct100(r.pctSqmeColl), copyHeader: "SQM-E collected % of target", cell: (r) => <PctCell pct={r.pctSqmeColl} under={`${whole(r.sqmeCollected)} / ${whole(r.sqmeTarget)}`} /> },
    { key: "s2p", header: "Signed to paid", right: true, sort: (r) => r.pctSoldThenPaid, copy: (r) => pct100(r.pctSoldThenPaid), copyHeader: "Signed to paid %", cell: (r) => <Stack top={pctText(r.pctSoldThenPaid)} under={`${whole(r.soldThenPaid)} of ${whole(r.sold)} paid`} /> },
    { key: "revenue", header: "Revenue", right: true, sort: (r) => r.revenue, copy: (r) => Math.round(r.revenue), copyHeader: `Revenue (${currency})`, cell: (r) => <Stack top={money(r.revenue, currency)} under={r.revenueTarget != null ? `of ${money(r.revenueTarget, currency)}` : undefined} /> },
    { key: "cash", header: "Cash received", right: true, sort: (r) => r.cashReceived, copy: (r) => Math.round(r.cashReceived), copyHeader: `Cash received (${currency})`, cell: (r) => <Stack top={money(r.cashReceived, currency)} /> },
    { key: "owed", header: "Still to collect", right: true, sort: (r) => owedOf(r.level, r.name)?.owed ?? 0, copy: (r) => Math.round(owedOf(r.level, r.name)?.owed ?? 0), copyHeader: `Still to collect (${currency})`, cell: (r) => { const o = owedOf(r.level, r.name); return <Stack top={money(o?.owed ?? 0, currency)} under={o ? `${whole(o.n)} customers` : undefined} />; } },
    { key: "csos", header: "CSOs", right: true, sort: (r) => r.csosActive, copy: (r) => r.csosActive, copyHeader: "CSOs active", cell: (r) => <Stack top={`${whole(r.csosActive)} of ${whole(r.minCsos)}`} under={r.csosShort != null && r.csosShort > 0 ? `${whole(r.csosShort)} short` : undefined} color={r.csosShort != null && r.csosShort > 0 ? "var(--critical)" : undefined} /> },
    { key: "paint", header: "Paint", right: true, sort: (r) => r.paintSqmeSold, copy: (r) => Math.round(r.paintSqmeSold), copyHeader: "Paint SQM-E sold", cell: (r) => <Paint sqme={r.paintSqmeSold} contracts={r.paintSold} /> },
  ];
  const exportRows: Cell[][] = sorted.map((r) => [
    r.name, r.level === "territory" ? r.parent ?? "" : "", r.sold, Math.round(r.salesTarget ?? 0), pct100(r.pctSales), Math.round(r.sqmeSold), Math.round(r.sqmeSalesTarget ?? 0),
    r.collected, Math.round(r.buildTarget ?? 0), pct100(r.pctColl), Math.round(r.sqmeCollected), Math.round(r.sqmeTarget ?? 0), pct100(r.pctSoldThenPaid),
    Math.round(r.revenue), r.revenueTarget == null ? "" : Math.round(r.revenueTarget), Math.round(r.cashReceived), Math.round(owedOf(r.level, r.name)?.owed ?? 0),
    r.csosActive, r.minCsos == null ? "" : Math.round(r.minCsos), r.csosShort == null ? "" : Math.round(r.csosShort),
    Math.round(r.paintSqmeSold), r.paintSold, Math.round(r.paintSqmeCollected), r.paintCollected,
  ]);

  return (
    <>
      {head ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Kpi label="Sold" pct={head.pctSales} tone={SERIES_SALES}
            lines={[<Fact key="c" n={head.sold} of={head.salesTarget} word="contracts" />, <Fact key="s" n={head.sqmeSold} of={head.sqmeSalesTarget} word="SQM-E" />]}
            remaining={head.salesTarget == null ? "no target set" : <Remaining parts={[{ n: head.salesTarget - head.sold, word: "contracts" }, { n: (head.sqmeSalesTarget ?? 0) - head.sqmeSold, word: "SQM-E" }]} />}
            note={paintNote(head.paintSqmeSold)}
            sub="Sales targets are the build targets times 1.3" />
          <Kpi label="Collected" pct={head.pctColl} tone={SERIES_COLL}
            lines={[<Fact key="c" n={head.collected} of={head.buildTarget} word="contracts" />, <Fact key="s" n={head.sqmeCollected} of={head.sqmeTarget} word="SQM-E" />]}
            remaining={head.buildTarget == null ? "no target set" : <Remaining parts={[{ n: head.buildTarget - head.collected, word: "contracts" }, { n: (head.sqmeTarget ?? 0) - head.sqmeCollected, word: "SQM-E" }]} />}
            note={paintNote(head.paintSqmeCollected)}
            sub={`${whole(today)} collected today`} />
          {head.revenueTarget != null ? (
            <Kpi label="Revenue" pct={head.pctRevenue} tone="var(--accent-strong)"
              lines={[<Fact key="r" n={money(head.revenue, currency)} of={money(head.revenueTarget, currency)} />]}
              remaining={head.revenueTarget > head.revenue ? <><b style={{ color: "var(--critical)" }}>{money(head.revenueTarget - head.revenue, currency)}</b> to go</> : "Target reached"}
              note="Contract value of builds completed, live from Salesforce"
              sub={`${money(head.cashReceived, currency)} of cash received in the same period.`} />
          ) : (
            <Kpi label="Revenue" big={money(head.revenue, currency)} tone="var(--accent-strong)"
              lines={[<Fact key="r" n={money(head.cashReceived, currency)} word="cash received" />]}
              note="Contract value of builds completed, live from Salesforce"
              sub="No revenue target set for this country" />
          )}
          <Kpi label="Still to collect" big={money(notPaid?.owed ?? 0, currency)} tone="var(--critical)"
            lines={[<Fact key="n" n={notPaid?.n ?? 0} word="customers" />, <Fact key="s" n={notPaid?.sqme ?? 0} word="SQM-E waiting for payment" />]}
            sub={notPaid ? `${whole(notPaid.zeroPaid)} have paid nothing yet` : undefined} />
        </div>
      ) : (
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>No figures for {s.scopeLabel} in {period.label}.</p>
      )}

      {trend.length > 0 && (
        <TrendChart title={`January to ${monthName(period.fetchMonth)}, against target`} months={trend.map((r) => r.monthLabel.slice(0, 3))} selected={selectedIdx}
          series={[
            { key: "sold", label: "Sold", color: SERIES_SALES, values: trend.map((r) => r.pctSales) },
            { key: "collected", label: "Collected", color: SERIES_COLL, values: trend.map((r) => r.pctColl) },
          ]} />
      )}

      <BarExports filename={`sales-${country.toLowerCase()}_${period.label.replace(/\s+/g, "-")}_${stamp()}`}
        headers={[levelTitle(level), "Branch", "Sold", "Sales target", "Sold %", "SQM-E sold", "SQM-E sales target", "Collected", "Collections target", "Collected %", "SQM-E collected", "SQM-E target", "Signed to paid %", `Revenue (${currency})`, `Revenue target (${currency})`, `Cash received (${currency})`, `Still to collect (${currency})`, "CSOs active", "CSOs required", "CSOs short", "Paint SQM-E sold", "Paint contracts sold", "Paint SQM-E collected", "Paint contracts collected"]}
        rows={exportRows} />

      <section className="flex flex-col gap-3">
        <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
          {scope ? (scope.level === "district" ? `Territories in ${scope.name}` : scope.name) : `By ${unitWord(level, 1)}`}
        </h2>
        <DataTable rows={sorted} cols={cols} keyOf={(r) => `${r.level}|${r.name}`} mark={(r) => worst.has(r.name)} copyName="the table"
          note="Focus marks the five furthest behind on the average of sales and collections against target. Still to collect is what customers who signed in 2026 still owe, as it stands now. Tap a name to see its CSOs." />
      </section>

      {head && (
        <Boxes
          happened={[
            `Signed ${whole(head.sold)} of ${whole(head.salesTarget)} contracts, ${pctText(head.pctSales)}. ${whole(head.sqmeSold)} SQM-E.`,
            `Collected ${whole(head.collected)} of ${whole(head.buildTarget)}, ${pctText(head.pctColl)}. ${whole(today)} today.`,
            `Revenue ${money(head.revenue, currency)}. Cash received ${money(head.cashReceived, currency)}.`,
          ]}
          next={[
            notPaid ? `${whole(notPaid.n)} customers owe ${money(notPaid.owed, currency)}. Open "Sold, not paid" on the Customer journey tab for the call list.` : "No customers are waiting to pay.",
            waiting ? `${whole(waiting.n)} paid customers are waiting for a build. Pass them to the masons page.` : "Nobody is waiting for a build to start.",
            head.csosShort != null && head.csosShort > 0 ? `Short ${whole(head.csosShort)} CSOs against the requirement of ${whole(head.minCsos)}.` : "CSOs in place. Check who is below target on the Individual CSOs tab.",
          ]} />
      )}
    </>
  );
}
