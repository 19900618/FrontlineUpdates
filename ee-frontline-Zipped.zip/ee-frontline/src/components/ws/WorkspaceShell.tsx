"use client";

import { createContext, useCallback, useContext, useMemo, useState, useTransition, type ReactNode } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import { parsePeriod, parseScope, periodInfo, periodParams, periodYears, scopeParam, type Period, type PeriodInfo, type Scope } from "@/lib/period";
import { levelTitle, unitLevelOf, unitWord } from "@/lib/workspace-ui";
import type { UnitLevel } from "@/lib/workspace-types";
import { AREAS, type Area } from "@/lib/workspaces";
import Logo from "@/components/Logo";
import Spinner from "@/components/Spinner";
import ExportButtons from "@/components/ExportButtons";
import FilterBar from "@/components/ws/FilterBar";
import type { Cell } from "@/lib/export";

/**
 * The frame of every page in a country workspace: the menu on the left (the
 * areas of src/lib/workspaces.ts, a group expanding while one of its
 * sub-pages is on screen), the filter bar across the top, the page, and the
 * freshness line. The period, the scope and Rwanda's territory or branch
 * toggle are URL state (`p`, `w`, `s`, `sp`, `d`, `tab`) so they persist
 * across every page and drill-down; every menu link carries them.
 *
 * A change that needs no new data (weeks, scope, toggle on the pages that
 * hold every week set) is written to the URL with the history API, which
 * Next syncs into useSearchParams without a server round trip. A change of
 * month or quarter, or any change at all on a page whose queries take the
 * window (`navigate="all"`), navigates inside a transition: Next only
 * updates the URL and the page when the server answers, which can take
 * seconds, so the bar shows the choice at once with a spinner and the page
 * dims until the figures arrive.
 */
export type WsState = {
  country: CapacityCountry;
  slug: string;
  period: PeriodInfo;
  scope: Scope;
  /** The scope's parent, when the page that set it knew (a territory's district). */
  scopeParent: string | null;
  /** Rwanda's table level: territory or district (shown as Branches). Uganda and Kenya: branch. */
  dim: UnitLevel;
  /** The sub-page, from `tab`, or "". */
  tab: string;
  /** Build a link to a page keeping the period, scope and toggle, with overrides. */
  href: (path: string, overrides?: { scope?: Scope; scopeParent?: string | null; dim?: UnitLevel; tab?: string; extra?: Record<string, string> }) => string;
  setPeriod: (p: Period) => void;
  setScope: (s: Scope, parent?: string | null) => void;
  setDim: (d: UnitLevel) => void;
  scopeLabel: string;
  unit: UnitLevel;
  /** True while the server computes a change. */
  pending: boolean;
};

const ExportSlot = createContext<HTMLElement | null>(null);

/** A page's export buttons, portalled to the right-hand end of the filter bar. */
export function BarExports(props: { filename: string; headers: string[]; rows: Cell[][] }) {
  const el = useContext(ExportSlot);
  if (!el) return null;
  return createPortal(<ExportButtons {...props} />, el);
}

const TAB_KEYS = new Set(AREAS.flatMap((a) => a.children ?? []).map((c) => c.tab).filter((t): t is string => !!t));

export default function WorkspaceShell({ country, slug, calendar, userEmail, freshness, years, navigate = "month", weekMode = "multi", defaultDim, units, unitLevel, periodControls = true, barControls, children }: {
  country: CapacityCountry;
  slug: string;
  calendar: CapacityWeek[];
  userEmail: string | null;
  freshness: string;
  /** The years the year filter offers; defaults to the calendar's. */
  years?: number[];
  /** Which changes need the server: a new month or quarter (the default), or every change. */
  navigate?: "month" | "all";
  weekMode?: "multi" | "single";
  /** Rwanda's level when the URL says nothing: territories unless a page asks for branches. */
  defaultDim?: UnitLevel;
  /** The territories (Rwanda) or branches (Uganda, Kenya) the filter bar's dropdown offers. */
  units?: string[];
  /** The level `units` are at, when it is not the country's own unit (Rwanda's branches are its districts). */
  unitLevel?: UnitLevel;
  /** False hides the period controls, for a page the period does not cut. */
  periodControls?: boolean;
  /** A page's own control in the filter bar, such as a currency toggle. */
  barControls?: ReactNode;
  children: (state: WsState) => ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);
  const [clicked, setClicked] = useState<string | null>(null);
  const [exportsEl, setExportsEl] = useState<HTMLElement | null>(null);
  // A change the server is still computing: shown in the bar at once, with a spinner.
  const [isPending, startTransition] = useTransition();
  const [pendingPeriod, setPendingPeriod] = useState<Period | null>(null);

  const period = useMemo(() => parsePeriod(params, calendar), [params, calendar]);
  const info = useMemo(() => periodInfo(period, calendar), [period, calendar]);
  const scope = useMemo(() => parseScope(params), [params]);
  const scopeParent = params.get("sp") || null;
  const unit = unitLevelOf(country);
  const dropdownLevel = unitLevel ?? unit;
  const dimParam = params.get("d");
  const dim: UnitLevel = country !== "Rwanda" ? unit
    : dimParam === "district" ? "district" : dimParam === "territory" ? "territory" : defaultDim ?? unit;
  const tabParam = params.get("tab") ?? "";
  const tab = TAB_KEYS.has(tabParam) ? tabParam : "";
  const yearList = years ?? periodYears(calendar);

  const build = useCallback((path: string, o?: { scope?: Scope; scopeParent?: string | null; dim?: UnitLevel; tab?: string; extra?: Record<string, string> }) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(periodParams(period, calendar))) q.set(k, v);
    const s = o && "scope" in o ? o.scope ?? null : scope;
    for (const [k, v] of Object.entries(scopeParam(s))) q.set(k, v);
    const sp = o && "scope" in o ? o.scopeParent ?? null : scopeParent;
    if (s && sp && s.level === "territory") q.set("sp", sp);
    const d = o?.dim ?? dim;
    if (d === "district") q.set("d", "district");
    else if (country === "Rwanda" && defaultDim === "district") q.set("d", "territory");
    const t = o && "tab" in o ? o.tab : tab;
    if (t) q.set("tab", t);
    for (const [k, v] of Object.entries(o?.extra ?? {})) if (v) q.set(k, v);
    const qs = q.toString();
    return qs ? `${path}?${qs}` : path;
  }, [period, calendar, scope, scopeParent, dim, tab, country, defaultDim]);

  const soft = useCallback((url: string) => window.history.replaceState(null, "", url), []);
  const hard = useCallback((url: string) => startTransition(() => router.replace(url, { scroll: false })), [router]);
  const go = useCallback((url: string) => (navigate === "all" ? hard(url) : soft(url)), [navigate, hard, soft]);

  const state: WsState = {
    country, slug, period: info, scope, scopeParent, dim, unit, tab, pending: isPending,
    href: build,
    setPeriod: (p) => {
      const q = new URLSearchParams(params.toString());
      q.delete("p"); q.delete("w");
      for (const [k, v] of Object.entries(periodParams(p, calendar))) q.set(k, v);
      const next = periodInfo(p, calendar);
      const url = `${pathname}?${q.toString()}`;
      const sameData = next.fetchMonth === info.fetchMonth && next.fetchFrom === info.fetchFrom;
      if (navigate === "month" && sameData) soft(url);
      else { setPendingPeriod(p); hard(url); }
    },
    setScope: (s, parent) => go(build(pathname, { scope: s, scopeParent: parent ?? null })),
    setDim: (d) => go(build(pathname, { dim: d, scope: null })),
    scopeLabel: scope ? scope.name : country,
  };

  const pendingHref = clicked && clicked !== pathname ? clicked : null;
  const areas = AREAS.filter((a) => !a.rwandaOnly || country === "Rwanda")
    .map((a) => (a.children ? { ...a, children: a.children.filter((c) => !c.rwandaOnly || country === "Rwanda") } : a));

  const isActive = (a: Area) => pathname === `/${slug}${a.path ?? ""}` && (a.tab ?? "") === tab;
  const link = (a: Area, indent: boolean) => {
    const href = `/${slug}${a.path ?? ""}`;
    const active = isActive(a);
    return (
      <Link key={`${a.label}|${a.tab ?? ""}`} href={build(href, { tab: a.tab ?? "" })}
        onClick={() => { setOpen(false); if (href !== pathname) setClicked(href); }}
        className={`flex items-center justify-between gap-2 rounded-md py-2 text-sm ${indent ? "pl-7 pr-3" : "px-3"}`}
        style={{
          color: active ? "var(--text-primary)" : "var(--text-secondary)",
          background: active ? "color-mix(in srgb, var(--seq-500) 14%, transparent)" : "transparent",
          boxShadow: active ? "inset 3px 0 0 var(--seq-500)" : "none",
          fontWeight: active ? 600 : 400,
        }}>
        <span className="truncate">{a.label}</span>
        {pendingHref === href && !active && <span style={{ color: "var(--accent-strong)" }}><Spinner size={13} /></span>}
      </Link>
    );
  };

  const nav = (
    <nav className="flex flex-col gap-0.5 p-3">
      <Link href="/" className="mb-2 flex items-center gap-2 rounded-md px-2 py-1.5 text-sm" style={{ color: "var(--accent-ink)" }} onClick={() => setOpen(false)}>
        ← All workspaces
      </Link>
      {areas.map((a) => {
        if (a.path === undefined) {
          return (
            <span key={a.label} className="flex items-center justify-between rounded-md px-3 py-2 text-sm" style={{ color: "var(--text-muted)", opacity: 0.6 }}>
              {a.label}<span className="rounded px-1.5 py-0.5 text-[10px]" style={{ border: "1px solid var(--border)" }}>soon</span>
            </span>
          );
        }
        if (!a.children) return link(a, false);
        // A group: its own link opens the first sub-page; it expands while any sub-page is on screen.
        const within = a.children.some((c) => pathname === `/${slug}${c.path ?? ""}`);
        const first = a.children[0];
        const href = `/${slug}${first.path ?? ""}`;
        return (
          <div key={a.label} className="flex flex-col gap-0.5">
            <Link href={build(href, { tab: first.tab ?? "" })} onClick={() => { setOpen(false); if (href !== pathname) setClicked(href); }}
              className="flex items-center justify-between gap-2 rounded-md px-3 py-2 text-sm"
              style={{ color: within ? "var(--text-primary)" : "var(--text-secondary)", fontWeight: within ? 600 : 400 }}>
              <span className="truncate">{a.label}</span>
              <span className="flex items-center gap-1.5">
                {pendingHref === href && !within && <span style={{ color: "var(--accent-strong)" }}><Spinner size={13} /></span>}
                <span aria-hidden className="text-xs" style={{ color: "var(--text-muted)" }}>{within ? "▾" : "▸"}</span>
              </span>
            </Link>
            {within && a.children.map((c) => link(c, true))}
          </div>
        );
      })}
    </nav>
  );

  const crumbs = (
    <div className="flex flex-wrap items-center gap-1.5 text-sm">
      {scope ? (
        <button type="button" onClick={() => state.setScope(null)} className="underline underline-offset-4" style={{ color: "var(--accent-ink)" }}>{country}</button>
      ) : (
        <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{country}</span>
      )}
      {scope && scope.level === "territory" && scopeParent && (
        <>
          <span style={{ color: "var(--text-muted)" }}>/</span>
          <button type="button" onClick={() => state.setScope({ level: "district", name: scopeParent })} className="underline underline-offset-4" style={{ color: "var(--accent-ink)" }}>{scopeParent}</button>
        </>
      )}
      {scope && (
        <>
          <span style={{ color: "var(--text-muted)" }}>/</span>
          <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{scope.name}</span>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>{levelTitle(scope.level).toLowerCase()}</span>
          <button type="button" onClick={() => state.setScope(null)} className="ml-1 min-h-11 rounded-md border px-2 py-0.5 text-xs sm:min-h-0" style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>
            Show all {unitWord(unit)}
          </button>
        </>
      )}
    </div>
  );

  return (
    <div className="flex min-h-[100dvh] flex-col md:flex-row">
      {/* mobile top bar */}
      <div className="no-print flex items-center justify-between border-b p-3 md:hidden" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <Brand country={country} />
        <button onClick={() => setOpen((v) => !v)} className="min-h-11 rounded-md border px-3 py-1.5 text-sm" style={{ borderColor: "var(--border)", color: "var(--text-secondary)" }}>Menu</button>
      </div>
      {open && <div className="no-print border-b md:hidden" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>{nav}</div>}

      <aside className="no-print hidden w-56 shrink-0 flex-col border-r md:flex" style={{ background: "var(--surface)", borderColor: "var(--border)", height: "100dvh", position: "sticky", top: 0 }}>
        <div className="border-b p-4" style={{ borderColor: "var(--border)" }}><Brand country={country} /></div>
        <div className="flex-1 overflow-y-auto">{nav}</div>
        <div className="border-t p-3 text-xs" style={{ borderColor: "var(--border)", color: "var(--text-muted)" }}>
          <span className="flex items-center gap-1.5" style={{ color: "var(--text-secondary)" }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--good)" }} />Salesforce syncs every 15 minutes</span>
          {userEmail && <span className="mt-1 block truncate" title={userEmail}>{userEmail}</span>}
          {userEmail && (
            // Auth.js route, not a page: a plain link is right, so the page-link rule is off here.
            // eslint-disable-next-line @next/next/no-html-link-for-pages
            <a href="/api/auth/signout" className="mt-1 inline-block" style={{ color: "var(--text-muted)" }}>Sign out</a>
          )}
        </div>
      </aside>

      <main className="min-w-0 flex-1">
        {/* Sticky on desktop only: on a phone the wrapped bar would cover most of the screen. */}
        <div className="no-print z-10 border-b px-4 py-2.5 sm:px-6 md:sticky md:top-0"
          style={{ background: "color-mix(in srgb, var(--page) 94%, transparent)", backdropFilter: "blur(6px)", borderColor: "var(--border)" }}>
          <FilterBar period={isPending && pendingPeriod ? pendingPeriod : period} calendar={calendar} years={yearList} weekMode={weekMode} pending={isPending}
            onChange={state.setPeriod}
            level={country === "Rwanda" && !scope && periodControls ? { value: dim === "district" ? "district" : "territory", onChange: (v) => state.setDim(v) } : null}
            unit={units && units.length > 0 ? {
              word: unitWord(dropdownLevel, 1), options: units, value: scope?.level === dropdownLevel ? scope.name : "",
              onChange: (name) => state.setScope(name ? { level: dropdownLevel, name } : null),
            } : null}
            periodControls={periodControls} extra={barControls}
            crumbs={crumbs} exportsRef={setExportsEl} />
        </div>
        <div className="mx-auto flex max-w-[80rem] flex-col gap-5 p-4 sm:p-6" aria-busy={isPending}
          style={{ opacity: isPending ? 0.45 : 1, transition: "opacity 200ms", pointerEvents: isPending ? "none" : undefined }}>
          <ExportSlot.Provider value={exportsEl}>{children(state)}</ExportSlot.Provider>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>{freshness}</p>
        </div>
      </main>
    </div>
  );
}

function Brand({ country }: { country: string }) {
  return (
    <div className="flex flex-col items-start gap-1">
      <Logo height={26} />
      <span className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>{country} workspace</span>
    </div>
  );
}
