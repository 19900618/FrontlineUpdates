"use client";

import type { ReactNode } from "react";
import type { CapacityWeek } from "@/lib/capacity-calendar";
import { addMonthsIso, monthName, periodInYear, periodMonths, periodQuarters, quarterOf, weekChipLabel, type Period } from "@/lib/period";
import Spinner from "@/components/Spinner";

/**
 * The one filter row every page shares, in this order:
 *
 *   [ Year ] [ Month | Quarter ] [ month or quarter ] [ W1 ][ W2 ][ W3 ][ W4 ]
 *   [ Territories | Branches ] [ territory or branch ]  breadcrumb  ·····  exports
 *
 * Year lists only the years the calendar offers and the period dropdown lists
 * the months or quarters inside it. The week chips toggle in `multi` mode
 * (any combination, all four by default) and pick one week in `single` mode,
 * for the pages whose queries take one date range; a second tap on the only
 * selected week returns to the whole month. The level toggle shows for
 * Rwanda alone, and only while nothing is scoped. The territory or branch
 * dropdown is the scope: choosing one narrows the whole page and carries
 * across pages exactly as the breadcrumb does. `pending` is on while the
 * server computes a change: the bar shows the choice at once, with a
 * spinner, and takes no further clicks. A page whose figures are not cut by
 * period (Cost to serve reads the closed books, January to date) turns the
 * period controls off and puts its own control in `extra`, in the same row.
 */
export default function FilterBar({ period, calendar, years, weekMode, pending, onChange, level, unit, crumbs, exportsRef, periodControls = true, extra }: {
  period: Period;
  calendar: CapacityWeek[];
  years: number[];
  weekMode: "multi" | "single";
  pending: boolean;
  onChange: (p: Period) => void;
  /** The Rwanda level toggle, or nothing. */
  level: { value: "territory" | "district"; onChange: (v: "territory" | "district") => void } | null;
  /** The territory (Rwanda) or branch (Uganda, Kenya) dropdown: every page, default all. */
  unit: { word: string; options: string[]; value: string; onChange: (name: string) => void } | null;
  crumbs: ReactNode;
  /** Where a page's export buttons portal in, at the right-hand end. */
  exportsRef: (el: HTMLElement | null) => void;
  /** False hides the year, month or quarter and week controls. */
  periodControls?: boolean;
  /** A page's own control, such as a currency toggle, before the unit dropdown. */
  extra?: ReactNode;
}) {
  const months = periodMonths(calendar);
  const quarters = periodQuarters(calendar);
  const year = period.month.slice(0, 4);
  const monthsInYear = months.filter((m) => m.startsWith(year));
  const quartersInYear = quarters.filter((q) => q.startsWith(year));
  const weeksInMonth = calendar.filter((w) => w.month === period.month);
  const allOn = period.mode === "month" && weeksInMonth.every((w) => period.weeks.includes(w.weekNo));

  function setMode(mode: "month" | "quarter") {
    if (mode === period.mode || pending) return;
    if (mode === "quarter") {
      const q = quarters.filter((m) => m <= period.month).pop() ?? quarters[quarters.length - 1];
      onChange({ mode: "quarter", month: q, weeks: [] });
    } else {
      // The quarter's latest started month: always one the page already holds, so the switch is instant.
      const end = addMonthsIso(period.month, 3);
      const inQuarter = months.filter((x) => x >= period.month && x < end);
      const m = inQuarter[inQuarter.length - 1] ?? months[months.length - 1];
      onChange({ mode: "month", month: m, weeks: calendar.filter((w) => w.month === m).map((w) => w.weekNo) });
    }
  }
  const setMonth = (m: string) => onChange({ mode: "month", month: m, weeks: calendar.filter((w) => w.month === m).map((w) => w.weekNo) });
  function toggleWeek(n: number) {
    const cur = period.weeks;
    if (weekMode === "single") {
      const all = weeksInMonth.map((w) => w.weekNo);
      onChange({ ...period, weeks: cur.length === 1 && cur[0] === n ? all : [n] });
      return;
    }
    const next = cur.includes(n) ? (cur.length === 1 ? cur : cur.filter((w) => w !== n)) : [...cur, n].sort();
    onChange({ ...period, weeks: next });
  }

  const seg = (on: boolean) => ({ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" });
  const segBtn = "min-h-11 rounded px-2.5 py-1 text-sm font-medium sm:min-h-0";
  const select = "min-h-11 rounded-md border px-2 py-1.5 text-sm sm:min-h-0";
  const selectStyle = { background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" } as const;
  const segBox = "inline-flex rounded-md border p-0.5";
  const segBoxStyle = { borderColor: "var(--border)", background: "var(--surface)" } as const;

  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-2" role="group" aria-label="Filters" aria-busy={pending} style={{ opacity: pending ? 0.7 : 1 }}>
      {periodControls && (<>
      <select value={year} onChange={(e) => onChange(periodInYear(period, Number(e.target.value), calendar))} disabled={pending} className={select} style={selectStyle} aria-label="Year">
        {years.map((y) => <option key={y} value={y}>{y}</option>)}
      </select>

      <div className={segBox} style={segBoxStyle}>
        <button type="button" onClick={() => setMode("month")} aria-pressed={period.mode === "month"} disabled={pending} className={segBtn} style={seg(period.mode === "month")}>Month</button>
        <button type="button" onClick={() => setMode("quarter")} aria-pressed={period.mode === "quarter"} disabled={pending} className={segBtn} style={seg(period.mode === "quarter")}>Quarter</button>
      </div>

      {period.mode === "month" ? (
        <>
          <select value={period.month} onChange={(e) => setMonth(e.target.value)} disabled={pending} className={select} style={selectStyle} aria-label="Month">
            {[...monthsInYear].reverse().map((m) => <option key={m} value={m}>{monthName(m)}</option>)}
          </select>
          <div className="flex flex-wrap gap-1.5" role="group" aria-label="Weeks">
            {weeksInMonth.map((w) => {
              const on = period.weeks.includes(w.weekNo);
              return (
                <button key={w.weekNo} type="button" onClick={() => toggleWeek(w.weekNo)} aria-pressed={on} disabled={pending}
                  title={`${w.weekLabel}${w.isCurrent ? ", in progress" : ""}`}
                  className="min-h-11 rounded-md border px-2 py-1 text-sm font-medium sm:min-h-0"
                  style={{
                    background: on ? "var(--accent-strong)" : "var(--surface)",
                    borderColor: on ? "var(--accent-strong)" : "var(--border)",
                    color: on ? "#fff" : "var(--text-secondary)",
                  }}>
                  <span className="block leading-tight">W{w.weekNo}</span>
                  <span className="block text-[10px] font-normal leading-tight" style={{ opacity: 0.85 }}>{weekChipLabel(w)}{w.isCurrent ? "*" : ""}</span>
                </button>
              );
            })}
          </div>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>
            {allOn ? "whole month" : weekMode === "single" ? `W${period.weeks[0]} only` : `${period.weeks.length} of ${weeksInMonth.length} weeks`}
          </span>
        </>
      ) : (
        <select value={period.month} onChange={(e) => onChange({ mode: "quarter", month: e.target.value, weeks: [] })} disabled={pending} className={select} style={selectStyle} aria-label="Quarter">
          {[...quartersInYear].reverse().map((q) => <option key={q} value={q}>Q{quarterOf(q)}</option>)}
        </select>
      )}
      </>)}

      {extra}

      {level && (
        <div className={segBox} style={segBoxStyle} role="group" aria-label="Level">
          <button type="button" onClick={() => level.onChange("territory")} aria-pressed={level.value === "territory"} disabled={pending} className={segBtn} style={seg(level.value === "territory")}>Territories</button>
          <button type="button" onClick={() => level.onChange("district")} aria-pressed={level.value === "district"} disabled={pending} className={segBtn} style={seg(level.value === "district")}>Branches</button>
        </div>
      )}

      {unit && (
        <select value={unit.value} onChange={(e) => unit.onChange(e.target.value)} disabled={pending} className={select} style={selectStyle} aria-label={unit.word}>
          <option value="">All {unit.word === "branch" ? "branches" : "territories"}</option>
          {unit.options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      )}

      {crumbs}
      {pending && <span className="flex items-center text-xs" style={{ color: "var(--accent-strong)" }}><Spinner size={14} label="Loading" /></span>}
      <div ref={exportsRef} className="ml-auto flex flex-wrap items-center gap-2 empty:hidden" />
    </div>
  );
}
