"use client";

import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import type { JourneyStock, JourneyStockRow, WsData, WsRow } from "@/lib/workspace-types";
import {
  bottomN, count, currencyOf, dayMonth, freshnessLine, headRow, lastCompleteWeeks, levelTitle, money, monthRow, one, pctText,
  tableLevel, tableRows, unitWord, weekRow, whole, SERIES_BUILDS, SERIES_COLL, SERIES_SALES, unitsOf,
} from "@/lib/workspace-ui";
import { stamp, type Cell } from "@/lib/export";
import { monthName } from "@/lib/period";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { Boxes, DataTable, Fact, Kpi, Remaining, Stack, type Col, paintNote } from "@/components/ws/primitives";
import Sparkline, { type SparkPoint } from "@/components/ws/Sparkline";

/**
 * Capacity planning, page 1, for every country: people, not volume. The
 * Overview already covers builds, sales and collections, so nothing here
 * repeats that table. Four scorecards, the People table (masons and CSOs
 * side by side), the last five complete weeks as sparklines for masons and
 * for CSOs, the backlog with months of work, and the two boxes.
 *
 * Every figure is a view row: the selected period's row for headcounts and
 * output, the month's whole row for the requirement and the shortfall (a
 * week's headcount is never compared with a monthly establishment), single
 * week rows for the trends, and the journey stock for the backlog.
 */
export default function CapacityPage(props: {
  country: CapacityCountry; slug: string; calendar: CapacityWeek[]; years: number[]; data: WsData; nowData: WsData; nowMonth: string;
  journey: JourneyStock; userEmail: string | null;
}) {
  const { country, slug, calendar, years, data, nowData, nowMonth, journey, userEmail } = props;
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} years={years} userEmail={userEmail} freshness={freshnessLine(data.syncedMs, data.builtAt)} defaultDim="district" units={unitsOf(data)}>
      {(s) => <Body s={s} data={data} nowData={nowData} nowMonth={nowMonth} journey={journey} currency={currencyOf(country)} />}
    </WorkspaceShell>
  );
}

const scopeOf = (r: WsRow) => (r.level === "territory" || r.level === "district" || r.level === "branch" ? { level: r.level, name: r.name } : null);

function Body({ s, data, nowData, nowMonth, journey, currency }: { s: WsState; data: WsData; nowData: WsData; nowMonth: string; journey: JourneyStock; currency: string }) {
  const { period, scope, country } = s;
  const head = headRow(data.rows, period, country, scope);
  const headLevel = scope?.level ?? "country";
  const headName = scope?.name ?? country;
  /** The month's whole row: the requirement and the shortfall are always read from it. */
  const headMonth = monthRow(data.rows, period.fetchMonth, headLevel, headName);
  const rows = tableRows(data.rows, period, country, scope, s.dim);
  const level = tableLevel(country, scope, s.dim);
  const monthOf = (r: WsRow) => monthRow(data.rows, period.fetchMonth, r.level, r.name);
  const wholeOrQuarter = period.isWhole;
  const monthWord = period.mode === "quarter" ? `${monthName(period.fetchMonth)}'s` : "the month's";

  // The last five complete weeks, from the current month's payload whatever the period says.
  const weeks = lastCompleteWeeks(nowCalendar(nowData), 5);
  const weekPoints = (r: WsRow, pick: (w: WsRow) => number | null): SparkPoint[] =>
    weeks.map((w) => { const x = weekRow(nowData.rows, r.level, r.name, w); return { label: `${dayMonth(w.weekStart)} to ${dayMonth(w.weekEnd)}`, value: x ? pick(x) : null }; });
  const nowMonthRow = (r: WsRow) => monthRow(nowData.rows, nowMonth, r.level, r.name);
  const weekLabel = weeks.length ? `${dayMonth(weeks[0].weekStart)} to ${dayMonth(weeks[weeks.length - 1].weekEnd)}` : "";

  const pick = (r: WsRow) => s.setScope(scopeOf(r), r.level === "territory" ? r.parent : null);
  const masonsHref = (r: WsRow) => s.href(`/${s.slug}/masons`, { scope: scopeOf(r), scopeParent: r.level === "territory" ? r.parent : null, tab: "" });
  const salesHref = (r: WsRow) => s.href(`/${s.slug}/sales`, { scope: scopeOf(r), scopeParent: r.level === "territory" ? r.parent : null, tab: "" });
  const csoStandardPct = (r: WsRow) => (r.contractsPerCso != null && r.usualContractsPerCso ? r.contractsPerCso / r.usualContractsPerCso : null);
  // Focus: the weaker of the two productivity figures.
  const weaker = (r: WsRow) => { const a = r.pctBuildProductivity, b = csoStandardPct(r); return a == null ? b : b == null ? a : Math.min(a, b); };
  const worst = bottomN(rows, weaker);
  const people = [...rows].sort((a, b) => (weaker(a) ?? 99) - (weaker(b) ?? 99) || a.name.localeCompare(b.name));

  const nameCol: Col<WsRow> = { key: "name", header: levelTitle(level), mobile: "title", sort: (r) => r.name, copy: (r) => r.name, cell: (r) => (
    <span className="flex flex-col">
      <button type="button" onClick={() => pick(r)} className="text-left font-semibold underline decoration-[var(--border)] underline-offset-4" style={{ color: "var(--text-primary)" }}>{r.name}</button>
      <span className="text-xs" style={{ color: "var(--text-muted)" }}>{r.level === "territory" ? r.parent : r.level === "district" ? count(r.nTerritories, "territory", "territories") : r.country}</span>
    </span>
  ) };
  const peopleCols: Col<WsRow>[] = [
    nameCol,
    { key: "working", group: "Masons", header: "Working", right: true, sort: (r) => r.working, cell: (r) => <Stack top={whole(r.working)} href={masonsHref(r)} /> },
    { key: "assigned", group: "Masons", header: "Assigned", right: true, sort: (r) => r.assigned, cell: (r) => <Stack top={whole(r.assigned)} href={masonsHref(r)} /> },
    { key: "mhire", group: "Masons", header: "To hire", right: true, sort: (r) => monthOf(r)?.toHire ?? null, copy: (r) => { const m = monthOf(r); return m?.toHire == null ? "" : Math.round(m.toHire); },
      cell: (r) => { const m = monthOf(r); return <Stack top={m?.toHire == null ? "-" : whole(m.toHire)} under={m?.minMasons == null ? "no requirement" : `of ${whole(m.minMasons)} needed`} color={m?.toHire ? "var(--critical)" : undefined} href={masonsHref(r)} />; } },
    { key: "bpm", group: "Masons", header: "Builds per mason", right: true, sort: (r) => r.buildsPerMason, copy: (r) => (r.buildsPerMason == null ? "" : Math.round(r.buildsPerMason * 10) / 10),
      cell: (r) => <Stack top={one(r.buildsPerMason)} under={r.usualBuildsPerMason == null ? "no standard" : `target ${one(r.usualBuildsPerMason)}`} color={r.pctBuildProductivity != null && r.pctBuildProductivity < 0.8 ? "var(--critical)" : undefined} href={masonsHref(r)} /> },
    { key: "active", group: "CSOs", header: "Active", right: true, sort: (r) => r.csosActive, cell: (r) => <Stack top={whole(r.csosActive)} href={salesHref(r)} /> },
    { key: "required", group: "CSOs", header: "Required", right: true, sort: (r) => monthOf(r)?.minCsos ?? null, copy: (r) => { const m = monthOf(r); return m?.minCsos == null ? "" : Math.round(m.minCsos); },
      cell: (r) => { const m = monthOf(r); return <Stack top={m?.minCsos == null ? "-" : whole(m.minCsos)} href={salesHref(r)} />; } },
    { key: "chire", group: "CSOs", header: "To hire", right: true, sort: (r) => monthOf(r)?.csosShort ?? null, copy: (r) => { const m = monthOf(r); return m?.csosShort == null ? "" : Math.round(m.csosShort); },
      cell: (r) => { const m = monthOf(r); return <Stack top={m?.csosShort == null ? "-" : whole(m.csosShort)} color={m?.csosShort ? "var(--critical)" : undefined} href={salesHref(r)} />; } },
    { key: "cpc", group: "CSOs", header: "Contracts per CSO", right: true, sort: (r) => r.contractsPerCso, copy: (r) => (r.contractsPerCso == null ? "" : Math.round(r.contractsPerCso * 10) / 10),
      cell: (r) => <Stack top={one(r.contractsPerCso)} under={r.usualContractsPerCso == null ? "no standard" : `standard ${one(r.usualContractsPerCso)}`} color={(csoStandardPct(r) ?? 1) < 0.8 ? "var(--critical)" : undefined} href={salesHref(r)} /> },
  ];
  const peopleExport: Cell[][] = people.map((r) => { const m = monthOf(r); return [
    r.name, r.working, r.assigned, m?.toHire == null ? "" : Math.round(m.toHire), m?.minMasons == null ? "" : Math.round(m.minMasons),
    r.buildsPerMason == null ? "" : Math.round(r.buildsPerMason * 10) / 10, r.usualBuildsPerMason == null ? "" : Math.round(r.usualBuildsPerMason * 10) / 10,
    r.csosActive, m?.minCsos == null ? "" : Math.round(m.minCsos), m?.csosShort == null ? "" : Math.round(m.csosShort),
    r.contractsPerCso == null ? "" : Math.round(r.contractsPerCso * 10) / 10, r.usualContractsPerCso == null ? "" : Math.round(r.usualContractsPerCso * 10) / 10,
  ]; });

  // Five-week tables: the current value large, the sparkline beside it.
  const trendRowsList = [...rows].sort((a, b) => a.name.localeCompare(b.name));
  const masonTrendCols: Col<WsRow>[] = [
    nameCol,
    { key: "working", header: "Masons working", copyHeader: "Masons working, last week", sort: (r) => weekPoints(r, (w) => w.working).at(-1)?.value ?? null,
      copy: (r) => weekPoints(r, (w) => w.working).map((p) => p.value ?? "-").join(" "), cell: (r) => {
        const pts = weekPoints(r, (w) => w.working);
        const need = nowMonthRow(r)?.minMasons ?? null;
        const last = pts.at(-1)?.value ?? null;
        const short = need != null && last != null ? Math.max(0, Math.ceil(need - last)) : null;
        return <TrendCell big={last == null ? "-" : whole(last)} under={need == null ? "no requirement" : `target ${whole(need)}${short ? `, ${whole(short)} short` : ""}`} points={pts} target={need} color={SERIES_BUILDS} targetLabel="requirement" />;
      } },
    { key: "earn", header: "Earnings per mason", copyHeader: "Earnings per mason, last week", sort: (r) => weekPoints(r, (w) => w.earningsPerMason).at(-1)?.value ?? null,
      copy: (r) => weekPoints(r, (w) => w.earningsPerMason).map((p) => (p.value == null ? "-" : Math.round(p.value))).join(" "), cell: (r) => {
        const pts = weekPoints(r, (w) => w.earningsPerMason);
        const last = pts.at(-1)?.value ?? null;
        return <TrendCell big={last == null ? "-" : money(last, currency)} under="approved pay, per paid mason" points={pts} target={null} color={SERIES_COLL} format={(v) => money(v, currency).replace(`${currency} `, "")} />;
      } },
  ];
  const csoTrendCols: Col<WsRow>[] = [
    nameCol,
    { key: "active", header: "CSOs active", copyHeader: "CSOs active, last week", sort: (r) => weekPoints(r, (w) => w.csosActive).at(-1)?.value ?? null,
      copy: (r) => weekPoints(r, (w) => w.csosActive).map((p) => p.value ?? "-").join(" "), cell: (r) => {
        const pts = weekPoints(r, (w) => w.csosActive);
        const need = nowMonthRow(r)?.minCsos ?? null;
        const last = pts.at(-1)?.value ?? null;
        return <TrendCell big={last == null ? "-" : whole(last)} under={need == null ? "no requirement" : `requirement ${whole(need)}`} points={pts} target={need} color={SERIES_SALES} targetLabel="requirement" />;
      } },
    { key: "cpc", header: "Contracts per CSO", copyHeader: "Contracts per CSO, last week", sort: (r) => weekPoints(r, (w) => w.contractsPerCso).at(-1)?.value ?? null,
      copy: (r) => weekPoints(r, (w) => w.contractsPerCso).map((p) => (p.value == null ? "-" : Math.round(p.value * 10) / 10)).join(" "), cell: (r) => {
        const pts = weekPoints(r, (w) => w.contractsPerCso);
        const lastRow = weeks.length ? weekRow(nowData.rows, r.level, r.name, weeks[weeks.length - 1]) : undefined;
        const std = lastRow?.usualContractsPerCso ?? null;
        const last = pts.at(-1)?.value ?? null;
        return <TrendCell big={last == null ? "-" : one(last)} under={std == null ? "no standard" : `standard ${one(std)} a week`} points={pts} target={std} color={SERIES_SALES} format={(v) => one(v)} targetLabel="standard" />;
      } },
  ];

  // Backlog: paid, build not started, at the table's level.
  const backlog = journey.stock
    .filter((b) => b.bucket === "paid_not_started" && (scope ? (scope.level === "district" ? b.level === "territory" && rows.some((r) => r.name === b.name) : b.level === scope.level && b.name === scope.name) : b.level === level))
    .sort((a, b) => (b.monthsOfWork ?? -1) - (a.monthsOfWork ?? -1) || b.sqme - a.sqme);
  const backlogRow = (b: JourneyStockRow) => rows.find((r) => r.name === b.name);
  const backlogCols: Col<JourneyStockRow>[] = [
    { key: "name", header: levelTitle(level), mobile: "title", sort: (b) => b.name, copy: (b) => b.name, cell: (b) => {
      const r = backlogRow(b);
      const href = s.href(`/${s.slug}/sales`, { scope: r ? scopeOf(r) : scope, scopeParent: r?.level === "territory" ? r.parent : null, tab: "journey", extra: { bucket: "paid_not_started" } });
      return <a href={href} className="font-semibold underline decoration-[var(--border)] underline-offset-4" style={{ color: "var(--text-primary)" }}>{b.name}</a>;
    } },
    { key: "sqme", header: "SQM-E waiting", right: true, sort: (b) => b.sqme, copy: (b) => Math.round(b.sqme), cell: (b) => <Stack top={whole(b.sqme)} /> },
    { key: "n", header: "Contracts", right: true, sort: (b) => b.n, cell: (b) => <Stack top={whole(b.n)} under={b.waitingMaterials ? `${whole(b.waitingMaterials)} waiting on materials` : undefined} /> },
    { key: "oldest", header: "Oldest job", right: true, sort: (b) => b.oldestDays, copy: (b) => b.oldestDays, copyHeader: "Oldest job (days)", cell: (b) => <Stack top={`${whole(b.oldestDays)} days`} under={`median ${whole(b.medianDays)}`} color={b.oldestDays > 90 ? "var(--critical)" : undefined} /> },
    { key: "months", header: "Months of work", right: true, sort: (b) => b.monthsOfWork, copy: (b) => (b.monthsOfWork == null ? "" : Math.round(b.monthsOfWork * 10) / 10),
      cell: (b) => <Stack top={b.monthsOfWork == null ? "-" : one(b.monthsOfWork)} under={b.sqmeBuilt3m > 0 ? `builds ${whole(b.sqmeBuilt3m / 3)} SQM-E a month` : "nothing built in three months"} color={b.monthsOfWork != null && b.monthsOfWork > 2 ? "var(--critical)" : undefined} /> },
  ];

  const scopeWord = scope ? scope.name : country;
  const unitPlural = unitWord(level);
  const behind = people.filter((r) => worst.has(r.name)).map((r) => r.name);
  const pileUp = backlog.slice(0, 3).filter((b) => (b.monthsOfWork ?? 0) > 1).map((b) => b.name);

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>Capacity planning, {scopeWord}</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>{period.label}. People against requirement; the Overview holds the volumes.</p>
      </div>
      <BarExports filename={`capacity-people-${country.toLowerCase()}_${period.label.replace(/\s+/g, "-")}_${stamp()}`}
        headers={[levelTitle(level), "Masons working", "Masons assigned", "Masons to hire", "Masons needed", "Builds per mason", "Builds per mason target", "CSOs active", "CSOs required", "CSOs to hire", "Contracts per CSO", "Contracts per CSO standard"]}
        rows={peopleExport} />

      {head ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          <Kpi label="Masons working" big={whole(head.working)} tone={SERIES_BUILDS} href={s.href(`/${s.slug}/masons`)}
            lines={[
              wholeOrQuarter ? <Fact key="n" n={head.working} of={head.minMasons} word="needed" /> : <span key="n">in {period.short}</span>,
              <span key="h"><b className="font-semibold tabular-nums" style={{ color: (headMonth?.toHire ?? 0) > 0 ? "var(--critical)" : "var(--text-primary)" }}>{headMonth?.toHire == null ? "-" : whole(headMonth.toHire)}</b> <span style={{ color: "var(--text-secondary)" }}>to hire</span></span>,
              <span key="a"><b className="font-semibold tabular-nums">{whole(head.assigned)}</b> <span style={{ color: "var(--text-secondary)" }}>assigned, not started</span></span>,
            ]}
            sub={`To hire is each ${unitWord(s.unit, 1)}'s own shortfall against ${monthWord} requirement, added up, never netted.`} />
          <Kpi label="CSOs working" big={whole(head.csosActive)} tone={SERIES_SALES} href={s.href(`/${s.slug}/sales`)}
            lines={[
              wholeOrQuarter ? <Fact key="n" n={head.csosActive} of={head.minCsos} word="needed" /> : <span key="n">in {period.short}</span>,
              <span key="h"><b className="font-semibold tabular-nums" style={{ color: (headMonth?.csosShort ?? 0) > 0 ? "var(--critical)" : "var(--text-primary)" }}>{headMonth?.csosShort == null ? "-" : whole(headMonth.csosShort)}</b> <span style={{ color: "var(--text-secondary)" }}>to hire</span></span>,
              <span key="c"><b className="font-semibold tabular-nums">{one(head.contractsPerCso)}</b> <span style={{ color: "var(--text-secondary)" }}>contracts per CSO{head.usualContractsPerCso != null ? `, standard ${one(head.usualContractsPerCso)}` : ""}</span></span>,
            ]}
            sub={`To hire is against ${monthWord} requirement: the CSOs each ${unitWord(s.unit, 1)} should have, as the company sets it, less those active.`} />
          <Kpi label="SQM-E built" pct={head.pctSqme} tone={SERIES_BUILDS} href={s.href(`/${s.slug}/masons`)}
            lines={[<Fact key="s" n={head.sqmeBuilt} of={head.sqmeTarget} word="SQM-E" />]}
            remaining={head.sqmeTarget == null ? "no target set" : <Remaining parts={[{ n: head.sqmeTarget - head.sqmeBuilt, word: "SQM-E" }]} />}
            note={paintNote(head.paintSqmeBuilt)} />
          <Kpi label="SQM-E sold" pct={head.pctSqmeSales} tone={SERIES_SALES} href={s.href(`/${s.slug}/sales`)}
            lines={[<Fact key="s" n={head.sqmeSold} of={head.sqmeSalesTarget} word="SQM-E" />]}
            remaining={head.sqmeSalesTarget == null ? "no target set" : <Remaining parts={[{ n: head.sqmeSalesTarget - head.sqmeSold, word: "SQM-E" }]} />}
            note={paintNote(head.paintSqmeSold)} />
        </div>
      ) : (
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>No figures for {scopeWord} in {period.label}.</p>
      )}

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>People, {scope ? (scope.level === "district" ? `territories in ${scope.name}` : scope.name) : `by ${unitWord(level, 1)}`}</h2>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>Weakest productivity first. Mason columns open the Masons page, CSO columns the Sales page.</span>
        </div>
        <DataTable rows={people} cols={peopleCols} keyOf={(r) => `${r.level}|${r.name}`} mark={(r) => worst.has(r.name)} copyName="the People table"
          note={`Working, assigned, active, builds per mason and contracts per CSO are for ${period.short}. To hire and Required are against ${monthWord} requirement whatever weeks are selected, each ${unitWord(s.unit, 1)}'s own shortfall floored at zero and added up. Builds per mason carries the standard of 4 a month scaled to the period; contracts per CSO carries the sales target over the CSO requirement. Focus marks the five weakest on the lower of the two.`} />
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>Masons, last five weeks</h2>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>{weekLabel ? `Complete weeks ${weekLabel}, whatever the period says.` : "No complete week yet."}</span>
        </div>
        <DataTable rows={trendRowsList} cols={masonTrendCols} keyOf={(r) => `${r.level}|${r.name}`} copyName="the mason trend"
          note="Oldest week on the left, the value at every point. The dashed line is the monthly mason requirement. A wobbly earnings line usually means uneven work allocation rather than a mason problem." />
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>CSOs, last five weeks</h2>
        <DataTable rows={trendRowsList} cols={csoTrendCols} keyOf={(r) => `${r.level}|${r.name}`} copyName="the CSO trend"
          note="Dashed lines are the CSO requirement and the per-CSO contract standard for a week (the sales target over the requirement)." />
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>Backlog, collected but not built</h2>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>Longest months of work first. Tap a name for the customers.</span>
        </div>
        <DataTable rows={backlog} cols={backlogCols} keyOf={(b) => `${b.level}|${b.name}`} copyName="the backlog" empty="Nobody is waiting for a build to start."
          note="Customers who have paid to the gate and whose build has not started, as it stands now. Months of work is that SQM-E divided by the place's own build rate over the last three whole months, from the same journey view." />
      </section>

      {head && (
        <Boxes
          happened={[
            `${whole(head.working)} masons worked in ${period.short} and ${whole(head.assigned)} were assigned without starting; each built ${one(head.buildsPerMason)}${head.usualBuildsPerMason != null ? ` against a standard of ${one(head.usualBuildsPerMason)}` : ""}.`,
            `${whole(head.csosActive)} CSOs were active, signing ${one(head.contractsPerCso)} contracts each${head.usualContractsPerCso != null ? ` against a standard of ${one(head.usualContractsPerCso)}` : ""}.`,
            `${pctText(head.pctMasonsProductive)} of working masons earned above the productive bar.`,
          ]}
          next={[
            (headMonth?.toHire ?? 0) > 0 || (headMonth?.csosShort ?? 0) > 0
              ? `Hire ${whole(headMonth?.toHire ?? 0)} masons and ${whole(headMonth?.csosShort ?? 0)} CSOs against ${monthWord} requirement, across ${count(headMonth?.territoriesShort ?? 0, unitWord(s.unit, 1), unitPlural)} short of masons and ${count(headMonth?.csosUnitsShort ?? 0, unitWord(s.unit, 1), unitPlural)} short of CSOs.`
              : `Every ${unitWord(s.unit, 1)} has the people it needs; the gap is output per person.`,
            pileUp.length ? `Work is piling up in ${pileUp.join(", ")}: more than a month of backlog at their own build rate.` : "No place holds more than a month of backlog at its own build rate.",
            behind.length ? `${level === "district" || level === "branch" ? "Branches" : "Territories"} to focus on: ${behind.join(", ")}.` : `No ${unitWord(level, 1)} stands out as weakest.`,
          ]} />
      )}
    </>
  );
}

/** The calendar weeks the current month's payload can answer for: every single-week row it holds. */
function nowCalendar(nowData: WsData): CapacityWeek[] {
  const seen = new Map<string, CapacityWeek>();
  for (const r of nowData.rows) {
    if (r.level !== "country" || r.isQuarter || r.nWeeks !== 1) continue;
    const key = `${r.month}|${r.weekKey}`;
    if (seen.has(key)) continue;
    seen.set(key, { month: r.month, monthLabel: r.monthLabel, weekNo: Number(r.weekKey), weekLabel: r.periodLabel, weekStart: r.periodStart, weekEnd: r.periodEnd, isComplete: r.isComplete, isCurrent: !r.isComplete });
  }
  return [...seen.values()].sort((a, b) => a.weekStart.localeCompare(b.weekStart));
}

/** The current value large on the left, the sparkline on the right, as the focus trend page lays it out. */
export function TrendCell({ big, under, points, target, color, format, targetLabel }: {
  big: string; under?: string; points: SparkPoint[]; target: number | null; color: string; format?: (v: number) => string; targetLabel?: string;
}) {
  return (
    <span className="flex items-center gap-3">
      <span className="flex w-24 shrink-0 flex-col">
        <span className="text-xl font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{big}</span>
        {under && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{under}</span>}
      </span>
      <span className="min-w-0 flex-1"><Sparkline points={points} target={target} color={color} format={format} targetLabel={targetLabel} /></span>
    </span>
  );
}
