"use client";

import { pctText, whole } from "@/lib/workspace-ui";

/**
 * The ranking chart under the Overview table: every unit on SQM-E built
 * against target, best at the top, the target line at 100%. One colour, no
 * legend: it is the same data as the table for people who read a picture
 * faster. Drawn as HTML bars so it wraps cleanly at 390px.
 */
export default function RankBars({ title, items, onPick }: {
  title: string;
  items: { name: string; pct: number | null; built: number; target: number | null }[];
  onPick?: (name: string) => void;
}) {
  const ranked = [...items].sort((a, b) => (b.pct ?? -1) - (a.pct ?? -1));
  const max = Math.max(1.2, ...ranked.map((i) => i.pct ?? 0));
  return (
    <section className="rounded-xl border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{title}</h2>
      <p className="text-xs" style={{ color: "var(--text-muted)" }}>SQM-E built against target. Best at the top; the dotted line is the target.</p>
      <div className="relative mt-3 flex flex-col gap-1.5">
        <span aria-hidden className="pointer-events-none absolute bottom-0 top-0 border-l border-dashed" style={{ left: `calc(9rem + (100% - 9rem - 3rem) * ${1 / max})`, borderColor: "var(--text-primary)", opacity: 0.55 }} />
        {ranked.map((i) => (
          <div key={i.name} className="flex items-center gap-2 text-xs">
            <button type="button" onClick={onPick ? () => onPick(i.name) : undefined} className="w-36 shrink-0 truncate text-left" title={i.name} style={{ color: "var(--text-secondary)" }}>{i.name}</button>
            <span className="h-3 flex-1 overflow-hidden rounded-sm" style={{ background: "var(--grid)" }}>
              <span className="block h-full rounded-sm" style={{ width: `${Math.min(100, ((i.pct ?? 0) / max) * 100)}%`, background: "var(--text-secondary)" }} />
            </span>
            <span className="w-12 shrink-0 text-right font-medium tabular-nums" style={{ color: "var(--text-primary)" }} title={`${whole(i.built)} of ${whole(i.target)} SQM-E`}>{pctText(i.pct)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
