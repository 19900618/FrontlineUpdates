"use client";

import type { ReactNode } from "react";
import { useNarrow } from "@/lib/use-narrow";

/**
 * The one line chart of the country workspaces: points over time, one line
 * per series, against a target line. Every page draws its trend with this so
 * the rules hold everywhere and cannot drift:
 *
 *   1. A value is printed at every point that has room, in the series
 *      colour, 600 weight, about 8px clear of the line. Labels never
 *      overlap: each one is measured, and where it would collide with a
 *      neighbour or sit on a line it moves from above the dot to below it
 *      (two series that nearly touch push their labels apart). A point whose
 *      label fits nowhere is left unlabelled, except the first, the last, the
 *      highest and the lowest of each series, which are always printed.
 *      Every point keeps its tooltip.
 *   2. The y axis starts at zero. Only when every value sits far above zero,
 *      so that zero would flatten the line, may the floor rise, and never
 *      above the lowest value minus a fifth of the range. `floor="zero"` pins
 *      it at zero regardless. A money or count axis has at most four
 *      gridlines above zero, at round steps.
 *
 * The geometry switches on phones so the labels stay legible (an SVG viewBox
 * scales its text with the drawing); `compact` keeps the phone width on every
 * screen with a taller plot, for a chart that sits in a column of a grid.
 * Values are ratios (1 = target) unless `format` says otherwise. A null
 * value leaves a gap, never a zero. A series can be `dashed` (a budget beside
 * an actual), and the point at `partial` is drawn hollow, for a month still
 * in progress. On a phone the month labels shrink to their initial.
 */
export type TrendSeries = {
  key: string; label: string; color: string; values: (number | null)[];
  /** A note per point for the tooltip. */
  notes?: (string | null)[];
  /** A dashed line, for a budget or plan beside an actual. */
  dashed?: boolean;
};

type Box = { x1: number; x2: number; y1: number; y2: number };

export default function TrendChart({
  title, months, series, target = 1, targetLabel = "Target", format, axisFormat, yMax: yMaxIn, selected, subtitle,
  partial, legend = true, floor = "auto", yLabel, compact = false, toolbar, note,
}: {
  title: string;
  /** Short labels per point, oldest first. */
  months: string[];
  series: TrendSeries[];
  target?: number | null;
  targetLabel?: string;
  /** The point labels and, unless `axisFormat` is given, the axis. */
  format?: (v: number) => string;
  /** The axis ticks, when they should be shorter than the point labels (20K against 19,412). */
  axisFormat?: (v: number) => string;
  yMax?: number;
  /** Index of the selected point, drawn bold. */
  selected?: number;
  subtitle?: string;
  /** Index of a point still in progress: drawn hollow, its month marked. */
  partial?: number;
  /** The series legend in the title row; off when a page keeps one legend for many charts. */
  legend?: boolean;
  floor?: "auto" | "zero";
  /** A caption up the y axis. */
  yLabel?: string;
  /** The phone width on every screen, with a taller plot, for a chart in a grid column. */
  compact?: boolean;
  /** A control in the title row, at the right. */
  toolbar?: ReactNode;
  /** A footnote under the drawing. */
  note?: ReactNode;
}) {
  const isNarrow = useNarrow();
  const narrow = isNarrow || compact;
  const fmt = format ?? ((v: number) => `${Math.round(v * 100)}%`);
  const tickFmt = axisFormat ?? fmt;
  const n = months.length;
  if (n < 1) return null;
  const W = narrow ? 380 : 800;
  // A compact chart keeps a band under the zero line so a label can sit below a dot near the floor.
  const H = compact ? 366 : narrow ? 250 : 230;
  const fs = narrow ? 12 : 10.5;
  const labelFs = fs - 0.5;
  const all = series.flatMap((s) => s.values.filter((v): v is number => v != null));
  const rawMax = Math.max(target ?? 0, ...all, 0.01);
  const rawMin = Math.min(target ?? Infinity, ...all);
  // The floor rule: zero unless everything sits so high that zero would flatten it.
  const range = rawMax - rawMin;
  const yMin = floor === "auto" && all.length > 0 && rawMin > 0 && range < 0.4 * rawMax ? Math.max(0, rawMin - range / 5) : 0;
  let yMax: number;
  let ticks: number[];
  if (format) {
    const axis = niceAxis((yMaxIn ?? rawMax * 1.1) - yMin);
    yMax = yMaxIn ?? yMin + axis.max;
    ticks = [];
    for (let t = yMin; t <= yMax + 1e-9; t += axis.step) ticks.push(t);
  } else {
    yMax = yMaxIn ?? Math.max(1.25, Math.ceil((rawMax * 1.08) / 0.25) * 0.25);
    ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => yMin + t * (yMax - yMin));
  }
  const textW = (s: string, size: number) => s.length * size * 0.62 + 4;
  const padL = Math.max(...ticks.map((t) => textW(tickFmt(t), fs))) + 10 + (yLabel ? 14 : 0);
  const padR = narrow ? 18 : 28, padT = 24, padB = compact ? 62 : narrow ? 36 : 30;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const x = (i: number) => (n === 1 ? padL + plotW / 2 : padL + (i * plotW) / (n - 1));
  const y = (v: number) => padT + plotH * (1 - (Math.min(Math.max(v, yMin), yMax) - yMin) / (yMax - yMin));
  const path = (vals: (number | null)[]) =>
    vals.map((v, i) => (v == null ? null : `${i === 0 || vals[i - 1] == null ? "M" : "L"}${x(i)},${y(v)}`)).filter(Boolean).join(" ");

  // ---- Label placement -----------------------------------------------------
  // Every label is a measured box. At each month the labels of all the
  // series are placed together: each may sit above its dot, below it, or one
  // or two lines further out, and the cheapest arrangement is taken in which
  // no label touches another label, a placed box, a line of any series, or
  // the month row, and the labels keep the vertical order of their dots (a
  // budget under the actual is never printed above it). Anchors (first,
  // last, highest, lowest per series) go first and are always printed; the
  // rest follow and a label is dropped only when no arrangement fits.
  const GAP = 8;
  const placed: Box[] = [
    { x1: 0, x2: W, y1: H - 10 - fs - 4, y2: H },
    ...ticks.map((t) => ({ x1: padL - 8 - textW(tickFmt(t), fs), x2: padL - 8, y1: y(t) - fs / 2, y2: y(t) + fs / 2 })),
  ];
  const overlaps = (a: Box, b: Box, m = 2) => a.x1 < b.x2 + m && a.x2 > b.x1 - m && a.y1 < b.y2 + m && a.y2 > b.y1 - m;
  const segments: { x1: number; y1: number; x2: number; y2: number }[] = [];
  for (const s of series) {
    for (let i = 1; i < n; i++) {
      const a = s.values[i - 1], b = s.values[i];
      if (a != null && b != null) segments.push({ x1: x(i - 1), y1: y(a), x2: x(i), y2: y(b) });
    }
  }
  if (target != null && target >= yMin && target <= yMax) segments.push({ x1: padL, y1: y(target), x2: W - padR, y2: y(target) });
  const crossesLine = (b: Box) => segments.some((s) => {
    const lo = Math.max(b.x1, s.x1), hi = Math.min(b.x2, s.x2);
    if (lo > hi) return false;
    const at = (px: number) => s.y1 + ((s.y2 - s.y1) * (px - s.x1)) / (s.x2 - s.x1 || 1);
    const ya = at(lo), yb = at(hi);
    return b.y1 < Math.max(ya, yb) + 3 && b.y2 > Math.min(ya, yb) - 3;
  });
  const boxFor = (i: number, text: string, top: number, dx = 0): Box => {
    const w = textW(text, labelFs);
    const cx = Math.min(Math.max(x(i) + dx, w / 2), W - w / 2);
    return { x1: cx - w / 2, x2: cx + w / 2, y1: top, y2: top + labelFs };
  };
  const labels = new Map<string, { box: Box; baseline: number }>();
  type Cand = { key: string; i: number; v: number; text: string; anchor: boolean };
  type Pos = { top: number; dx: number; cost: number } | null;
  // Above the dot, below it, one or two lines further out (stacked labels
  // keep their order, so stacking is preferred), and each of those nudged a
  // little to the side, which finds room where the other line is higher.
  const positions = (c: Cand, allowDrop: boolean): Pos[] => {
    const dot = y(c.v);
    // A series running just under another prefers below, so a budget hugging the actual reads under its own line.
    const crowded = series.some((s) => s.key !== c.key && s.values[c.i] != null && y(s.values[c.i] as number) <= dot && dot - y(s.values[c.i] as number) < 2 * labelFs + GAP);
    const list: Pos[] = [];
    for (let k = 0; k < 3; k++) {
      for (const dx of [0, -14, 14]) {
        const shift = dx === 0 ? 0 : 3;
        list.push({ top: dot - GAP - labelFs * (k + 1) - 3 * k, dx, cost: k * 2 + shift + (crowded ? 1 : 0) });
        list.push({ top: dot + GAP + 3 * k + labelFs * k, dx, cost: k * 2 + shift + (crowded ? 0 : 1) });
      }
    }
    list.sort((a, b) => (a as { cost: number }).cost - (b as { cost: number }).cost);
    if (allowDrop) list.push(null);
    return list;
  };
  const centre = (b: Box) => (b.y1 + b.y2) / 2;
  const inOrder = (aY: number, aBox: Box, bY: number, bBox: Box) => (aY < bY) === (centre(aBox) < centre(bBox));
  const keyOf = (c: Cand) => `${c.key}|${c.i}`;
  /**
   * Place a set of points together (a month's, or a point with its
   * neighbours): the cheapest arrangement with no touching, ordering kept
   * within each month, and a non-anchor dropped only when nothing fits.
   * Returns the number of labels placed, or -1 when no arrangement exists.
   */
  const placeSet = (pts: Cand[], allowDrop: boolean, allowCross: boolean): number => {
    const own = new Set(pts.map(keyOf));
    // Labels already on the chart at the same months as these points keep their order against them.
    const fixed = pts.map((c) => series
      .map((s) => ({ key: `${s.key}|${c.i}`, v: s.values[c.i], l: labels.get(`${s.key}|${c.i}`) }))
      .filter((f): f is { key: string; v: number; l: { box: Box; baseline: number } } => f.v != null && !!f.l && !own.has(f.key)));
    let best: { boxes: (Box | null)[]; cost: number } | null = null;
    const walk = (j: number, boxes: (Box | null)[], cost: number) => {
      if (best && cost >= best.cost) return;
      if (j === pts.length) { best = { boxes: [...boxes], cost }; return; }
      const c = pts[j];
      for (const pos of positions(c, allowDrop && !c.anchor)) {
        if (pos == null) { walk(j + 1, [...boxes, null], cost + 30); continue; }
        const box = boxFor(c.i, c.text, pos.top, pos.dx);
        if (placed.some((p) => overlaps(box, p))) continue;
        const crosses = crossesLine(box);
        if (crosses && !allowCross) continue;
        let ok = true;
        for (let q = 0; q < j && ok; q++) {
          const other = boxes[q];
          if (!other) continue;
          if (overlaps(box, other)) ok = false;
          else if (pts[q].i === c.i && !inOrder(y(pts[q].v), other, y(c.v), box)) ok = false;
        }
        for (const f of fixed[j]) {
          if (!ok) break;
          if (overlaps(box, f.l.box) || !inOrder(y(f.v), f.l.box, y(c.v), box)) ok = false;
        }
        if (!ok) continue;
        walk(j + 1, [...boxes, box], cost + pos.cost + (crosses ? 15 : 0));
      }
    };
    walk(0, [], 0);
    if (!best) return -1;
    const found = best as { boxes: (Box | null)[]; cost: number };
    let count = 0;
    found.boxes.forEach((box, j) => {
      if (!box) return;
      placed.push(box);
      labels.set(keyOf(pts[j]), { box, baseline: box.y1 + labelFs * 0.8 });
      count += 1;
    });
    return count;
  };
  const unplace = (c: Cand) => {
    const l = labels.get(keyOf(c));
    if (!l) return;
    labels.delete(keyOf(c));
    const at = placed.indexOf(l.box);
    if (at >= 0) placed.splice(at, 1);
  };
  const cands: Cand[] = [];
  for (const s of series) {
    for (let i = 0; i < n; i++) {
      const v = s.values[i];
      if (v != null) cands.push({ key: s.key, i, v, text: fmt(v), anchor: false });
    }
  }
  for (const s of series) {
    const pts = cands.filter((c) => c.key === s.key);
    if (pts.length === 0) continue;
    const hi = pts.reduce((a, b) => (b.v > a.v ? b : a)), lo = pts.reduce((a, b) => (b.v < a.v ? b : a));
    for (const c of [pts[0], pts[pts.length - 1], hi, lo]) c.anchor = true;
  }
  // The anchors first, month by month; a line may run under one only when nothing else fits.
  for (let i = 0; i < n; i++) {
    const anchors = cands.filter((c) => c.i === i && c.anchor);
    if (anchors.length === 0) continue;
    if (placeSet(anchors, false, false) < 0 && placeSet(anchors, false, true) < 0) {
      for (const c of anchors) { const top = y(c.v) - GAP - labelFs; const box = boxFor(c.i, c.text, top); placed.push(box); labels.set(keyOf(c), { box, baseline: top + labelFs * 0.8 }); }
    }
  }
  // Then the rest. A point left without a label gets one more try together
  // with its own series' neighbours, which may move to make room; the move
  // is kept only when it labels more points than before.
  for (let i = 0; i < n; i++) {
    const rest = cands.filter((c) => c.i === i && !c.anchor);
    if (rest.length > 0) placeSet(rest, true, false);
  }
  for (const c of cands) {
    if (c.anchor || labels.has(keyOf(c))) continue;
    const neighbours = cands.filter((o) => o.key === c.key && Math.abs(o.i - c.i) === 1 && labels.has(keyOf(o)));
    if (neighbours.length === 0) continue;
    const saved = neighbours.map((o) => ({ o, l: labels.get(keyOf(o))! }));
    for (const o of neighbours) unplace(o);
    const got = placeSet([c, ...neighbours], true, false);
    if (got <= neighbours.length) {
      for (const o of [c, ...neighbours]) unplace(o);
      for (const { o, l } of saved) { placed.push(l.box); labels.set(keyOf(o), l); }
    }
  }

  const monthLabel = (m: string) => (isNarrow ? m.slice(0, 1) : m);

  return (
    <section className={`rounded-xl border ${compact ? "p-5" : "p-4"}`} style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{title}</h2>
          {subtitle && <p className="text-xs" style={{ color: "var(--text-muted)" }}>{subtitle}</p>}
        </div>
        <div className="flex flex-wrap items-center gap-3 text-xs" style={{ color: "var(--text-muted)" }}>
          {legend && series.map((s) => (
            <span key={s.key} className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-sm" style={s.dashed ? { border: `2px dashed ${s.color}` } : { background: s.color }} />{s.label}
            </span>
          ))}
          {toolbar}
        </div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="mt-3 w-full" style={{ maxHeight: compact ? 390 : narrow ? 260 : 250, overflow: "visible" }} role="img" aria-label={title}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeWidth="1" opacity={t === yMin ? 0.9 : 0.45} />
            <text x={padL - 8} y={y(t) + 4} textAnchor="end" fontSize={fs} fill="var(--text-muted)">{tickFmt(t)}</text>
          </g>
        ))}
        {yLabel && (
          <text transform={`translate(11 ${padT + plotH / 2}) rotate(-90)`} textAnchor="middle" fontSize={fs - 1} fill="var(--text-muted)">{yLabel}</text>
        )}
        {target != null && target >= yMin && target <= yMax && (
          <>
            <line x1={padL} x2={W - padR} y1={y(target)} y2={y(target)} stroke="var(--text-primary)" strokeWidth="1.25" strokeDasharray="4 5" opacity="0.6" />
            <text x={padL + 2} y={y(target) - 5} fontSize={fs} fill="var(--text-secondary)">{targetLabel}</text>
          </>
        )}
        {series.map((s) => (
          <g key={s.key}>
            <path d={path(s.values)} fill="none" stroke={s.color} strokeWidth={s.dashed ? 1.75 : 2.25} strokeDasharray={s.dashed ? "5 4" : undefined}
              strokeLinejoin="round" strokeLinecap="round" />
            {s.values.map((v, i) => {
              if (v == null) return null;
              const l = labels.get(`${s.key}|${i}`);
              return (
                <g key={i}>
                  <circle cx={x(i)} cy={y(v)} r={selected === i ? 5 : partial === i ? 3.5 : 3}
                    fill={partial === i ? "var(--surface)" : s.color} stroke={partial === i ? s.color : "var(--surface)"} strokeWidth="2">
                    <title>{`${months[i]}${partial === i ? " (in progress)" : ""}: ${s.label} ${fmt(v)}${s.notes?.[i] ? ` (${s.notes[i]})` : ""}`}</title>
                  </circle>
                  {l && (
                    <text x={(l.box.x1 + l.box.x2) / 2} y={l.baseline} textAnchor="middle" fontSize={labelFs} fontWeight={600}
                      fill={s.color} stroke="var(--surface)" strokeWidth="3" paintOrder="stroke">{fmt(v)}</text>
                  )}
                </g>
              );
            })}
          </g>
        ))}
        {months.map((m, i) => (
          <text key={m + i} x={x(i)} y={H - 10} textAnchor="middle" fontSize={fs}
            fill={selected === i ? "var(--text-primary)" : "var(--text-muted)"} fontWeight={selected === i ? 600 : 400}
            fontStyle={partial === i ? "italic" : undefined}>{monthLabel(m)}{partial === i ? "*" : ""}</text>
        ))}
      </svg>
      {note && <p className="mt-2 text-xs" style={{ color: "var(--text-muted)" }}>{note}</p>}
    </section>
  );
}

/** The next round number above v (1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8 times a power of ten), for a money or count axis. */
export function niceCeil(v: number): number {
  if (!(v > 0)) return 1;
  const e = Math.pow(10, Math.floor(Math.log10(v)));
  const m = v / e;
  const step = [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10].find((s) => s >= m) ?? 10;
  return step * e;
}

/**
 * A round axis for a span: the smallest round step (1, 2, 2.5 or 5 times a
 * power of ten) that covers it in at most four gridlines, and the top it
 * reaches. Pages that share one axis across several charts call this on the
 * largest span and pass the result as `yMax`.
 */
export function niceAxis(span: number): { step: number; max: number } {
  if (!(span > 0)) return { step: 0.25, max: 1 };
  const e = Math.pow(10, Math.floor(Math.log10(span)) - 1);
  for (const m of [1, 2, 2.5, 5, 10, 20, 25, 50, 100]) {
    const step = m * e;
    const ticks = Math.ceil(span / step - 1e-9);
    if (ticks <= 4) return { step, max: ticks * step };
  }
  return { step: span, max: span };
}
