"use client";

import { useMemo, useState, type ReactNode } from "react";
import { copyForSheets, type Cell } from "@/lib/export";
import { pctText, toneOf, TONE_COLOR, whole } from "@/lib/workspace-ui";

/**
 * The building blocks of the country workspaces, copied from the mockup and,
 * where it is silent, from the CSO overview and individual CSO pages: a
 * scorecard with the percentage large and the achieved-of-target line under
 * it, a percentage pill with the figures beneath, a table that becomes
 * stacked cards below md, the two bottom boxes, chips, toggles, selects.
 */

const CARD = { background: "var(--surface)", borderColor: "var(--border)" } as const;

/**
 * One scorecard. The percentage (or `big`, a money figure or a count) sits
 * large under a small label; the achieved-of-target facts follow one per
 * line, then the "to go" line; the footnote is pinned to the bottom so a row
 * of cards lines up. `href` puts an Open link in the label row.
 */
export function Kpi({ label, pct, big, lines, remaining, note, sub, tone, href, footer }: {
  label: string;
  pct?: number | null;
  big?: string;
  /** The achieved-of-target facts, one per line. Use `Fact` for "N of M word". */
  lines?: ReactNode[];
  remaining?: ReactNode;
  /** One muted line under the facts, such as "plus 107 SQM-E paint". */
  note?: ReactNode;
  sub?: ReactNode;
  /** The series colour on the top rule. */
  tone: string;
  href?: string;
  /** A control under the footnote, such as a button that opens the records behind the figure. */
  footer?: ReactNode;
}) {
  const body = (
    <>
      <span className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--text-secondary)" }}>{label}</span>
        {href && <span className="text-xs font-medium" style={{ color: "var(--accent-ink)" }}>Open →</span>}
      </span>
      <span className="mt-2.5 block text-[2rem] font-semibold leading-none tracking-tight tabular-nums" style={{ color: "var(--text-primary)" }}>
        {big ?? pctText(pct)}
      </span>
      {lines && lines.length > 0 && (
        <span className="mt-3.5 flex flex-col gap-1 text-sm leading-snug" style={{ color: "var(--text-primary)" }}>
          {lines.map((l, i) => <span key={i} className="block">{l}</span>)}
        </span>
      )}
      {remaining && <span className="mt-2 block text-sm leading-snug" style={{ color: "var(--text-secondary)" }}>{remaining}</span>}
      {note && <span className="mt-1.5 block text-xs leading-snug" style={{ color: "var(--text-muted)" }}>{note}</span>}
      {sub && (
        <span className="mt-auto block pt-3.5">
          <span className="block border-t pt-2.5 text-xs leading-snug" style={{ color: "var(--text-muted)", borderColor: "var(--grid)" }}>{sub}</span>
        </span>
      )}
      {footer && <span className={`block ${sub ? "mt-2" : "mt-auto pt-3"}`}>{footer}</span>}
    </>
  );
  const style = { ...CARD, borderTop: `3px solid ${tone}` };
  const cls = "flex h-full flex-col rounded-xl border p-5 text-left";
  if (href) {
    return <a href={href} className={`${cls} transition hover:shadow-sm`} style={style}>{body}</a>;
  }
  return <div className={cls} style={style}>{body}</div>;
}

/** "1,003 of 2,787 contracts": the achieved figure bold, the target and the unit quieter. Strings pass through as they are. */
export function Fact({ n, of, word }: { n: number | string; of?: number | string | null; word?: string }) {
  const num = (v: number | string | null) => (v == null ? "-" : typeof v === "number" ? whole(v) : v);
  return (
    <>
      <b className="font-semibold tabular-nums">{num(n)}</b>
      <span style={{ color: "var(--text-secondary)" }}>{of !== undefined ? ` of ${num(of)}` : ""}{word ? ` ${word}` : ""}</span>
    </>
  );
}

/** "583 contracts and 12,300 SQM-E to go" in the mockup's shape: the number bold in clay. */
export function Remaining({ parts }: { parts: { n: number; word: string }[] }) {
  const left = parts.filter((p) => p.n > 0);
  if (left.length === 0) return <>Target reached</>;
  return (
    <>
      {left.map((p, i) => (
        <span key={p.word}>
          {i > 0 && " and "}
          <b style={{ color: "var(--critical)" }}>{whole(p.n)}</b> {p.word}
        </span>
      ))}
      {" to go"}
    </>
  );
}

/** A percentage in its performance colour, with the achieved-of-target line under it. */
export function PctCell({ pct, under, href, onClick }: { pct: number | null; under?: string; href?: string; onClick?: () => void }) {
  const tone = toneOf(pct);
  const pill = (
    <span className="inline-block rounded-md px-2 py-0.5 text-sm font-semibold tabular-nums"
      style={{ background: tone === "none" ? "transparent" : `color-mix(in srgb, ${TONE_COLOR[tone]} 16%, transparent)`, color: tone === "none" ? "var(--text-muted)" : "var(--text-primary)" }}>
      {pctText(pct)}
    </span>
  );
  return (
    <span className="flex flex-col items-end">
      {href ? <a href={href} className="hover:underline">{pill}</a> : onClick ? <button type="button" onClick={onClick}>{pill}</button> : pill}
      {under && <span className="mt-0.5 text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{under}</span>}
    </span>
  );
}

/** A value with a muted line under it, right-aligned. */
export function Stack({ top, under, color, href }: { top: ReactNode; under?: ReactNode; color?: string; href?: string }) {
  const t = <span className="font-semibold tabular-nums" style={{ color: color ?? "var(--text-primary)" }}>{top}</span>;
  return (
    <span className="flex flex-col items-end">
      {href ? <a href={href} className="hover:underline">{t}</a> : t}
      {under && <span className="mt-0.5 text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{under}</span>}
    </span>
  );
}

/**
 * Paint beside a scored figure, the way the Uganda and Kenya branch breakdown
 * shows it: one narrow right-hand column, SQM-E as the figure, the contracts
 * small underneath. Never a second big number.
 */
export function Paint({ sqme, contracts, word = "contracts" }: { sqme: number; contracts: number; word?: string }) {
  return (
    <span className="flex flex-col items-end">
      <span className="whitespace-nowrap text-sm tabular-nums" style={{ color: "var(--text-secondary)" }}>{whole(sqme)} SQM-E</span>
      <span className="whitespace-nowrap text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{whole(contracts)} {word}</span>
    </span>
  );
}

/** "plus 107 SQM-E paint" under a scored figure, or nothing when there is none. */
export const paintNote = (sqme: number): string | undefined => (sqme > 0 ? `plus ${whole(sqme)} SQM-E paint` : undefined);

export function MiniBar({ label, pct, tone }: { label: string; pct: number | null; tone: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-20 shrink-0 text-xs" style={{ color: "var(--text-muted)" }}>{label}</span>
      <span className="h-2 flex-1 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: tone }} />
      </span>
      <span className="w-10 shrink-0 text-right text-xs font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</span>
    </div>
  );
}

/** A progress bar on its own, for a table cell: actual of target, percentage, bar, then a line under. */
export function Progress({ actual, target, pct, tone, under }: { actual: number; target: number | null; pct: number | null; tone: string; under?: string }) {
  return (
    <div className="flex min-w-36 flex-col gap-1">
      <span className="flex items-baseline gap-1.5">
        <span className="font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{whole(actual)}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>of {target == null ? "-" : whole(target)}</span>
        <span className="ml-auto text-xs font-medium tabular-nums" style={{ color: "var(--text-secondary)" }}>{pctText(pct)}</span>
      </span>
      <span className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: tone }} />
      </span>
      {under && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{under}</span>}
    </div>
  );
}

/** The two bottom boxes, wording from the mockup. */
export function Boxes({ happened, next }: { happened: ReactNode[]; next: ReactNode[] }) {
  return (
    <section className="grid grid-cols-1 gap-3 md:grid-cols-2">
      <div className="rounded-xl border p-4" style={CARD}>
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>What already happened</h3>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>Results for this period</p>
        <ul className="mt-3 flex flex-col gap-2 text-sm" style={{ color: "var(--text-primary)" }}>
          {happened.map((h, i) => <li key={i} className="flex gap-2"><span aria-hidden className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: "var(--text-muted)" }} />{h}</li>)}
        </ul>
      </div>
      <div className="rounded-xl border p-4" style={{ background: "#fff7ee", borderColor: "#f3d9bf" }}>
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>What to do next</h3>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>Early warnings, and what they mean for next month</p>
        <ul className="mt-3 flex flex-col gap-2 text-sm" style={{ color: "var(--text-primary)" }}>
          {next.map((h, i) => <li key={i} className="flex gap-2"><span aria-hidden className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: "var(--accent)" }} />{h}</li>)}
        </ul>
      </div>
    </section>
  );
}

export type Col<T> = {
  key: string;
  header: ReactNode;
  right?: boolean;
  cell: (row: T) => ReactNode;
  /** On phones: the first column is the card title; 'hide' drops it; anything else shows as a labelled fact. */
  mobile?: "title" | "hide";
  mobileLabel?: string;
  /** The value the column sorts on. A column without one does not sort. Nulls sink to the bottom either way. */
  sort?: (row: T) => number | string | null;
  /** The value the Copy table button writes for this column; falls back to `sort`. */
  copy?: (row: T) => Cell;
  /** The header the copy writes when `header` is not plain text. */
  copyHeader?: string;
  /** A shared header over a run of columns, as in the People table's Masons and CSOs groups. */
  group?: string;
};

type SortState = { key: string; dir: "asc" | "desc" } | null;

const headerText = <T,>(c: Col<T>): string => c.copyHeader ?? c.mobileLabel ?? (typeof c.header === "string" ? c.header : c.key);

/**
 * A table on wide screens, stacked cards below md. Never scrolls sideways.
 * Every column with a `sort` sorts on a header click, again to reverse, a
 * third time back to the table's own order; on phones the same choice is a
 * select above the cards. The Copy table button puts the table on the
 * clipboard as tab-separated text, headers included, for Sheets or Excel.
 * `mark` puts the clay rule and the Focus tag on a row.
 */
export function DataTable<T>({ rows, cols, keyOf, mark, markLabel = "Focus", note, empty = "Nothing to show for this period.", onRow, selectedKey, copyName, toolbar, pageSize }: {
  rows: T[];
  cols: Col<T>[];
  keyOf: (row: T) => string;
  mark?: (row: T) => boolean;
  markLabel?: string;
  note?: ReactNode;
  empty?: string;
  onRow?: (row: T) => void;
  selectedKey?: string | null;
  /** What the copy button calls the table in its confirmation. */
  copyName?: string;
  /** Anything else to show in the toolbar row, left of the copy button. */
  toolbar?: ReactNode;
  /** Rows per page for a long list; sorting runs over every row, the copy takes them all. */
  pageSize?: number;
}) {
  const [sort, setSort] = useState<SortState>(null);
  const [page, setPage] = useState(0);
  const [copied, setCopied] = useState<"ok" | "fail" | null>(null);
  const title = cols.find((c) => c.mobile === "title") ?? cols[0];
  const facts = cols.filter((c) => c !== title && c.mobile !== "hide");
  const sortable = cols.filter((c) => c.sort);
  const copyCols = cols.filter((c) => c.copy || c.sort);
  const hasGroups = cols.some((c) => c.group);

  const sorted = useMemo(() => {
    if (!sort) return rows;
    const col = cols.find((c) => c.key === sort.key);
    if (!col?.sort) return rows;
    const f = col.sort;
    const dir = sort.dir === "asc" ? 1 : -1;
    return rows.map((r, i) => ({ r, i, v: f(r) })).sort((a, b) => {
      if (a.v == null && b.v == null) return a.i - b.i;
      if (a.v == null) return 1;
      if (b.v == null) return -1;
      const c = typeof a.v === "number" && typeof b.v === "number" ? a.v - b.v : String(a.v).localeCompare(String(b.v));
      return c === 0 ? a.i - b.i : c * dir;
    }).map((x) => x.r);
  }, [rows, cols, sort]);

  function clickSort(c: Col<T>) {
    if (!c.sort) return;
    setSort((cur) => {
      // Numbers start high to low (the end that needs attention); words start A to Z.
      const first: "asc" | "desc" = rows.some((r) => typeof c.sort!(r) === "number") ? "desc" : "asc";
      if (!cur || cur.key !== c.key) return { key: c.key, dir: first };
      if (cur.dir === first) return { key: c.key, dir: first === "asc" ? "desc" : "asc" };
      return null;
    });
  }

  async function copy() {
    const headers = copyCols.map(headerText);
    const body: Cell[][] = sorted.map((r) => copyCols.map((c) => (c.copy ? c.copy(r) : c.sort ? c.sort(r) : "")));
    const ok = await copyForSheets(headers, body);
    setCopied(ok ? "ok" : "fail");
    setTimeout(() => setCopied(null), 2500);
  }

  const arrow = (c: Col<T>) => (sort?.key === c.key ? (sort.dir === "asc" ? " ↑" : " ↓") : "");
  const pages = pageSize ? Math.max(1, Math.ceil(sorted.length / pageSize)) : 1;
  const pageAt = Math.min(page, pages - 1);
  const shown = pageSize ? sorted.slice(pageAt * pageSize, pageAt * pageSize + pageSize) : sorted;
  const groupRuns = useMemo(() => {
    const runs: { label: string; span: number }[] = [];
    for (const c of cols) {
      const label = c.group ?? "";
      const last = runs[runs.length - 1];
      if (last && last.label === label) last.span += 1; else runs.push({ label, span: 1 });
    }
    return runs;
  }, [cols]);

  return (
    <div className="overflow-hidden rounded-xl border" style={CARD}>
      {(copyCols.length > 0 || toolbar) && (
        <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2" style={{ borderColor: "var(--grid)" }}>
          {toolbar}
          {sortable.length > 0 && (
            <label className="flex items-center gap-1.5 text-xs md:hidden" style={{ color: "var(--text-muted)" }}>
              Sort
              <select value={sort ? `${sort.key}|${sort.dir}` : ""} onChange={(e) => { const [k, d] = e.target.value.split("|"); setSort(k ? { key: k, dir: d as "asc" | "desc" } : null); }}
                className="min-h-11 rounded-md border px-2 py-1 text-sm" style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
                <option value="">Table order</option>
                {sortable.flatMap((c) => [
                  <option key={`${c.key}|desc`} value={`${c.key}|desc`}>{headerText(c)}, high to low</option>,
                  <option key={`${c.key}|asc`} value={`${c.key}|asc`}>{headerText(c)}, low to high</option>,
                ])}
              </select>
            </label>
          )}
          <span className="ml-auto flex items-center gap-2">
            {copied === "ok" && <span className="text-xs" style={{ color: "var(--good)" }}>Copied{copyName ? ` ${copyName}` : ""}, paste into a sheet</span>}
            {copied === "fail" && <span className="text-xs" style={{ color: "var(--critical)" }}>Copy failed, use Download CSV</span>}
            {copyCols.length > 0 && (
              <button type="button" onClick={copy} className="min-h-11 rounded-md border px-2.5 py-1 text-xs font-medium sm:min-h-0"
                style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-secondary)" }}>
                Copy table
              </button>
            )}
          </span>
        </div>
      )}

      <table className="hidden w-full text-sm md:table print:table">
        <thead>
          {hasGroups && (
            <tr style={{ color: "var(--text-muted)", borderBottom: "1px solid var(--grid)" }}>
              {groupRuns.map((g, i) => (
                <th key={i} colSpan={g.span} className="px-3 pt-2 pb-1 text-center text-[11px] font-semibold uppercase tracking-wider">{g.label}</th>
              ))}
            </tr>
          )}
          <tr style={{ color: "var(--text-muted)", borderBottom: "1px solid var(--border)" }}>
            {cols.map((c) => (
              <th key={c.key} className={`px-3 py-2.5 text-xs font-medium ${c.right ? "text-right" : "text-left"}`}
                aria-sort={sort?.key === c.key ? (sort.dir === "asc" ? "ascending" : "descending") : undefined}>
                {c.sort ? (
                  <button type="button" onClick={() => clickSort(c)} className={`${c.right ? "text-right" : "text-left"} hover:underline underline-offset-2`}
                    style={{ color: sort?.key === c.key ? "var(--text-primary)" : "inherit", fontWeight: sort?.key === c.key ? 600 : 500 }} title="Sort on this column">
                    {c.header}{arrow(c)}
                  </button>
                ) : c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {shown.map((r) => {
            const k = keyOf(r);
            const marked = mark?.(r) ?? false;
            return (
              <tr key={k} onClick={onRow ? () => onRow(r) : undefined}
                style={{
                  borderTop: "1px solid var(--grid)", cursor: onRow ? "pointer" : undefined,
                  boxShadow: marked ? "inset 3px 0 0 var(--critical)" : "none",
                  background: selectedKey === k ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)" : "transparent",
                }}>
                {cols.map((c) => (
                  <td key={c.key} className={`px-3 py-2.5 align-top ${c.right ? "text-right tabular-nums" : "text-left"}`}>
                    {c.cell(r)}
                    {c === title && marked && (
                      <span className="ml-1.5 rounded px-1.5 py-px align-top text-[11px] font-semibold"
                        style={{ background: "color-mix(in srgb, var(--critical) 14%, transparent)", color: "var(--critical)" }}>{markLabel}</span>
                    )}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="flex flex-col md:hidden print:hidden">
        {shown.map((r) => {
          const k = keyOf(r);
          const marked = mark?.(r) ?? false;
          return (
            <div key={k} onClick={onRow ? () => onRow(r) : undefined} className="border-t p-4"
              style={{
                borderColor: "var(--grid)", boxShadow: marked ? "inset 3px 0 0 var(--critical)" : "none",
                background: selectedKey === k ? "color-mix(in srgb, var(--accent-strong) 7%, transparent)" : "transparent",
              }}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">{title.cell(r)}</div>
                {marked && (
                  <span className="shrink-0 rounded px-1.5 py-px text-[11px] font-semibold"
                    style={{ background: "color-mix(in srgb, var(--critical) 14%, transparent)", color: "var(--critical)" }}>{markLabel}</span>
                )}
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                {facts.map((c) => (
                  <div key={c.key} className="flex items-start justify-between gap-2">
                    <dt className="text-xs" style={{ color: "var(--text-muted)" }}>{c.group ? `${c.group} · ` : ""}{c.mobileLabel ?? (typeof c.header === "string" ? c.header : c.key)}</dt>
                    <dd className="text-right">{c.cell(r)}</dd>
                  </div>
                ))}
              </dl>
            </div>
          );
        })}
      </div>

      {rows.length === 0 && <p className="p-8 text-center text-sm" style={{ color: "var(--text-muted)" }}>{empty}</p>}
      {pageSize && pages > 1 && (
        <div className="flex flex-wrap items-center gap-2 border-t px-3 py-2" style={{ borderColor: "var(--grid)" }}>
          <button type="button" onClick={() => setPage(Math.max(0, pageAt - 1))} disabled={pageAt === 0}
            className="min-h-11 rounded-md border px-2.5 py-1 text-sm disabled:opacity-40 sm:min-h-0"
            style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-secondary)" }}>Previous</button>
          <span className="text-sm tabular-nums" style={{ color: "var(--text-secondary)" }}>
            {whole(pageAt * pageSize + 1)} to {whole(pageAt * pageSize + shown.length)} of {whole(sorted.length)}
          </span>
          <button type="button" onClick={() => setPage(Math.min(pages - 1, pageAt + 1))} disabled={pageAt >= pages - 1}
            className="min-h-11 rounded-md border px-2.5 py-1 text-sm disabled:opacity-40 sm:min-h-0"
            style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-secondary)" }}>Next</button>
        </div>
      )}
      {note && <p className="border-t px-3 py-2.5 text-xs" style={{ color: "var(--text-muted)", borderColor: "var(--grid)" }}>{note}</p>}
    </div>
  );
}

export function Chip({ label, count, on, color, onClick }: { label: string; count?: number; on: boolean; color: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick}
      className="flex min-h-11 items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs font-medium sm:min-h-0"
      style={{
        borderColor: on ? color : "var(--border)",
        background: on ? `color-mix(in srgb, ${color} 12%, var(--surface))` : "var(--surface)",
        color: "var(--text-primary)",
      }}>
      <span className="h-2 w-2 rounded-full" style={{ background: color }} />
      {label}
      {count != null && <span className="tabular-nums" style={{ color: "var(--text-muted)" }}>{whole(count)}</span>}
    </button>
  );
}

export function Toggle({ options, value, onChange }: { options: { key: string; label: string }[]; value: string; onChange: (k: string) => void }) {
  return (
    <div className="inline-flex rounded-md border p-0.5" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      {options.map((o) => {
        const on = o.key === value;
        return (
          <button key={o.key} type="button" onClick={() => onChange(o.key)} aria-pressed={on}
            className="min-h-11 rounded px-2.5 py-1 text-sm font-medium sm:min-h-0"
            style={{ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" }}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

export function Select({ label, value, options, onChange, optionLabel }: {
  label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string;
}) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}

/** The five-pill form guide of the individual CSO page: percentage per window, the current one outlined. */
export function FormPills({ pills, size = 5 }: { pills: { key: string; label: string; pct: number | null; muted?: boolean }[]; size?: number }) {
  if (pills.length === 0) return <span className="text-xs" style={{ color: "var(--text-muted)" }}>no history</span>;
  const pad = Math.max(0, size - pills.length);
  return (
    <span className="flex items-center gap-1">
      {Array.from({ length: pad }).map((_, i) => (
        <span key={`pad${i}`} className="grid h-5 min-w-9 place-items-center rounded px-1 text-[11px] font-semibold"
          style={{ background: "var(--border)", color: "var(--text-muted)" }}>·</span>
      ))}
      {pills.map((p, i) => {
        const tone = p.muted || p.pct == null ? "none" : toneOf(p.pct);
        return (
          <span key={p.key} title={`${p.label}: ${p.pct == null ? "no data" : `${pctText(p.pct)} of target`}`}
            className="grid h-5 min-w-9 place-items-center rounded px-1 text-[11px] font-semibold tabular-nums"
            style={{
              background: tone === "none" ? "var(--border)" : TONE_COLOR[tone],
              color: tone === "none" ? "var(--text-muted)" : "#fff",
              outline: i === pills.length - 1 ? "2px solid var(--text-primary)" : "none",
              outlineOffset: "1px",
            }}>
            {p.pct == null ? "·" : pctText(p.pct)}
          </span>
        );
      })}
    </span>
  );
}

/** A small tag beside a name or a standing. */
export function Tag({ children, color }: { children: ReactNode; color?: string }) {
  return (
    <span className="rounded px-1.5 py-0.5 text-[11px]" style={{ border: "1px solid var(--border)", color: color ?? "var(--text-secondary)" }}>{children}</span>
  );
}

/** Empty or loading state line. */
export function Muted({ children }: { children: ReactNode }) {
  return <p className="text-sm" style={{ color: "var(--text-muted)" }}>{children}</p>;
}
