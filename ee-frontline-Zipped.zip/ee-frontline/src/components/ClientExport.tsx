"use client";

import { useState } from "react";
import ExportButtons from "@/components/ExportButtons";
import { stamp, type Cell } from "@/lib/export";
import { BUCKETS, bucketLabel, fmtInt, stageName } from "@/lib/format";
import type { ClientRow } from "@/lib/data";

const CURRENCY: Record<string, string> = { Rwanda: "RWF", Uganda: "UGX", Kenya: "KES" };
import { PRODUCT_LABEL } from "@/lib/journey-flow-shared";

/** Excel caps tab names at 31 characters and bans : \ / ? * [ ]; the two pre-2026 labels are too long. */
const SHORT_TAB: Record<string, string> = {
  "1": "Signed, not collected pre-2026",
  "2": "Collected, unfinished pre-2026",
};
const tabName = (key: string) =>
  (SHORT_TAB[key.charAt(0)] ?? bucketLabel(key)).replace(/[:\\/?*[\]]/g, " ").slice(0, 31);

/** Excel column widths in characters, in header order. */
const WIDTHS = [26, 16, 15, 22, 9, 12, 12, 16, 15, 10, 9, 28, 36, 8, 11, 7, 13, 15, 14, 9, 11, 14, 12];

/**
 * Export for the customer journey client list: exactly the clients on screen
 * (the chosen territory or branch, the search, and a selected column if any),
 * using the values the view already holds. Formatting only; nothing is derived.
 */
export default function ClientExport({ clients, country, location, column }: {
  clients: ClientRow[];
  country: string;
  location: string;
  column: string | null;
}) {
  const [busy, setBusy] = useState(false);
  const cur = CURRENCY[country] ?? "local currency";
  const headers = [
    "Customer", "Opportunity", "Phone", "CSO", "Country", "Branch", "District", "Territory",
    "Product", "Size (m²)", "SQM-E", "Board column", "Journey stage", "Days in stage", "Signed date",
    "% paid", `Cash paid (${cur})`, `Contract value (${cur})`, `Outstanding (${cur})`, "Nothing paid yet",
    "Materials available", "Materials confirmed date", "Queue owner",
  ];
  const rowFor = (c: ClientRow): Cell[] => [
    c.customer_name ?? "", c.opportunity_label ?? "", c.phone ?? "", c.cso_name ?? "",
    c.country, c.branch, c.district ?? "", c.territory,
    PRODUCT_LABEL[c.product_family] ?? c.product_family, c.raw_sqm, c.sqme, bucketLabel(c.app_bucket), stageName(c.journey_stage), c.days_in_stage, c.signed_date ?? "",
    c.pct_paid == null ? "" : Math.round(c.pct_paid * 100),
    Math.round(c.cash_paid), Math.round(c.total_amount), Math.round(c.outstanding_amount),
    c.is_zero_paid ? "Yes" : "No",
    c.materials_available ? "Yes" : "No", c.materials_confirmed_date ?? "", c.queue_owner ?? "",
  ];
  const rows = clients.map(rowFor);

  const slug = (s: string) => s.replace(/[^A-Za-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const filename = `journey_${slug(country)}_${slug(location)}${column ? `_${slug(bucketLabel(column))}` : ""}_${stamp()}`;

  // A CSV cannot hold tabs, so this writes an Excel file instead: every client on
  // one tab, then a tab per board column. The library loads only on click.
  async function downloadExcel() {
    setBusy(true);
    try {
      const { default: writeExcelFile } = await import("write-excel-file/universal");
      const header = headers.map((h) => ({ value: h, fontWeight: "bold" as const }));
      const columns = WIDTHS.map((width) => ({ width }));
      const tab = (sheet: string, list: ClientRow[]) => ({
        data: [header, ...list.map((c) => rowFor(c).map((v) => (v === "" || v == null ? null : v)))],
        sheet,
        columns,
        stickyRowsCount: 1,
      });
      const sheets = [
        tab("All clients", clients),
        ...BUCKETS.filter((b) => clients.some((c) => c.app_bucket === b.key))
          .map((b) => tab(tabName(b.key), clients.filter((c) => c.app_bucket === b.key))),
      ];
      const blob = await writeExcelFile(sheets).toBlob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${filename}.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-wrap items-center justify-between gap-2">
      <span className="text-sm" style={{ color: "var(--text-secondary)" }}>
        {fmtInt(clients.length)} {clients.length === 1 ? "client" : "clients"} in view
        {column ? ` · ${bucketLabel(column)}` : ""}
      </span>
      <div className="flex flex-wrap items-center gap-2">
        <ExportButtons filename={filename} headers={headers} rows={rows} />
        <button type="button" onClick={downloadExcel} disabled={busy}
          className="min-h-11 rounded-md border px-3 py-1.5 text-sm font-medium sm:min-h-0"
          style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)", opacity: busy ? 0.6 : 1 }}>
          {busy ? "Preparing Excel…" : "Download Excel (tab per stage)"}
        </button>
      </div>
    </div>
  );
}
