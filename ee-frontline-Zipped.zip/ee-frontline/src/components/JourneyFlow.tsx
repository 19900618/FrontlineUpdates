"use client";

import { useEffect, useMemo, useState } from "react";
import { fmtInt } from "@/lib/format";
import {
  CEILING_OPTION, COHORT_START, PRODUCT_OPTIONS, STEPS, addDays, daysInclusive, defaultWindow, flowQueryString, fmtDay, fmtRange,
  isWholePeriod, relativeName, shiftPeriod, stepOf, trendPeriods, windowFor,
  type Cohort, type FlowPick, type FlowQuery, type FlowRow, type FlowSummary, type Gran, type MoveTotal, type Product,
} from "@/lib/journey-flow-shared";
import FlowRiver from "./FlowRiver";
import Spinner from "./Spinner";
import FlowTrends from "./FlowTrends";
import FlowTable from "./FlowTable";

const COUNTRY_ORDER = ["Rwanda", "Uganda", "Kenya"];
const BEFORE: Record<Gran, string> = { day: "the day before", week: "the week before", month: "the month before" };
const NO_ROWS: FlowRow[] = [];

async function getJson<T>(url: string): Promise<T> {
  const r = await fetch(url);
  const d = await r.json();
  if (!r.ok) throw new Error(d.error ?? `HTTP ${r.status}`);
  return d as T;
}
const message = (e: unknown) => (e instanceof Error ? e.message : String(e));

/**
 * Customer journey flow. The static journey page shows where customers are; this one
 * shows who moved, and when. One set of filters drives three views that stay in step:
 * the flow chart (the period at a glance), the trend charts (is it getting better) and
 * the customer list (who exactly). Tapping anything narrows the list below it.
 */
export default function JourneyFlow({ locations, initialQuery, initialSummary, today, syncNote }: {
  locations: Record<string, string[]>;
  initialQuery: FlowQuery;
  initialSummary: FlowSummary;
  today: string;
  syncNote: string;
}) {
  const countries = COUNTRY_ORDER.filter((c) => c in locations);
  const [q, setQ] = useState<FlowQuery>(initialQuery);
  const [pick, setPick] = useState<FlowPick>(null);

  const qs = flowQueryString(q);
  const initialQs = flowQueryString(initialQuery);

  // ---- summary (flow chart + trends) ----
  // Each answer is stored with the query it answers, so "loading" is simply "the latest
  // answer is for a different query" and the previous numbers stay on screen, dimmed.
  const [res, setRes] = useState<{ qs: string; summary?: FlowSummary; error?: string } | null>(null);
  useEffect(() => {
    if (qs === initialQs) return;
    let cancelled = false;
    getJson<FlowSummary>(`/api/journey-flow?${qs}`)
      .then((summary) => { if (!cancelled) setRes({ qs, summary }); })
      .catch((e: unknown) => { if (!cancelled) setRes((cur) => ({ qs, summary: cur?.summary, error: message(e) })); });
    return () => { cancelled = true; };
  }, [qs, initialQs]);
  const summary = qs === initialQs ? initialSummary : res?.summary ?? initialSummary;
  const loading = qs !== initialQs && res?.qs !== qs;
  const error = qs !== initialQs && res?.qs === qs ? res.error ?? null : null;

  // ---- the customers behind the numbers ----
  // One list per period holds every move, and tapping a movement filters it in place, so
  // taps are instant. Only when a period has more moves than one list holds does a tap go
  // back to the server for that movement's own list.
  type List = { key: string; rows: FlowRow[]; truncated: boolean; error?: string };
  const [base, setBase] = useState<List | null>(null);
  useEffect(() => {
    let cancelled = false;
    getJson<{ rows: FlowRow[]; truncated: boolean }>(`/api/journey-flow/rows?${qs}&to=0&from=-1`)
      .then((d) => { if (!cancelled) setBase({ key: qs, ...d }); })
      .catch((e: unknown) => { if (!cancelled) setBase({ key: qs, rows: NO_ROWS, truncated: false, error: message(e) }); });
    return () => { cancelled = true; };
  }, [qs]);
  const baseReady = base?.key === qs;
  const needOwnList = !!base && baseReady && base.truncated && pick != null;
  const pickKey = pick ? `${qs}&to=${pick.to}&from=${pick.from ?? -1}` : "";
  const [own, setOwn] = useState<List | null>(null);
  useEffect(() => {
    if (!needOwnList) return;
    let cancelled = false;
    getJson<{ rows: FlowRow[]; truncated: boolean }>(`/api/journey-flow/rows?${pickKey}`)
      .then((d) => { if (!cancelled) setOwn({ key: pickKey, ...d }); })
      .catch((e: unknown) => { if (!cancelled) setOwn({ key: pickKey, rows: NO_ROWS, truncated: false, error: message(e) }); });
    return () => { cancelled = true; };
  }, [needOwnList, pickKey]);

  const list = useMemo(() => {
    if (needOwnList) {
      return own?.key === pickKey
        ? { rows: own.rows, truncated: own.truncated, loading: false, error: own.error ?? null }
        : { rows: NO_ROWS, truncated: false, loading: true, error: null };
    }
    const all = base?.rows ?? NO_ROWS;
    const rows = pick ? all.filter((r) => r.to_key === pick.to && (pick.from == null || (r.from_key ?? 0) === pick.from)) : all;
    return { rows, truncated: base?.truncated ?? false, loading: !baseReady, error: baseReady ? base?.error ?? null : null };
  }, [needOwnList, own, pickKey, base, baseReady, pick]);

  // ---- controls ----
  const update = (patch: Partial<FlowQuery>) => setQ((cur) => ({ ...cur, ...patch }));
  const whole = isWholePeriod(q.gran, q.start, q.end);
  const pickGran = (g: Gran) => update({ gran: g, ...defaultWindow(g, today) });
  function step(dir: -1 | 1) {
    if (whole) return update(windowFor(q.gran, shiftPeriod(q.gran, q.start, dir)));
    const len = daysInclusive(q.start, q.end);
    update({ start: addDays(q.start, dir * len), end: addDays(q.end, dir * len) });
  }
  function setDates(start: string, end: string) {
    if (!start || !end) return;
    update(start <= end ? { start, end } : { start: end, end: start });
  }
  // Ceiling plaster is sold in Uganda only, so leaving Uganda drops that filter.
  const pickCountry = (c: string) =>
    update({ country: c, dim: c === "Rwanda" ? "territory" : "branch", loc: "",
      product: q.product === "ceiling plaster" && c !== "Uganda" ? "all" : q.product });
  const select = (to: number, from: number | null) =>
    setPick((cur) => (cur && cur.to === to && cur.from === from ? null : { to, from }));

  // ---- labels ----
  const rel = relativeName(q.gran, q.start, q.end, today);
  const range = fmtRange(q.start, q.end);
  const windowTitle = rel ? `${rel}, ${range}` : range;
  const before = whole ? BEFORE[q.gran] : `the ${daysInclusive(q.start, q.end)} days before`;
  const filling = q.end >= addDays(today, -3);
  const periods = trendPeriods(q.gran, today, q.cohort);
  const locLabel = q.dim === "branch" ? "Branch" : "Territory";
  const slug = (s: string) => s.replace(/[^A-Za-z0-9]+/g, "-").replace(/^-|-$/g, "");
  const pickName = pick ? (pick.from != null ? `${stepOf(pick.from)?.short}-to-${stepOf(pick.to)?.short}` : stepOf(pick.to)?.short ?? "") : "all-moves";
  const filenameBase = `journey-flow_${slug(q.country)}_${slug(q.loc || "all")}_${q.start}_to_${q.end}_${slug(pickName)}`;

  return (
    <div className="mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6">
      <header className="flex flex-col gap-1">
        <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>Customer journey flow</h1>
        <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
          Who moved forward in the customer journey, and when. Pick a period, then tap any arrow or number to see the customers.
        </p>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>{syncNote}</p>
      </header>

      {/* ---- filters ---- */}
      <section className="flex flex-col gap-3 rounded-lg border p-3 sm:p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          <Segmented label="Period" value={q.gran} onChange={pickGran}
            options={[["day", "Day"], ["week", "Week"], ["month", "Month"]]} />
          <div className="flex w-full items-center gap-1 sm:w-auto">
            <StepButton label="Previous period" onClick={() => step(-1)}>‹</StepButton>
            <span className="min-w-0 flex-1 px-1 text-center text-sm font-semibold sm:min-w-56" style={{ color: "var(--text-primary)" }}>
              {windowTitle}
            </span>
            <StepButton label="Next period" disabled={q.end >= today} onClick={() => step(1)}>›</StepButton>
          </div>
          <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto">
            <DateInput label="From" value={q.start} min={COHORT_START[q.cohort]} max={today} onChange={(v) => setDates(v, q.end)} />
            <DateInput label="To" value={q.end} min={COHORT_START[q.cohort]} max={today} onChange={(v) => setDates(q.start, v)} />
            {!whole && <span className="rounded-full px-2 py-0.5 text-xs" style={{ background: "var(--page)", color: "var(--text-secondary)" }}>Custom dates</span>}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          <Select label="Country" value={q.country} options={countries} onChange={pickCountry} />
          <Select label={locLabel} value={q.loc} options={["", ...(locations[q.country] ?? [])]}
            optionLabel={(v) => (v === "" ? `All ${locLabel.toLowerCase() === "branch" ? "branches" : "territories"}` : v)}
            onChange={(v) => update({ loc: v })} />
          <Segmented<Product> label="Product" value={q.product} onChange={(v) => update({ product: v })}
            options={q.country === "Uganda" ? [...PRODUCT_OPTIONS, CEILING_OPTION] : PRODUCT_OPTIONS} />
          <Segmented<Cohort> label="Contracts" value={q.cohort} onChange={(v) => update({ cohort: v, start: q.start < COHORT_START[v] ? COHORT_START[v] : q.start })}
            options={[["2026", "Signed in 2026"], ["all", "Since 2024"]]} />
        </div>
      </section>

      {error && (
        <p className="rounded-md border p-3 text-sm" style={{ borderColor: "var(--critical)", color: "var(--critical)", background: "var(--surface)" }}>
          Couldn&apos;t load the numbers: {error}
        </p>
      )}

      {/* ---- the period at a glance ---- */}
      <section className="flex flex-col gap-4 rounded-lg border p-4 sm:p-5"
        style={{ background: "var(--surface)", borderColor: "var(--border)", opacity: loading ? 0.55 : 1, transition: "opacity .15s" }}>
        <Headline totals={summary.totals} title={windowTitle} loading={loading} pick={pick} onSelect={select} />
        <FlowRiver summary={summary} pick={pick} onSelect={select} endLabel={fmtDay(q.end)} before={before} />
        <div className="flex flex-col gap-1 text-xs" style={{ color: "var(--text-muted)" }}>
          <span>
            <b style={{ color: "var(--text-secondary)" }}>How to read it:</b> arrows are customers who moved during the period, and
            the thicker the arrow the more customers. Boxes are customers still waiting at that step on {fmtDay(q.end)}.
            ▲ and ▼ compare with {before}. Arcs over the top are customers who jumped a step.
          </span>
          {filling && <span>The last few days are still filling in: teams often enter dates in Salesforce a few days late.</span>}
          {summary.latest && <span>Latest movement recorded in {q.country}: {fmtDay(summary.latest)}.</span>}
          <details className="mt-1">
            <summary className="cursor-pointer" style={{ color: "var(--accent-ink)" }}>How each step is dated</summary>
            <ul className="mt-1 flex flex-col gap-0.5 pl-4">
              {STEPS.map((s) => (
                <li key={s.key} className="list-disc"><b style={{ color: "var(--text-secondary)" }}>{s.name}:</b> {s.hint}</li>
              ))}
              <li className="list-disc">A job moves forward only. A step reached after a later one (for example paid after the build started) is not counted as a move.</li>
              <li className="list-disc">Dates in the future, and start or payment dates from before the contract was signed, are ignored.</li>
            </ul>
          </details>
        </div>
      </section>

      <div style={{ opacity: loading ? 0.55 : 1, transition: "opacity .15s" }}>
        <FlowTrends trend={summary.trend} totals={summary.totals} periods={periods} gran={q.gran} today={today}
          start={q.start} end={q.end} pick={pick}
          onPickPeriod={(p) => update(windowFor(q.gran, p))} onSelect={(to) => select(to, null)} />
      </div>

      <FlowTable rows={list.rows} truncated={list.truncated} loading={list.loading} error={list.error}
        totals={summary.totals} pick={pick} onPick={(to) => select(to, null)} onClear={() => setPick(null)}
        windowTitle={windowTitle} dim={q.dim} filenameBase={filenameBase} />
    </div>
  );
}

/** The period in one line of big numbers, before any chart. Each number opens its customers. */
function Headline({ totals, title, loading, pick, onSelect }: {
  totals: MoveTotal[];
  title: string;
  loading: boolean;
  pick: FlowPick;
  onSelect: (to: number, from: number | null) => void;
}) {
  const n = (k: number) => totals.find((t) => t.to === k)?.n ?? 0;
  const items: [number, string][] = [
    [1, "contracts signed"],
    [2, "paid enough to build"],
    [4, "builds started"],
    [5, "varnish or paint deliveries"],
    [6, "jobs completed"],
    [9, "lost"],
  ];
  return (
    <div className="flex flex-col gap-2">
      <h2 className="flex flex-wrap items-center gap-2 text-sm font-semibold" style={{ color: "var(--text-secondary)" }}>
        {title}
        {loading && <span style={{ color: "var(--accent-strong)" }}><Spinner size={14} label="updating" /></span>}
      </h2>
      {/* On phones the vertical flow below already leads with these numbers. */}
      <div className="hidden flex-wrap gap-x-6 gap-y-2 min-[901px]:flex">
        {items.map(([k, text]) => {
          const on = !pick || pick.to === k;
          return (
            <button key={k} type="button" onClick={() => onSelect(k, null)}
              className="flex items-baseline gap-1.5 rounded-md text-left" style={{ opacity: on ? 1 : 0.4 }}>
              <span className="h-2.5 w-2.5 shrink-0 self-center rounded-full" style={{ background: stepOf(k)?.color }} />
              <span className="text-2xl font-semibold tabular-nums" style={{ color: k === 9 ? "var(--text-secondary)" : "var(--text-primary)" }}>
                {fmtInt(n(k))}
              </span>
              <span className="text-sm" style={{ color: "var(--text-secondary)" }}>{text}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function Segmented<T extends string>({ label, value, options, onChange }: {
  label: string;
  value: T;
  options: [T, string][];
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex w-full items-center gap-2 sm:w-auto">
      <span className="shrink-0 text-sm" style={{ color: "var(--text-muted)" }}>{label}</span>
      <div className="flex flex-1 overflow-hidden rounded-md border sm:flex-none" style={{ borderColor: "var(--border)" }} role="group" aria-label={label}>
        {options.map(([v, text]) => {
          const on = v === value;
          return (
            <button key={v} type="button" onClick={() => onChange(v)} aria-pressed={on}
              className="min-h-11 flex-1 whitespace-nowrap px-3 py-1.5 text-sm sm:min-h-0 sm:flex-none"
              style={{ background: on ? "var(--accent-strong)" : "var(--surface)", color: on ? "#fff" : "var(--text-secondary)", fontWeight: on ? 600 : 400 }}>
              {text}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function StepButton({ label, onClick, disabled, children }: { label: string; onClick: () => void; disabled?: boolean; children: React.ReactNode }) {
  return (
    <button type="button" aria-label={label} title={label} onClick={onClick} disabled={disabled}
      className="grid min-h-11 w-11 place-items-center rounded-md border text-lg sm:min-h-0 sm:h-8 sm:w-8"
      style={{ borderColor: "var(--border)", background: "var(--surface)", color: "var(--text-secondary)", opacity: disabled ? 0.35 : 1 }}>
      {children}
    </button>
  );
}

function DateInput({ label, value, min, max, onChange }: { label: string; value: string; min: string; max: string; onChange: (v: string) => void }) {
  return (
    <label className="flex flex-1 items-center gap-1.5 text-sm sm:flex-none" style={{ color: "var(--text-muted)" }}>
      {label}
      <input type="date" value={value} min={min} max={max} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full rounded-md border px-2 py-1 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
    </label>
  );
}

function Select({ label, value, options, onChange, optionLabel }: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
  optionLabel?: (v: string) => string;
}) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => (
          <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>
        ))}
      </select>
    </label>
  );
}
