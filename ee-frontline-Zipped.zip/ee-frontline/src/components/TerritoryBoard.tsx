"use client";

import { useEffect, useMemo, useState } from "react";
import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import type { TerritoryData, TerritoryRow, TerritoryBuild, BuildFilter } from "@/lib/territory";
import type { Period as LeadsPeriod } from "@/lib/leads-period";
import { fmtInt } from "@/lib/format";
import { stamp, type Cell } from "@/lib/export";
import { SERIES_COLL, SERIES_SALES, unitWord } from "@/lib/workspace-ui";
import Spinner from "@/components/Spinner";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { Chip, DataTable, Kpi, type Col } from "@/components/ws/primitives";

const TL = SERIES_COLL;
const LATE = "var(--critical)";

/** Which slice of a territory's builds the panel is listing. */
const SLICES: { key: BuildFilter; label: string }[] = [
  { key: "not-started", label: "Not started" },
  { key: "in-progress", label: "In progress" },
  { key: "pending", label: "Pending evaluation or stock movement" },
];

const pct = (a: number, b: number): number | null => (b > 0 ? a / b : null);
const pctText = (v: number | null): string => (v == null ? "-" : `${Math.round(v * 100)}%`);
const band = (v: number | null): string =>
  v == null ? "var(--text-muted)" : v >= 0.95 ? "var(--good)" : v >= 0.85 ? "var(--warning)" : "var(--critical)";
const fmtK = (n: number): string => (Math.abs(n) >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : Math.abs(n) >= 1e3 ? `${Math.round(n / 1e3)}K` : String(Math.round(n)));

/**
 * Every territory in the country, what it is carrying and what is stuck:
 * scorecards, then one row per territory with the most late to finish first,
 * then the scoped territory opened under the table with the builds behind it.
 * The scope in the filter bar narrows the list and opens the panel.
 */
export default function TerritoryBoard(props: {
  country: CapacityCountry; slug: string; calendar: CapacityWeek[]; years: number[]; userEmail: string | null; freshness: string;
  /** The country's territories or branches, for the filter bar's dropdown. */
  units: string[];
  leads: LeadsPeriod; data: TerritoryData;
}) {
  const { country, slug, calendar, years, userEmail, freshness } = props;
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} years={years} userEmail={userEmail} freshness={freshness} navigate="all" weekMode="single" units={props.units}>
      {(s) => <Body s={s} leads={props.leads} data={props.data} />}
    </WorkspaceShell>
  );
}

function Body({ s, leads, data }: { s: WsState; leads: LeadsPeriod; data: TerritoryData }) {
  const { country, scope } = s;
  const rwanda = country === "Rwanda";
  const unitTitle = rwanda ? "Territory" : "Branch";

  const rows = useMemo(() => {
    const list = data.rows.filter((r) => !scope
      || (scope.level === "territory" ? r.territory === scope.name : r.branch === scope.name || r.territory === scope.name));
    // Most late to finish first; the table's headers sort on anything else.
    return list.slice().sort((a, b) => b.runningLate - a.runningLate || a.territory.localeCompare(b.territory));
  }, [data.rows, scope]);

  const t = useMemo(() => {
    const sum = { notStarted: 0, inProgress: 0, finished: 0, onTime: 0, late: 0, running: 0, lateNotStarted: 0, pass: 0, fail: 0,
      tl: 0, stock: 0, pendingAction: 0, bonus: 0, builtSqme: 0, builtCount: 0, soldSqme: 0, soldCount: 0, productive: 0, onBuilds: 0,
      inProgressFloor: 0, inProgressPlaster: 0, inProgressPaint: 0, inProgressRepair: 0,
      // Targets add up only over the units that have one. A window nobody has a target for stays null.
      builtTarget: null as number | null, soldTarget: null as number | null, masonTarget: null as number | null };
    const add = (acc: number | null, v: number | null) => (v == null ? acc : (acc ?? 0) + v);
    for (const r of rows) {
      sum.builtTarget = add(sum.builtTarget, r.builtSqmeTarget);
      sum.soldTarget = add(sum.soldTarget, r.soldCountTarget);
      sum.masonTarget = add(sum.masonTarget, r.productiveMasonsTarget);
      sum.inProgressFloor += r.inProgressFloor; sum.inProgressPlaster += r.inProgressPlaster;
      sum.inProgressPaint += r.inProgressPaint; sum.inProgressRepair += r.inProgressRepair;
      sum.notStarted += r.notStarted; sum.inProgress += r.inProgress; sum.finished += r.finished;
      sum.onTime += r.finishedOnTime; sum.late += r.finishedLate; sum.running += r.runningLate;
      sum.lateNotStarted += r.lateNotStarted;
      sum.pass += r.qaPassed; sum.fail += r.qaFailed; sum.tl += r.pendingTl; sum.stock += r.pendingStock;
      sum.pendingAction += r.pendingAction;
      sum.bonus += r.bonusRwf;
      sum.builtSqme += r.builtSqme; sum.builtCount += r.builtCount;
      sum.soldSqme += r.soldSqme; sum.soldCount += r.soldCount;
      sum.productive += r.productiveMasons; sum.onBuilds += r.masonsWorking;
    }
    return sum;
  }, [rows]);

  const exportRows: Cell[][] = rows.map((r) => [
    r.territory, r.branch, r.notStarted, r.inProgress, r.finished, r.finishedOnTime, r.finishedLate,
    r.runningLate, r.worstDaysLate ?? "", r.qaPassed, r.qaFailed, r.pendingTl, r.pendingStock, r.masons,
    r.inCapacity ? Math.round(r.builtSqme) : "", r.inCapacity ? Math.round(r.soldSqme) : "",
    r.inCapacity ? r.soldCount : "", r.masonsWorking, r.productiveMasons,
    Math.round(r.sqmeTarget),
    r.builtSqmeTarget == null ? "" : Math.round(r.builtSqmeTarget),
    r.soldCountTarget == null ? "" : Math.round(r.soldCountTarget),
    r.productiveMasonsTarget == null ? "" : Math.round(r.productiveMasonsTarget),
    r.onTimeRate == null ? "" : Math.round(r.onTimeRate * 100), Math.round(r.bonusRwf),
  ]);

  const open = (r: TerritoryRow) => s.setScope({ level: rwanda ? "territory" : "branch", name: r.territory }, rwanda ? r.branch || null : null);
  const under = (text: string) => <span className="block text-xs" style={{ color: "var(--text-muted)" }}>{text}</span>;
  const cols: Col<TerritoryRow>[] = [
    { key: "name", header: unitTitle, mobile: "title", sort: (r) => r.territory, copy: (r) => r.territory, cell: (r) => (
      <span className="flex flex-col">
        <button type="button" onClick={() => open(r)} className="text-left font-semibold underline decoration-[var(--border)] underline-offset-4" style={{ color: "var(--text-primary)" }}>{r.territory}</button>
        {under([r.branch, `${fmtInt(r.masons)} masons`].filter(Boolean).join(" · "))}
      </span>
    ) },
    { key: "notstarted", header: "Not started", right: true, sort: (r) => r.notStarted, cell: (r) => <span className="tabular-nums">{fmtInt(r.notStarted)}</span> },
    { key: "inprogress", header: "In progress", right: true, sort: (r) => r.inProgress, cell: (r) => <span className="tabular-nums">{fmtInt(r.inProgress)}</span> },
    { key: "late", header: "Late to finish", right: true, sort: (r) => r.runningLate, cell: (r) => (
      <span className="flex flex-col items-end tabular-nums">
        <span style={{ color: r.runningLate > 0 ? LATE : "inherit", fontWeight: r.runningLate > 0 ? 600 : 400 }}>{fmtInt(r.runningLate)}</span>
        {r.worstDaysLate != null && r.worstDaysLate > 0 && under(`longest ${fmtInt(r.worstDaysLate)} days past deadline`)}
      </span>
    ) },
    { key: "completed", header: "Completed", right: true, sort: (r) => r.finished, cell: (r) => (
      <span className="flex flex-col items-end tabular-nums">
        <span>{fmtInt(r.finished)}</span>
        {r.finishedOnTime + r.finishedLate > 0 && under(`${pctText(pct(r.finishedOnTime, r.finishedOnTime + r.finishedLate))} on time`)}
      </span>
    ) },
    { key: "built", header: "Built", right: true, sort: (r) => (r.inCapacity ? r.builtSqme : null), copy: (r) => (r.inCapacity ? Math.round(r.builtSqme) : ""), copyHeader: "SQM-E built",
      cell: (r) => (r.inCapacity ? <span className="flex flex-col items-end tabular-nums"><span>{fmtInt(Math.round(r.builtSqme))}</span>{under("SQM-E")}</span> : <span style={{ color: "var(--text-muted)" }}>-</span>) },
    { key: "sold", header: "Sold", right: true, sort: (r) => (r.inCapacity ? r.soldSqme : null), copy: (r) => (r.inCapacity ? Math.round(r.soldSqme) : ""), copyHeader: "SQM-E sold",
      cell: (r) => (r.inCapacity ? <span className="flex flex-col items-end tabular-nums"><span>{fmtInt(Math.round(r.soldSqme))}</span>{under(`${fmtInt(r.soldCount)} signed`)}</span> : <span style={{ color: "var(--text-muted)" }}>-</span>) },
    { key: "productive", header: "Productive masons", right: true, sort: (r) => pct(r.productiveMasons, r.masonsWorking), copy: (r) => r.productiveMasons,
      cell: (r) => <span className="flex flex-col items-end tabular-nums"><span>{fmtInt(r.productiveMasons)}</span>{under(`of ${fmtInt(r.masonsWorking)} working`)}</span> },
    { key: "qa", header: "QA passed", right: true, sort: (r) => pct(r.qaPassed, r.qaPassed + r.qaFailed), copy: (r) => { const q = pct(r.qaPassed, r.qaPassed + r.qaFailed); return q == null ? "" : Math.round(q * 100); }, copyHeader: "QA pass rate %",
      cell: (r) => {
        const qa = pct(r.qaPassed, r.qaPassed + r.qaFailed);
        return (
          <span className="flex flex-col items-end">
            {qa == null ? <span style={{ color: "var(--text-muted)" }}>no check</span> : (
              <span className="rounded px-2 py-0.5 text-sm font-semibold tabular-nums" style={{ background: `color-mix(in srgb, ${band(qa)} 14%, transparent)`, color: band(qa) }}>{pctText(qa)}</span>
            )}
            {under(`${fmtInt(r.qaPassed + r.qaFailed)} checks`)}
          </span>
        );
      } },
    { key: "bonus", header: "Bonus", right: true, sort: (r) => r.bonusRwf, copy: (r) => Math.round(r.bonusRwf), copyHeader: "Bonus (RWF)", cell: (r) => (
      <span className="flex flex-col items-end tabular-nums">
        {r.bonusRwf > 0 ? <span>{fmtK(r.bonusRwf)}</span> : <span style={{ color: "var(--text-muted)" }}>-</span>}
        {r.sqmeTarget > 0 && under(`${pctText(pct(r.sqmeBuilt, r.sqmeTarget))} of SQM-E target`)}
      </span>
    ) },
  ];

  const opened = scope ? rows.find((r) => r.territory === scope.name) : undefined;

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>Territory leads, {s.scopeLabel}</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>{leads.label} · {leads.range}. What each {unitTitle.toLowerCase()} is carrying, what is stuck, and what it earned.</p>
      </div>
      <BarExports filename={`territory-${country}_${leads.from}_to_${leads.to}_${stamp()}`}
        headers={[unitTitle, "Branch", "Not started", "In progress", "Completed", "Completed on time", "Completed late",
          "Late to finish", "Longest days past deadline", "QA passed", "QA sent back", "Waiting on lead", "Waiting on materials",
          "Masons", "SQM-E built this window", "SQM-E sold", "Contracts signed", "Masons on builds",
          "Productive masons", "SQM-E target (bonus)", "SQM-E target (capacity)", "Contracts target",
          "Productive masons target", "On-time rate %", "Bonus"]}
        rows={exportRows} />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Builds" big={fmtInt(t.inProgress)} tone={TL}
          lines={[`${fmtInt(t.inProgress)} in progress`, `${fmtInt(t.notStarted)} not started`]} sub={products(t)} />
        <Kpi label="Late to finish" big={fmtInt(t.running)} tone={t.running > 0 ? LATE : "var(--good)"}
          lines={[`${fmtInt(t.lateNotStarted)} of them not even started`]} sub="Past the finish deadline the product allows: 30 days for a floor, 20 for plaster." />
        <Kpi label="Completed" big={fmtInt(t.finished)} tone="var(--good)"
          lines={[t.onTime + t.late > 0 ? `${pctText(pct(t.onTime, t.onTime + t.late))} on time, of ${fmtInt(t.onTime + t.late)} with a deadline` : "none has a deadline to judge"]} />
        <Kpi label="Built" big={fmtInt(Math.round(t.builtSqme))} tone="var(--good)"
          lines={[`SQM-E on ${fmtInt(t.builtCount)} ${t.builtCount === 1 ? "build" : "builds"}`, target(t.builtSqme, t.builtTarget)]} />
        <Kpi label="Sold" big={fmtInt(Math.round(t.soldSqme))} tone={SERIES_SALES}
          lines={[`SQM-E on ${fmtInt(t.soldCount)} ${t.soldCount === 1 ? "contract" : "contracts"}`, target(t.soldCount, t.soldTarget)]} />
        <Kpi label="Productive masons" big={fmtInt(t.productive)} tone={TL}
          lines={[`of ${fmtInt(t.onBuilds)} who worked here`, target(t.productive, t.masonTarget)]} />
        <Kpi label="Bonus so far" big={t.bonus > 0 ? fmtK(t.bonus) : "-"} tone="var(--accent-strong)"
          lines={[data.bonusMonths > 0 ? `over ${data.bonusMonths} ${data.bonusMonths === 1 ? "month" : "months"}` : "nothing published for this window"]} />
      </div>

      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{scope ? scope.name : `By ${unitTitle.toLowerCase()}`}</h2>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>Most late to finish first. Tap a name to open it.</span>
        </div>
        <DataTable rows={rows} cols={cols} keyOf={(r) => r.territory} copyName="the table" empty={scope ? "Nothing in that scope." : "Nothing in this window."}
          selectedKey={opened?.territory ?? null} />
      </section>

      {opened && <Panel key={opened.territory} country={country} row={opened} onClose={() => s.setScope(null)} />}
    </>
  );
}

/**
 * What the builds under way are. Paint is not listed on its own: the company no
 * longer sells it, so the few still running are shown under plaster, which is how
 * they are built, paid for and judged on time anyway.
 */
function products(t: { inProgress: number; inProgressFloor: number; inProgressPlaster: number; inProgressPaint: number; inProgressRepair: number }): string {
  const named: [number, string, string][] = [
    [t.inProgressFloor, "floor", "floors"],
    [t.inProgressPlaster + t.inProgressPaint, "plaster", "plaster"],
    [t.inProgressRepair, "repair", "repairs"],
  ];
  const parts = named.filter(([n]) => n > 0).map(([n, one, many]) => `${fmtInt(n)} ${n === 1 ? one : many}`);
  const rest = t.inProgress - named.reduce((a, [n]) => a + n, 0);
  if (rest > 0) parts.push(`${fmtInt(rest)} with no product recorded`);
  return parts.length > 0 ? `Under way: ${parts.join(", ")}` : "Nothing under way";
}

/** A figure against what the window was asked for. No target published is said plainly rather than shown as 0. */
function target(actual: number, goal: number | null): string {
  if (goal == null || goal <= 0) return "no target published";
  return `${Math.round((actual / goal) * 100)}% of a ${fmtInt(Math.round(goal))} target`;
}

/** One territory opened under the table, with the builds behind it. */
function Panel({ country, row, onClose }: { country: string; row: TerritoryRow; onClose: () => void }) {
  const [slice, setSlice] = useState<BuildFilter>("in-progress");
  // Which waiting state the pending slice is narrowed to, empty meaning all of them.
  const [reason, setReason] = useState("");
  const count: Partial<Record<BuildFilter, number>> = { "in-progress": row.inProgress, "not-started": row.notStarted, pending: row.pendingAction };
  const shownTotal = slice === "pending" && reason ? row.waitingBreakdown.find((w) => w.reason === reason)?.count ?? 0 : count[slice] ?? 0;
  return (
    <section className="flex flex-col gap-3 rounded-xl border-l-2 p-5" style={{ background: "var(--page)", borderColor: "var(--accent-strong)" }}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{row.territory}</h3>
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>{[row.branch, `${fmtInt(row.masons)} masons on site`].filter(Boolean).join(" · ")}</p>
        </div>
        <button type="button" onClick={onClose} className="min-h-11 rounded-md border px-2.5 py-1 text-sm sm:min-h-0" style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>
          Show all {unitWord(country === "Rwanda" ? "territory" : "branch")}
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Kpi label="Builds" big={fmtInt(row.inProgress)} tone={TL} lines={[`${fmtInt(row.inProgress)} in progress`, `${fmtInt(row.notStarted)} not started`, `${fmtInt(row.pendingAction)} waiting on an evaluation or a stock movement`]} />
        <Kpi label="Late to finish" big={fmtInt(row.runningLate)} tone={row.runningLate > 0 ? LATE : "var(--good)"}
          lines={[row.worstDaysLate != null && row.worstDaysLate > 0 ? `Longest ${fmtInt(row.worstDaysLate)} days past deadline` : "All still inside their deadline"]} />
        <Kpi label="Completed" big={fmtInt(row.finished)} tone="var(--good)"
          lines={[row.finishedOnTime + row.finishedLate > 0 ? `${fmtInt(row.finishedOnTime)} on time, ${fmtInt(row.finishedLate)} late` : "None measurable"]}
          sub={row.sqmeTarget > 0 ? `Bonus ${row.bonusRwf > 0 ? fmtK(row.bonusRwf) : "-"}: ${fmtInt(Math.round(row.sqmeBuilt))} of ${fmtInt(Math.round(row.sqmeTarget))} SQM-E target${row.onTimeRate != null ? `, ${pctText(row.onTimeRate)} on time` : ""}` : "No bonus target published"} />
      </div>

      <div className="flex flex-wrap gap-1.5">
        {SLICES.map((sl) => (
          <Chip key={sl.key} label={sl.label} count={count[sl.key] ?? 0} on={slice === sl.key} color={sl.key === "pending" ? "var(--warning)" : TL} onClick={() => { setSlice(sl.key); setReason(""); }} />
        ))}
      </div>

      {slice === "pending" && row.waitingBreakdown.length > 0 && (
        <div>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>Waiting for</span>
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            <Chip label="Everything" count={row.pendingAction} on={reason === ""} color="var(--text-secondary)" onClick={() => setReason("")} />
            {row.waitingBreakdown.map((w) => (
              <Chip key={w.reason} label={w.reason.replace(/^Waiting for /, "")} count={w.count} on={reason === w.reason} color="var(--warning)" onClick={() => setReason(w.reason)} />
            ))}
          </div>
        </div>
      )}

      <Builds key={`${row.territory}|${slice}|${reason}`} country={country} territory={row.territory} slice={slice} reason={reason} total={shownTotal} />
    </section>
  );
}

/** The builds behind one slice, fewest days since started first, ten to a page. */
function Builds({ country, territory, slice, reason, total }: { country: string; territory: string; slice: BuildFilter; reason: string; total: number }) {
  // A build nobody has started has no clock running, so those columns are left off that list.
  const started = slice !== "not-started";
  const [rows, setRows] = useState<TerritoryBuild[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    const qs = new URLSearchParams({ country, territory, filter: slice });
    if (reason) qs.set("reason", reason);
    fetch(`/api/territory-builds?${qs}`)
      .then(async (r) => {
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? r.statusText);
        if (live) setRows(j.rows as TerritoryBuild[]);
      })
      .catch((e) => { if (live) setError(e instanceof Error ? e.message : String(e)); });
    return () => { live = false; };
  }, [country, territory, slice, reason]);

  const muted = (text: string) => <span className="text-xs" style={{ color: "var(--text-muted)" }}>{text}</span>;
  const cols: Col<TerritoryBuild>[] = [
    { key: "job", header: "Opportunity", mobile: "title", sort: (b) => b.job || b.customer, copy: (b) => b.job || b.customer, cell: (b) => (
      <span className="flex flex-col"><span style={{ color: "var(--text-primary)" }}>{b.job || b.customer}</span>{b.cso && muted(`CSO ${b.cso}`)}</span>
    ) },
    { key: "product", header: "Product", sort: (b) => b.product ?? null, cell: (b) => b.product ?? "-" },
    { key: "stage", header: "Stage", sort: (b) => b.stage, cell: (b) => (
      <span className="rounded px-1.5 py-0.5 text-xs font-semibold"
        style={{ background: `color-mix(in srgb, ${b.stage === "In progress" ? TL : "var(--text-muted)"} 14%, transparent)`, color: b.stage === "In progress" ? TL : "var(--text-secondary)" }}>{b.stage}</span>
    ) },
    { key: "waiting", header: "Waiting for", sort: (b) => b.waitingFor ?? null, copy: (b) => b.waitingFor?.replace("Waiting for ", "") ?? "", cell: (b) => (b.waitingFor ? <span className="text-xs">{b.waitingFor.replace("Waiting for ", "")}</span> : muted("nothing")) },
    ...(started ? [
      { key: "deadline", header: "Against deadline", sort: (b) => b.daysLate, copy: (b) => (b.daysLate == null ? "no deadline" : b.daysLate > 0 ? "Past deadline" : "Still inside it"), cell: (b) => (b.daysLate == null ? muted("no deadline set") : (
        <span className="rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: `color-mix(in srgb, ${b.daysLate > 0 ? LATE : "var(--good)"} 14%, transparent)`, color: b.daysLate > 0 ? LATE : "var(--good)" }}>{b.daysLate > 0 ? "Past deadline" : "Still inside it"}</span>
      )) },
      { key: "dayslate", header: "Days past deadline", right: true, sort: (b) => b.daysLate, cell: (b) => (b.daysLate == null || b.daysLate <= 0 ? <span style={{ color: "var(--text-muted)" }}>-</span> : <span style={{ color: LATE, fontWeight: 600 }}>{fmtInt(b.daysLate)}</span>) },
    ] as Col<TerritoryBuild>[] : []),
    { key: "signed", header: "Signed", sort: (b) => b.signedDate ?? null, cell: (b) => b.signedDate ?? <span style={{ color: "var(--text-muted)" }}>-</span> },
    ...(started ? [
      { key: "since", header: "Days since started", right: true, sort: (b) => b.daysSinceStart, cell: (b) => (b.daysSinceStart == null ? muted("no date") : <span className="tabular-nums">{fmtInt(b.daysSinceStart)}</span>) },
    ] as Col<TerritoryBuild>[] : []),
    { key: "masons", header: "Masons", sort: (b) => b.masonCount, copy: (b) => (b.masonNames.length > 0 ? b.masonNames.join("; ") : b.mason ?? ""), cell: (b) => (
      b.masonNames.length > 0 ? (
        <span className="flex flex-col">
          {b.masonNames.map((n, i) => <span key={n + i}>{n}{b.masonSqm[i] > 0 && <span className="ml-1 text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(Math.round(b.masonSqm[i]))} sqm</span>}</span>)}
          {b.masonCount > b.masonNames.length && muted(`${fmtInt(b.masonCount)} assigned`)}
        </span>
      ) : b.mason ? b.mason : muted("none")
    ) },
    { key: "sqm", header: "SQM", right: true, sort: (b) => b.projectSqm, cell: (b) => (b.projectSqm == null ? "-" : fmtInt(Math.round(b.projectSqm))) },
    { key: "paid", header: "Paid", right: true, sort: (b) => b.pctPaid, copy: (b) => (b.pctPaid == null ? "" : Math.round(b.pctPaid * 100)), copyHeader: "Paid %", cell: (b) => (b.pctPaid == null ? "-" : pctText(b.pctPaid)) },
  ];

  return (
    <div className="flex flex-col gap-2">
      {error && <p className="text-sm" style={{ color: "var(--critical)" }}>Could not load the builds: {error}</p>}
      {!rows && !error && <p className="text-sm" style={{ color: "var(--text-muted)" }}><Spinner label="Loading builds…" /></p>}
      {rows && rows.length === 300 && <p className="text-xs" style={{ color: "var(--text-muted)" }}>Showing the newest 300 of {fmtInt(total)}.</p>}
      {rows && <DataTable rows={rows} cols={cols} keyOf={(b) => b.opportunityId} pageSize={10} copyName="the builds" empty="Nothing here." note={started ? "Fewest days since started first." : undefined} />}
    </div>
  );
}
