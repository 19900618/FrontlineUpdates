"use client";

import { useEffect, useMemo, useState } from "react";
import type { CapacityWeek } from "@/lib/capacity-calendar";
import type { CapacityCountry } from "@/lib/capacity-ui";
import type { QaIndividual as Data, QaOfficer, QaTask, QaOfficerEval } from "@/lib/quality-individual";
import { QA_STAGES, type QaStage } from "@/lib/quality-stages";
import type { Period as LeadsPeriod } from "@/lib/leads-period";
import { fmtInt } from "@/lib/format";
import { stamp, type Cell } from "@/lib/export";
import { SERIES_QA } from "@/lib/workspace-ui";
import Spinner from "@/components/Spinner";
import WorkspaceShell, { BarExports, type WsState } from "@/components/ws/WorkspaceShell";
import { DataTable, Kpi, type Col } from "@/components/ws/primitives";

const STAGE_COLOUR: Record<QaStage, string> = {
  Compaction: "#6a5a8c",
  Screed: "#2f6f9f",
  "Prior Paint": "#c2703d",
  Final: "#0ca30c",
  "Pre-House": "#9c928a",
  Other: "#b0a79f",
};

const pct = (a: number, b: number): number | null => (b > 0 ? a / b : null);
const pctText = (v: number | null): string => (v == null ? "-" : `${Math.round(v * 100)}%`);
const rate = (v: number | null): string =>
  v == null ? "var(--text-muted)" : v >= 0.95 ? "var(--good)" : v >= 0.85 ? "var(--warning)" : "var(--critical)";

/** What the open panel under a row is showing. */
type Open = { officerId: string; kind: "evals" | "tasks"; stage: string; title: string } | null;

/**
 * Every QA officer in the country, what they evaluated in the window and what
 * is still waiting on them: one row per person, ranked, opening under the
 * table to their full record. Evaluations are counted on exactly the terms the
 * Quality overview uses, so the compaction, screed and prior paint columns add
 * up to what the overview reports for the same country and window.
 */
export default function QaIndividual(props: {
  country: CapacityCountry; slug: string; calendar: CapacityWeek[]; years: number[]; userEmail: string | null; freshness: string;
  /** The country's territories or branches, for the filter bar's dropdown. */
  units: string[];
  leads: LeadsPeriod; data: Data;
}) {
  const { country, slug, calendar, years, userEmail, freshness } = props;
  return (
    <WorkspaceShell country={country} slug={slug} calendar={calendar} years={years} userEmail={userEmail} freshness={freshness} navigate="all" weekMode="single" units={props.units}>
      {(s) => <Body s={s} leads={props.leads} data={props.data} />}
    </WorkspaceShell>
  );
}

function Body({ s, leads, data }: { s: WsState; leads: LeadsPeriod; data: Data }) {
  const { country } = s;
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [open, setOpen] = useState<Open>(null);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = data.officers.filter(
      (o) => !q || o.name.toLowerCase().includes(q) || (o.position ?? "").toLowerCase().includes(q) || (o.branch ?? "").toLowerCase().includes(q),
    );
    // Most evaluations first; the table's headers sort on anything else.
    return list.slice().sort((a, b) => b.evals - a.evals);
  }, [data.officers, search]);

  const totals = useMemo(() => {
    const t = { evals: 0, passed: 0, failed: 0, notReady: 0, pending: 0, overdue: 0, threeStage: 0, done: 0, onTime: 0, byStep: [] as { step: string; n: number }[] };
    const steps = new Map<string, number>();
    for (const o of data.officers) {
      t.evals += o.evals; t.passed += o.passed; t.failed += o.failed; t.notReady += o.notReady;
      t.pending += o.pending; t.overdue += o.pendingOverdue;
      t.threeStage += o.byStage.Compaction + o.byStage.Screed + o.byStage["Prior Paint"];
      t.done += o.tasksDone; t.onTime += o.tasksOnTime;
      for (const x of o.pendingByStep) steps.set(x.step, (steps.get(x.step) ?? 0) + x.n);
    }
    t.byStep = [...steps].map(([step, n]) => ({ step, n })).sort((a, b) => b.n - a.n);
    return t;
  }, [data.officers]);

  const show = (officerId: string, kind: "evals" | "tasks", stage: string, title: string) =>
    setOpen((o) => (o && o.officerId === officerId && o.kind === kind && o.stage === stage ? null : { officerId, kind, stage, title }));

  const exportRows: Cell[][] = rows.map((o) => [
    o.name, o.position ?? "", o.branch ?? "", o.evals, o.passed, o.failed, o.notReady,
    pct(o.passed, o.evals) == null ? "" : Math.round((pct(o.passed, o.evals) as number) * 100),
    ...QA_STAGES.map((st) => o.byStage[st]),
    o.jobs, o.activeDays, o.pending, o.pendingOverdue, o.oldestPending ?? "", o.tasksDone, o.tasksOnTime,
  ]);

  const pillCell = (v: number | null) => (
    <span className="rounded px-2 py-0.5 text-sm font-semibold tabular-nums" style={{ background: `color-mix(in srgb, ${rate(v)} 14%, transparent)`, color: rate(v) }}>{pctText(v)}</span>
  );
  const cols: Col<QaOfficer>[] = [
    { key: "officer", header: "QA officer", mobile: "title", sort: (o) => o.name, copy: (o) => o.name, cell: (o) => (
      <span className="flex flex-col">
        <span className="font-medium leading-tight" style={{ color: "var(--text-primary)" }}>{o.name}</span>
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>{[o.position, o.branch].filter(Boolean).join(" · ") || "no position recorded"}</span>
      </span>
    ) },
    { key: "evals", header: "Evaluations", right: true, sort: (o) => o.evals, cell: (o) => (
      <span className="flex flex-col items-end tabular-nums">
        <span className="font-medium" style={{ color: "var(--text-primary)" }}>{fmtInt(o.evals)}</span>
        {o.activeDays > 0 && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{(o.evals / o.activeDays).toFixed(1)} a day over {fmtInt(o.activeDays)} days</span>}
      </span>
    ) },
    { key: "passed", header: "Passed", right: true, sort: (o) => pct(o.passed, o.evals), copy: (o) => { const p = pct(o.passed, o.evals); return p == null ? "" : Math.round(p * 100); }, copyHeader: "Pass rate %",
      cell: (o) => (o.evals === 0 ? <span style={{ color: "var(--text-muted)" }}>-</span> : pillCell(pct(o.passed, o.evals))) },
    { key: "failed", header: "Sent back", right: true, sort: (o) => o.failed, cell: (o) => (
      <span className="flex flex-col items-end tabular-nums">
        <span style={{ color: o.failed > 0 ? "var(--critical)" : "inherit" }}>{fmtInt(o.failed)}</span>
        {o.notReady > 0 && <span className="text-xs" style={{ color: "var(--warning)" }}>{fmtInt(o.notReady)} not ready</span>}
      </span>
    ) },
    { key: "stages", header: "By stage", copy: (o) => QA_STAGES.filter((st) => o.byStage[st] > 0).map((st) => `${st} ${o.byStage[st]}`).join(", "), cell: (o) => <StageBar officer={o} /> },
    { key: "ontime", header: "Tasks on time", right: true, sort: (o) => pct(o.tasksOnTime, o.tasksDone), copy: (o) => { const p = pct(o.tasksOnTime, o.tasksDone); return p == null ? "" : Math.round(p * 100); }, copyHeader: "Tasks on time %",
      cell: (o) => (o.tasksDone === 0 ? <span style={{ color: "var(--text-muted)" }}>none closed</span> : (
        <span className="flex flex-col items-end">{pillCell(pct(o.tasksOnTime, o.tasksDone))}<span className="text-xs" style={{ color: "var(--text-muted)" }}>{fmtInt(o.tasksOnTime)} of {fmtInt(o.tasksDone)}</span></span>
      )) },
    { key: "pending", header: "Pending tasks", right: true, sort: (o) => o.pending, cell: (o) => (o.pending === 0 ? <span style={{ color: "var(--text-muted)" }}>none</span> : (
      <span className="flex flex-col items-end tabular-nums">
        <span className="font-medium" style={{ color: "var(--text-primary)" }}>{fmtInt(o.pending)}</span>
        {o.pendingOverdue > 0 && <span className="text-xs" style={{ color: "var(--warning)" }}>{fmtInt(o.pendingOverdue)} overdue</span>}
        {o.oldestPending != null && <span className="text-xs" style={{ color: "var(--text-muted)" }}>oldest {fmtInt(o.oldestPending)}d</span>}
        {o.pendingByStep.length > 0 && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{o.pendingByStep.map((x) => `${fmtInt(x.n)} ${x.step.toLowerCase()}`).join(", ")}</span>}
      </span>
    )) },
  ];

  const officer = selected ? data.officers.find((o) => o.id === selected) : undefined;

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>Individual QA, {country}</h1>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>
          {leads.label} · {leads.range}. What each QA officer evaluated, how it went, and what is still on their list. Active QA staff only:
          territory leads, district and construction staff, QA managers, the call centre and anyone who has left are not here.
        </p>
      </div>
      <BarExports filename={`qa-individual-${country}_${leads.from}_to_${leads.to}_${stamp()}`}
        headers={["QA officer", "Position", "Branch", "Evaluations", "Passed", "Sent back", "Not ready", "Pass rate %",
          ...QA_STAGES, "Jobs", "Days active", "Pending tasks", "Overdue", "Oldest pending (days)", "Tasks closed", "Closed on time"]}
        rows={exportRows} />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="QA officers" big={fmtInt(data.officers.length)} tone={SERIES_QA}
          lines={[`${fmtInt(data.officers.filter((o) => o.evals > 0).length)} evaluated something in this window`]} />
        <Kpi label="Evaluations done" big={fmtInt(totals.evals)} tone={SERIES_QA}
          lines={[`${fmtInt(totals.threeStage)} at compaction, screed or prior paint`]} />
        <Kpi label="Passed" big={pctText(pct(totals.passed, totals.evals))} tone={rate(pct(totals.passed, totals.evals))}
          lines={[`${fmtInt(totals.failed)} sent back`, `${fmtInt(totals.notReady)} not ready`]} />
        <Kpi label="Tasks" big={pctText(pct(totals.onTime, totals.done))} tone={totals.overdue > 0 ? "var(--warning)" : rate(pct(totals.onTime, totals.done))}
          lines={[totals.done > 0 ? `${fmtInt(totals.onTime)} of ${fmtInt(totals.done)} closed by their due date` : "no task closed in this window", `${fmtInt(totals.pending)} still pending, ${fmtInt(totals.overdue)} overdue`]}
          sub={totals.byStep.length > 0 ? totals.byStep.map((x) => `${fmtInt(x.n)} ${x.step.toLowerCase()}`).join(", ") : undefined} />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search officer, position, branch…"
          className="min-h-11 w-full flex-1 rounded-md border px-3 py-1.5 text-sm sm:min-h-0 sm:w-auto sm:min-w-56"
          style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }} />
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>Most evaluations first. Tap a row for the full record.</span>
      </div>

      <DataTable rows={rows} cols={cols} keyOf={(o) => o.id} onRow={(o) => setSelected((cur) => (cur === o.id ? null : o.id))} selectedKey={selected}
        copyName="the roster" empty="No QA officer matches that search." />

      {officer && (
        <Detail key={officer.id} country={country} period={leads} officer={officer} open={open} onShow={show} onClose={() => setSelected(null)} />
      )}

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        This roster is the QA team still on the staff: active, in a QA position, and not a manager or the call centre.
        An evaluation counts as QA when the QA Survey&apos;s department is neither District nor Construction, a blank one counting
        as QA, which is the rule the Quality overview uses.
        {data.outsideTeam.threeStage > 0 ? (
          <>
            {" "}The overview applies that rule alone, so it also counts {fmtInt(data.outsideTeam.threeStage)} checks by{" "}
            {fmtInt(data.outsideTeam.people)} staff outside this team; the roster accounts for the other {fmtInt(totals.threeStage)}.
          </>
        ) : (
          <> Every check the overview counts here was done by someone on this roster: {fmtInt(totals.threeStage)}.</>
        )}
        {data.outsideTeam.pending > 0 && ` ${fmtInt(data.outsideTeam.pending)} open tasks sit outside it too.`}
        {" "}A task is on time when it was closed by its due date, counting only tasks closed in this window.
        Pending tasks are those open now and raised by the window&apos;s end, so older untouched ones still count.
      </p>
    </>
  );
}

/** The officer's evaluations split across the stages, as one proportional bar. */
function StageBar({ officer }: { officer: QaOfficer }) {
  if (officer.evals === 0) return <span className="text-xs" style={{ color: "var(--text-muted)" }}>nothing this window</span>;
  const parts = QA_STAGES.map((st) => ({ st, n: officer.byStage[st] })).filter((x) => x.n > 0);
  return (
    <span className="block min-w-44">
      <span className="flex h-2 overflow-hidden rounded-sm" style={{ background: "var(--grid)" }}>
        {parts.map((x) => <span key={x.st} style={{ width: `${(x.n / officer.evals) * 100}%`, background: STAGE_COLOUR[x.st] }} />)}
      </span>
      <span className="mt-1 flex flex-wrap gap-x-2 text-[11px]" style={{ color: "var(--text-muted)" }}>
        {parts.map((x) => (
          <span key={x.st}><span className="mr-1 inline-block h-2 w-2 rounded-sm align-[-1px]" style={{ background: STAGE_COLOUR[x.st] }} />{x.st} {fmtInt(x.n)}</span>
        ))}
      </span>
    </span>
  );
}

/** One officer's full record under the table, with everything on it openable. */
function Detail({ country, period, officer, open, onShow, onClose }: {
  country: string; period: LeadsPeriod; officer: QaOfficer; open: Open;
  onShow: (officerId: string, kind: "evals" | "tasks", stage: string, title: string) => void; onClose: () => void;
}) {
  const p = pct(officer.passed, officer.evals);
  const perDay = officer.activeDays > 0 ? officer.evals / officer.activeDays : null;
  const chip = (on: boolean, tone = "var(--accent-strong)") => ({
    background: on ? tone : "var(--surface)", borderColor: on ? tone : "var(--border)", color: on ? "#fff" : "var(--text-secondary)",
  });
  return (
    <section className="flex flex-col gap-3 rounded-xl border-l-2 p-5" style={{ background: "var(--page)", borderColor: "var(--accent-strong)" }}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>{officer.name}</h3>
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>{[officer.position, officer.branch].filter(Boolean).join(" · ") || "no position recorded"}</p>
        </div>
        <button type="button" onClick={onClose} className="min-h-11 rounded-md border px-2.5 py-1 text-sm sm:min-h-0" style={{ borderColor: "var(--border)", color: "var(--text-secondary)", background: "var(--surface)" }}>Collapse</button>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi label="Evaluations" big={fmtInt(officer.evals)} tone={SERIES_QA} lines={[`${fmtInt(officer.jobs)} houses`, perDay == null ? "no day out" : `${perDay.toFixed(1)} a day over ${fmtInt(officer.activeDays)} days out`]} />
        <Kpi label="Passed" big={pctText(p)} tone={rate(p)} lines={[`${fmtInt(officer.passed)} of ${fmtInt(officer.evals)}`]} />
        <Kpi label="Sent back" big={fmtInt(officer.failed)} tone="var(--critical)" lines={[`${pctText(pct(officer.failed, officer.evals))} of evaluations`, `${fmtInt(officer.notReady)} not ready, wasted visits`]} />
        <Kpi label="Tasks" big={pctText(pct(officer.tasksOnTime, officer.tasksDone))} tone={officer.pendingOverdue > 0 ? "var(--warning)" : rate(pct(officer.tasksOnTime, officer.tasksDone))}
          lines={[officer.tasksDone > 0 ? `${fmtInt(officer.tasksOnTime)} of ${fmtInt(officer.tasksDone)} closed by their due date` : "none closed", `${fmtInt(officer.pending)} pending${officer.pendingByStep.length > 0 ? `: ${officer.pendingByStep.map((x) => `${fmtInt(x.n)} ${x.step.toLowerCase()}`).join(", ")}` : ""}`]} />
      </div>

      <div>
        <h4 className="mb-1.5 text-sm font-semibold" style={{ color: "var(--text-primary)" }}>By stage</h4>
        <div className="flex flex-wrap gap-1.5">
          {QA_STAGES.filter((st) => officer.byStage[st] > 0).map((st) => {
            const on = open?.officerId === officer.id && open.kind === "evals" && open.stage === st;
            return (
              <button key={st} type="button" onClick={() => onShow(officer.id, "evals", st, `${officer.name} · ${st}`)} aria-pressed={on}
                className="min-h-11 rounded-md border px-2.5 py-1 text-sm sm:min-h-0" style={chip(on)}>
                <span className="mr-1.5 inline-block h-2 w-2 rounded-sm align-[-1px]" style={{ background: on ? "#fff" : STAGE_COLOUR[st] }} />
                {st} <span className="font-semibold tabular-nums">{fmtInt(officer.byStage[st])}</span>
              </button>
            );
          })}
          {officer.evals > 0 && (
            <button type="button" onClick={() => onShow(officer.id, "evals", "", `${officer.name} · every evaluation`)}
              className="min-h-11 rounded-md border px-2.5 py-1 text-sm sm:min-h-0" style={chip(open?.officerId === officer.id && open.kind === "evals" && open.stage === "")}>
              All {fmtInt(officer.evals)}
            </button>
          )}
          {officer.pending > 0 && (
            <button type="button" onClick={() => onShow(officer.id, "tasks", "", `${officer.name} · pending tasks`)}
              className="min-h-11 rounded-md border px-2.5 py-1 text-sm sm:min-h-0" style={chip(open?.officerId === officer.id && open.kind === "tasks", "var(--warning)")}>
              Pending tasks <span className="font-semibold tabular-nums">{fmtInt(officer.pending)}</span>
            </button>
          )}
        </div>
      </div>

      {open && open.officerId === officer.id && (
        <Drill key={`${open.kind}|${open.stage}|${period.from}|${period.to}`}
          country={country} period={period} officerId={officer.id} kind={open.kind} stage={open.stage}
          title={open.title} onClose={() => onShow(officer.id, open.kind, open.stage, open.title)} />
      )}
    </section>
  );
}

/** The records behind a figure: evaluations done, or tasks still waiting. */
function Drill({ country, period, officerId, kind, stage, title, onClose }: {
  country: string; period: LeadsPeriod; officerId: string; kind: "evals" | "tasks"; stage: string; title: string; onClose: () => void;
}) {
  const [evals, setEvals] = useState<QaOfficerEval[] | null>(null);
  const [tasks, setTasks] = useState<QaTask[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    const qs = new URLSearchParams({ country, what: kind, officerId, from: period.from, to: period.to, stage });
    fetch(`/api/quality/qa-individual?${qs}`)
      .then(async (r) => {
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? r.statusText);
        if (!live) return;
        if (kind === "evals") setEvals(j.rows as QaOfficerEval[]); else setTasks(j.rows as QaTask[]);
      })
      .catch((e) => { if (live) setError(e instanceof Error ? e.message : String(e)); });
    return () => { live = false; };
  }, [country, kind, officerId, period.from, period.to, stage]);

  const evalCols: Col<QaOfficerEval>[] = [
    { key: "date", header: "Date", sort: (r) => r.date, cell: (r) => r.date },
    { key: "job", header: "Opportunity", mobile: "title", sort: (r) => r.job, copy: (r) => r.job, cell: (r) => <span style={{ color: "var(--text-primary)" }}>{r.job}</span> },
    { key: "stage", header: "Stage", sort: (r) => r.stage, cell: (r) => r.stage },
    { key: "decision", header: "QA said", sort: (r) => r.decision, cell: (r) => {
      const tone = r.passed ? "var(--good)" : r.decision === "Not Ready for Evaluation" ? "var(--warning)" : "var(--critical)";
      return <span className="rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: `color-mix(in srgb, ${tone} 14%, transparent)`, color: tone }}>{r.decision}</span>;
    } },
    { key: "mason", header: "Mason", sort: (r) => r.mason ?? null, cell: (r) => r.mason ?? "-" },
    { key: "comment", header: "Comment", copy: (r) => r.comment ?? "", cell: (r) => <span className="text-xs">{r.comment || <span style={{ color: "var(--text-muted)" }}>no comment</span>}</span> },
  ];
  const taskCols: Col<QaTask>[] = [
    { key: "subject", header: "Task", mobile: "title", sort: (t) => t.subject, copy: (t) => t.subject, cell: (t) => <span style={{ color: "var(--text-primary)" }}>{t.subject}</span> },
    { key: "job", header: "Opportunity", sort: (t) => t.job, copy: (t) => `${t.job}${t.branch ? ` (${t.branch})` : ""}`, cell: (t) => <span className="flex flex-col">{t.job}{t.branch && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{t.branch}</span>}</span> },
    { key: "officer", header: "Assigned to", sort: (t) => t.officer ?? null, cell: (t) => t.officer ?? <span style={{ color: "var(--text-muted)" }}>nobody</span> },
    { key: "created", header: "Raised", sort: (t) => t.createdOn ?? null, cell: (t) => t.createdOn ?? "-" },
    { key: "due", header: "Due", sort: (t) => t.dueOn ?? null, cell: (t) => t.dueOn ?? "-" },
    { key: "days", header: "Days pending", right: true, sort: (t) => t.pendingDays, cell: (t) => <span className="tabular-nums" style={{ color: t.overdue ? "var(--warning)" : "inherit" }}>{fmtInt(t.pendingDays)}</span> },
    { key: "status", header: "Status", sort: (t) => t.status, copy: (t) => `${t.status}${t.overdue ? " (overdue)" : ""}`, cell: (t) => <>{t.status}{t.overdue && <span className="ml-1 text-xs" style={{ color: "var(--warning)" }}>overdue</span>}</> },
  ];

  const rows = kind === "evals" ? evals : tasks;
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h4 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
          {title}{rows ? <span className="ml-2 font-normal" style={{ color: "var(--text-muted)" }}>{fmtInt(rows.length)} shown</span> : null}
        </h4>
        <button type="button" onClick={onClose} className="text-sm" style={{ color: "var(--text-muted)" }}>Close</button>
      </div>
      {error && <p className="text-sm" style={{ color: "var(--critical)" }}>Could not load: {error}</p>}
      {!rows && !error && <p className="text-sm" style={{ color: "var(--text-muted)" }}><Spinner label="Loading…" /></p>}
      {kind === "evals" && evals && <DataTable rows={evals} cols={evalCols} keyOf={(r) => r.surveyId} pageSize={25} copyName="the evaluations" empty="Nothing here." />}
      {kind === "tasks" && tasks && <DataTable rows={tasks} cols={taskCols} keyOf={(t) => t.taskId} pageSize={25} copyName="the tasks" empty="Nothing here." />}
    </div>
  );
}
