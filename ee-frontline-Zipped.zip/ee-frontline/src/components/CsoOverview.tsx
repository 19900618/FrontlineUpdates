"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import type { CsoTerritoryMonth, TerritoryCapacity, CsoHeadcount } from "@/lib/cso";
import { band, BAND_COLOR, BAND_LABEL } from "@/lib/cso-bands";
import { fmtInt } from "@/lib/format";
import { useNarrow } from "@/lib/use-narrow";
import ExportButtons from "@/components/ExportButtons";
import { stamp, type Cell } from "@/lib/export";

const ALL = "All";
/** Two series, two identities. Validated for CVD separation against the light surface. */
const SERIES_SALES = "#ee7203";
const SERIES_COLL = "#2f6f9f";
const TREND_MONTHS = 9;
const WORST_N = 8;

const plural = (noun: "district" | "territory", n: number) =>
  noun === "district" ? (n === 1 ? "district" : "districts") : n === 1 ? "territory" : "territories";

type Dim = "district" | "territory";
type Unit = "contracts" | "sqme";

type Agg = {
  csos: number;
  sold: number; collected: number;
  soldSqme: number; collectedSqme: number;
  minSold: number; minCollected: number;
  minSoldSqme: number; minCollectedSqme: number;
};

function aggregate(rows: CsoTerritoryMonth[]): Agg {
  const a: Agg = {
    csos: 0, sold: 0, collected: 0, soldSqme: 0, collectedSqme: 0,
    minSold: 0, minCollected: 0, minSoldSqme: 0, minCollectedSqme: 0,
  };
  for (const r of rows) {
    a.csos += r.csos;
    a.sold += r.sold; a.collected += r.collected;
    a.soldSqme += r.soldSqme; a.collectedSqme += r.collectedSqme;
    a.minSold += r.minSold; a.minCollected += r.minCollected;
    a.minSoldSqme += r.minSoldSqme; a.minCollectedSqme += r.minCollectedSqme;
  }
  return a;
}

const ratio = (actual: number, standard: number): number | null =>
  standard > 0 ? actual / standard : null;

const salesOf = (a: Agg, u: Unit) => ratio(u === "contracts" ? a.sold : a.soldSqme, u === "contracts" ? a.minSold : a.minSoldSqme);
const collOf = (a: Agg, u: Unit) => ratio(u === "contracts" ? a.collected : a.collectedSqme, u === "contracts" ? a.minCollected : a.minCollectedSqme);

const pctText = (v: number | null) => (v == null ? "-" : `${Math.round(v * 100)}%`);

export default function CsoOverview({ rows, capacity, headcount }: { rows: CsoTerritoryMonth[]; capacity: TerritoryCapacity[]; headcount: CsoHeadcount[] }) {
  const months = useMemo(() => Array.from(new Set(rows.map((r) => r.month))).sort(), [rows]);
  const monthLabel = useMemo(() => {
    const m = new Map<string, string>();
    for (const r of rows) m.set(r.month, r.monthLabel);
    return m;
  }, [rows]);

  // Open on the last COMPLETE month. The month in progress always reads low and
  // is not a fair comparison, so it should be chosen deliberately, not landed on.
  const defaultMonth = useMemo(() => {
    const complete = [...months].reverse().find((m) => rows.some((r) => r.month === m && r.minSold > 0 && !r.isCurrentMonth));
    return complete ?? months[months.length - 1] ?? "";
  }, [months, rows]);

  const [month, setMonth] = useState(defaultMonth);
  const [dim, setDim] = useState<Dim>("territory");
  const [district, setDistrict] = useState(ALL);
  const [unit, setUnit] = useState<Unit>("contracts");
  // Leavers and duplicate stub contacts are off by default: they pull the
  // averages down without representing anyone you can act on.
  const [includeLeavers, setIncludeLeavers] = useState(false);

  const districts = useMemo(
    () => [ALL, ...Array.from(new Set(rows.map((r) => r.district))).filter((d) => d !== "Unassigned").sort()],
    [rows],
  );

  /** Rows for one month, narrowed to the district scope and the staff roster. */
  const scopeFor = useMemo(
    () => (m: string) =>
      rows.filter((r) =>
        r.month === m &&
        (district === ALL || r.district === district) &&
        (includeLeavers || r.currentStaff)),
    [rows, district, includeLeavers],
  );

  const scoped = useMemo(() => scopeFor(month), [scopeFor, month]);
  const total = useMemo(() => aggregate(scoped), [scoped]);

  const prevMonth = months[months.indexOf(month) - 1];
  const prev = useMemo(() => (prevMonth ? aggregate(scopeFor(prevMonth)) : null), [prevMonth, scopeFor]);

  const salesPct = salesOf(total, unit);
  const collPct = collOf(total, unit);
  const salesPrev = prev ? salesOf(prev, unit) : null;
  const collPrev = prev ? collOf(prev, unit) : null;

  /**
   * Distinct headcount for a level. Never sum territory counts to get a district:
   * a CSO who covers two territories is one person, and summing double-counts
   * them. That is the discrepancy against the capacity planning dashboard.
   */
  const headcountOf = useMemo(() => {
    const idx = new Map<string, number>();
    for (const h of headcount) {
      if (h.month !== month) continue;
      if (!includeLeavers && !h.currentStaff) continue;
      const k = `${h.level}|${h.name}`;
      idx.set(k, (idx.get(k) ?? 0) + h.csos);
    }
    return (level: CsoHeadcount["level"], name: string) => idx.get(`${level}|${name}`) ?? 0;
  }, [headcount, month, includeLeavers]);

  // Every territory in scope, whatever the grouping — the 5-per-territory standard
  // is defined on territories, so headcount expectation is counted there.
  const territoriesInScope = useMemo(
    () => new Set(scoped.filter((r) => r.territory !== "Unassigned").map((r) => r.territory)).size,
    [scoped],
  );
  const expectedCsos = territoriesInScope * 5;
  const activeCsos = district === ALL ? headcountOf("country", "Rwanda") : headcountOf("district", district);

  const isC = unit === "contracts";
  const soldActual = isC ? total.sold : Math.round(total.soldSqme);
  const collActual = isC ? total.collected : Math.round(total.collectedSqme);
  const soldPrev = prev ? (isC ? prev.sold : Math.round(prev.soldSqme)) : null;

  /** Build-side capacity for the selected month, keyed the same way as the CSO rows. */
  const capForMonth = useMemo(
    () => capacity.filter((c) => c.month === month && (district === ALL || c.district === district)),
    [capacity, month, district],
  );

  /** Groups by the selected dimension, scored across the whole chain. */
  const groups = useMemo(() => {
    const m = new Map<string, CsoTerritoryMonth[]>();
    for (const r of scoped) {
      const key = dim === "district" ? r.district : r.territory;
      if (key === "Unassigned") continue;
      (m.get(key) ?? m.set(key, []).get(key)!).push(r);
    }
    // Capacity rolls up the same way, so a district row sums its territories.
    const cap = new Map<string, TerritoryCapacity[]>();
    for (const c of capForMonth) {
      const key = dim === "district" ? c.district : c.territory;
      if (key === "Unassigned") continue;
      (cap.get(key) ?? cap.set(key, []).get(key)!).push(c);
    }

    return Array.from(m.entries())
      .map(([name, rs]) => {
        const a = aggregate(rs);
        const s = salesOf(a, unit);
        const c = collOf(a, unit);
        const cs = cap.get(name) ?? [];
        const territories = new Set(rs.map((r) => r.territory).filter((t: string) => t !== "Unassigned")).size;
        const sum = (f: (x: TerritoryCapacity) => number) => cs.reduce((t, x) => t + f(x), 0);
        const builds = sum((x) => x.builds);
        const buildTarget = sum((x) => x.buildTarget ?? 0);
        const masons = sum((x) => x.masons);
        const minMasons = sum((x) => x.minMasons ?? 0);
        return {
          name,
          parent: dim === "territory" ? rs[0]?.district ?? "" : "",
          csos: headcountOf(dim === "district" ? "district" : "territory", name),
          minCsos: territories * 5,
          territories,
          sold: isC ? a.sold : Math.round(a.soldSqme),
          collected: isC ? a.collected : Math.round(a.collectedSqme),
          pctSales: s,
          pctColl: c,
          builds,
          buildTarget,
          pctBuild: buildTarget > 0 ? builds / buildTarget : null,
          masons,
          minMasons,
          buildsPerMason: masons > 0 ? builds / masons : null,
          // Rank on the weakest link in the chain, so a territory that sells well
          // but cannot build still surfaces.
          worst: [s, c, buildTarget > 0 ? builds / buildTarget : null]
            .filter((v): v is number => v != null)
            .reduce<number | null>((lo, v) => (lo == null ? v : Math.min(lo, v)), null),
        };
      })
      .sort((a, b) => (a.worst ?? 99) - (b.worst ?? 99));
  }, [scoped, dim, unit, isC, capForMonth, headcountOf]);

  // Nearly every territory sits under the absolute standard, so listing them all
  // says nothing. Show the weakest few and give the pack average as the yardstick.
  const belowStandard = groups.filter((g) => g.worst != null && g.worst < 1);
  const weakest = belowStandard.slice(0, WORST_N);

  /** Longitudinal: the same two ratios across the last N months in the current scope. */
  const trend = useMemo(() => {
    const window = months.slice(-TREND_MONTHS);
    return window.map((m) => {
      const a = aggregate(scopeFor(m));
      return { month: m, label: monthLabel.get(m) ?? m, sales: salesOf(a, unit), coll: collOf(a, unit) };
    });
  }, [months, scopeFor, unit, monthLabel]);

  const dimLabel = dim === "district" ? "District" : "Territory";

  const exportHeaders = [dimLabel, dim === "territory" ? "District" : "Territories",
    "CSOs", "CSOs required", "Masons", "Masons required",
    isC ? "Contracts sold" : "SQM-E sold", "Sales % of target",
    isC ? "Contracts collected" : "SQM-E collected", "Collections % of target",
    "Builds", "Build target", "Builds % of target"];

  const exportRows: Cell[][] = groups.map((g) => [
    g.name, dim === "territory" ? g.parent : g.territories,
    g.csos, g.minCsos, g.masons, Math.round(g.minMasons),
    g.sold, g.pctSales == null ? "" : Math.round(g.pctSales * 100),
    g.collected, g.pctColl == null ? "" : Math.round(g.pctColl * 100),
    g.builds, Math.round(g.buildTarget), g.pctBuild == null ? "" : Math.round(g.pctBuild * 100),
  ]);

  const exportName = `cso-${dim}_${(monthLabel.get(month) ?? month).replace(/\s+/g, "-")}_${stamp()}`;

  return (
    <div className="mx-auto flex max-w-[95rem] flex-col gap-4 p-4 sm:p-6">
      <header className="flex flex-col gap-3">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-semibold" style={{ color: "var(--text-primary)" }}>RW CSO performance</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              Sales and collections productivity against the per-CSO standard. Rwanda.
            </p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Link href="/toolkit/cso/individual" className="rounded-md px-3 py-1.5 text-sm font-medium text-white" style={{ background: "var(--accent-strong)" }}>
              Individual CSOs
            </Link>
            <ExportButtons filename={exportName} headers={exportHeaders} rows={exportRows} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Toggle options={[{ key: "district", label: "District" }, { key: "territory", label: "Territory" }]}
            value={dim} onChange={(k) => setDim(k as Dim)} />
          <Select label="Month" value={month} options={[...months].reverse()} optionLabel={(m) => monthLabel.get(m) ?? m} onChange={setMonth} />
          <Select label="District" value={district} options={districts} onChange={setDistrict} />
          <Toggle options={[{ key: "contracts", label: "Contracts" }, { key: "sqme", label: "SQM-E" }]}
            value={unit} onChange={(k) => setUnit(k as Unit)} />
          <button type="button" onClick={() => setIncludeLeavers((v) => !v)}
            className="rounded-md border px-2.5 py-1.5 text-sm"
            style={{
              background: "var(--surface)",
              borderColor: includeLeavers ? "var(--accent-strong)" : "var(--border)",
              color: includeLeavers ? "var(--text-primary)" : "var(--text-secondary)",
            }}>
            {includeLeavers ? "Including leavers" : "Current staff only"}
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Score label="Sales productivity" pct={salesPct} prev={salesPrev} tone={SERIES_SALES}
          actual={soldActual} standard={Math.round(isC ? total.minSold : total.minSoldSqme)} unit={unit} />
        <Score label="Collections productivity" pct={collPct} prev={collPrev} tone={SERIES_COLL}
          actual={collActual} standard={Math.round(isC ? total.minCollected : total.minCollectedSqme)} unit={unit} />
        <Compare label="Active CSOs" actual={activeCsos} expected={expectedCsos}
          note={`${territoriesInScope} territories at 5 each · distinct people, not summed per territory`} />
        <Compare label={isC ? "Contracts sold" : "SQM-E sold"} actual={soldActual}
          expected={Math.round(isC ? total.minSold : total.minSoldSqme)}
          note={soldPrev == null ? `${fmtInt(collActual)} collected` : `${fmtInt(collActual)} collected · ${delta(soldActual, soldPrev)} vs ${monthLabel.get(prevMonth) ?? "last month"}`} />
      </div>

      <Trend data={trend} selected={month} />

      {weakest.length > 0 && (
        <section className="rounded-lg border p-5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
          <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
            <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
              Weakest {plural(dim === "district" ? "district" : "territory", weakest.length)}
            </h2>
            <span className="text-xs" style={{ color: "var(--text-muted)" }}>
              Showing {weakest.length} of {belowStandard.length} below target · scope average {pctText(salesPct)} sales, {pctText(collPct)} collections
            </span>
          </div>
          <p className="mt-0.5 text-xs" style={{ color: "var(--text-muted)" }}>
            Ranked on whichever half of the job is lagging. The bar behind each figure is the target.
          </p>
          <div className="mt-4 grid grid-cols-1 gap-x-5 gap-y-4 sm:grid-cols-2 xl:grid-cols-4">
            {weakest.map((g) => (
              <div key={g.name} className="flex flex-col gap-2 border-l-2 pl-3" style={{ borderColor: BAND_COLOR[band(g.worst)] }}>
                <div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="truncate text-sm font-semibold" style={{ color: "var(--text-primary)" }} title={g.name}>{g.name}</span>
                    <span className="shrink-0 text-xs tabular-nums" style={{ color: "var(--text-muted)" }}>{g.csos} CSOs</span>
                  </div>
                  {g.parent && <span className="text-xs" style={{ color: "var(--text-muted)" }}>{g.parent}</span>}
                </div>
                <div className="flex flex-col gap-1.5">
                  <MiniBar label="Sales" pct={g.pctSales} tone={SERIES_SALES} />
                  <MiniBar label="Collections" pct={g.pctColl} tone={SERIES_COLL} />
                  <MiniBar label="Builds" pct={g.pctBuild} tone="var(--text-secondary)" />
                </div>
                <p className="text-xs leading-snug" style={{ color: "var(--text-secondary)" }}>
                  {readOut(g.pctSales, g.pctColl, g.pctBuild)}
                </p>
                {(g.minCsos - g.csos > 0 || g.minMasons - g.masons > 0) && (
                  <p className="text-xs leading-snug" style={{ color: "var(--warning)" }}>
                    Short {[
                      g.minCsos - g.csos > 0 ? `${Math.round(g.minCsos - g.csos)} CSOs` : null,
                      g.minMasons - g.masons > 0 ? `${Math.round(g.minMasons - g.masons)} masons` : null,
                    ].filter(Boolean).join(" and ")}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="rounded-lg border" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
        <div className="border-b p-4" style={{ borderColor: "var(--border)" }}>
          <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{dimLabel} breakdown</h2>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            Measured in {isC ? "contracts" : "SQM-E"}. The standard is the territory build target shared across 5 CSOs, with sales set 30% higher to keep the pipeline fed.
          </p>
        </div>
        <div className="hidden overflow-x-auto md:block print:block">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ color: "var(--text-muted)" }}>
                <Th>{dimLabel}</Th>
                <Th right>CSOs</Th>
                <Th right>Masons</Th>
                <Th right>Sold</Th><Th right>Sales prod.</Th>
                <Th right>Collected</Th><Th right>Coll. prod.</Th>
                <Th right>Builds</Th><Th right>vs target</Th>
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => (
                <tr key={g.name} style={{ borderTop: "1px solid var(--border)" }}>
                  <Td>
                    <span className="block font-medium leading-tight" style={{ color: "var(--text-primary)" }}>{g.name}</span>
                    <span className="block text-xs" style={{ color: "var(--text-muted)" }}>
                      {dim === "territory" ? g.parent : `${g.territories} ${plural(dim === "district" ? "territory" : "district", g.territories)}`}
                    </span>
                  </Td>
                  <Td right><Headcount have={g.csos} need={g.minCsos} /></Td>
                  <Td right><Headcount have={g.masons} need={g.minMasons} /></Td>
                  <Td right>{fmtInt(g.sold)}</Td>
                  <Td right><Pct v={g.pctSales} /></Td>
                  <Td right>{fmtInt(g.collected)}</Td>
                  <Td right><Pct v={g.pctColl} /></Td>
                  <Td right>
                    <span className="block tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(g.builds)}</span>
                    <span className="block text-xs" style={{ color: "var(--text-muted)" }}>
                      of {g.buildTarget > 0 ? fmtInt(Math.round(g.buildTarget)) : "-"}
                    </span>
                  </Td>
                  <Td right><Pct v={g.pctBuild} /></Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Phones get stacked cards: a nine-column table is unreadable at 390px. */}
        <div className="flex flex-col md:hidden">
          {groups.map((g) => (
            <div key={g.name} className="border-t p-4" style={{ borderColor: "var(--border)" }}>
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate font-medium" style={{ color: "var(--text-primary)" }}>{g.name}</span>
                <span className="shrink-0 text-xs" style={{ color: "var(--text-muted)" }}>
                  {dim === "territory" ? g.parent : `${g.territories} ${plural("territory", g.territories)}`}
                </span>
              </div>

              <div className="mt-3 flex flex-col gap-2">
                <MiniBar label="Sales" pct={g.pctSales} tone={SERIES_SALES} />
                <MiniBar label="Collections" pct={g.pctColl} tone={SERIES_COLL} />
                <MiniBar label="Builds" pct={g.pctBuild} tone="var(--text-secondary)" />
              </div>

              <dl className="mt-3 grid grid-cols-3 gap-2 text-xs">
                <Fact label="CSOs" value={fmtInt(g.csos)}
                  note={g.minCsos > 0 ? (g.minCsos - g.csos > 0 ? `${Math.round(g.minCsos - g.csos)} short` : "full") : ""}
                  bad={g.minCsos - g.csos > 0} />
                <Fact label="Masons" value={fmtInt(g.masons)}
                  note={g.minMasons > 0 ? (g.minMasons - g.masons > 0 ? `${Math.round(g.minMasons - g.masons)} short` : "full") : ""}
                  bad={g.minMasons - g.masons > 0} />
                <Fact label="Builds" value={fmtInt(g.builds)}
                  note={g.buildTarget > 0 ? `of ${fmtInt(Math.round(g.buildTarget))}` : ""} />
              </dl>
            </div>
          ))}
        </div>

        {groups.length === 0 && (
          <p className="p-8 text-center text-sm" style={{ color: "var(--text-muted)" }}>No CSO activity for this month.</p>
        )}
      </section>

      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        A CSO counts as active in a month if they sold or collected. Collected means the customer crossed the payment gate: 50% for floors, 100% for plaster and paint. Sales and collections in a month are not the same contracts, so the two columns are not a conversion rate. Targets come from the territory bonus targets and are compared one month ahead, matching the capacity model. The current month is still in progress and will read low until it closes.
      </p>
    </div>
  );
}

function delta(now: number, before: number): string {
  if (before === 0) return "no prior month";
  const d = Math.round(((now - before) / before) * 100);
  return `${d > 0 ? "+" : ""}${d}%`;
}

/** Names the weakest link in the sell → collect → build chain. */
function readOut(sales: number | null, coll: number | null, build: number | null): string {
  const parts: [string, number][] = [];
  if (sales != null) parts.push(["selling", sales]);
  if (coll != null) parts.push(["collecting", coll]);
  if (build != null) parts.push(["building", build]);
  if (parts.length === 0) return "No target set for this month.";

  parts.sort((a, b) => a[1] - b[1]);
  const [name, low] = parts[0];
  const highest = parts[parts.length - 1][1];
  if (low >= 1) return "Every part of the chain is at target.";
  if (highest - low < 0.15) return "The whole chain is moving at the same pace.";
  return {
    selling: "Selling is the constraint here.",
    collecting: "Signing is ahead of collecting. Payments are the constraint.",
    building: "Customers are paying faster than masons can build.",
  }[name] ?? "";
}

/** Round ticks, so the axis never reads 65% or 131%. */
function axisFor(max: number): { yMax: number; ticks: number[] } {
  const yMax = Math.max(1.25, Math.ceil((max * 1.08) / 0.25) * 0.25);
  // Few, round gridlines. Six faint lines read as clutter, three read as structure.
  const step = yMax > 3 ? 1 : 0.5;
  const ticks: number[] = [];
  for (let t = 0; t <= yMax + 1e-9; t += step) ticks.push(Number(t.toFixed(2)));
  return { yMax, ticks };
}

/** Longitudinal view of both ratios against the standard. */
function Trend({ data, selected }: { data: { month: string; label: string; sales: number | null; coll: number | null }[]; selected: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const narrow = useNarrow();
  // Fewer points and a squarer box on a phone, so labels stay legible.
  const all = data.filter((d) => d.sales != null || d.coll != null);
  const pts = narrow ? all.slice(-5) : all;
  if (pts.length < 2) return null;

  const W = narrow ? 380 : 800;
  const H = narrow ? 250 : 224;
  const padL = narrow ? 40 : 46, padR = narrow ? 16 : 22, padT = 18, padB = narrow ? 34 : 36;
  const fs = narrow ? 13 : 10.5;
  const plotW = W - padL - padR, plotH = H - padT - padB;
  const { yMax, ticks } = axisFor(Math.max(...pts.flatMap((d) => [d.sales ?? 0, d.coll ?? 0])));
  const x = (i: number) => padL + (i * plotW) / (pts.length - 1);
  const y = (v: number) => padT + plotH * (1 - v / yMax);

  const line = (key: "sales" | "coll") =>
    pts.map((d, i) => (d[key] == null ? null : `${i === 0 || pts[i - 1][key] == null ? "M" : "L"}${x(i)},${y(d[key]!)}`))
      .filter(Boolean).join(" ");
  const area = (key: "sales" | "coll") => {
    const v = pts.map((d, i) => ({ i, val: d[key] })).filter((p) => p.val != null);
    if (v.length < 2) return "";
    return `M${x(v[0].i)},${y(v[0].val!)}` + v.slice(1).map((p) => `L${x(p.i)},${y(p.val!)}`).join("")
      + `L${x(v[v.length - 1].i)},${padT + plotH}L${x(v[0].i)},${padT + plotH}Z`;
  };

  const hv = hover != null ? pts[hover] : null;

  return (
    <section className="rounded-lg border p-5" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Longitudinal data</h2>
          <p className="mt-0.5 text-xs" style={{ color: "var(--text-muted)" }}>
            Productivity against the standard, month by month.
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <Key color={SERIES_SALES} label="Sales" />
          <Key color={SERIES_COLL} label="Collections" />
        </div>
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} className="mt-3 w-full" style={{ maxHeight: narrow ? 260 : 250, overflow: "visible" }} role="img"
        aria-label="Sales and collections productivity by month">
        <defs>
          <linearGradient id="csoSales" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_SALES} stopOpacity="0.16" />
            <stop offset="100%" stopColor={SERIES_SALES} stopOpacity="0" />
          </linearGradient>
          <linearGradient id="csoColl" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_COLL} stopOpacity="0.14" />
            <stop offset="100%" stopColor={SERIES_COLL} stopOpacity="0" />
          </linearGradient>
        </defs>

        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)}
              stroke="var(--border)" strokeWidth="1" opacity={t === 0 ? 0.9 : 0.45} />
            <text x={padL - 10} y={y(t) + 4} textAnchor="end" fontSize={fs} fill="var(--text-muted)">{Math.round(t * 100)}%</text>
          </g>
        ))}

        <line x1={padL} x2={W - padR} y1={y(1)} y2={y(1)} stroke="var(--text-secondary)" strokeWidth="1.25" strokeDasharray="4 5" opacity="0.75" />
        <text x={W - padR + 4} y={y(1) + 3.5} fontSize={fs} fill="var(--text-muted)">target</text>

        <path d={area("sales")} fill="url(#csoSales)" />
        <path d={area("coll")} fill="url(#csoColl)" />
        <path d={line("sales")} fill="none" stroke={SERIES_SALES} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />
        <path d={line("coll")} fill="none" stroke={SERIES_COLL} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />

        {hover != null && (
          <line x1={x(hover)} x2={x(hover)} y1={padT} y2={padT + plotH} stroke="var(--text-muted)" strokeWidth="1" opacity="0.35" />
        )}

        {pts.map((d, i) => {
          const on = hover === i || (hover == null && d.month === selected);
          return (
            <g key={d.month}>
              {d.sales != null && <circle cx={x(i)} cy={y(d.sales)} r={on ? 5 : 3} fill={SERIES_SALES} stroke="var(--surface)" strokeWidth="2" />}
              {d.coll != null && <circle cx={x(i)} cy={y(d.coll)} r={on ? 5 : 3} fill={SERIES_COLL} stroke="var(--surface)" strokeWidth="2" />}
              <text x={x(i)} y={H - 14} textAnchor="middle" fontSize={fs}
                fill={d.month === selected ? "var(--text-primary)" : "var(--text-muted)"}
                fontWeight={d.month === selected ? 600 : 400}>
                {d.label.slice(0, 3)}
              </text>
            </g>
          );
        })}

        {hv && (
          <g transform={`translate(${Math.min(Math.max(x(hover!) - 66, padL), W - padR - 132)}, ${padT + 2})`}>
            <rect width="132" height="52" rx="6" fill="var(--surface)" stroke="var(--border)" />
            <text x="10" y="17" fontSize="11" fontWeight="600" fill="var(--text-primary)">{hv.label}</text>
            <circle cx="14" cy="30" r="3.5" fill={SERIES_SALES} />
            <text x="24" y="34" fontSize="10.5" fill="var(--text-secondary)">Sales {pctText(hv.sales)}</text>
            <circle cx="14" cy="44" r="3.5" fill={SERIES_COLL} />
            <text x="24" y="48" fontSize="10.5" fill="var(--text-secondary)">Collections {pctText(hv.coll)}</text>
          </g>
        )}

        {pts.map((_, i) => (
          <rect key={i} x={x(i) - plotW / (pts.length * 2)} y={padT} width={plotW / pts.length} height={plotH}
            fill="transparent" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
        ))}
      </svg>
    </section>
  );
}

function Key({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5" style={{ color: "var(--text-muted)" }}>
      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />
      {label}
    </span>
  );
}

function Score({ label, pct, prev, tone, actual, standard, unit }: { label: string; pct: number | null; prev: number | null; tone: string; actual: number; standard: number; unit: Unit }) {
  const b = band(pct);
  const moved = pct != null && prev != null ? Math.round((pct - prev) * 100) : null;
  return (
    <div className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)", borderTop: `3px solid ${tone}` }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 flex items-baseline gap-2">
        <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</span>
        {moved != null && (
          <span className="text-xs font-medium" style={{ color: moved >= 0 ? "var(--good)" : "var(--critical)" }}>
            {moved > 0 ? "+" : ""}{moved} pts
          </span>
        )}
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <div className="h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: BAND_COLOR[b] }} />
      </div>
      <span className="mt-2 block text-xs" style={{ color: "var(--text-muted)" }}>
        {fmtInt(actual)} against a standard of {fmtInt(standard)} {unit === "contracts" ? "contracts" : "SQM-E"}
      </span>
      <span className="mt-0.5 block text-xs font-medium" style={{ color: BAND_COLOR[b] }}>{BAND_LABEL[b]}</span>
    </div>
  );
}

/** A count that means nothing on its own, shown against what it should have been. */
function Compare({ label, actual, expected, note }: { label: string; actual: number; expected: number; note: string }) {
  const pct = expected > 0 ? actual / expected : null;
  const gap = actual - expected;
  const b = band(pct);
  return (
    <div className="rounded-lg border p-4" style={{ background: "var(--surface)", borderColor: "var(--border)" }}>
      <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{label}</span>
      <div className="mt-1 flex items-baseline gap-1.5">
        <span className="text-3xl font-semibold" style={{ color: "var(--text-primary)" }}>{fmtInt(actual)}</span>
        <span className="text-sm" style={{ color: "var(--text-muted)" }}>of {fmtInt(expected)}</span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <div className="h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: BAND_COLOR[b] }} />
      </div>
      <span className="mt-2 block text-xs" style={{ color: gap < 0 ? "var(--critical)" : "var(--good)" }}>
        {gap === 0 ? "exactly at expectation" : gap > 0 ? `${fmtInt(gap)} above expectation` : `${fmtInt(Math.abs(gap))} short`}
      </span>
      <span className="mt-0.5 block text-xs" style={{ color: "var(--text-muted)" }}>{note}</span>
    </div>
  );
}

function MiniBar({ label, pct, tone }: { label: string; pct: number | null; tone: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-20 shrink-0 text-xs" style={{ color: "var(--text-muted)" }}>{label}</span>
      <span className="h-2 flex-1 overflow-hidden rounded-full" style={{ background: "var(--border)" }}>
        <span className="block h-full rounded-full" style={{ width: `${Math.min(100, (pct ?? 0) * 100)}%`, background: tone }} />
      </span>
      <span className="w-10 shrink-0 text-right text-xs font-medium tabular-nums" style={{ color: "var(--text-primary)" }}>{pctText(pct)}</span>
    </div>
  );
}

/** Actual headcount against the establishment, with the gap called out. */
function Headcount({ have, need }: { have: number; need: number }) {
  const short = Math.round(need - have);
  const tone = need <= 0 ? "var(--text-muted)" : short > 0 ? "var(--warning)" : "var(--good)";
  return (
    <>
      <span className="block tabular-nums" style={{ color: "var(--text-primary)" }}>{fmtInt(have)}</span>
      <span className="block text-xs tabular-nums" style={{ color: tone }}>
        {need <= 0 ? "no target" : short > 0 ? `${fmtInt(short)} short` : "full"}
      </span>
    </>
  );
}

/** Compact labelled figure for the mobile cards. */
function Fact({ label, value, note, bad }: { label: string; value: string; note?: string; bad?: boolean }) {
  return (
    <div>
      <dt style={{ color: "var(--text-muted)" }}>{label}</dt>
      <dd className="font-semibold tabular-nums" style={{ color: "var(--text-primary)" }}>{value}</dd>
      {note && <dd className="tabular-nums" style={{ color: bad ? "var(--warning)" : "var(--text-muted)" }}>{note}</dd>}
    </div>
  );
}

function Pct({ v }: { v: number | null }) {
  const b = band(v);
  return (
    <span className="rounded px-1.5 py-0.5 text-xs font-semibold tabular-nums"
      style={{ background: `color-mix(in srgb, ${BAND_COLOR[b]} 18%, transparent)`, color: "var(--text-primary)" }}>
      {pctText(v)}
    </span>
  );
}

function Th({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <th className={`px-3 py-2 font-medium ${right ? "text-right" : "text-left"}`}>{children}</th>;
}
function Td({ children, right }: { children: React.ReactNode; right?: boolean }) {
  return <td className={`px-3 py-2 ${right ? "text-right tabular-nums" : "text-left"}`}>{children}</td>;
}

function Toggle({ options, value, onChange }: { options: { key: string; label: string }[]; value: string; onChange: (k: string) => void }) {
  return (
    <div className="inline-flex rounded-md border p-0.5" style={{ borderColor: "var(--border)", background: "var(--surface)" }}>
      {options.map((o) => {
        const on = o.key === value;
        return (
          <button key={o.key} type="button" onClick={() => onChange(o.key)} className="rounded px-2.5 py-1 text-sm font-medium"
            style={{ background: on ? "var(--accent-strong)" : "transparent", color: on ? "#fff" : "var(--text-secondary)" }}>
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

function Select({ label, value, options, onChange, optionLabel }: { label: string; value: string; options: string[]; onChange: (v: string) => void; optionLabel?: (v: string) => string }) {
  return (
    <label className="flex w-full items-center gap-1.5 text-sm sm:w-auto" style={{ color: "var(--text-secondary)" }}>
      <span className="shrink-0" style={{ color: "var(--text-muted)" }}>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="min-h-11 w-full flex-1 rounded-md border px-2 py-1.5 text-sm sm:min-h-0 sm:w-auto"
        style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text-primary)" }}>
        {options.map((o) => <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>)}
      </select>
    </label>
  );
}
