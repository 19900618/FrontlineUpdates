import NextAuth, { customFetch } from "next-auth";
import Google from "next-auth/providers/google";

/**
 * Company login (Auth.js v5), locked to a single Google Workspace domain.
 *
 * IMPORTANT: auth is OPT-IN. Until GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET are
 * set, `authConfigured` is false and the app skips the login gate entirely — so
 * local development shows data without needing OAuth. The gate turns on
 * automatically once those env vars exist (i.e. on the deployed site).
 */
const ALLOWED_DOMAIN = process.env.ALLOWED_EMAIL_DOMAIN ?? "earthenable.org";

export const authConfigured = Boolean(
  process.env.GOOGLE_CLIENT_ID &&
    process.env.GOOGLE_CLIENT_SECRET &&
    process.env.NEXTAUTH_SECRET,
);

export const { handlers, auth, signIn, signOut } = NextAuth({
  trustHost: true,
  // Surface auth failures in the Vercel runtime logs. Auth.js shows users a
  // generic "Configuration" page for every callback failure, so without this the
  // real cause is invisible.
  logger: {
    error(err: unknown) {
      const e = err as { name?: string; message?: string; cause?: unknown };
      console.error("[auth]", e?.name ?? "Error", e?.message ?? String(err), e?.cause ?? "");
    },
    warn() {},
    debug() {},
  },
  secret: process.env.NEXTAUTH_SECRET,
  // Re-login required after 8 hours (a work day); the account chooser shows each
  // time so it's a deliberate sign-in, not silent SSO.
  session: { maxAge: 60 * 60 * 8 },
  providers: [
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
      authorization: { params: { prompt: "select_account" } },
      // Google's OIDC discovery document advertises
      // `authorization_response_iss_parameter_supported: true` (RFC 9207), but
      // Google does not actually return an `iss` parameter on the callback.
      // oauth4webapi therefore rejects EVERY login with
      // `OAUTH_INVALID_RESPONSE: response parameter "iss" (issuer) missing`,
      // which Auth.js surfaces as the generic "Configuration" error page.
      // Nothing on our side changed; Google flipped that flag.
      // We keep discovery (so jwks and endpoints stay correct) and drop only
      // that one claim. Remove this once Google returns `iss`, or once
      // next-auth ships a fix.
      [customFetch]: async (input: RequestInfo | URL, init?: RequestInit) => {
        const href =
          typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
        const response = await fetch(input as RequestInfo, init);
        if (!href.includes("/.well-known/openid-configuration")) return response;
        const metadata = (await response.clone().json()) as Record<string, unknown>;
        delete metadata.authorization_response_iss_parameter_supported;
        return Response.json(metadata, {
          status: response.status,
          headers: { "content-type": "application/json" },
        });
      },
    }),
  ],
  pages: { signIn: "/signin" },
  callbacks: {
    // Only allow @earthenable.org accounts. Google sets the `hd` (hosted
    // domain) claim for Workspace accounts; we check both it and the address.
    async signIn({ profile }) {
      const email = (profile?.email ?? "").toLowerCase();
      const hd = (profile as { hd?: string } | undefined)?.hd;
      return email.endsWith(`@${ALLOWED_DOMAIN}`) || hd === ALLOWED_DOMAIN;
    },
  },
});
